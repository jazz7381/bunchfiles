<?php
require_once(ADNI_TPL_DIR.'/frontend_manager/header.php');

    echo ADNI_Frontend::content();

require_once(ADNI_TPL_DIR.'/frontend_manager/footer.php');
?>