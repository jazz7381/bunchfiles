import '../css/_ning.css';
import '../css/_ning_sell.css';
import '../../packages/modaljs/index.bundle.js.css';
import '../../packages/cornerpeel/cornerpeel.css';
import '../../packages/bg_takeover/bg_takeover.css';

import './_ning.js';
import './jQuery.adnplugins.js';
import './jssor.slider.min.js';
import '../../packages/modaljs/index.bundle.js';
import '../../packages/cornerpeel/cornerpeel.js';
import '../../packages/bg_takeover/bg_takeover.js';
import './ga_tracking.js';