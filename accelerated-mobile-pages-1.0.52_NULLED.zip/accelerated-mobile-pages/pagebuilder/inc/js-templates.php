<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;
/*
 * Module Template
 */
global $moduleTemplate;
include_once AMP_PAGE_BUILDER . '/components/modulesHtmlTemplate.php';
include_once AMP_PAGE_BUILDER . '/components/fieldsTemplate.php';
include_once AMP_PAGE_BUILDER . '/components/modulePopupTemplate.php';
include_once AMP_PAGE_BUILDER . '/components/pbSettingTemplates.php';
?>