<?php
/**
 * Callback for new param 'penci_separator'.
 *
 * @param array $settings
 * @param string $value
 *
 * @return string
 */
function penci_vc_param_separator( $settings, $value ) {
	return '<hr>';
}

