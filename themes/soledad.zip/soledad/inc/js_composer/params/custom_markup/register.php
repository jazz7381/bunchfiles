<?php
/**
 * Callback for new param 'penci_separator'.
 *
 * @param array $settings
 * @param string $value
 *
 * @return string
 */
function penci_vc_param_custom_markup( $settings, $value ) {
	return $value;
}

