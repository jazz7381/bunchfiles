<?php
namespace PenciSoledadElementor\Modules\PenciFeaturedSliders;

use PenciSoledadElementor\Base\Module_Base;

class Module extends Module_Base {

	public function get_name() {
		return 'penci-featured-sliders';
	}

	public function get_widgets() {
		return array( 'PenciFeaturedSliders' );
	}
}
