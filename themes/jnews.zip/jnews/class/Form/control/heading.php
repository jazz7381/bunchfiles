<div class="widget-wrapper type-heading" data-field="<?php echo esc_attr($fieldkey) ?>">
    <div class="widget-heading">
        <h2><?php echo esc_html($title); ?></h2>
    </div>
</div>