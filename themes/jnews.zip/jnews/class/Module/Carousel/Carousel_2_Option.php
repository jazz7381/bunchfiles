<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Carousel;

Class Carousel_2_Option extends CarouselOptionAbstract
{
    public function get_module_name()
    {
        return esc_html__('JNews - Carousel 2', 'jnews');
    }
}
