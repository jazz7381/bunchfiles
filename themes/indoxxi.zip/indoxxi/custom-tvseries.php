<?php
/*
Template Name: TV-Series Page
*/
get_header(); ?>
<div id="main" class="page-category" style="padding-top:70px;">
        <div class="container">
            <div class="main-content" style="min-height:80vh">
                <div class="modal" id="pop-trailer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none;">
                    <div class="modal-dialog" style="margin-top:66px;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                <h4 class="modal-title" id="myModalLabel"></h4></div>
                            <div class="modal-body">
                                <div class="modal-body-trailer">
                                    <iframe id="iframe-trailer" width="100%" height="380" src="" frameborder="0" allowfullscreen=""></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="extend" style="margin-top:1em;text-align:center;">
				 <?php get_template_part('includes/ads'); ?>
				</div>
<?php $active = get_option('modleter'); if ($active == "true") { ?>
<div class="extend">
<div class="ml-announce" style="margin-top:1em;text-align:center;">
<ul class="pagination">
<li><a <?php echo $s == '09' ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>">#</a><li>
	<?php for ($l="a";$l!="aa";$l++){?>
	<li><a <?php echo $s == "$l" ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>"><?php echo strtoupper($l); ?></a><li>
	<?php } ?>
</ul>
<div class="clearfix"></div>
</div>
<div class="items_glossary"></div>					
</div>
<?php }?>
                <div class="movies-list-wrap mlw-topview mt20">
				<?php get_template_part('includes/mobile-menu'); ?>
<?php $active = get_option('movsmodule'); if ($active == "true") { ?>
                    <div class="ml-title"><span class="pull-left"><?php if($title = get_option('latestmov_title2')){ echo $title; } else { echo 'Series Barat'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="/series/" id="lihatutama" class="pull-right cat-more"><?php _e('View More', 'indoxxi'); ?></a>
                        <ul role="tablist" class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" id="ongoing-movie" role="tab" href="#ongoing" aria-expanded="false">Ongoing</a></li>
                            <li><a onclick="getContent('rekomendasi')" data-toggle="tab" id="movies-rekomendasi" role="tab" href="#tvseries-rekomendasi" aria-expanded="false"><?php $title = get_option('mtb2_titlee'); echo $title;?>Rekomendasi</a></li>
                            <li><a onclick="getContent('topseries')" data-toggle="tab" id="movies-topseries" role="tab" href="#tvseries-topseries" aria-expanded="false"><?php $title = get_option('mtb3_titlee'); echo $title;?>Top Series</a></li>
                            <li><a onclick="getContent('animation')" data-toggle="tab" id="movies-animation" role="tab" href="#tvseries-animation" aria-expanded="false"><?php $title = get_option('mtb4_titlee'); echo $title;?>Animation</a></li>
                            <li><a onclick="getContent('actionadventures')" data-toggle="tab" id="movies-actionadventures" role="tab" href="#tvseries-actionadventures" aria-expanded="false"><?php $title = get_option('mtb5_titlee'); echo $title;?>Action-Adventure</a></li>
                            <li><a onclick="getContent('completed')" data-toggle="tab" id="movies-completed" role="tab" href="#tvseries-completed" aria-expanded="false"><?php $title = get_option('mtb6_titlee'); echo $title;?>Completed</a></li>
                        </ul>
                    </div>
<div class="tab-content">
<div id="ongoing" class="movies-list movies-list-full tab-pane in fade active">
<?php 
$suggnum = get_option('archive_posts');
$numerado = 1; { query_posts(
array('posts_per_page' => $suggnum,
    'post_type' => array('tvshows'),
    'tax_query' => array(
        array(
          'taxonomy' => 'film',
          'field' => 'slug',
          'terms' => array( 'ongoing', ),
        )
      )));
while ( have_posts() ) : the_post(); 
$imdbRating = get_post_meta($post->ID, "imdbRating", $single = true); 
if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
$imgsrc = wp_get_attachment_image_src($postimage->ID, 'full');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = info_movie_get_meta('poster_url')){
$imgsrc = $img;
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
}
$dt_player	= get_post_meta($post->ID, 'repeatable_fields', true);
?>
<div data-movie-id="<?php the_id(); ?>" class="ml-item">
    <a href="<?php the_permalink() ?>" data-url="" class="ml-mask jt" title="<?php the_title(); ?>">
        <div class="mli-eps">Eps <br><span><?php echo $values = info_movie_get_meta("number_of_episodes") ?></span></div>
        <div class="rating-durasi"><span class="mli-rating"><i class="fa fa-star mr5"></i><?php echo $values = info_movie_get_meta("serie_vote_average") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $values = info_movie_get_meta("episode_run_time") ?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div>
        <img class="lazy thumb mli-thumb" alt="<?php the_title(); ?>" src="<?php echo $imgsrc; $imgsrc = ''; ?>" style="display: inline-block;"><span class="mli-info"><h2><?php the_title(); ?></h2></span></a>
</div><?php $numerado++; ?>
<?php  endwhile; ?>	
</div>
<div id="tvseries-ongoing" class="movies-list movies-list-full tab-pane in fade active"></div>
<div id="tvseries-rekomendasi" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="tvseries-topseries" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="tvseries-animation" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="tvseries-actionadventures" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="tvseries-completed" class="movies-list movies-list-full tab-pane in fade"></div>
</div>
<?php }?>
</div>
                <div class="extend" style="margin-top:1em;text-align:center;">
                    <?php get_template_part('includes/ads2'); ?>
                </div>
<?php $active = get_option('tvmodule'); if ($active == "true") { ?>
                <div class="movies-list-wrap mlw-latestmovie">
                    <div class="ml-title"><span class="pull-left"><?php if($title = get_option('latesttv_titlee')){ echo $title; } else { echo 'Drama Series'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="<?php bloginfo('url'); ?>/series/" id="lihatrekomen" class="pull-right cat-more"><?php _e('View More', 'indoxxi'); ?> </a>
                        <ul role="tablist" class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" id="serial-ongoingkorea" role="tab" href="#tvseries-ongoingkorea" aria-expanded="false">Ongoing</a></li>
                            <li><a onclick="getContent('drakors')" data-toggle="tab" id="serial-drakors" role="tab" href="#tvseries-drakors" aria-expanded="false"><?php $title = get_option('stb2_titlee'); echo $title;?>Drakor</a></li>
                            <li><a onclick="getContent('dorama')" data-toggle="tab" id="serial-dorama" role="tab" href="#tvseries-dorama" aria-expanded="false"><?php $title = get_option('stb3_titlee'); echo $title;?>Dorama</a></li>
                            <li><a onclick="getContent('recommendedkorea')" data-toggle="tab" id="serial-recommendedkorea" role="tab" href="#tvseries-recommendedkorea" aria-expanded="false"><?php $title = get_option('stb4_titlee'); echo $title;?>Recommended</a></li>
                            <li><a onclick="getContent('asia')" data-toggle="tab" id="serial-asia" role="tab" href="#tvseries-asia" aria-expanded="false"><?php $title = get_option('stb5_titlee'); echo $title;?>Asia</a></li>
                            <li><a onclick="getContent('komplit')" data-toggle="tab" id="serial-komplit" role="tab" href="#tvseries-komplit" aria-expanded="false"><?php $title = get_option('stb6_titlee'); echo $title;?>Completed</a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
<div class="tab-content">
<div id="tvseries-ongoingkorea" class="movies-list movies-list-full tab-pane in fade active">
<?php 
$suggnum = get_option('archive_posts');
$numerado = 1; { query_posts(
array('posts_per_page' => $suggnum,
    'post_type' => array('tvshows'),
    'tax_query' => array(
        array(
          'taxonomy' => 'film',
          'field' => 'slug',
          'terms' => array( 'ongoingkorea', ),
        )
      )));
while ( have_posts() ) : the_post(); 
$imdbRating = get_post_meta($post->ID, "imdbRating", $single = true); 
if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
$imgsrc = wp_get_attachment_image_src($postimage->ID, 'full');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = info_movie_get_meta('poster_url')){
$imgsrc = $img;
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
}
$dt_player	= get_post_meta($post->ID, 'repeatable_fields', true);
?>
<div data-movie-id="<?php the_id(); ?>" class="ml-item">
    <a href="<?php the_permalink() ?>" data-url="" class="ml-mask jt" title="<?php the_title(); ?>">
        <div class="mli-eps">Eps <br><span><?php echo $values = info_movie_get_meta("number_of_episodes") ?></span></div>
        <div class="rating-durasi"><span class="mli-rating"><i class="fa fa-star mr5"></i><?php echo $values = info_movie_get_meta("serie_vote_average") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $values = info_movie_get_meta("episode_run_time") ?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div>
        <img class="lazy thumb mli-thumb" alt="<?php the_title(); ?>" src="<?php echo $imgsrc; $imgsrc = ''; ?>" style="display: inline-block;"><span class="mli-info"><h2><?php the_title(); ?></h2></span></a>
</div><?php $numerado++; ?>
<?php  endwhile; ?>
</div>
                        <div id="tvseries-ongoingkorea" class="movies-list movies-list-full tab-pane in fade active"></div>
                        <div id="tvseries-drakors" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="tvseries-dorama" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="tvseries-recommendedkorea" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="tvseries-asia" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="tvseries-komplit" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div class="clearfix"></div>
                </div>
<?php } ?>
                <div class="ml-announce">
					<?php get_template_part('includes/funciones/announce'); ?>
                </div>
            </div>
        </div>
	</div>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
                $("img.lazy").lazyload({
                    skip_invisible: true,
                    effect: "fadeIn",
                    event: "movie"
                });
                $(window).bind("load", function() {
                    var timeout = setTimeout(function() {
                        $("img.lazy").trigger("movie")
                    }, 50);
                });
            });

function getContent(e) {
   $.ajax({
     type: "GET",
     url: "<?php echo get_template_directory_uri(); ?>/ajax-tvseries-" + e + ".php",
     success: function(data) {
     $("#tvseries-"  + e).html(data);
    }
   });
}
</script>
<?php } ?>
<?php } ?>
<?php  get_footer(); ?>