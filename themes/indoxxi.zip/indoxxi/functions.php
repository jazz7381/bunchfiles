<?php
define('DT_THEME_NAME', 'Indoxxi');
define('DT_THEME_SLUG', 'indoxxi');
define('FIX_MSG', '_transient_indoxxi');
define('DT_KEY', DT_THEME_SLUG . '_valid_key_status');
define('DT_MSG', FIX_MSG . '_license_message');
define('DT_KEY_S', DT_THEME_SLUG . '_valid_key');
define('DT_VERSION', '1.0.7');
define	('tmdburl','https://api.themoviedb.org/3/');
define	('tmdbkey', get_option('tmdbkey', '6b4357c41d9c606e4d7ebe2f4a8850ea'));
define	('tmdblang', get_option('tmdbidioma', 'en-US'));
define('DT_DIR_URI', get_template_directory_uri());
define('DT_DIR', get_template_directory());



/* Insert Genres
-------------------------------------------------------------------------------
*/
function insert_genres( $post_id , $type ) {
	$permit = get_option('apigenero');
	$title = $_POST['ids'];
	$term = get_the_term_list( $post_id, 'category' );
	if( $permit == 'true' ) {
		if( $term == false ) {
			$json = dt_http_api( tmdburl. $type. "/" . $title . "?language=" . tmdblang . "&api_key=" . tmdbkey );
			$data = json_decode($json, TRUE);
			$genres = $data['genres'];
			$generos = array();
			foreach($genres as $dat) {
				$generos[] = $dat['name'];
			}
			wp_set_object_terms( $post_id, $generos, 'category', false);
		}
	}
}

function _d( $text ){
	echo translate($text , 'indoxxi');
}
add_option( 'my_dbmovieslive', 'movieslive' );
/* Return Translated Text
-------------------------------------------------------------------------------
*/
function __d( $text ) {
    return translate($text, 'indoxxi');
}
function dt_http_api( $api ) {
	$url = wp_remote_retrieve_body( wp_remote_get( $api ) );
	return $url; 
}
function dbmupdate($data) {
	$option = get_option("wp_app_dbmkey");
	return $option[$data];
}
function prefix_theme_updater() {
	require( get_template_directory() . '/updater/theme-updater.php' );
}
add_action( 'after_setup_theme', 'prefix_theme_updater' );
add_action('admin_menu', 'add_indoxxi_options_menu');
 function add_indoxxi_options_menu() {
    add_theme_page('Indoxxi Options', 'Indoxxi Options', 'manage_options', 'indoxxi');
 }
function star_rating() {?>
<div id="movie-mark" class="btn btn-danger averagerate"><?php if($noners = get_post_meta( get_the_ID(), 'ratings_average', true ) ) { echo $noners; ?><?php } else { echo '0' ?><?php }?></div>
<label id="movie-rating">Rating <?php if($noners = get_post_meta( get_the_ID(), 'ratings_users', true ) ) { ?>(<?php echo $noners; ?>)<?php } else { ?>(0)<?php }?></label>
<?php if(function_exists('the_ratings')) { the_ratings(); } ?>
<?php }
 function custom_rating_image_extension() {
    return 'png';
}
add_filter( 'wp_postratings_image_extension', 'custom_rating_image_extension' );
require get_template_directory() . '/ajax/ajax-login-register.php';
require_once dirname( __FILE__ ) . '/tgm-init.php';

add_action( 'tgmpa_register', 'my_theme_register_required_plugins' );

function my_theme_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
		'name'               => 'WP-PostRatings Plugin', // The plugin name.
			'slug'               => 'wp-postratings', // The plugin slug (typically the folder name).
			'source'             => get_stylesheet_directory() . '/includes/plugins/wp-postratings.zip', // The plugin source.
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '1.84', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),
		array(
			'name'               => 'WP-Postviews Plugin', // The plugin name.
			'slug'               => 'wp-postviews', // The plugin slug (typically the folder name).
			'source'             => get_stylesheet_directory() . '/includes/plugins/wp-postviews.zip', // The plugin source.
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),
		$config = array(
		'id'           => 'tgmpa',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => false,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => true,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.
		),
);

	tgmpa( $plugins, $config );
}
function movies_breadcrumbs() { ?>
<div id="bread">
<ol class="breadcrumb">
<li><a href="<?php bloginfo('url'); ?>"><?php _e('Home', 'indoxxi'); ?></a></li>
<li itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="<?php echo get_option('mov_archive');?>"><span itemprop="title"><?php _e('Movies', 'indoxxi'); ?></span></a></li>
<li class="active"><h1 style="font-size:medium;display:inline;"> <?php the_title(); ?></h1></li>
</ol>
</div>
<?php }
function series_breadcrumbs() { ?>
<div id="bread">
<ol class="breadcrumb">
<li><a href="<?php bloginfo('url'); ?>"><?php _e('Home', 'indoxxi'); ?></a></li>
<li itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="<?php echo get_option('series_archive');?>"><span itemprop="title"><?php _e('Series', 'indoxxi'); ?></span></a></li>
<li class="active"><h1 style="font-size:medium;display:inline;"> <?php the_title(); ?></h1></li>
</ol>
</div>
<?php }

function register_my_menu() {
register_nav_menu('menu_navegador',__( 'Menu Header', 'indoxxi' ));
register_nav_menu('menu_footer1',__( 'Footer Menu 1', 'indoxxi' ));
register_nav_menu('menu_footer2',__( 'Footer Menu 2', 'indoxxi' ));
register_nav_menu('menu_footer3',__( 'Footer Menu 3', 'indoxxi' ));
register_nav_menu('menu_footer4',__( 'Footer Menu 4', 'indoxxi' ));
register_nav_menu('menu_footer5',__( 'Footer Menu 5', 'indoxxi' ));
register_nav_menu('menu_footer6',__( 'Footer Menu 6', 'indoxxi' ));
}
add_action( 'init', 'register_my_menu' );
add_action('after_switch_theme', 'theme_activation_function', 10 ,  2);

function theme_activation_function ($oldname, $oldtheme = false) {
  $menus = array(
    'Main Menu'  => array(
      'home'  => 'Home', 
      'genre'  => 'Genre', 
      'tv-series'  => 'TV - Series', 
      'top-imdb'  => 'Top IMDb', 
    ), 
  'Footer Menu 1' => array(
    'movies' => 'Movies', 
    'top-imdb' => 'Top IMDb', 
    'dmca' => 'DMCA',
	'faq' => 'FAQ',
	'advertising' => 'Advertising'
  ),
    'Footer Menu 2' => array(
    'action' => 'Action', 
    'history' => 'History', 
    'thriller' => 'Thriller'
  ),
  'Footer Menu 3' => array(
    'action' => 'Action', 
    'history' => 'History', 
    'thriller' => 'Thriller'
  ),
  'Footer Menu 4' => array(
    'action' => 'Action', 
    'history' => 'History', 
    'thriller' => 'Thriller'
  ),
  'Footer Menu 5' => array(
    'action' => 'Action', 
    'history' => 'History', 
    'thriller' => 'Thriller'
  ),
  'Footer Menu 6' => array(
    'united-states' => 'United States', 
    'korea' => 'Korea', 
    'china' => 'China',
	'taiwan' => 'Taiwan'
  )
);
foreach($menus as $menuname => $menuitems) {
  $menu_exists = wp_get_nav_menu_object($menuname);
  // If it doesn't exist, let's create it.
  if ( !$menu_exists) {
    $menu_id = wp_create_nav_menu($menuname);
    foreach($menuitems as $slug => $item) {
      wp_update_nav_menu_item(
      $menu_id, 0, array(
            'menu-item-title'  => $item,
			'menu-item-url'     => '', 
			'menu-item-status'  => 'publish'
        )
      );
    }
  }
}

}

add_filter( 'show_admin_bar', '__return_false' );
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
if (!is_admin()) {
            wp_deregister_script('jquery');                                     // De-Register jQuery
            wp_register_script('jquery', '', '', '', true);                     // Register as 'empty', because we manually insert our script in header.php
        }
remove_action('wp_head', 'rest_output_link_wp_head', 10);
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'rsd_link');
function imagenes_size() {
add_theme_support( 'post-thumbnails' );
add_image_size('newss', 350, 210, true);
}
function backdrops($imagen){
	$val = str_replace(array("http","jpg","png","gif"),array('<div class="galeria_img"><img itemprop="image" src="http','jpg" alt="'.get_the_title().'" /></div>','png" /></div>','gif" /></div>'),$imagen);
	echo $val;	
}
function fbimage($img){
	$val = str_replace(array("http","jpg","png","gif"),array('<meta property="og:image" content="http','jpg" />','png" />','gif" />'),$img);
	echo $val;	
}


function insert_attachment($file_handler,$post_id,$setthumb='false') {
if ($_FILES[$file_handler]['error'] !== UPLOAD_ERR_OK){ return __return_false(); 
} 
require_once(ABSPATH . "wp-admin" . '/includes/image.php');
require_once(ABSPATH . "wp-admin" . '/includes/file.php');
require_once(ABSPATH . "wp-admin" . '/includes/media.php');
echo $attach_id = media_handle_upload( $file_handler, $post_id );
if ($setthumb == 1) update_post_meta($post_id,'_thumbnail_id',$attach_id);
return $attach_id;
}
include_once 'includes/framework/options-init.php';
$year_estreno = 'release-year';
$calidad = 'quality';
$director = 'director';
$actor = get_option('actor');
$elenco = get_option('elenco');
$relmovie = get_option('related-movie');
$reltv = get_option('related-tv');
$suggnum = get_option('sugg_num');
$lmvnum = get_option('latestmov_num');
$ltvnum = get_option('latesttv_num');
$mvpostpage = get_option('mv-posts-page');
$tvpostpage = get_option('tv-posts-page');
# Fix URL Imagen del poser
$imagefix = "poster_url";
$featuredimg_alt = "fondo_player";
##########################
add_action('after_setup_theme', 'imagenes_size'); 

if (get_option('posts_per_page') < get_option ('archive_posts') ) {
	$num = get_option('archive_posts');
	update_option('posts_per_page', $num);
}
function recoger_version() {
$version = wp_get_theme();
define('version', trim($version->Version));
echo version;
}

add_filter('posts_search', 'search_title'); 
function search_title($search) { 
	preg_match('/title-([^%]+)/', $search, $m); 
	if (isset($m[1])) { 
		global $wpdb;
		if($m[1] == '09') return " AND $wpdb->posts.post_title REGEXP '^[0-9]' AND ($wpdb->posts.post_password = '') "; 
		return " AND $wpdb->posts.post_title LIKE '$m[1]%' AND ($wpdb->posts.post_password = '') "; 
	} else { 
		return $search; 
	} 
}


if(is_admin() and current_user_can('administrator')){
	// Top IMDb Page
	$page_topimdb = get_option('topimdb_archive');
	if(empty($page_topimdb)){
		$post_id = wp_insert_post(array(
		  'post_content'   => '',
		  'post_name'      => __('Top IMDb','mtms'),
		  'post_title'     => __('Top IMDb','mtms'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'top_imdb.php'
		)); 
		$get_01 = get_option('siteurl').'/' . sanitize_title(__('Top IMDb','mtms')).'/';
		update_option('topimdb_archive', $get_01);
	}
		// Most Rating Page
	$page_mostrating = get_option('mrat_archive');
	if(empty($page_mostrating)){
		$post_id = wp_insert_post(array(
		  'post_content'   => '',
		  'post_name'      => __('Most Rating','mtms'),
		  'post_title'     => __('Most Rating','mtms'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'top_ratings.php'
		)); 
		$get_02 = get_option('siteurl').'/' . sanitize_title(__('Most Rating','mtms')).'/';
		update_option('mrat_archive', $get_02);
	}
		// Most Favorite Page
	$page_mostfavorite = get_option('mfav_archive');
	if(empty($page_mostfavorite)){
		$post_id = wp_insert_post(array(
		  'post_content'   => '',
		  'post_name'      => __('Most Favorites','mtms'),
		  'post_title'     => __('Most Favorites','mtms'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'top_favorites.php'
		)); 
		$get_03 = get_option('siteurl').'/' . sanitize_title(__('Most Favorites','mtms')).'/';
		update_option('mfav_archive', $get_03);
	}
	
			// Most Viewed Page
	$page_mostviewed = get_option('mviewed_archive');
	if(empty($page_mostviewed)){
		$post_id = wp_insert_post(array(
		  'post_content'   => '',
		  'post_name'      => __('Most Viewed','mtms'),
		  'post_title'     => __('Most Viewed','mtms'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'top_views.php'
		)); 
		$get_04 = get_option('siteurl').'/' . sanitize_title(__('Most Viewed','mtms')).'/';
		update_option('mviewed_archive', $get_04);
	}
	
				// Movies Page
	$page_movies = get_option('mov_archive');
	if(empty($page_movies)){
		$post_id = wp_insert_post(array(
		  'post_content'   => '',
		  'post_name'      => __('Movies','mtms'),
		  'post_title'     => __('Movies','mtms'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'archive-movies.php'
		)); 
		$get_05 = get_option('siteurl').'/' . sanitize_title(__('Movies','mtms')).'/';
		update_option('mov_archive', $get_05);
	}
	
				// Account Page
	$page_account = get_option('account_page');
	if(empty($page_account)){
		$post_id = wp_insert_post(array(
		  'post_content'   => '',
		  'post_name'      => __('Account','mtms'),
		  'post_title'     => __('Account','mtms'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'pages/account.php'
		)); 
		$get_06 = get_option('siteurl').'/' . sanitize_title(__('Account','mtms')).'/';
		update_option('account_page', $get_06);
	}
	
	
					// Keywords Page
	$page_series = get_option('series_archive');
	if(empty($page_series)){
		$post_id = wp_insert_post(array(
		  'post_content'   => '',
		  'post_name'      => __('Series','mtms'),
		  'post_title'     => __('Series','mtms'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'archive-tvshows.php'
		)); 
		$get_07 = get_option('siteurl').'/' . sanitize_title(__('Series','mtms')).'/';
		update_option('series_archive', $get_07);
	}
	// JWPlayer page
	$page_jwplayer = get_option('dt_jwplayer_page');
	if(empty($page_jwplayer)){
		$post_id = wp_insert_post(array(		
		  'post_content'   => '',
		  'post_name'      => __d('player'),
		  'post_title'     => __d('JW Player'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'jwplayer.php'
		));
		$get_posts_page = get_option('siteurl').'/' . sanitize_title('player').'/';
		update_option('dt_jwplayer_page', $get_posts_page);
	}
	// JWPlayer page
	$page_gdrive = get_option('drive_page');
	if(empty($page_gdrive)){
		$post_id = wp_insert_post(array(		
		  'post_content'   => '',
		  'post_name'      => __d('gdrive'),
		  'post_title'     => __d('JW Player Drive'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'drive/index2.php'
		));
		$get_posts_page1 = get_option('siteurl').'/' . sanitize_title('gdrive').'/';
		update_option('drive_page', $get_posts_page1);
	}
	// JWPlayer page
	$page_iframembed = get_option('embed_page');
	if(empty($page_iframembed)){
		$post_id = wp_insert_post(array(		
		  'post_content'   => '',
		  'post_name'      => __d('iembed'),
		  'post_title'     => __d('Iframe Embed'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'iframe-embed.php'
		));
		$get_posts_page2 = get_option('siteurl').'/' . sanitize_title('iembed').'/';
		update_option('embed_page', $get_posts_page2);
	}
	// page DMCA
	$page_dmca = get_option('dmca_page');
	if(empty($page_dmca)){
		$post_id = wp_insert_post(array(		
		  'post_content'   => '',
		  'post_name'      => __d('dmca'),
		  'post_title'     => __d('DMCA'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'page-dmca.php'
		));
		$get_posts_dmca = get_option('siteurl').'/' . sanitize_title('dmca').'/';
		update_option('dmca_page', $get_posts_dmca);
	}
	// page faq
	$page_faq = get_option('faq_page');
	if(empty($page_faq)){
		$post_id = wp_insert_post(array(		
		  'post_content'   => '',
		  'post_name'      => __d('faq'),
		  'post_title'     => __d('Faq'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'page-faq.php'
		));
		$get_posts_faq = get_option('siteurl').'/' . sanitize_title('faq').'/';
		update_option('faq_page', $get_posts_faq);
	}
	// page faq
	$page_privacy = get_option('privacy_page');
	if(empty($page_privacy)){
		$post_id = wp_insert_post(array(		
		  'post_content'   => '',
		  'post_name'      => __d('privacy'),
		  'post_title'     => __d('privacy'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'page-privacy.php'
		));
		$get_posts_privacy = get_option('siteurl').'/' . sanitize_title('privacy').'/';
		update_option('privacy_page', $get_posts_privacy);
	}
	$page_openloadembed = get_option('openloadembed');
	if(empty($page_openloadembed)){
		$post_id = wp_insert_post(array(		
		  'post_content'   => '',
		  'post_name'      => __d('openloadembed'),
		  'post_title'     => __d('openloadembed'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'openload-embed.php'
		));
		$get_posts_openloadembed = get_option('siteurl').'/' . sanitize_title('openloadembed').'/';
		update_option('openloadembed', $get_posts_openloadembed);
	}
	$page_stremagoembed = get_option('stremagoembed');
	if(empty($page_openloadembed)){
		$post_id = wp_insert_post(array(		
		  'post_content'   => '',
		  'post_name'      => __d('stremagoembed'),
		  'post_title'     => __d('stremagoembed'),
		  'post_status'    => 'publish',
		  'post_type'      => 'page',
		  'ping_status'    => 'closed',
		  'post_date'      => date('Y-m-d H:i:s'),
		  'post_date_gmt'  => date('Y-m-d H:i:s'),
		  'comment_status' => 'closed',
		  'page_template'  => 'streamango-embed.php'
		));
		$get_posts_stremagoembed = get_option('siteurl').'/' . sanitize_title('stremagoembed').'/';
		update_option('stremagoembed', $get_posts_stremagoembed);
	}

	// JW Player Access KEY
	$jwplayer_key = get_option('dt_jw_key');
	if ( empty($jwplayer_key) ) {
		update_option('dt_jw_key', 'IMtAJf5X9E17C1gol8B45QJL5vWOCxYUDyznpA==');
	}
}

function meta_image() {?>
<meta property="og:image:width" content="300"/>
<meta property="og:image:height" content="425"/>
<meta property="og:image:type" content="image/jpeg"/>
<?php }
# Filtrar resultados de busqueda.
function fb_search_filter($query) {
if ( !$query->is_admin && $query->is_search) {
$query->set('post_type', array('post','tvshows') ); 
} return $query; }
add_filter( 'pre_get_posts', 'fb_search_filter' );

function la_ip() {
	/* obtener ip local */
	if (!empty($_SERVER['HTTP_CLIENT_IP']))
		return $_SERVER['HTTP_CLIENT_IP'];	
	if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
		return $_SERVER['HTTP_X_FORWARDED_FOR'];
	return $_SERVER['REMOTE_ADDR'];
}

function mget_the_term_list( $id, $taxonomy, $before = '', $sep = '', $after = '' ) {
	$terms = get_the_terms( $id, $taxonomy );
	if ( is_wp_error( $terms ) )
		return $terms;
	if ( empty( $terms ) )
		return false;
	foreach ( $terms as $term ) {
		$link = get_term_link( $term, $taxonomy );
		if ( is_wp_error( $link ) )
			return $link;
		$term_links[] = '<a href="' . esc_url( $link ) . '" rel="tag"><span itemprop="genre">' . $term->name . '</span></a>';
	}
$term_links = apply_filters( "term_links-$taxonomy", $term_links );
	return $before . join( $sep, $term_links ) . $after;
}
function castget_the_term_list( $id, $taxonomy, $before = '', $sep = '', $after = '' ) {
	$terms = get_the_terms( $id, $taxonomy );
	if ( is_wp_error( $terms ) )
		return $terms;
	if ( empty( $terms ) )
		return false;
	foreach ( $terms as $term ) {
		$link = get_term_link( $term, $taxonomy );
		if ( is_wp_error( $link ) )
			return $link;
		$term_links[] = '<a href="' . esc_url( $link ) . '" rel="tag"><span itemprop="name">' . $term->name . '</span></a>';
	}
$term_links = apply_filters( "term_links-$taxonomy", $term_links );
	return $before . join( $sep, $term_links ) . $after;
}

# Movies Genre
function categorias() {

$args = array('hide_empty' => FALSE, 'title_li'=> __( '' ), 'show_count'=> 1, 'echo' => 0 );             
$links = wp_list_categories($args);
$links = str_replace('</a> (', '</a> <span>', $links);
$links = str_replace(')', '</span>', $links);
echo $links;  
}

include_once 'includes/funciones/metadatos.php'; 
include_once 'includes/funciones/taxonomias.php';
require_once( DT_DIR . '/inc/api/dbmovies.php');
include_once 'includes/funciones/paginador.php';
include_once 'includes/funciones/dt_player.php';
require_once('includes/funciones/wpas.php');
include_once 'includes/series/tipo.php';
//require_once( DT_DIR . '/inc/temporadas/tipo.php');
if (get_option('category_base') == '') {
update_option( 'category_base', 'genre' );
}
// Plugins

include_once 'includes/plugins/minify/minifier.php';
# Hook Labels
function change_post_menu_label() {
    global $menu;
    global $submenu;
    $menu[5][0] = __('Movies', 'indoxxi');
    $submenu['edit.php'][5][0] = __('All Movies', 'indoxxi');
    $submenu['edit.php'][10][0] = __('Add Movie', 'indoxxi');
    echo '';
}
function change_post_object_label() {
        global $wp_post_types;
        $labels = &$wp_post_types['post']->labels;
        $labels->name = __('Movies', 'indoxxi');
        $labels->singular_name = __('Movie', 'indoxxi');
        $labels->add_new = __('Add Movie', 'indoxxi');
        $labels->add_new_item = __('Add New movie', 'indoxxi');
        $labels->edit_item = __('Edit Movie', 'indoxxi');
        $labels->new_item = __('Movie', 'indoxxi');
}
add_action( 'init', 'change_post_object_label' );
add_action( 'admin_menu', 'change_post_menu_label' );
define('indoxxik', DT_THEME_SLUG . '_valid_key_status');
function replace_admin_menu_icons_css() { ?>
<style>
.dashicons-admin-post:before,.dashicons-format-standard:before{content:"\f219"}span.mundo{color:green;width:70%;float:left;margin-bottom:5px;font-size:17px;padding:16px
15%;background:#C4E4C4;text-align:center}span.error{color:#DB5252;width:70%;float:left;margin-bottom:5px;font-size:17px;padding:16px
15%;background:#E4C4C4;text-align:center}i.cmsxx{float:left;width:100%;font-style:normal;font-size:12px;margin-bottom:20px;text-align:right;color:#C0C0C0}.mundobt{width:100%}.mundotxt{width:100%!important;padding:5%;font-size:28px;color:#2EA2CC!important}
li#toplevel_page_psyplay, li#toplevel_page_indoxxi {display:none;}
</style>
<?php }
add_action( 'admin_head', 'replace_admin_menu_icons_css' );

function admin_style() {
  wp_enqueue_style('admin-styles', get_template_directory_uri().'/css/admin/admin_extra.css');
}
add_action('admin_enqueue_scripts', 'admin_style');

function psy_duplicate_scripts( $hook ) {
    if( !in_array( $hook, array( 'post.php', 'post-new.php' , 'edit.php'))) return;
    wp_enqueue_script('duptitles',
    wp_enqueue_script('duptitles',get_template_directory_uri() .'/js/psy_duplicate.js',
    array( 'jquery' )), array( 'jquery' )  );
}
add_action( 'admin_enqueue_scripts', 'psy_duplicate_scripts', 2000 );
add_action('wp_ajax_psy_duplicate', 'psy_duplicate_callback');


function psy_duplicate_callback() {
	function psy_results_checks() {
		global $wpdb;
		$title = $_POST['post_title'];
		$post_id = $_POST['post_id'];
		$titles = "SELECT post_title FROM $wpdb->posts WHERE post_status = 'publish' AND post_title = '{$title}' AND ID != {$post_id} ";
		$results = $wpdb->get_results($titles);
		if($results) {
			return '<div class="error"><p><span class="dashicons dashicons-warning"></span> '. __( 'This content already exists, we recommend not to publish.' , 'indoxxi' ) .' </p></div>';
		} else {
			return '<div class="notice rebskt updated"><p><span class="dashicons dashicons-thumbs-up"></span> '.__('Excellent! this content is unique.' , 'indoxxi').'</p></div>';
		}
	}
	echo psy_results_checks();
	die();
}


function is_post_type($type){
    global $wp_query;
    if($type == get_post_type($wp_query->post->ID)) return true;
    return false;
}
function namespace_add_custom_types( $query ) {
  if( is_category() || is_tag() && empty( $query->query_vars['suppress_filters'] ) ) {
    $query->set( 'post_type', array(
     'post', 'nav_menu_item', 'tvshows', 'episodes'
		));
	  return $query;
	}
}
add_filter( 'pre_get_posts', 'namespace_add_custom_types' );
function indoxxi_custom_posts_per_page($query)
{
	$ppp = get_option('article-archive-posts');
    switch ( $query->query_vars['post_type'] )
    {
        case 'noticias':  
            $query->query_vars['posts_per_page'] = $ppp; //display all is -1
            break;

    }
    return $query;
}
if( !is_admin() )
{
    add_filter( 'pre_get_posts', 'indoxxi_custom_posts_per_page' );
}

if ( ! function_exists( 'get_current_page_url' ) ) {
function get_current_page_url() {
  global $wp;
  return add_query_arg( $_SERVER['QUERY_STRING'], '', home_url( $wp->request ) );
}
}

function get_first_paragraph(){
	global $post;
	$str = wpautop( get_the_content() );
	$str = substr( $str, 0, strpos( $str, '</p>' ) + 4 );
	$str = strip_tags($str, '<a><strong><em>');
	return $str;
}

/* Generate release country
-------------------------------------------------------------------------------
*/
function dt_show_country() { 
	$args = array('number' => 50); 
	$camel = 'country'; 
	$tax_terms = get_terms($camel,$args); 
	foreach ($tax_terms as $tax_term) 
		{ echo '<span>' . '<a href="' . esc_attr(get_term_link($tax_term, $taxonomy)) . '">' . $tax_term->name.'</a></span>'; } 
	}
	

/* API upload image
-------------------------------------------------------------------------------
*/
function dt_upload_image( $image_url, $post_id  ){
	$option = get_option('dt_api_upload_poster');
	global $wp_filesystem;
	if($option == 'true') {
		WP_Filesystem();
		$upload_dir		= wp_upload_dir();
		$imagex			= wp_remote_get($image_url);
		$image_data		= wp_remote_retrieve_body($imagex);
		$filename		= wp_basename($image_url);
		if(wp_mkdir_p($upload_dir['path']))    
			$file = $upload_dir['path'] . '/' . $filename;
		else                          
			$file = $upload_dir['basedir'] . '/' . $filename;
			$wp_filesystem->put_contents($file, $image_data, FS_CHMOD_FILE);
			$wp_filetype = wp_check_filetype($filename, null );
		$attachment = array(
			'post_mime_type' => $wp_filetype['type'],
			'post_title' => sanitize_file_name($filename),
			'post_content' => '',
			'post_status' => 'inherit'
		);
		$attach_id = wp_insert_attachment($attachment, $file, $post_id);
		require_once( ABSPATH . 'wp-admin/includes/image.php');
		$attach_data = wp_generate_attachment_metadata($attach_id, $file);
		$res1= wp_update_attachment_metadata($attach_id, $attach_data );
		$res2= set_post_thumbnail($post_id, $attach_id);
	}
}

function dt_clear($text) {
	return wp_strip_all_tags(html_entity_decode($text));
}
/* Get post meta
-------------------------------------------------------------------------------
*/
function dt_get_meta( $value ) {
	global $post;
	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}


/* Verify nonce
-------------------------------------------------------------------------------
*/
function dooplay_verify_nonce( $id, $value ) {
    $nonce = get_option( $id );
    if( $nonce == $value )
        return true;
    return false;
}

/* Create nonce
-------------------------------------------------------------------------------
*/
function dooplay_create_nonce( $id ) {
    if( ! get_option( $id ) ) {
        $nonce = wp_create_nonce( $id );
        update_option( $id, $nonce );
    }
    return get_option( $id );
}
/* Search API URL
-------------------------------------------------------------------------------
*/
function dooplay_url_search() {
	return rest_url('/dooplay/search/');
}
function dooplay_url_imdb() {
	return rest_url('/imdb/search/');
}
/* Search Register API
-------------------------------------------------------------------------------
*/
function wpc_register_wp_api_search() {
	register_rest_route('dooplay', '/search/', array(
        'methods' => 'GET',
        'callback' => 'dooplay_live_search',
    ));
}
add_action('rest_api_init', 'wpc_register_wp_api_search');

function wpc_register_wp_api_imdb() {
	register_rest_route('imdb', '/search/', array(
        'methods' => 'GET',
        'callback' => 'dooplay_imdb_search',
    ));
}
add_action('rest_api_init', 'wpc_register_wp_api_imdb');

/* Search exclude
-------------------------------------------------------------------------------
*/
add_filter('register_post_type_args',function($args, $post_type) { if(!is_admin() && $post_type=='page') { $args['exclude_from_search']=true; } return $args; }, 10, 2);
add_filter('register_post_type_args',function($args, $post_type) { if(!is_admin() && $post_type=='post') { $args['exclude_from_search']=true; } return $args; }, 10, 2);
/* Live Search
-------------------------------------------------------------------------------
*/
function dooplay_live_search( $request_data ) {
   	$parameters = $request_data->get_params();
    $keyword = dt_clear($parameters['keyword']);
    $nonce = dt_clear($parameters['nonce']);
	$types = array('post','tvshows');
	if( !dooplay_verify_nonce('dooplay-search-nonce', $nonce ) ) return array('error' => 'no_verify_nonce', 'title' => __d('No data nonce') );
	if( !isset( $keyword ) || empty($keyword) ) return array('error' => 'no_parameter_given');
	if( strlen( $keyword ) <= 2 ) return array('error' => 'keyword_not_long_enough', 'title' => __d('') );

	$args = array(
		's' => $keyword,
		'post_type' => $types,
		'posts_per_page' => 6,
		'orderby' => 'title',
	);
    $query = new WP_Query( $args );
    if ( $query->have_posts() ) {
    	$data = array();
        while ( $query->have_posts() ) {
            $query->the_post();
            global $post;
            $data[$post->ID]['title'] = $post->post_title;
            $data[$post->ID]['url'] = get_the_permalink();
			//$kat= wp_get_post_terms($post->ID, 'category');
			$kat= strip_tags(get_the_term_list( $post->ID, 'category', '', ', '));
			$data[$post->ID]['kat'] = $kat;
			if ( has_post_thumbnail() ) {
			$dato= get_the_post_thumbnail_url($post->ID, 'poster_url');
			$data[$post->ID]['img'] = $dato;
			} elseif ($dato = dt_get_meta('poster_url')) {
			$data[$post->ID]['img'] = ''. $dato;
			}
			if($dato = dt_get_meta('release_date')) {
				$data[$post->ID]['extra']['date'] = substr($dato, 0, 4);
			}
			if($dato = dt_get_meta('first_air_date')) {
				$data[$post->ID]['extra']['date'] = substr($dato, 0, 4);
			}
			$data[$post->ID]['extra']['imdb'] = dt_get_meta('imdbRating');
        }
        return $data;
    } else {
    	return array('error' => 'no_posts', 'title' => __d('No results') );
    }
    wp_reset_postdata();
}
function dooplay_imdb_search( $request_data ) {
   	$parameters = $request_data->get_params();
	$keyword = $parameters['keyword'];
	$types = array('post','tvshows');


$args = array(
    'post_type' => $types,
    'posts_per_page' => -1,
    'meta_key' => 'Checkbx2', 
    'meta_value' => $keyword,
	'compare' => '=',
);
    $query = new WP_Query( $args );
    if ( $query->have_posts() ) {
    	$data = array();
        while ( $query->have_posts() ) {
            $query->the_post();
            global $post;
            $data[$post->ID]['title'] = $post->post_title;
            $data[$post->ID]['url'] = get_the_permalink();
			if ( has_post_thumbnail() ) {
			$dato= get_the_post_thumbnail_url($post->ID, 'poster_url');
			$data[$post->ID]['img'] = $dato;
			} elseif ($dato = dt_get_meta('poster_url')) {
			$data[$post->ID]['img'] = ''. $dato;
	}		
if( have_rows('player') ):
$numerado = 1; { while( have_rows('player') ): the_row(); 
$data1[] = array(
'embed' => get_sub_field('embed_player'),
'type_player' => get_sub_field('type_player'),

);
$numerado++;
$data['movies'] =$data1;
endwhile; }
endif;

        }
        return $data;
    } else {
    	return array('error' => 'no_posts', 'title' => __d('No results') );
    }
    wp_reset_postdata();
}

function dtloadp() { ?>
<script type="text/javascript">
<?php if(is_single()) { global $user_ID; if( $user_ID ) : if( current_user_can('level_10') ) : ?>
jQuery(document).ready(function($) {
    $(".dtload").click(function() {
        var o = $(this).attr("id");
        1 == o ? ($(".dtloadpage").hide(), $(this).attr("id", "0")) : ($(".dtloadpage").show(), $(this).attr("id", "1"))
    }), $(".dtloadpage").mouseup(function() {
        return !1
    }), $(".dtload").mouseup(function() {
        return !1
    }), $(document).mouseup(function() {
        $(".dtloadpage").hide(), $(".dtload").attr("id", "")
    })
})
<?php endif; endif; } ?>
</script>
<?php }
add_action('wp_footer', 'dtloadp');

 class WPSE_78121_Sublevel_Walker extends Walker_Nav_Menu
{
function start_lvl( &$output, $depth = 0, $args = array() ) {
$indent = str_repeat("\t", $depth);
$output .= "\n$indent<div class='sub-container' style='display: none;'><ul class='sub-menu'>\n";
}
function end_lvl( &$output, $depth = 0, $args = array() ) {
$indent = str_repeat("\t", $depth);
$output .= "$indent</ul></div>\n";
}
}



function wpse45700_get_menu_by_location( $location ) {
    if( empty($location) ) return false;

    $locations = get_nav_menu_locations();
    if( ! isset( $locations[$location] ) ) return false;

    $menu_obj = get_term( $locations[$location], 'nav_menu' );

    return $menu_obj;
}





class Walker_Quickstart_Menu extends Walker_Nav_Menu {

    // Tell Walker where to inherit it's parent and id values
    var $db_fields = array(
        'parent' => 'menu_item_parent', 
        'id'     => 'db_id' 
    );

    function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $output .= sprintf( "<li><a href='%s'%s>%s</a>",
            $item->url,
            ( $item->object_id === get_the_ID() ) ? '' : '',
            $item->title
        );
    }


}
add_filter('pre_get_posts','stars_archive');

function stars_archive( $query ) {

    if ( $query->is_tax( 'stars' ) && $query->is_main_query() ) {
        $terms = get_terms( 'stars', array( 'fields' => 'ids' ) );
        $query->set( 'post_type', array( 'post', 'tvshows' ) );
        $query->set( 'tax_query', array(
            'relation' => 'OR',
            array(
                'taxonomy' => 'stars',
                'field' => 'id',
                'terms' => $terms,
                'operator' => '='
            )
        ) );
    }

    return $query;
}
add_filter('pre_get_posts','quality_archive');

function quality_archive( $query ) {

    if ( $query->is_tax( 'quality' ) && $query->is_main_query() ) {
        $terms = get_terms( 'quality', array( 'fields' => 'ids' ) );
        $query->set( 'post_type', array( 'post', 'tvshows' ) );
        $query->set( 'tax_query', array(
            'relation' => 'OR',
            array(
                'taxonomy' => 'quality',
                'field' => 'id',
                'terms' => $terms,
                'operator' => '='
            )
        ) );
    }

    return $query;
}
add_filter('pre_get_posts','country_archive');
function country_archive( $query ) {

    if ( $query->is_tax( 'country' ) && $query->is_main_query() ) {
        $terms = get_terms( 'country', array( 'fields' => 'ids' ) );
        $query->set( 'post_type', array( 'post', 'tvshows' ) );
        $query->set( 'tax_query', array(
            'relation' => 'OR',
            array(
                'taxonomy' => 'country',
                'field' => 'id',
                'terms' => $terms,
                'operator' => '='
            )
        ) );
    }

    return $query;
}
add_filter('pre_get_posts','releaseyear_archive');
function releaseyear_archive( $query ) {

    if ( $query->is_tax( 'release-year' ) && $query->is_main_query() ) {
        $terms = get_terms( 'release-year', array( 'fields' => 'ids' ) );
        $query->set( 'post_type', array( 'post', 'tvshows' ) );
        $query->set( 'tax_query', array(
            'relation' => 'OR',
            array(
                'taxonomy' => 'release-year',
                'field' => 'id',
                'terms' => $terms,
                'operator' => '='
            )
        ) );
    }

    return $query;
}
add_filter('pre_get_posts','director_archive');
function director_archive( $query ) {

    if ( $query->is_tax( 'director' ) && $query->is_main_query() ) {
        $terms = get_terms( 'director', array( 'fields' => 'ids' ) );
        $query->set( 'post_type', array( 'post', 'tvshows' ) );
        $query->set( 'tax_query', array(
            'relation' => 'OR',
            array(
                'taxonomy' => 'director',
                'field' => 'id',
                'terms' => $terms,
                'operator' => '='
            )
        ) );
    }

    return $query;
}

add_rewrite_endpoint( 'play', EP_PERMALINK | EP_PAGES );
function makeplugins_add_json_endpoint() {
    add_rewrite_endpoint( 'play', EP_PERMALINK | EP_PAGES );
}
add_action( 'init', 'makeplugins_add_json_endpoint' );

function makeplugins_json_template_redirect() {
    global $wp_query;
 
    // if this is not a request for play or a singular object then bail
    if ( ! isset( $wp_query->query_vars['play'] ) || ! is_singular() )
        return;
 
    // include custom template
    include dirname( __FILE__ ) . '/play.php';
    exit;
}
add_action( 'template_redirect', 'makeplugins_json_template_redirect' );

add_rewrite_endpoint( 'watch', EP_PERMALINK | EP_PAGES );
function playserie_add_json_endpoint() {
    add_rewrite_endpoint( 'watch', EP_PERMALINK | EP_PAGES );
}
add_action( 'init', 'playserie_add_json_endpoint' );

function playserie_json_template_redirect() {
    global $wp_query;
 
    // if this is not a request for play or a singular object then bail
    if ( ! isset( $wp_query->query_vars['watch'] ) || ! is_singular() )
        return;
 
    // include custom template
    include dirname( __FILE__ ) . '/playserie.php';
    exit;
}
add_action( 'template_redirect', 'playserie_json_template_redirect' );
add_action('wp_print_styles', 'mytheme_dequeue_css_from_plugins', 100);
 function mytheme_dequeue_css_from_plugins() {
 wp_dequeue_style('wp-postratings');
 }
if(get_option( indoxxik ) == "valid") {
function my_assets() {
wp_register_script('cos', get_template_directory_uri() . '/js/cos.js', array('jquery'), '1.0', true );
wp_enqueue_script('cos');
}
add_action( 'wp_enqueue_scripts', 'my_assets', 20, 1);
}

function add_defer_attribute($tag, $handle) {
   // add script handles to the array below
   $scripts_to_defer = array('wp-postratings', 'wp-embed');
   
   foreach($scripts_to_defer as $defer_script) {
      if ($defer_script === $handle) {
         return str_replace(' src', ' async="async" src', $tag);
      }
   }
   return $tag;
}
add_filter('script_loader_tag', 'add_defer_attribute', 10, 2);
?>
<?php
/* Live Search
-------------------------------------------------------------------------------
*/
if( ! function_exists( 'doo_search_title' ) ) {
    function doo_search_title($search) {
    	preg_match('/title-([^%]+)/', $search, $m);
    	if ( isset( $m[1] ) ) {
    		global $wpdb;
    		if($m[1] == '09') return $wpdb->query( $wpdb->prepare("AND $wpdb->posts.post_title REGEXP '^[0-9]' AND ($wpdb->posts.post_password = '') ") );
    		return $wpdb->query( $wpdb->prepare("AND $wpdb->posts.post_title LIKE '$m[1]%' AND ($wpdb->posts.post_password = '') ") );
    	} else {
    		return $search;
    	}
    }
    add_filter('posts_search', 'doo_search_title');
}
# First Letter
if( ! function_exists( 'doo_first_letter' ) ) {
    function doo_first_letter( $where, $qry ) {

    	global $wpdb;
    	$sub = $qry->get('doo_first_letter');

    	if (!empty($sub)) {
    		$where .= $wpdb->prepare(
    			" AND SUBSTRING( {$wpdb->posts}.post_title, 1, 1 ) = %s ",
    			$sub
    		);
    	}

    	return $where;
    }
    add_filter( 'posts_where' , 'doo_first_letter', 1 , 2 );
}
function live_search() {
wp_enqueue_script( 'live_search', get_template_directory_uri() . '/js/live.search.js', array ( 'jquery' ), 2.1, true);
wp_localize_script(
'live_search',
'dtGonza',
array(
'api' => dooplay_url_search(),
'glossary' => dooplay_url_glossary(),
'nonce' => dooplay_create_nonce('dooplay-search-nonce'),
'area' => ".search-suggest",
'button' => ".search-submit",
'more' => __d('View all results'),
)
);
}
add_action('wp_enqueue_scripts','live_search', 19, 1);

if( ! function_exists( 'dooplay_url_glossary' ) ) {
    function dooplay_url_glossary() {
    	return rest_url('/dooplay/glossary/');
    }
}

if( ! function_exists( 'dooplay_register_wp_api_glossary' ) ) {
    function dooplay_register_wp_api_glossary() {
    	register_rest_route('dooplay', '/glossary/', array(
            'methods' => 'GET',
            'callback' => 'dooplay_live_glossary',
        ));
    }
    add_action('rest_api_init', 'dooplay_register_wp_api_glossary');
}
if( ! function_exists( 'doo_mobile' ) ) {
    function doo_mobile() {
    	$mobile = ( wp_is_mobile() == true ) ? '1' : 'false';
    	return $mobile;
    }
}

if( ! function_exists( 'dooplay_live_glossary' ) ) {
	function dooplay_live_glossary( $request_data ) {
$suggnum = get_option('modleter_num');
	    $parameters = $request_data->get_params();
	    $term	    = dt_clear( $parameters['term'] );
		$nonce	    = dt_clear( $parameters['nonce'] );
	    $type       = isset( $parameters['type'] ) ? $parameters['type'] : null;
		if( !dooplay_verify_nonce('dooplay-search-nonce', $nonce ) ) return array('error' => 'no_verify_nonce', 'title' => __d('No data nonce') );
	    if( !isset( $term ) || empty($term) ) return array('error' => 'no_parameter_given');
	    if( $type == all )  $post_types = array('post','tvshows'); else $post_types = $type;
	    $args = array(
	        'doo_first_letter' => $term,
	        'post_type'        => $post_types,
			'post_status'      => 'publish',
	        'posts_per_page'   => $suggnum,
	    	'orderby'          => 'rand',
	    );

	    query_posts( $args );
if ( have_posts() ) {
	        $data = array();
			while ( have_posts() ) {
	            the_post();
	            global $post;
	        $data[$post->ID]['title'] = $post->post_title;
            $data[$post->ID]['url'] = get_the_permalink();
			//$kat= wp_get_post_terms($post->ID, 'category');
			$kat= strip_tags(get_the_term_list( $post->ID, 'category', '', ', '));
			$data[$post->ID]['kat'] = $kat;
			$quality= strip_tags(get_the_term_list( $post->ID, 'quality', '', ', '));
			$data[$post->ID]['quality'] = $quality;
			$releaseyear= strip_tags(get_the_term_list( $post->ID, 'release-year', '', ', '));
			$data[$post->ID]['release-year'] = $releaseyear;
			$country= strip_tags(get_the_term_list( $post->ID, 'country', '', ', '));
			$data[$post->ID]['country'] = $country;
			if ( has_post_thumbnail() ) {
			$dato= get_the_post_thumbnail_url($post->ID, 'poster_url');
			$data[$post->ID]['img'] = $dato;
			} elseif ($dato = dt_get_meta('poster_url')) {
			$data[$post->ID]['img'] = ''. $dato;
			}
			if($datoi = dt_get_meta('imdbRating')) {
			$data[$post->ID]['extra']['imdb'] = dt_get_meta('imdbRating');
			}else {
			$data[$post->ID]['extra']['imdb'] = 'N/A';
			}
        }
        return $data;

	    } else {
	        return array('error' => 'no_posts', 'title' => __d('No results') );
	    }
	    wp_reset_query();
	}
}	
	

add_action('wp_footer', 'aja');
function aja() { ?>
<script type="text/javascript">
    $(document).on('click', '.lglossary', function() {
        var term = $(this).data('glossary')
        var type = $(this).data('type')
        $('.lglossary').removeClass('active')
        $(this).addClass('active')
        $('.items_glossary').show()
        $('.items_glossary').html( '<div class="loading">Loading&#8230;</div>')
        $.ajax({
            type:'GET',
            url: dtGonza.glossary,
            data: 'term=' + term + '&nonce=' + dtGonza.nonce + '&type=' + type,
            dataType: "json",
            success: function(data){
                if( data['error'] ) {
					$('.items_glossary').hide()
                    $('.lglossary').removeClass('active')
					return;
				}
                $('.items_glossary').show();
                var items = [];
                $.each( data, function( key, val ) {
					name = '';
					date = '';
					imdb = 'N/A';
					kat = '';
					quality = '';
					if( val['extra']['imdb'] !== false )
						imdb = "<div class='rating'><i class='icon-star'></i> " + val['extra']['imdb'] + "</div>";

					items.push("<tr class=\"mlnew\"><td class=\"mlnh-1\">#</td><td class=\"mlnh-thumb\"><a href=" + val['url'] + " class=\"thumb\"><img src=" + val['img'] + "></a></td><td class=\"mlnh-2\"><h2><a href='" + val['url'] + "'>"+ val['title'] +"</a></h2></td><td>"+ val['release-year'] +"</td><td class=\"mlnh-3\">"+ val['quality'] +"</td><td class=\"mlnh-4\">"+ val['country'] +"</td><td class=\"mlnh-5\">"  + val['kat'] +  "</td><td class=\"mlnh-6\"><span class=\"label label-warning\">"+ imdb +"</span></td></tr>");
                });
				$('.items_glossary').html('<div id=\"filter\" class=\"active\"><div class=\"letter-movies-lits\"><table class=\"table-striped\"><tbody><tr class=\"mlnew-head\"><td class=\"mlnh-1\">#</td><td colspan=\"2\" class=\"mlnh-letter\">Title</td><td class=\"mlnh-3\">Year</td><td class=\"mlnh-3\">Quality</td><td class=\"mlnh-5\">Country</td><td class=\"mlnh-4\">Genre</td><td class=\"mlnh-6\">IMDb</td></tr>' + items.join("") +'</tbody></table></div></div>');
            }
        });
    });
</script>
<?php }
