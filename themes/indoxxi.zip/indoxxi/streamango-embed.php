<?php 
/*
Template Name: STREAMAGO Embed
*/

if( isset($_GET['source'])) {
$source = base64_decode( $_GET['source'] );
?>
<iframe src="<?php echo esc_url($source); ?>" frameborder="0" width="100%" height="100%" allowscriptaccess="always" allowfullscreen="true" scrolling="no" frameborder="0"></iframe>
<?php } else { 
	_d('Access denied'); 
} ?>