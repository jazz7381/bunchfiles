<?php get_header(); ?>
<div id="main" class="page-category" style="padding-top:70px;">

        <div class="container">
            <div class="main-content" style="min-height:80vh">
                <div class="modal" id="pop-trailer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none;">
                    <div class="modal-dialog" style="margin-top:66px;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                <h4 class="modal-title" id="myModalLabel"></h4></div>
                            <div class="modal-body">
                                <div class="modal-body-trailer">
                                    <iframe id="iframe-trailer" width="100%" height="380" src="" frameborder="0" allowfullscreen=""></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="sosial" class="social-home">
				   <?php get_template_part('includes/featured/social'); ?>
                </div>
				<div class="extend" style="margin-top:1em;text-align:center;">
				 <?php get_template_part('includes/ads'); ?>
				</div>
<?php $active = get_option('modleter'); if ($active == "true") { ?>
<div class="extend">
<div class="ml-announce" style="margin-top:1em;text-align:center;">
<ul class="pagination">
<li><a <?php echo $s == '09' ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>">#</a><li>
	<?php for ($l="a";$l!="aa";$l++){?>
	<li><a <?php echo $s == "$l" ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>"><?php echo strtoupper($l); ?></a><li>
	<?php } ?>
</ul>
<div class="clearfix"></div>
</div>
<div class="items_glossary"></div>					
</div>
<?php }?>
                <div class="movies-list-wrap mlw-topview mt20">
				<?php get_template_part('includes/mobile-menu'); ?>
<?php $active = get_option('movsmodule'); if ($active == "true") { ?>
                    <div class="ml-title"><span class="pull-left"><?php if($title = get_option('latestmov_title')){ echo $title; } else { echo 'Cinema XXI'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="<?php echo get_option("mov_archive");?>" id="lihatutama" class="pull-right cat-more"><?php _e('Lihat Lebih', 'indoxxi'); ?> </a>
                        <ul role="tablist" class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" id="featured-movie" role="tab" href="#featured" aria-expanded="false">Featured</a></li>
                            <li><a onclick="getContent('mtab1')" data-toggle="tab" id="movies-mtab1" role="tab" href="#top-mtab1" aria-expanded="false"><?php $title = get_option('mtb1_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('mtab2')" data-toggle="tab" id="movies-mtab2" role="tab" href="#top-mtab2" aria-expanded="false"><?php $title = get_option('mtb2_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('mtab3')" data-toggle="tab" id="movies-mtab3" role="tab" href="#top-mtab3" aria-expanded="false"><?php $title = get_option('mtb3_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('mtab4')" data-toggle="tab" id="movies-mtab4" role="tab" href="#top-mtab4" aria-expanded="false"><?php $title = get_option('mtb4_title'); echo $title;?></a></li>
							<li><a onclick="getContent('mtab5')" data-toggle="tab" id="movies-mtab5" role="tab" href="#top-mtab5" aria-expanded="false"><?php $title = get_option('mtb5_title'); echo $title;?></a></li>
						 </ul>
                    </div>
<div class="tab-content">
<div id="featured" class="movies-list movies-list-full tab-pane in fade active">
<?php 
$lsm = get_option('latestmov_num');
$args = array();
$args['wp_query'] = array('post_type' => 'post',
'posts_per_page' => $lsm,
'order' => 'DESC',
'orderby' => 'date');

 $args['fields'][] = array( 'type' => 'post_type', 
'format' => 'radio', 
'label' => 'Search Type', 
'values' => array('post' => 'Peliculas', ),
'default' => 'post'
);

$args['fields'][] = array('type' => 'taxonomy',
'label' => __( 'Quality', 'indoxxi' ),
'taxonomy' => 'quality',
'format' => 'checkbox',
'operator' => 'IN');


$args['fields'][] = array('type' => 'taxonomy',
'label' => __( 'Genre', 'indoxxi' ),
'taxonomy' => 'category',
'format' => 'checkbox',
'operator' => 'AND');

$args['fields'][] = array('type' => 'taxonomy',
'label' => __( 'Country', 'indoxxi' ),
'taxonomy' => 'country',
'format' => 'checkbox',
'operator' => 'IN');

$args['fields'][] = array('type' => 'taxonomy',
'label' => __( 'Release Year', 'indoxxi' ),
'taxonomy' => 'release-year',
'format' => 'radio',
'operator' => 'IN');

$args['fields'][] = array('type' => 'submit', 'value' => __('Filter results', 'indoxxi'));
$my_search_object = new WP_Advanced_Search($args);
$temp_query = $wp_query;

$wp_query = $my_search_object->query();
if ( have_posts() ): while ( have_posts() ): the_post(); ?>
<?php   if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'medium');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
	$imgsrc = wp_get_attachment_image_src($postimage->ID, 'medium');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = get_post_custom_values($imagefix)){
$imgsrc = $img[0];
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
} 
$dt_player	= get_post_meta($post->ID, 'repeatable_fields', true);
?>
<div data-movie-id='<?php the_id(); ?>' class='ml-item'><a href='<?php the_permalink() ?>' data-url='' class='ml-mask jt' title='<?php the_title(); ?>'><span class='mli-quality <?php echo strtolower ($mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality'))) ?>'><?php echo $mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality')) ?></span><div class="rating-durasi"><span class='mli-rating'><i class='fa fa-star mr5'></i><?php echo $values = info_movie_get_meta("imdbRating") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $dato = info_movie_get_meta("Runtime")?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div><img src='<?php echo $imgsrc; $imgsrc = ''; ?>' class='lazy thumb mli-thumb' alt='<?php the_title(); ?>'><span class='mli-info'><h2><?php the_title(); ?></h2></span></a></div>
<?php endwhile; endif; ?>
</div>
<div id="top-mtab1" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="top-mtab2" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="top-mtab3" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="top-mtab4" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="top-mtab5" class="movies-list movies-list-full tab-pane in fade"></div>
                    </div>
<?php }?>
                </div>
                <div class="extend" style="margin-top:1em;text-align:center;">
                    <?php get_template_part('includes/ads2'); ?>
                </div>
<?php $active = get_option('tvmodule'); if ($active == "true") { ?>
                <div class="movies-list-wrap mlw-latestmovie">
                    <div class="ml-title"><span class="pull-left"><?php if($title = get_option('latesttv_title')){ echo $title; } else { echo 'Latest TV Series'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="<?php bloginfo('url'); ?>/series/" id="lihatrekomen" class="pull-right cat-more"><?php _e('Lihat Lebih', 'indoxxi'); ?> </a>
                        <ul role="tablist" class="nav nav-tabs">
                            <li><a onclick="getContent('stab1')" data-toggle="tab" id="serial-tab1" role="tab" href="#top-stab1" aria-expanded="false"><?php $title = get_option('stb1_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stab2')" data-toggle="tab" id="serial-tab2" role="tab" href="#top-stab2" aria-expanded="false"><?php $title = get_option('stb2_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stab3')" data-toggle="tab" id="serial-tab3" role="tab" href="#top-stab3" aria-expanded="false"><?php $title = get_option('stb3_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stab4')" data-toggle="tab" id="serial-tab4" role="tab" href="#top-stab4" aria-expanded="false"><?php $title = get_option('stb4_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stab5')" data-toggle="tab" id="serial-tab5" role="tab" href="#top-stab5" aria-expanded="false"><?php $title = get_option('stb5_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stab6')" data-toggle="tab" id="serial-tab6" role="tab" href="#top-stab6" aria-expanded="false"><?php $title = get_option('stb6_title'); echo $title;?></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab-content">
                        <div id="top-stab1" class="movies-list movies-list-full tab-pane in fade active"></div>
                        <div id="top-stab2" class="movies-list movies-list-full tab-pane in fade "></div>
                        <div id="top-stab3" class="movies-list movies-list-full tab-pane in fade "></div>
                        <div id="top-stab4" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-stab5" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-stab6" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
<?php } ?>
<?php $active = get_option('stremodule'); if ($active == "true") { ?>
                <div class="movies-list-wrap mlw-latestmovie">
                    <div class="ml-title"><span class="pull-left"><?php if($title = get_option('streaming_title')){ echo $title; } else { echo 'Streaming'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="<?php bloginfo('url'); ?>/streaming/" id="lihatrekomen" class="pull-right cat-more"><?php _e('Lihat Lebih', 'indoxxi'); ?> </a>
                        <ul role="tablist" class="nav nav-tabs">
                            <li><a onclick="getContent('stre1')" data-toggle="tab" id="serial-tab1" role="tab" href="#top-stre1" aria-expanded="false"><?php $title = get_option('str1_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stre2')" data-toggle="tab" id="serial-tab2" role="tab" href="#top-stre2" aria-expanded="false"><?php $title = get_option('str2_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stre3')" data-toggle="tab" id="serial-tab3" role="tab" href="#top-stre3" aria-expanded="false"><?php $title = get_option('str3_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stre4')" data-toggle="tab" id="serial-tab4" role="tab" href="#top-stre4" aria-expanded="false"><?php $title = get_option('str4_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stre5')" data-toggle="tab" id="serial-tab5" role="tab" href="#top-stre5" aria-expanded="false"><?php $title = get_option('str5_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('stre6')" data-toggle="tab" id="serial-tab6" role="tab" href="#top-stre6" aria-expanded="false"><?php $title = get_option('str6_title'); echo $title;?></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab-content">
                        <div id="top-stre1" class="movies-list movies-list-full tab-pane in fade active"></div>
                        <div id="top-stre2" class="movies-list movies-list-full tab-pane in fade "></div>
                        <div id="top-stre3" class="movies-list movies-list-full tab-pane in fade "></div>
                        <div id="top-stre4" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-stre5" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-stre6" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
<?php } ?>
<?php $active = get_option('allmodule'); if ($active == "true") { ?>
                <div class="movies-list-wrap mlw-latestmovie">
                    <div class="ml-title"><span class="pull-left"><?php if($title = get_option('latestall_title')){ echo $title; } else { echo 'Latest TV Series'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="<?php bloginfo('url'); ?>/bluray/" id="lihatrekomen" class="pull-right cat-more"><?php _e('Lihat Lebih', 'indoxxi'); ?> </a>
                        <ul role="tablist" class="nav nav-tabs">
                            <li><a onclick="getContent('xtab1')" data-toggle="tab" id="serial-tab1" role="tab" href="#top-xtab1" aria-expanded="false"><?php $title = get_option('xtb1_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('xtab2')" data-toggle="tab" id="serial-tab2" role="tab" href="#top-xtab2" aria-expanded="false"><?php $title = get_option('xtb2_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('xtab3')" data-toggle="tab" id="serial-tab3" role="tab" href="#top-xtab3" aria-expanded="false"><?php $title = get_option('xtb3_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('xtab4')" data-toggle="tab" id="serial-tab4" role="tab" href="#top-xtab4" aria-expanded="false"><?php $title = get_option('xtb4_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('xtab5')" data-toggle="tab" id="serial-tab5" role="tab" href="#top-xtab5" aria-expanded="false"><?php $title = get_option('xtb5_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('xtab6')" data-toggle="tab" id="serial-tab6" role="tab" href="#top-xtab6" aria-expanded="false"><?php $title = get_option('xtb6_title'); echo $title;?></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab-content">
                        <div id="top-xtab1" class="movies-list movies-list-full tab-pane in fade active"></div>
                        <div id="top-xtab2" class="movies-list movies-list-full tab-pane in fade "></div>
                        <div id="top-xtab3" class="movies-list movies-list-full tab-pane in fade "></div>
                        <div id="top-xtab4" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-xtab5" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-xtab6" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
<?php } ?>
<?php $active = get_option('fwmodule-activated'); if ($active == "true") { ?>
<div class="ml-announce" style="margin-top:30px;background:transparent;">
    <hr style="margin-bottom:30px;">
    <a href="<?php echo get_option('fwmodule1_url');?>" style="color:#f0f0f0;" title="film">
        <div class="u-link"><i class="fa fa-globe"></i> <?php echo get_option('fwmodule1_title');?></div>
    </a>
    <a href="<?php echo get_option('fwmodule2_url');?>" style="color:#f0f0f0;" title="film">
        <div class="u-link"><i class="fa fa-th"></i> <?php echo get_option('fwmodule2_title');?></div>
    </a>
    <a href="<?php echo get_option('fwmodule3_url');?>" style="color:#f0f0f0;" title="film">
        <div class="u-link"><i class="fa fa-list"></i> <?php echo get_option('fwmodule3_title');?></div>
    </a>
    <a href="<?php echo get_option('fwmodule4_url');?>" style="color:#f0f0f0;" title="film">
        <div class="u-link"><i class="fa fa-coffee"></i> <?php echo get_option('fwmodule4_title');?></div>
    </a>
    <a href="<?php echo get_option('fwmodule5_url');?>" style="color:#f0f0f0;" title="film">
        <div class="u-link"><i class="fa fa-wrench"></i> <?php echo get_option('fwmodule5_title');?></div>
    </a>
    <div style="clear:both;"></div>
</div>
<?php } ?>

<div class="extend" style="margin-top:1em;text-align:center;">
                    <?php get_template_part('includes/ads3'); ?>
                </div>
                <div class="ml-announce">
					<?php get_template_part('includes/funciones/announce'); ?>
                </div>
            </div>
        </div>
	</div>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
                $("img.lazy").lazyload({
                    skip_invisible: true,
                    effect: "fadeIn",
                    event: "movie"
                });
                $(window).bind("load", function() {
                    var timeout = setTimeout(function() {
                        $("img.lazy").trigger("movie")
                    }, 50);
                });
            });

function getContent(e) {
   $.ajax({
     type: "GET",
     url: "<?php echo get_template_directory_uri(); ?>/ajax-top-" + e + ".php",
     success: function(data) {
     $("#top-"  + e).html(data);
    }
   });
}
</script>
<?php  get_footer(); ?>