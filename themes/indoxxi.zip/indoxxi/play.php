<?php get_header(); ?>
<?php 
global $wp_query; 
$postid = $wp_query->post->ID;
$dt_player	= get_post_meta($postid, 'repeatable_fields', true);
?>
    <div id="main" class="page-category" style="padding-top: 70px;">
        <div id="container" style="min-height: 70vh;">
        <!-- Ads-Custom START -->
        <div class="ads-kiri-player">
            <?php get_template_part('includes/ads-kiri-player'); ?>
        </div>
        <div class="ads-kanan-player">
            <?php get_template_part('includes/ads-kanan-player'); ?>
        </div>
        <!-- Ads-Custom END -->
        <!-- Ads-Custom START -->
        <div class="kanan kiri main-content main-detail" style="width:85%; max-width:1700px ;">
                    <?php get_template_part('includes/ads-atas-player'); ?>
        </div>
        <!-- Ads-Custom END -->
            <div class="main-content main-detail" id="utamasakti" style="width:85%; max-width:1700px ; min-height:60vh">
                <div class="pad">
                </div>
                <?php echo movies_breadcrumbs(); ?>
                <div id="mv-info" style="padding:0">
                    <div id="mv-dt" style=""><?php _e('', 'indoxxi'); ?></div>
                    <div class="play-notice">
                    <?php $active = get_option('notice-player-aktifkan'); if ($active == "true") { ?>
	                    <?php if ($ads = get_option('notice-player-text1')) { ?><?php echo stripslashes($ads); ?><?php }?>
                    <?php }?>
                        <div class="alert alert-warning" style="margin-bottom: 0; border-radius: 0;">
                            <i class="fa fa-warning mr5" style="padding:0px"></i><?php _e('Jika tidak bisa diputar: gunakan', 'indoxxi'); ?> <a rel="nofollow" href="https://www.google.com/chrome/browser/desktop/"> CHROME</a>, <?php _e('bersihkan cache, lakukan reload browser.', 'indoxxi'); ?> <a href="/pages/request-report-dead-links/">Report Link</a>.
                        </div>
                        <div class="alert alert-warning-mobile" style="padding:3px 0 0 5px;margin-bottom: 0; border-radius: 0;">
                            <i class="fa fa-warning mr5" style="padding:0px"></i> <?php _e('Use.', 'indoxxi'); ?> <a rel="nofollow" href="https://play.google.com/store/apps/details?id=com.android.chrome&hl=en">CHROME</a>. <a href="/pages/request-report-dead-links/">Report Links</a>.
                        </div>
                        
                    </div>
<div id="content-embed" style="display:table;margin:auto;max-height:45vh;background: #000;">


<div id="subl" style="display: none; position:absolute;width:100%;height:100%;top:0;left:0;background:rgba(0,0,0,0.5);z-index:100;color:#f8f8f8;">
    <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);padding:10px;width:300px;max-width:95%;max-height:90%;overflow-y:auto;background:#000;box-shadow:0 0 2px #f8f8f8;">
        <h4 style="text-align:center;">Subtitles</h4>
        <table width="100%" border="1" style="border-collapse:collapse;border:1px solid #555;color:#f0f0f0;font-size:medium;">
            <tbody>
<?php  if ( $dt_player ) : ?>
<?php $numerado = 1; { foreach ( $dt_player as $field ) { ?>
<?php if($field['select'] == 'subtitle') {  ?>
                <tr>
                    <td style="padding:10px;"><?php echo $field['name']; ?></td>
                    <td style="padding:10px;text-align:center;"><a href="<?php echo $field['url']; ?>" target="_blank"><i class="fa fa-download" style="cursor:pointer;"></i></a></td>
                </tr>
<?php } $numerado++; } } ?> 
<?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="dlm" style="display: none; position:absolute;width:100%;height:100%;top:0;left:0;background:rgba(0,0,0,0.5);z-index:100;color:#f8f8f8;">
    <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);padding:10px;width:300px;max-width:95%;max-height:90%;overflow-y:auto;background:#000;box-shadow:0 0 2px #f8f8f8;">
        <h4 style="text-align:center;">Download</h4>
        <table width="100%" border="1" style="border-collapse:collapse;border:1px solid #555;color:#f0f0f0;font-size:medium;">
            <tbody>
<?php  if ( $dt_player ) : ?>
<?php $numerado = 1; { foreach ( $dt_player as $field ) { ?>
<?php if($field['select'] == 'download') {  ?>
                <tr>
                    <td style="padding:10px;"><?php echo $field['name']; ?></td>
					<td style="padding:10px;"><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div></td>
                    <td style="padding:10px;text-align:center;"><a href="<?php echo $field['url']; ?>" target="_blank"><i class="fa fa-download" style="cursor:pointer;"></i></a></td>
                </tr>
<?php } $numerado++; } } ?> 
<?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $active = get_option('onplayer'); if ($active == "true") { ?>
<script>
$(document).ready(function(){
    $("#server-list-close").click(function(){
        $("#server-list-contenta").show(500);
		$("#server-list-content").hide(500);
    });
    $("#server-list-closea").click(function(){
        $("#server-list-content").show(500);
		$("#server-list-contenta").hide(500);
		$('#server-list-content').delay(5000).hide(500);
		$('#server-list-contenta').show(500);
    });
$('#server-list-content').delay(10000).hide(500);
$('#server-list-contenta').show(500);

});




$(document).ready(function() {
    $("#downloadmv").click(function(e) {
        $("#dlm").toggle();
        e.stopPropagation();
    });

    $(document).click(function(e) {
        if (!$(e.target).is('#dlm, #dlm *')) {
            $("#dlm").hide();
        }
    });
});

$(document).ready(function() {
    $("#dlsub").click(function(a) {
        $("#subl").toggle();
        a.stopPropagation();
    });

    $(document).click(function(a) {
        if (!$(a.target).is('#subl, #subl *')) {
            $("#subl").hide();
        }
    });
});



</script>
<div id="server-list-contenta" style="display: none; right: 0px;">
    <div id="server-list-closea" style="display: block;"><i class="fa fa-chevron-right"></i></div>
</div>	
					
<div id="server-list-content" style="display: block; right: 0px;">
    <div id="server-list-close" style="display: block;"><i class="fa fa-chevron-right"></i></div>
<div id="server-list">
<div id="server-list-title">List Server</div>
<?php  if ( $dt_player ) : ?>
<?php $numerado = 1; { foreach ( $dt_player as $field ) { ?>
<?php if($field['select'] == 'iframe') {  ?>
<div class="server-wrapper">
<div class="server server-active" data-type="dv" data-idx="0" id="episode-2<?php echo $field['mid']; ?>" onclick="load_movie_iframe(2, <?php echo $field['mid']; ?>);" data-iframe="<?php echo base64_encode ( $field['url'] ); ?>">
<div class="server-indicator" data-color="0"></div>
<div class="server-title"><img class="server-list-icon" src="<?php echo get_template_directory_uri(); ?>/images/icon-server/blogspot.png"> <small><?php echo $field['name']; ?></small></div>
</div>
</div>
<?php } if($field['select'] == 'mp4') {  ?>
<div class="server-wrapper">
<div class="server server-active" data-type="dv" data-idx="0" id="episode-7<?php echo $field['mid']; ?>" onclick="load_movie_iframe(7,<?php echo $field['mid']; ?>);" data-mp4="<?php echo base64_encode ( $field['url'] ); ?>">
<div class="server-indicator" data-color="0"></div>
<div class="server-title"><img class="server-list-icon" src="<?php echo get_template_directory_uri(); ?>/images/icon-server/mp4.png"> <small><?php echo $field['name']; ?></small></div>
</div>
</div>
<?php } if($field['select'] == 'drive') {  ?>
<div class="server-wrapper">
<div class="server server-active" data-type="ex" data-idx="0" id="episode-8<?php echo $field['mid']; ?>" onclick="load_movie_iframe(8,<?php echo $field['mid']; ?>);" data-drive="<?php echo base64_encode ( $field['url'] ); ?>">
<div class="server-indicator" data-color="0"></div>
<div class="server-title"><img class="server-list-icon" src="<?php echo get_template_directory_uri(); ?>/images/icon-server/google.png"><small><?php echo $field['name']; ?></small></div>
</div>
</div>
<?php } if($field['select'] == 'drive-backup') {  ?>
<div class="server-wrapper">
<div class="server server-active" data-type="ex" data-idx="0" id="episode-10<?php echo $field['mid']; ?>" onclick="load_movie_iframe(10,<?php echo $field['mid']; ?>);" data-drive="<?php echo base64_encode ( $field['url'] ); ?>">
<div class="server-indicator" data-color="0"></div>
<div class="server-title"><img class="server-list-icon" src="<?php echo get_template_directory_uri(); ?>/images/icon-server/mp4.png"> <small><?php echo $field['name']; ?></small></div>
</div>
</div>
<?php } if($field['select'] == 'openload') {  ?>
        <div class="server-wrapper">
            <div class="server " data-type="dv" data-idx="0" id="episode-2<?php echo $field['mid']; ?>" onclick="load_movie_iframe(2, <?php echo $field['mid']; ?>);" data-iframe="<?php echo base64_encode ( $field['url'] ); ?>">
                <div class="server-indicator" data-color="0"></div>
                <div class="server-title"><img class="server-list-icon" src="<?php echo get_template_directory_uri(); ?>/images/icon-server/oload.png"> <small><?php echo $field['name']; ?></small></div>
            </div>
        </div>
<?php } if($field['select'] == 'streamango') {  ?>
<div class="server-wrapper">
<div class="server server-active" data-type="ex" data-idx="0" id="episode-2<?php echo $field['mid']; ?>" onclick="load_movie_iframe(2,  <?php echo $field['mid']; ?>);" data-iframe="<?php echo base64_encode ( $field['url'] ); ?>">
<div class="server-indicator" data-color="0"></div>
<div class="server-title"><img class="server-list-icon" src="<?php echo get_template_directory_uri(); ?>/images/icon-server/mango.png"> <small><?php echo $field['name']; ?></small></div>
</div>
</div>
<?php } if($field['select'] == 'rapidvideo') {  ?>
<div class="server-wrapper">
    <div class="server server-active" data-type="ex" data-idx="0" id="episode-2<?php echo $field['mid']; ?>" onclick="load_movie_iframe(2,  <?php echo $field['mid']; ?>);" data-iframe="<?php echo base64_encode ( $field['url'] ); ?>">
<div class="server-indicator" data-color="0"></div>
<div class="server-title"><img class="server-list-icon" src="<?php echo get_template_directory_uri(); ?>/images/icon-server/r.png"> <small><?php echo $field['name']; ?></small></div>
</div>
</div>
<?php } if($field['select'] == 'vidplay') {  ?>
<div class="server-wrapper">
    <div class="server server-active" data-type="ex" data-idx="0" id="episode-2<?php echo $field['mid']; ?>" onclick="load_movie_iframe(2,  <?php echo $field['mid']; ?>);" data-iframe="<?php echo base64_encode ( $field['url'] ); ?>">
<div class="server-indicator" data-color="0"></div>
<div class="server-title"><img class="server-list-icon" src="<?php echo get_template_directory_uri(); ?>/images/icon-server/vidplay.png"> <small><?php echo $field['name']; ?></small></div>
</div>
</div>
<?php } $numerado++; } } ?>
<?php endif; ?>
</div>
</div>					
<?php } ?>
<div id="colimedia" style="width:100%;margin:auto;background: #000;">
<iframe id="iframe-embed" src="" frameborder="0" width="100%" height="100%" scrolling="no" allowfullscreen></iframe>
</div>    
</div>
<?php get_template_part('includes/bar-player'); ?>
<?php $active = get_option('onbotum'); if ($active == "true") { ?>
<div id="list-eps" style="display:inline-block;border:1px solid #c0c0c0;"><?php  if ( $dt_player ) : ?><?php $numerado = 1; { foreach ( $dt_player as $field ) { ?><?php if($field['select'] == 'iframe') {  ?><a title="" id="episode-2" onclick="load_movie_iframe(2, <?php echo $field['mid']; ?>);" data-iframe="<?php echo base64_encode ( $field['url'] ); ?>"  href="javascript:void(0);" class="btn-eps"><?php echo $field['name']; ?></a><?php } if($field['select'] == 'mp4') {  ?><a title="" id="episode-7" onclick="load_movie_iframe(7, <?php echo $field['mid']; ?>);" data-mp4="<?php echo base64_encode ( $field['url'] ); ?>"  href="javascript:void(0);" class="btn-eps"><?php echo $field['name']; ?></a><?php } if($field['select'] == 'drive') {  ?><a title="" id="episode-8" onclick="load_movie_iframe(8, <?php echo $field['mid']; ?>);" data-drive="<?php echo base64_encode ( $field['url'] ); ?>"  href="javascript:void(0);" class="btn-eps"><?php echo $field['name']; ?></a><?php } if($field['select'] == 'drive-beckup') {  ?><a title="" id="episode-10" onclick="load_movie_iframe(10, <?php echo $field['mid']; ?>);" data-drive="<?php echo base64_encode ( $field['url'] ); ?>"  href="javascript:void(0);" class="btn-eps"><?php echo $field['name']; ?></a><?php } $numerado++; } } ?> <?php endif; ?></div>
<?php } ?> 
<script type="text/javascript">
$(document).ready(function () {
	load_movie_iframe(<?php if (isset($_GET['ep'])) {echo $_GET['ep'];}else {echo $ser = get_option('defultserver');;} ?>, <?php if (isset($_GET['sv'])) {echo $_GET['sv'];}else {echo '1';} ?>);		
});
</script>
<script type="text/javascript">
	var movieperma = "<?php the_permalink() ?>";
	var movieid = "<?php echo $postid; ?>";
	var moviethumbnail = "<?php echo $img = info_movie_get_meta('fondo_player'); ?>";
    var movie = {
        id: "<?php echo $postid; ?>",
        name: "<?php the_title(); ?>",
        type: "movie",
    };
</script>
<div class="clearfix"></div>
<div class="mvi-content" style="display:block">
<?php 
if (have_posts()) :
while (have_posts()) : the_post();
if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
$imgsrc = wp_get_attachment_image_src($postimage->ID, 'full');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = info_movie_get_meta('poster_url')){
$imgsrc = $img;
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
} ?>
                        <div itemscope itemtype="http://schema.org/Movie">
                            <meta itemprop="name" content="<?php the_title(); ?>">
                            <meta itemprop="image" content="<?php echo $img = info_movie_get_meta('poster_url'); ?>">
                            <meta itemprop="datePublished" content="<?php echo $values = info_movie_get_meta("release_date") ?>">
                            <!-- Ads-Custom START -->
                            <div class="kanan kiri">
                                <?php get_template_part('includes/ads-bawah-player'); ?>
                            </div>
                            <!-- Ads-Custom END -->
                            <div class="mvic-desc">
                                <div class="mvic-info" style="font-size:medium">
                                    <div class="mvic-tagline2">
                                        <span id='mv-release' style='display:none;'><?php echo $values = info_movie_get_meta("release_date") ?></span>
                                       <h3 style="display:block"><?php the_title(); ?> </h3>
                                        <div id="socialmovie" style="display:inline-block;">
                                            <div class="fb-share-button" data-href="" data-layout="button_count" data-size="small" data-mobile-iframe="true" style="vertical-align: top; padding-bottom:5px; height: 25px;">
                                                <a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink() ?>"></a>
                                            </div>
                                            <a href="https://twitter.com/share" class="twitter-share-button" data-show-count="false"></a>
                                            <script async src="//platform.twitter.com/widgets.js" style="vertical-align: top; padding-bottom:5px; height: 25px;" charset="utf-8"></script>
                                        </div>
                                        <span class="mv-stat"><?php echo $dato = get_the_term_list($post->ID, 'quality', '', ', ', '')?> | <?php echo $values = info_movie_get_meta("Runtime") ?> <?php _e('Min.', 'indoxxi'); ?> | <?php echo $dato = get_the_term_list($post->ID, 'country', '', ', ', '')?> | <?php echo $dato = mget_the_term_list($post->ID, 'category', '', ', ', '')?></span>
                                    </div>
                                    <div class="thumb mvic-thumb" style="background-image: url(<?php echo $img = info_movie_get_meta('poster_url'); ?>);"></div>
                                    <div class="desc-des-pendek" itemprop="description">
									<div class="mv-rating"><?php echo star_rating(); ?></div>
                                        <?php the_content(); ?>
                                    </div>
                                    <div id="cast" style="display:block">
                                        <strong>Directors: </strong><span itemprop="director" itemscope itemtype="http://schema.org/Person"><?php echo $dato = castget_the_term_list($post->ID, 'director', '', ', ', '')?></span>
                                        <br />
                                        <strong>Actors:</strong> <span itemprop="actor" itemscope itemtype="http://schema.org/Person"><?php echo $dato = castget_the_term_list($post->ID, 'stars', '', ', ', '')?></span>
                                        <br />
                                    </div>
                                </div>
                            </div>
                        </div>
<?php endwhile; endif; ?>
                        <div class="clearfix"></div>
                        <div style="margin-bottom:2em">
                            <div class="terkait" style="margin-top:1em">
                                <span><?php _e('Labels and Related Movies', 'indoxxi'); ?></span>
                            </div>
                            <div id="mv-keywords"><?php $tags = get_the_tags($post->ID);  ?><?php if ( $tags ) { foreach($tags as $tag){ ?><a href="<?php bloginfo('url');?>/tag/<?php print_r($tag->slug);?>"><h5 itemprop="keywords"><?php print_r($tag->name); ?></h5></a><?php } }; ?></div>
                            <div id="terkaitan" class="movies-list movies-list-full">
                                <?php get_template_part('includes/funciones/movies-related'); ?>
                            </div>
                        </div>
                    </div>
<div class="clearfix"></div>
<?php $activar = get_option('comm_mov'); if ($activar == "true") { ?>
<?php include_once 'comentarios.php'; ?>
<?php }?>						
                </div>
                <div id="basabasi" class="content-kus" style="margin-bottom:2em;">
                    <div class="widget" style="color:#000; border-top: 3px solid rgb(198, 170, 40);clear: both;display: block;margin-bottom: 0em;max-height:20vh;padding: 1em; background: rgba(255,255,255,0.24) none repeat scroll;">
                        <h2 style="font-size:medium; display: inline"><a href="<?php the_permalink() ?>">Nonton Film </a>&nbsp;<?php the_title(); ?> </h2>
                        <p style="font-size:small;">Website streaming film terlengkap dan terbaru dengan kualitas terbaik. Hanya di <?php bloginfo('name'); ?> kalian bisa nonton berbagai macam film berkualitas dengan mudah dan gratis tanpa harus registrasi, kami menyediakan berbagai macam film baru maupun klasik bagi para pencinta film box office subtitle indonesia secara lengkap dengan kualitas terbaik. Sekarang <?php bloginfo('name'); ?> menyediakan layanan gratis youtube downloader untuk <a href="#"> download video youtube terbaru </a> (Android, iOS, PC) tanpa perlu install aplikasi / software. Mudah dan Cepat.</p>
                        <p style="font-size:small;"Nonton Film <?php the_title(); ?> di <a href="<?php bloginfo('url'); ?>"> <?php bloginfo('name'); ?> </a> secara gratis tanpa keluar uang dan ngantri, apalagi kehabisan tiket!. Anda juga bisa <a href="/country/united-states">streaming film barat terbaru</a> atau <a href="/genre/drama-korea/">nonton drama korea</a> full season yang kami update dengan jadwal tvshows  seri terbaik anda tidak akan ketinggalan lagi menikmati film series  kesayangan anda dirumah. </p>
                    </div>
                </div>
<div id="infoacak" class="next-inf" style="display:none"><span class="nextinf"></span></div>
<div id="overlay" style="position:fixed"></div>
<div id="extension" style="display:none">0</div>
            </div>
        </div>

        <div id="mundur" style="display:none"></div>
		</div>
       <?php  get_footer(); ?>