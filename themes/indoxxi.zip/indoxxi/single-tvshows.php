<?php get_header(); ?>
    <div id="main" class="page-category" style="padding-top:70px;">
        <!-- Ads-Custom START -->
        <div class="ads-kiri-player">
            <?php get_template_part('includes/ads-kiri-player'); ?>
        </div>
        <div class="ads-kanan-player">
            <?php get_template_part('includes/ads-kanan-player'); ?>
        </div>
        <!-- Ads-Custom END -->
        <div class="kanan kiri main-content main-detail" style="width: 90% !important; max-width:1079px ;">
                    <?php get_template_part('includes/ads-atas-player'); ?>
        </div>
        <div class="container" style="padding-top:5px;min-height:70vh;">
            <div class="main-content main-detail" style="max-width:1079px">
                <div class="main-content main-category">
				<?php echo series_breadcrumbs(); ?>
                    <div id="mv-info">
                        <a href="<?php the_permalink() ?>watch" title="" class="thumb mvi-cover" style="background-image:url(https://images2-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&amp;gadget=a&amp;no_expand=1&amp;refresh=604800&amp;url=<?php if($splash = info_movie_get_meta('fondo_player')){echo $splash;} else {$splash = get_template_directory_uri().'/images/default_splash.jpg'; echo $splash;} ?>)" alt="<?php the_title(); ?>"></a>
                        <div class="btn-watch-area">
                            <div class="bwa-content"><span class="bwac-btn"><i class="fa fa-play"></i></span></div>
                        </div>
                    </div>
					<?php if (have_posts()) :
while (have_posts()) : the_post(); if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
	$imgsrc = wp_get_attachment_image_src($postimage->ID, 'full');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = info_movie_get_meta('poster_url')){
$imgsrc = $img;
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
} ?>
                    <div id="mv-info">
                        <div itemscope itemtype="http://schema.org/Movie" class="mvi-content">
                            <h3 itemprop="name" content="<?php the_title(); ?>"><?php the_title(); ?> <meta itemprop="worstRating" content="1"><meta itemprop="bestRating" content="10"><span itemprop="ratingCount" class="irank" content="<?php echo $values = info_movie_get_meta("serie_vote_count") ?>"><span itemprop="ratingValue" class="irank-voters" content="<?php echo $values = info_movie_get_meta("serie_vote_average") ?>"><?php echo $values = info_movie_get_meta("serie_vote_average") ?></span><?php echo $values = info_movie_get_meta("serie_vote_count") ?></span></h3>
                            <div class="block-trailer" data-target="#pop-trailer" data-toggle="modal">
                                <div itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating" class="imdb-rating"><span class="imdb-logo"><img src="<?php echo get_template_directory_uri(); ?>/images/imdb.png" alt="rating-imdb" data-pin-nopin="true"></span>
                                    <meta itemprop="worstRating" content="1">
                                    <meta itemprop="bestRating" content="10"><span itemprop="ratingValue" class="rating" content="<?php echo $values = info_movie_get_meta("serie_vote_average") ?>"><?php echo $values = info_movie_get_meta("serie_vote_average") ?></span><span itemprop="ratingCount" class="imdb-votes" content="<?php echo $values = info_movie_get_meta("serie_vote_count") ?>"><?php echo $values = info_movie_get_meta("serie_vote_count") ?></span></div>
                                <div class="trailerz"><i class="fa fa-video-camera"></i><span class="trailers">Trailer</span></div>
                            </div><span style="display:block;border-bottom:2px solid #c6aa28;margin-top:5px"></span>
                            <div itemprop="description" class="desc" style="margin-top:1em;min-height:1em">
                                <div class=""></div><span itemprop="reviewBody"> <?php the_content(); ?></span></div>
                            <div class="mvic-desc">
                                <div class="thumb mvic-thumb" style="background-image:url(<?php echo $imgsrc; $imgsrc = ''; ?>)">
                                    <meta itemprop="image" content="<?php echo $img; ?>">
                                </div>
                                <div class="mvic-info">
                                    <div class="mvici-left">
                                        <p><strong>Genre:</strong><?php echo $dato = mget_the_term_list($post->ID, 'category', '', ', ', '')?></p>
                                        <p><strong>Actors:</strong><span itemprop="actor" itemscope itemtype="http://schema.org/Person"><?php echo $dato = castget_the_term_list($post->ID, 'stars', '', ', ', '')?></span>
                                        </p>
                                        <p><strong>Directors:</strong><span itemprop="director" itemscope itemtype="http://schema.org/Person"><?php echo $dato = castget_the_term_list($post->ID, 'director', '', ', ', '')?>
                                            </span>
                                        </p>
                                        
                                    </div>
                                    <div class="mvici-right">
                                        <p><strong>Duration:</strong> <?php echo $values = info_movie_get_meta("episode_run_time") ?> <?php _e('Min', 'indoxxi'); ?></p>
                                        <p><strong>Quality:</strong> <span class="quality"> <?php echo $dato = get_the_term_list($post->ID, 'quality', '', ', ', '')?></span></p>
                                        <p><strong>Release Date:</strong>
                                            <meta itemprop="datePublished" content="<?php echo $values = info_movie_get_meta("air_date") ?>"><?php echo $values = info_movie_get_meta("air_date") ?></p>
                                        <p><strong>Countries:</strong><?php echo $dato = get_the_term_list($post->ID, 'country', '', ', ', '')?></p>
                                    </div>
                                </div>
                                <div class="clearfix"></div>

                                <div id="mv-keywords"><?php $tags = get_the_tags($post->ID);  ?><?php if ( $tags ) { foreach($tags as $tag){ ?><a href="<?php bloginfo('url');?>/tag/<?php print_r($tag->slug);?>"><h5 itemprop="keywords"><?php print_r($tag->name); ?></h5></a><?php } }; ?></div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div><span style="display:block;border-bottom:2px dashed #3c3c3c;margin-top:1em;margin-bottom:1em"></span>
                        <div id="mv-label"><?php get_template_part('includes/funciones/movies-related-title'); ?></div>
                    </div>
					<?php endwhile; endif; ?>
                </div>
            </div>
        </div>
	</div>
        <div class="modal fade modal-cuz modal-trailer" id="pop-trailer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                        <h4 class="modal-title" id="myModalLabel"></h4>
					</div>
                    <div class="modal-body">
                        <div class="modal-body-trailer">
                            <?php if($values = info_movie_get_meta("youtube_id")) { ?><?php $trailers = get_post_meta($post->ID, "youtube_id", $single = true); mostrar_trailer($trailers) ?>
							<?php }else  {?>
                            <div class="no_trailer"><i class="fa fa-warning"></i> <span><?php _e('No Trailer Available', 'psythemes'); ?></span></div>
                            <?php } ?>
                        </div>
                    </div>
					<div class="modal-footer">
                       <button type="button" class="btn btn-default" data-dismiss="modal"><?php _e('Close', 'indoxxi'); ?></button>
                    </div>
                </div>
            </div>
        </div>
<script>
            document.addEventListener("DOMContentLoaded", function() {
                $('#pop-trailer').on('hide.bs.modal', function() {
                    $('#iframe-trailer').attr('src', '');
                    //alert("Bye now!");
                });

            });
 </script>
<?php get_footer(); ?>