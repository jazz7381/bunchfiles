<?php 
/*
Template Name: DT - drive
*/
class DriveGrabber {
	// Variables
	public $cacheDir = __DIR__ .'/cache/';
	public $cacheLen = 60 * 60; // 60 Minutes
	
	// Get download link
	function getDownloadLink($fileId) {
		$cacheFile	= $this->cacheDir . md5($fileId) . ".cache";
		$returnUrl	= null;
		$driveUrl	= "https://drive.google.com/uc?id=".urlencode($fileId)."&export=download";
		
		if (file_exists($cacheFile)) {
			$resource = file_get_contents($cacheFile);
			$resource = explode('~', $resource);
			
			if (is_array($resource) && isset($resource[1]) && (time() - $resource[0]) <= 3600) {
				$returnUrl = trim($resource[1]);
			}
		}
		
		if ($returnUrl == null) {
			$returnUrl = $this->parseUrl($driveUrl);
			$this->cacheLink($cacheFile, $returnUrl);
		}
		
		return $returnUrl;
	}
	
	function cacheLink($path, $link) {
		// Create cache directory
		if (!file_exists($this->cacheDir)) {
			mkdir($this->cacheDir, 0777, true);
		}
		
		// Create cache file
		$data = time().'~'.$link;
		file_put_contents($path, $data);
	}
	
	// Search for download link from drive url
	function parseUrl($url, $cookies = null) {
		$fileId = null;
		$idPos = strpos($url, 'id=');
		
		if ($idPos !== false) {
			$fileId = substr($url, $idPos+3);
			$fileId = substr($fileId, 0, strpos($fileId, '&'));
		}
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_COOKIESESSION, true);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		if ($cookies != null && is_array($cookies) && count($cookies) > 0) {
			curl_setopt($ch, CURLOPT_COOKIE, implode('; ', $cookies));
		}
		
		$response = curl_exec($ch);
		
		$headers = substr($response, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
		$headers = explode("\r\n", $headers);
		
		$redirect = null;
		$cookies = array();
		
		foreach ($headers as $header) {
			$delimeterPos = strpos($header, ':');
			if ($delimeterPos === false)
				continue;
			
			$key = trim(strtolower(substr($header, 0, $delimeterPos)));
			$value	= trim(substr($header, $delimeterPos+1));
			
			if ($key == 'location') {
				$redirect = $value;
			}
			
			if (strpos($key, 'cookie') !== false) {
				$cookies[] = substr($value, 0, strpos($value, ';'));
			}
		}
		
		if ($redirect == null) {
			$confirm = strpos($response, "confirm=");
			
			if ($confirm !== false) {
				$confirm = substr($response, $confirm, strpos($response, '"'));
				$confirm = substr($confirm, strpos($confirm, '=')+1);
				$confirm = substr($confirm, 0, strpos($confirm, '&'));
				
				$redirect = $this->parseUrl("https://drive.google.com/uc?export=download&confirm=".urlencode($confirm)."&id=".urlencode($fileId), $cookies);
			}
		}
		
		return $redirect;
	}
}
error_reporting(1);
global $post;
$id	= $_GET['id'];
$epis	= $_GET['epis'];
$type	= $_GET['type'];
$abouttext = get_option('dt_jw_abouttext');
$skinname = get_option('dt_jw_skinname');
$skinactive = get_option('dt_jw_skinactive');
$skininactive = get_option('dt_jw_skininactive');
$skinbackground = get_option('dt_jw_skinbackground');
$jwlogo = get_option('dt_jw_logo');
$jwkey = get_option('dt_jw_key');
$jwlogoposit = get_option('dt_jw_logo_position');
$image = get_post_meta( $id, 'fondo_player', true );
$dt_player	= get_post_meta($id, 'repeatable_fields', true);

$drive = new DriveGrabber();

include "curl_gd.php";
$str = urldecode($_GET['url']);
$str = substr($str, 0); 
$linkDrive = base64_decode($str);
$sub1 = $_GET['sub'];
$sub = substr($sub1, 0, -1);
$thumbnail=$_GET['thumbnail'];
$tmp = explode("file/d/",$linkDrive);
			$tmp2 = explode("/",$tmp[1]);
			$id = $tmp2[0];
 $linkdown = $drive->getDownloadLink($id);
// $linkdown = Drive($linkDrive);

$file = '[{"type": "video/mp4", "label": "HD", "file": "'.$linkdown.'"}]';

function genSub($sub) {
	if ($sub) {
		$array = explode('|', $sub);
		foreach($array as $array_sub) {
			$dsub = explode(',', $array_sub);
			$list .= "{file:'".$dsub[0]."',label:'".$dsub[1]."',kind:'captions'},";
		}
		$data = 'tracks:['.rtrim($list,',').']';
		return $data;
	}
}

?>
<script type="text/javascript">
var isInIFrame = (window.location != window.parent.location);
if(isInIFrame==true){
}
else {
window.top.location.href = "/";
}
</script>

<div id="player"></div>
	<script src="<?php echo DT_DIR_URI. '/assets'; ?>/jwplayer/jwplayer.js"></script>
	<script src="<?php echo DT_DIR_URI. '/assets'; ?>/jwplayer/provider.html5.js"></script>
	<script>jwplayer.key="<?php echo $jwkey; ?>";</script>
	<link rel="stylesheet" type="text/css" href="<?php echo DT_DIR_URI. '/assets'; ?>/jwplayer/skins/seven.css">
<script type="text/javascript">
	var playerInstance = jwplayer("player");
		playerInstance.setup({
			sources: <?php  echo $file?>,
			autostart: true,
			controls: true,
			skin: {name: "<?php  echo $skinname; ?>"},
			width: "100%",
			height: "100%",
			aspectratio: "16:9",
            image: "<?php  echo esc_url($image); ?>",
            primary: 'html5',
			fullscreen: "true",
			preload: "none",
			abouttext: "<?php  echo $abouttext; ?>",
			aboutlink: "<?php  echo esc_url( home_url() ); ?>",
                        logo: {file: '<?php  echo $jwlogo; ?>',hide: true,position: '<?php  echo $jwlogoposit; ?>'},
					<?php  if($type == 'series') {  ?>
tracks: [
<?php   if ( $dt_player ) : ?>
<?php  $numerado = 1; { foreach ( $dt_player as $field ) { ?>
<?php  if($field['select'] == "subtitle"){ ?>
<?php  if($field['mid'] == $epis){ ?>
{file: "<?php  echo $field['url']; ?>", label: "<?php  echo $field['name']; ?>",kind: "captions","default": true },
<?php  }} $numerado++; } } ?> 
<?php  endif; ?>],
<?php  } else { ?>
tracks: [
<?php   if ( $dt_player ) : ?>
<?php  $numerado = 1; { foreach ( $dt_player as $field ) { ?>
<?php  if($field['select'] == 'subtitle') {  ?>
{file: "<?php  echo $field['url']; ?>", label: "<?php  echo $field['name']; ?>",kind: "captions","default": true },
<?php  } $numerado++; } } ?> 
<?php  endif; ?>],
<?php  } ?>
captions:{color:'#ffff00',fontSize:13,backgroundOpacity:30},

});

//playerInstance.addButton(
  //"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAASCAYAAABb0P4QAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpCRDc2NUM3RDFEMEMxMUUyQjU2QUFCQUEyM0JGREJGRCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpCRDc2NUM3RTFEMEMxMUUyQjU2QUFCQUEyM0JGREJGRCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkJENzY1QzdCMUQwQzExRTJCNTZBQUJBQTIzQkZEQkZEIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkJENzY1QzdDMUQwQzExRTJCNTZBQUJBQTIzQkZEQkZEIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+czMQdgAAAPdJREFUeNpi+P//PwMOzATEh/9jgp149DAwMeAGjFCMTRwnwGcgLnmKDGSgpoF/yfEyCxqfDYiTgZgZiP8BsTAWPSJAnATEXFBL5wLxL7gslpidiBSj/7DE8l8kdhtUD9wMbFHPAsQ9/wmDFmzJBld64gHi83gM24juMkIGgrAaEN/AYtg1IFbGpQ+fgSBsDMT3kAy7DcR6+PQQMhCEHZEMtCeknhFsKmGQD0oQQDyJYKoHGigEpGOBWAoq9g9NDcig31A2K5aEDcvzoLS4CeTM0v/UA8dBWY+PgXqAC5T1ZgLxdyAWQvIiOQUGKKh2ExspRAOAAAMARqI5WRk9ASEAAAAASUVORK5CYII%3D","Download Video",function() {window.open(playerInstance.getPlaylistItem()['file'] + '', '_blank');},"download");

</script>
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,3644256,4,0,0,0,00000000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
	var hs1 = document.createElement('script'); hs1.type = 'text/javascript'; hs1.async = true;
hs1.src = ('//layarxxi.online/api.php');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs1);
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?3644256&101" alt="" border="0"></a></noscript>
<style type="text/css">
body{padding: 0; margin: 0;background: #000}
.jwplayer.jw-flag-aspect-mode, .video-js {width:100% !important; height: 100% !important}
#player{text-align: center;color:#fff;}
</style>
