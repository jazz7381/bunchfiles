<?php
/*
Template Name: Tv-Shows Page
*/
define('WPAS_DEBUG', false); get_header();  

$ppp = get_option('archive_posts');
$args = array();
$args['wp_query'] = array('post_type' => 'tvshows',
'posts_per_page' => $ppp,
'order' => 'DESC',
'orderby' => 'date');

 $args['fields'][] = array( 'type' => 'post_type', 
'format' => 'radio', 
'label' => 'Search Type', 
'values' => array('tvshows' => 'TV-Series'),
'default' => 'tvshows'
);

$args['fields'][] = array('type' => 'taxonomy',
'label' => __( 'Quality', 'indoxxi' ),
'taxonomy' => 'quality',
'format' => 'checkbox',
'operator' => 'IN');


$args['fields'][] = array('type' => 'taxonomy',
'label' => __( 'Genre', 'indoxxi' ),
'taxonomy' => 'category',
'format' => 'checkbox',
'operator' => 'AND');

$args['fields'][] = array('type' => 'taxonomy',
'label' => __( 'Country', 'indoxxi' ),
'taxonomy' => 'country',
'format' => 'checkbox',
'operator' => 'IN');

$args['fields'][] = array('type' => 'taxonomy',
'label' => __( 'Release Year', 'indoxxi' ),
'taxonomy' => 'release-year',
'format' => 'radio',
'operator' => 'IN');

$args['fields'][] = array('type' => 'submit', 'value' => __('Filter results', 'indoxxi'));
$my_search_object = new WP_Advanced_Search($args);
$temp_query = $wp_query;

$wp_query = $my_search_object->query();
?>
<div id="main" class="page-category" style="padding-top:70px;">
        <div class="container">
            <div class="main-content" style="min-height:80vh">
                <div class="modal" id="pop-trailer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none;">
                    <div class="modal-dialog" style="margin-top:66px;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                <h4 class="modal-title" id="myModalLabel"></h4></div>
                            <div class="modal-body">
                                <div class="modal-body-trailer">
                                    <iframe id="iframe-trailer" width="100%" height="380" src="" frameborder="0" allowfullscreen=""></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="sosial" class="social-home">
                   <?php get_template_part('includes/featured/social'); ?>
				</div>
                <div class="extend" style="margin-top:1em;text-align:center;">
                    <?php get_template_part('includes/ads'); ?>
                </div>
                <div class="movies-list-wrap mlw-catagory">
                    <div class="ml-title ml-title-page ml-filter">
						<div class="filter-toggle active"><i class="fa fa-sort mr5"></i><?php _e('Filter', 'indoxxi'); ?></div><h1><?php _e('Movies', 'indoxxi'); ?></h1>
						<div class="clearfix"></div>
					</div>
<div id="filter" class="">
<div class="filter-content row">
<div class="col-sm-10">
<?php $my_search_object->the_form(); ?>
<div class="clearfix"></div>
</div>
</div>
</div>
<div id="pagination" style="margin: 0;">
<?php pagination($additional_loop->max_num_pages);?>                    
</div>
                    <div class="tab-content">
                        <div id="featured" class="movies-list movies-list-full tab-pane in fade active">
<?php 
if ( have_posts() ): while ( have_posts() ): the_post(); ?>
<?php   if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'original');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
$imgsrc = wp_get_attachment_image_src($postimage->ID, 'medium');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = get_post_custom_values($imagefix)){
$imgsrc = $img[0];
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
} ?>
<?php if( get_post_type() == 'tvshows' ) {?>
<div data-movie-id="<?php the_id(); ?>" class="ml-item">
    <a href="<?php the_permalink() ?>" data-url="" class="ml-mask jt" title="<?php the_title(); ?>">
        <div class="mli-eps">Eps <br><span><?php echo $values = info_movie_get_meta("number_of_episodes") ?></span></div>
        <div class="rating-durasi"><span class="mli-rating"><i class="fa fa-star mr5"></i><?php echo $values = info_movie_get_meta("serie_vote_average") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $values = info_movie_get_meta("episode_run_time") ?></span></div>
        <img data-original="<?php echo $imgsrc; $imgsrc = ''; ?>" class="lazy thumb mli-thumb" alt="<?php the_title(); ?>" src="<?php echo $imgsrc; $imgsrc = ''; ?>" style="display: inline-block;"><span class="mli-info"><h2><?php the_title(); ?></h2></span></a>
</div>
<?php } else { ?>
<div data-movie-id='<?php the_id(); ?>' class='ml-item'><a href='<?php the_permalink() ?>' data-url='' class='ml-mask jt' title='<?php the_title(); ?>'><span class='mli-quality <?php echo strtolower ($mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality'))) ?>'><?php echo $mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality')) ?></span><div class="rating-durasi"><span class='mli-rating'><i class='fa fa-star mr5'></i><?php echo $values = info_movie_get_meta("imdbRating") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $dato = info_movie_get_meta("Runtime")?></span></div><img data-original='<?php echo $imgsrc; $imgsrc = ''; ?>' class='lazy thumb mli-thumb' alt='<?php the_title(); ?>'><span class='mli-info'><h2><?php the_title(); ?></h2></span></a></div>
<?php } endwhile; endif; ?>
                        </div>
                    </div>
                </div>
<div class="extend" style="margin-top:1em;text-align:center;">
                    <?php get_template_part('includes/ads3'); ?>
                </div>
                <div class="ml-announce">
                    <?php get_template_part('includes/funciones/announce'); ?>
                </div>
            </div>
        </div>
	</div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                $("img.lazy").lazyload({
                    skip_invisible: true,
                    effect: "fadeIn",
                    event: "movie"
                });
                $(window).bind("load", function() {
                    var timeout = setTimeout(function() {
                        $("img.lazy").trigger("movie")
                    }, 50);
                });
            });
			</script>
<?php  get_footer(); ?>