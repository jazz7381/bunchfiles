<?php
include("../../../wp-config.php");
$filter = get_option('str1_tax');
$suggnum = get_option('latesttv_num');
$cat = get_option('str1_slug');
if($filter == 'category'){
$tax = 'category_name';
} else {
$tax = $filter;
}
$catquery = new WP_Query( $tax.'='.$cat.'&post_type=post&posts_per_page='.$suggnum.'' );
while($catquery->have_posts()) : $catquery->the_post();


if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'medium');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
$imgsrc = wp_get_attachment_image_src($postimage->ID, 'medium');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = get_post_custom_values($imagefix)){
$imgsrc = $img[0];
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
}
$dt_player	= get_post_meta($post->ID, 'repeatable_fields', true);
?>
<div data-movie-id='<?php the_id(); ?>' class='ml-item'><a href='<?php the_permalink() ?>' data-url='' class='ml-mask jt' title='<?php the_title(); ?>'><span class='mli-quality <?php echo strtolower ($mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality'))) ?>'><?php echo $mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality')) ?></span><div class="rating-durasi"><span class='mli-rating'><i class='fa fa-star mr5'></i><?php echo $values = info_movie_get_meta("imdbRating") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $dato = info_movie_get_meta("Runtime")?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div><img src='<?php echo $imgsrc; $imgsrc = ''; ?>' class='lazy thumb mli-thumb' alt='<?php the_title(); ?>'><span class='mli-info'><h2><?php the_title(); ?></h2></span></a></div>
<?php endwhile; wp_reset_query(); ?>
