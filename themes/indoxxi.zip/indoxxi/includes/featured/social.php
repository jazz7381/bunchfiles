<!--social home-->
<div class="addthis_native_toolbox">
      <div class="fb-share-button" data-href="" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php bloginfo('url'); ?>"></a></div>
      <div style="display:inline-block;">
         <a href="https://twitter.com/share" class="twitter-share-button" data-show-count="false"></a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
      </div>
   </div>
   <script type="text/javascript">window.___gcfg = {lang: "id"};
      (function () {
          var po = document.createElement("script");
          po.type = "text/javascript";
          po.async = true;
          po.src = "https://apis.google.com/js/platform.js";
          var s = document.getElementsByTagName("script")[0];
          s.parentNode.insertBefore(po, s);
      })();
   </script><span class="sh-text"><?php _e('Support Kami - Mau Pasang Iklan? Hubungi Kami'); ?></span>
   <span class="sh-gm"><a href="/contact" style="color:#be2e4f!important;" title="iklan">&nbsp;<i class="fa fa-envelope"></i>&nbsp;<b>G-mail</b></a></span>
   <span id="h1qu" style="float:right;margin-left:1em">
      <h1 style="font-size:medium;display:inline"><?php if($message = get_option('sli-social-message')) {?><?php echo $message; ?><?php }?></h1>
   </span>

<!--/social home-->

