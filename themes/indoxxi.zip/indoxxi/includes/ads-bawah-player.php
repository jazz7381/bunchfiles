<?php $active = get_option('homepage-playerpage-bawah'); if ($active == "true") { ?>
	<?php if ($ads = get_option('ads-playerpage-bawah')) { ?><?php echo stripslashes($ads); ?><?php }?>
<?php }?>