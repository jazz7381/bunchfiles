<?php  

$options = array(

/*============================================================================*/

array("type" => "section","icon" => "dashicons-admin-settings","title" => __( "Configuration", "psythemes" ),"id" => "general","expanded" => "true"),

array("type" => "section","icon" => "dashicons-admin-home","title" => __( "Home page", "psythemes" ),"id" => "homepage","expanded" => "false"),

array("type" => "section","icon" => "dashicons-analytics","title" => __( "Advertising", "psythemes" ),"id" => "adsconfig","expanded" => "false"),

array("type" => "section","icon" => "dashicons-chart-area","title" => __( "SEO", "psythemes" ),"id" => "seo-config","expanded" => "false"),

array("type" => "section","icon" => "dashicons-admin-tools","title" => __( "Tools", "psythemes" ),"id" => "general2","expanded" => "false"),

array("section" => "general", "type" => "heading","title" => __( "General Settings", "psythemes" ),"id" => "general-config"),	

array("section" => "general", "type" => "heading","title" => __( "TMDb API", "psythemes" ),"id" => "api-config"),

array("section" => "general", "type" => "heading","title" => __( "Site Notice", "psythemes" ),"id" => "notice-config"),

array("section" => "general", "type" => "heading","title" => __( "Watch Page Settings", "psythemes" ),"id" => "watch-page"),

array("section" => "general", "type" => "heading","title" => __( "Comments", "psythemes" ),"id" => "comentarios-config"),

array("section" => "general", "type" => "heading","title" => __( "Footer Settings", "psythemes" ),"id" => "footer-config"),

array("section" => "adsconfig", "type" => "heading","title" => __( "Ad blocks - Home Page", "psythemes" ),"id" => "ads-homepage-config"),

array("section" => "adsconfig", "type" => "heading","title" => __( "Ad blocks - Player Page", "psythemes" ),"id" => "ads-playerpage-config"),    /* Custom 01 */

array("section" => "adsconfig", "type" => "heading","title" => __( "Ads - Fake Buttons", "psythemes" ),"id" => "ads-buttons-config"),

array("section" => "homepage", "type" => "heading","title" => __( "Latest Movies Modules", "psythemes" ),"id" => "latest-mov"),

array("section" => "homepage", "type" => "heading","title" => __( "Latest TV Series Modules", "psythemes" ),"id" => "latest-tv"),

array("section" => "homepage", "type" => "heading","title" => __( "Streaming Modules", "psythemes" ),"id" => "streaming"),

array("section" => "homepage", "type" => "heading","title" => __( "Latest All Modules", "psythemes" ),"id" => "latest-all"),

array("section" => "homepage", "type" => "heading","title" => __( "Footer Widget Module", "psythemes" ),"id" => "footer-wmodule"),

array("section" => "homepage", "type" => "heading","title" => __( "Modules Leter", "psythemes" ),"id" => "mod-leter"),

array("section" => "general2", "type" => "heading","title" => __( "Minify HTML", "psythemes" ),"id" => "minify-config"),

/* array("section" => "general2", "type" => "heading","title" => __( "External Link Page", "psythemes" ),"id" => "link-config"), */

array("section" => "general2", "type" => "heading","title" => __( "Code Integrations", "psythemes" ),"id" => "dev-config"),

array("section" => "seo-config", "type" => "heading","title" => __( "Basic Settings", "psythemes" ),"id" => "seo-config"),

array("section" => "seo-config", "type" => "heading","title" => __( "Site Verification", "psythemes" ),"id" => "verify-config"),

array("section" => "general", "type" => "heading","title" => __d("JW Player"),"id" => "jwplayer"),


##################  JW Player #######################
array(
	// dt_jw_key
    "under_section" => "jwplayer", 
    "type" => "text",
    "name" => __d('License Key'), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "dt_jw_key",
    "desc" => __d('JW Player 7 (Self-Hosted)'),
    "default" => 'IMtAJf5X9E17C1gol8B45QJL5vWOCxYUDyznpA=='
),

array(
	// dt_jwplayer_page
	"under_section" => "jwplayer", 
    "type" => "pages", 
    "name" => __d('Page jwplayer'), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "dt_jwplayer_page", 
    "desc" => __d('Select page to display player'),
),

array(
	// dt_jw_key
    "under_section" => "jwplayer", 
    "type" => "text",
    "name" => __d('About text'), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "dt_jw_abouttext",
    "desc" => __d('JW Player About text in right click'),
),

array(
	// Small heading
    "under_section" => "jwplayer", 
    "type" => "small_heading", 
    "display_checkbox_id" => "toggle_checkbox_id",
    "title" => __d('Customize player'),
),

array(
	// dt_jw_skinname
	"under_section" => "jwplayer", 
    "type" => "select", 
    "name" => __d('Skin name'), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "dt_jw_skinname", 
    "options" => array(
			"beelden" => "beelden",
			"bekle" => "bekle",
			"five" => "five",
			"glow" => "glow",
			"roundster" => "roundster",
			"seven" => "seven",
			"six" => "six",
			"stormtrooper" => "stormtrooper",
			"vapor" => "vapor"
		), 
    "desc" => __d('Select a skin'),
    "default" => "seven"
),

array(
	// dt_jw_skinactive
	"under_section" => "jwplayer",
	"type" => "color",
	"name" => __d("Active"),
	"id" => "dt_jw_skinactive",
	"desc" => __d("Choose a color"),
	"default" => '#0099ff'
),

array(
	// dt_jw_skininactive
	"under_section" => "jwplayer",
	"type" => "color",
	"name" => __d("Inactive"),
	"id" => "dt_jw_skininactive",
	"desc" => __d("Choose a color"),
	"default" => '#f9f9f9'
),

array(
	// dt_jw_skinbackground
	"under_section" => "jwplayer",
	"type" => "color",
	"name" => __d("Background"),
	"id" => "dt_jw_skinbackground",
	"desc" => __d("Choose a color"),
	"default" => '#000000'
),

array(
	// dt_jw_logo
    "under_section" => "jwplayer", 
    "type" => "image", 
	"display_checkbox_id" => "toggle_checkbox_id",
    "name" => __d('Logo player'),
    "id" => "dt_jw_logo", 
    "desc" => __d('Upload your logo using the Upload Button or insert image URL')
),

array(
	// dt_jw_logo_position
	"under_section" => "jwplayer", 
    "type" => "select", 
    "name" => __d('Logo position'), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "dt_jw_logo_position", 
    "options" => array(
			"top-left" => __d("top-left"),
			"top-right" => __d("top-right"),
			"bottom-left" => __d("bottom-left"),
			"bottom-right" => __d("bottom-right"),
		), 
    "desc" => __d('Select a postion for logo player'),
    "default" => "top-right"
),
// General Settings 
array(
	// dt_jw_logo_position
	"under_section" => "watch-page", 
    "type" => "select", 
    "name" => __d('Default server autostart'), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "defultserver", 
    "options" => array(
			"2" => __d("2"),
			"7" => __d("7"),
			"8" => __d("8"),
			"undefined" => __d("undefined"),
		), 
    "desc" => __d('Select a default server [2=iframe.  7=mp4. 8=drive]  if undefined autoembed from https://pelistream.com/embed/'),
    "default" => "undefined"
),

array(
    "under_section" => "watch-page",
    "type" => "checkbox",
    "name" => __d('Select position of server links'),
    "id" => array(
			"onplayer", 
			"onbotum"
		), 
    "options" => array( 
			__d("On Player"), 
			__d("under the player")
		), 
    "desc" => __d('Check to enable. <a href=\"https://image.prntscr.com/image/qsoWxW7pRC6NeNHxoHzyOA.png/\" target=\"_blank\">exemple screanshot</a>'),
    "display_checkbox_id" => "toggle_checkbox_id",
    "default" => array(
			"not", 
			"checked"
		)
),


array(
    "under_section" => "general-config",
    "type" => "image", //Required
    "placeholder" => __("Upload favicon","psythemes"),
    "name" => __("Site Favicon","psythemes"), //Required
    "id" => "general-favicon", //Required
    "desc" => __("Add favicon, Recommended in .ico format","psythemes"),
    "default" => ""),
array(
    "under_section" => "general-config",
    "type" => "image", //Required
    "placeholder" => __("Upload Logo","psythemes"),
    "name" => __("Header Logo","psythemes"), //Required
    "id" => "header-logo", //Required
    "desc" => __("Add header logo. Recommended size: 300px x 80px","psythemes"),
    "default" => ""),
array(
    "under_section" => "general-config",
    "type" => "image", //Required
    "placeholder" => __("wp-admin Logo","psythemes"),
    "name" => __("Admin Logo","psythemes"), //Required
    "id" => "wpadmin-logo", //Required
    "desc" => __("Replace wp-admin logo. Required dimension's 300px * 80px ","psythemes"),
    "default" => ""),

array(

    "under_section" => "general-config", //Required

    "type" => "text", //Required

    "name" => __( "Google Analytics", "psythemes" ), //Required

    "id" => "analitica", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Insert tracking code to use this function.", "psythemes" ),

    "placeholder" => __( "UA-30189257-31", "psythemes" ),

),




array (
	"under_section" => "general-config",
	"type" => "small_heading",
	"title" => __( "Social Buttons", "psythemes" ),
),



array(
    "under_section" => "general-config", //Required
    "type" => "text", //Required
    "name" => __( "Header - Social Message", "psythemes" ), //Required
    "id" => "sli-social-message", //Required
    "default" => __( "Like and Share our website to support us.", "psythemes" )
),




array(

    "under_section" => "general-config", //Required

    "type" => "small_heading", //Required

    "title" => __( "Configure Pages", "psythemes" ), //Required
),

	array(
	// Field pages
	"under_section" => "general-config", 
    "type" => "pages", 
    "name" => __( "Series Page", "psythemes" ), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "series_archive", 
    "desc" => __( "Select relevant page.", "psythemes" )
),

	array(
	// Field pages
	"under_section" => "general-config", 
    "type" => "pages", 
    "name" => __( "Account Page", "psythemes" ), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "account_page", 
    "desc" => __( "Add link to the page (Account Area)", "psythemes" ),
),


array(
    "under_section" => "general-config", //Required
    "type" => "number", //Required
    "name" => __("Archives: Post per page","psythemes"), //Required
    "id" => "archive_posts", //Required
    "desc" => __("Amount of post per page. Recommended: 24 ","psythemes"),
	"default" => "32"
),


array(
	// Field pages
	"under_section" => "general-config", 
    "type" => "pages", 
    "name" => __( "Movies Archive", "psythemes" ), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "mov_archive", 
    "desc" => __( "Select relevant page.", "psythemes" ),
),

array(
	// Field pages
	"under_section" => "general-config", 
    "type" => "pages", 
    "name" => __( "Most Viewed Archive", "psythemes" ), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "mviewed_archive", 
    "desc" => __( "Select relevant page.", "psythemes" ),
),


array(
	// Field pages
	"under_section" => "general-config", 
    "type" => "pages", 
    "name" => __( "Most Favorite Archive", "psythemes" ), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "mfav_archive", 
    "desc" => __( "Select relevant page.", "psythemes" ),
),


array(
	// Field pages
	"under_section" => "general-config", 
    "type" => "pages", 
    "name" => __( "Most Rating Archive", "psythemes" ), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "mrat_archive", 
    "desc" => __( "Select relevant page.", "psythemes" ),
),


array(
	// Field pages
	"under_section" => "general-config", 
    "type" => "pages", 
    "name" => __( "Top IMDb Archive", "psythemes" ), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "topimdb_archive", 
    "desc" => __( "Select relevant page.", "psythemes" ),
),



// TMDb Settings
array(
    "under_section" => "api-config",
    "type" => "checkbox",
    "name" => __("TMDb API","psythemes"),
    "id" => array("tmdbapi"),
    "options" => array( __("Activate","psythemes"), ), 
    "desc" => __("Configure your API on<a href=\"https://www.themoviedb.org/account/\" target=\"_blank\">Themoviedb.org</a>", "psythemes"),
   ),
array(
    "under_section" => "api-config", //Required
    "type" => "text", //Required
    "name" => __( "API Key", "psythemes" ),  //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "tmdbkey", //Required
    "desc" => __( "Add the API Details from themoviedb.org", "psythemes" ),
	"default" => array("6b4357c41d9c606e4d7ebe2f4a8850ea"),
),
array(
    "under_section" => "api-config", 
    "type" => "text", 
    "name" => __('Language API','psythemes'), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "tmdbidioma", 
    "desc" => __('Select language of the generated data.','psythemes'),
    "default" =>"en-US",
),


	
array(
    "under_section" => "api-config",
    "type" => "checkbox",
    "name" => __d('API control'),
    "id" => array(
			"apigenero", 
			"dt_api_upload_poster"
		), 
    "options" => array( 
			__d("Generate genres"), 
			__d("Upload poster image")
		), 
    "desc" => __d('Check to enable.'),
    "display_checkbox_id" => "toggle_checkbox_id",
    "default" => array(
			"checked", 
			"checked"
		)
),

array(
	// Quality
	"under_section" => "api-config", 
    "type" => "select", 
    "name" => __d('Select Quality'), 
    "display_checkbox_id" => "toggle_checkbox_id",
    "id" => "d_quality", 
    "options" => array(
			"HD" => "HD",
			"BLU" => "BLU",
			"CAM" => "CAM",
			"SD" => "SD",
			"TRAILER" => "TRAILER"
		), 
    "desc" => __d('Select a Defult quality for dbmovie'),
    "default" => "HD"
),

array(
    "under_section" => "api-config",
    "type" => "checkbox",
    "name" => __("Add year on title", "psythemes"),
    "id" => array("y_title"),
    "options" => array( __("Activate","psythemes"), ), 
    "desc" => __("Add year on title exemple <strong>Gladiator (2000)</strong>", "psythemes"),
    "default" => array("not")
),
array(
    "under_section" => "api-config",
    "type" => "checkbox",
    "name" => __("Add auto tag", "psythemes"),
    "id" => array("tag_title"),
    "options" => array( __("Activate","psythemes"), ), 
    "desc" => __("Add auto tags <strong>edit dbmovies.php on api folder to add costrum tags</strong>", "psythemes"),
    "default" => array("not")
),
	// Site Notice

array(

    "under_section" => "notice-config",

    "type" => "checkbox",

    "name" => __("Noticebar Module", "psythemes"),

    "id" => array("activar_notice"),

    "options" => array( __("Activate","psythemes"), ), 

    "desc" => __("Active to display the module.", "psythemes"),

    "default" => array("not")

),

array(
    "under_section" => "notice-config", //Required
    "type" => "radio", //Required
    "name" => __( "Appearance", "psythemes" ), //Required
    "id" => "notice_location", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array("home" => __('Home page','psythemes')), //Required
    "default" => "home"
),

array(

    "under_section" => "notice-config", //Required

    "type" => "textarea", 

    "name" => __( "Message", "psythemes" ), //Required

    "id" => "notice", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Add notice, this field accepts HTML", "psythemes" ),

),

array(
	"under_section" => "notice-config",
	"type" => "small_heading",
	"title" => __( "Home Notification", "psythemes" ),
),
array(
    "under_section" => "notice-config",
    "type" => "checkbox",
    "name" => __("Noticebar Module", "psythemes"),
    "id" => array("notice-home-aktifkan"),
    "options" => array( __("Activate","psythemes"), ), 
    "desc" => __("Active to display the module.", "psythemes"),
    "default" => array("not")

),
array(
    "under_section" => "notice-config", //Required
    "type" => "textarea", 
    "name" => __( "Message 1", "psythemes" ), //Required
    "id" => "notice-home-text1", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Add notice, this field accepts HTML", "psythemes" ),

),
array(
    "under_section" => "notice-config", //Required
    "type" => "textarea", 
    "name" => __( "Message 2", "psythemes" ), //Required
    "id" => "notice-home-text2", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Add notice, this field accepts HTML", "psythemes" ),

),
array(
    "under_section" => "notice-config", //Required
    "type" => "textarea", 
    "name" => __( "Message 3", "psythemes" ), //Required
    "id" => "notice-home-text3", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Add notice, this field accepts HTML", "psythemes" ),

),


// Notice Player Settings
array(
	"under_section" => "notice-config",
	"type" => "small_heading",
	"title" => __( "Player Notification", "psythemes" ),
),
array(
    "under_section" => "notice-config",
    "type" => "checkbox",
    "name" => __("Notice Player Module", "psythemes"),
    "id" => array("notice-player-aktifkan"),
    "options" => array( __("Activate","psythemes"), ), 
    "desc" => __("Active to display the module.", "psythemes"),
    "default" => array("not")
),
array(
    "under_section" => "notice-config", //Required
    "type" => "textarea", 
    "name" => __( "Message", "psythemes" ), //Required
    "id" => "notice-player-text1", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Add notice, this field accepts HTML", "psythemes" ),

),

// Comments Settings

array(
    "under_section" => "comentarios-config", //Required
    "type" => "radio", //Required
    "name" => __( "Comments System", "psythemes" ), //Required
    "id" => "comment-sys", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array("wp_comment" => __('Wordpress','psythemes'), "fb_comment" => __('Facebook Comments','psythemes'),"dq_comment" => __('Disqus Comments','psythemes')), //Required
    "desc" => __( "Choose an option", "psythemes" ),
    "default" => "fb_comment"
),

array(
    "under_section" => "comentarios-config", //Required
    "type" => "checkbox", //Required
    "name" => __( "Enable or Disable", "psythemes" ), //Required
    "id" => array("comm_mov", "comm_tv","comm_page"), //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array (__( "Movies", "psythemes" ), __( "TV Series", "psythemes" ), __( "Single Pages", "psythemes" )), //Required
    "desc" => __( "Choose which pages you want the comments section to be enabled.", "psythemes" ),
    "default" => array("checked", "checked", "checked",)
),

array (

	"under_section" => "comentarios-config",
	"type" => "small_heading",
	"title" => __( "Facebook Commnets", "psythemes" ),
),
array (

	"under_section" => "comentarios-config",
	"type" => "tips",
	"text" => __( "We recommend setting these fields to moderate the facebook comments, <a href='https://developers.facebook.com/docs/plugins/comments' target='_blank'>more info</a>", "psythemes" ),
),

array(

    "under_section" => "comentarios-config", //Required

    "type" => "text", //Required

    "name" => __( "Facebook App ID", "psythemes" ), //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "id" => "fb_id", //Required

    "placeholder" => "209955335852854",

    "desc" => __( "Insert you Facebook app id here. If you don't have one for your webpage you can create it <a href='https://developers.facebook.com/apps/' target='_blank'>here</a>", "psythemes" ),

    "default" => ""

),

array(

    "under_section" => "comentarios-config", //Required

    "type" => "text", //Required

    "name" => __( "Admin User", "psythemes" ), //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "id" => "fb_id_admin", //Required

    "desc" => __( "Enter username or user ID to manage comments", "psythemes" ),

    "default" => ""

),

array(

    "under_section" => "comentarios-config", //Required

    "type" => "text", //Required

    "name" => __( "App language", "psythemes" ), //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "id" => "fb_idioma", //Required

    "placeholder" => "en_EN",

    "desc" => __( "Add the language code you want, (es_LA, ro_RO, pt_BR)", "psythemes" ),

    "default" => ""

),


array(
    "under_section" => "comentarios-config", //Required
    "type" => "radio", //Required
    "name" => __( "Color Scheme", "psythemes" ), //Required
    "id" => "fb_color", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array("light" => __('Light Color','psythemes'), "dark" => __('Dark Color','psythemes')), //Required
    "desc" => __( "Choose an option", "psythemes" ),
    "default" => "light"
),

array(

    "under_section" => "comentarios-config", //Required

    "type" => "number", //Required

    "name" => __("Facebook Number of Posts", "psythemes"), //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "id" => "fb_numero", //Required

    "desc" => __("Select number of comments to display per publication", "psythemes"),

    "default" => "10"
	),
	
array(
	"under_section" => "comentarios-config",
	"type" => "small_heading",
	"title" => __( "Disqus Comments", "psythemes" ),
),


array(

    "under_section" => "comentarios-config", //Required

    "type" => "text", //Required

    "name" => __( "Shorname Disqus", "psythemes" ), //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "id" => "disqus_id", //Required

    "placeholder" => "grifus",

    "desc" => __( "Add your community shortname Disqus", "psythemes" ),

    "default" => ""

),

// Footer Settings

array(
    "under_section" => "footer-config",
    "type" => "image", //Required
    "placeholder" => __("Upload Logo","psythemes"),
    "name" => __("Footer Logo","psythemes"), //Required
    "id" => "footer-logo", //Required
    "desc" => __("Add footer logo. Recommended size: 300px x 80px","psythemes"),
    "default" => ""
	),
	


array(
    "under_section" => "footer-config", 
    "type" => "small_heading", 
    "title" => __( "Footer Keywords", "psythemes" ),
),


array(
    "under_section" => "footer-config", //Required
    "type" => "radio", //Required
    "name" => __( "Display Keywords", "psythemes" ), //Required
    "id" => "display-footkey", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array("enable" => __('Enable','psythemes'), "disable" => __('Disable','psythemes')), //Required
    "default" => "enable"
),


array(

    "under_section" => "footer-config", //Required

    "type" => "text", //Required

    "name" => __( "Keyword 1", "psythemes" ), //Required

    "id" => "footkeyword_1", //Required

	"placeholder" => "Watch full movies online",

    "display_checkbox_id" => "toggle_checkbox_id",

    "placeholder" => __( "Leave blank to use default.", "psythemes" )

),

array(

    "under_section" => "footer-config", //Required

    "type" => "text", //Required

    "name" => __( "Keyword 2", "psythemes" ), //Required

    "id" => "footkeyword_2", //Required

	"placeholder" => "Free movies online",

    "display_checkbox_id" => "toggle_checkbox_id",

	
    "placeholder" => __( "Leave blank to use default.", "psythemes" )

),

array(

    "under_section" => "footer-config", //Required

    "type" => "text", //Required

    "name" => __( "Keyword 3", "psythemes" ), //Required

    "id" => "footkeyword_3", //Required

	"placeholder" => "Movietube",

    "display_checkbox_id" => "toggle_checkbox_id",

    "placeholder" => __( "Leave blank to use default.", "psythemes" )

),

array(

    "under_section" => "footer-config", //Required

    "type" => "text", //Required

    "name" => __( "Keyword 4", "psythemes" ), //Required

    "id" => "footkeyword_4", //Required

	"placeholder" => "Free online movies full",

    "display_checkbox_id" => "toggle_checkbox_id",

    "placeholder" => __( "Leave blank to use default.", "psythemes" )

),

array(

    "under_section" => "footer-config", //Required

    "type" => "text", //Required

    "name" => __( "Keyword 5", "psythemes" ), //Required

    "id" => "footkeyword_5", //Required

	"placeholder" => "Movie2k",

    "display_checkbox_id" => "toggle_checkbox_id",

    "placeholder" => __( "Leave blank to use default.", "psythemes" )

),
array(

    "under_section" => "footer-config", //Required

    "type" => "text", //Required

    "name" => __( "Keyword 6", "psythemes" ), //Required

    "id" => "footkeyword_6", //Required

	"placeholder" => "Watch movies 2k",

    "display_checkbox_id" => "toggle_checkbox_id",

    "placeholder" => __( "Leave blank to use default.", "psythemes" )

),

### HOMEPAGE ####
array(
    "under_section" => "mod-leter",
    "type" => "checkbox",
    "name" => __("Module filter by leter","psythemes"),
    "id" => array("modleter"),
    "options" => array( __("Activate","psythemes"), ), 
    "default" => array("checked")),
array(
    "under_section" => "mod-leter", //Required
    "type" => "number", //Required
    "name" => __("Items Amount","psythemes"), //Required
    "id" => "modleter_num", //Required
    "desc" => __("Enter amount of movies you want to display in mod leter default is 20","psythemes"),
	"default" => ("20")),	
	
// Latest Movies Module 


array(
    "under_section" => "latest-mov",
    "type" => "checkbox",
    "name" => __("Latest Movies Module","psythemes"),
    "id" => array("movsmodule"),
    "options" => array( __("Activate","psythemes"), ), 
    "default" => array("checked")),
array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Module Title","psythemes"), //Required
    "id" => "latestmov_title", //Required
    "placeholder" => __("Latest Movies","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Latest Movies")),
array(
    "under_section" => "latest-mov", //Required
    "type" => "number", //Required
    "name" => __("Items Amount","psythemes"), //Required
    "id" => "latestmov_num", //Required
    "desc" => __("Enter amount of movies you want to display in homepage","psythemes"),
	"default" => ("16")),
	
	
array (
	"under_section" => "latest-mov",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 1", "indoxxi" ),
),	

array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Tab 1","indoxxi"), //Required
    "id" => "mtb1_title", //Required
    "placeholder" => __("Tab Title","indoxxi"),
    "desc" => __("Leave blank to use default title.","indoxxi"),
	"default" => ("Tab 1")),

array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","indoxxi"), //Required
    "id" => "mtb1_tax", //Required
	"placeholder" => __("category","indoxxi"),
    "desc" => __("Enter Taxonomy","indoxxi"),
	"default" => ("category")),
	
array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","indoxxi"), //Required
    "id" => "mtb1_slug", //Required
	"placeholder" => __("drama","indoxxi"),
    "desc" => __("Enter Taxonomy slug","indoxxi"),
	"default" => ("drama")),
// tab2	
array (
	"under_section" => "latest-mov",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 2", "indoxxi" ),
),	

array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Tab 2","indoxxi"), //Required
    "id" => "mtb2_title", //Required
    "placeholder" => __("Tab Title","indoxxi"),
    "desc" => __("Leave blank to use default title.","indoxxi"),
	"default" => ("Tab 2")),

array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","indoxxi"), //Required
    "id" => "mtb2_tax", //Required
	"placeholder" => __("category","indoxxi"),
    "desc" => __("Enter Taxonomy","indoxxi"),
	"default" => ("country")),
	
array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","indoxxi"), //Required
    "id" => "mtb2_slug", //Required
	"placeholder" => __("drama","indoxxi"),
    "desc" => __("Enter Taxonomy slug","indoxxi"),
	"default" => ("usa")),
	
// tab3	
array (
	"under_section" => "latest-mov",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 3", "indoxxi" ),
),	

array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Tab 3","indoxxi"), //Required
    "id" => "mtb3_title", //Required
    "placeholder" => __("Tab Title","indoxxi"),
    "desc" => __("Leave blank to use default title.","indoxxi"),
	"default" => ("Tab 3")),
array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","indoxxi"), //Required
    "id" => "mtb3_tax", //Required
	"placeholder" => __("category","indoxxi"),
    "desc" => __("Enter Taxonomy","indoxxi"),
	"default" => ("release-year")),
	
array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","indoxxi"), //Required
    "id" => "mtb3_slug", //Required
	"placeholder" => __("drama","indoxxi"),
    "desc" => __("Enter Taxonomy slug","indoxxi"),
	"default" => ("2017")),
// tab4	
array (
	"under_section" => "latest-mov",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 4", "indoxxi" ),
),	

array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Tab 4","indoxxi"), //Required
    "id" => "mtb4_title", //Required
    "placeholder" => __("Tab Title","indoxxi"),
    "desc" => __("Leave blank to use default title.","indoxxi"),
	"default" => ("Tab 4")),
array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","indoxxi"), //Required
    "id" => "mtb4_tax", //Required
	"placeholder" => __("category","indoxxi"),
    "desc" => __("Enter Taxonomy","indoxxi"),
	"default" => ("category")),
	
array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","indoxxi"), //Required
    "id" => "mtb4_slug", //Required
	"placeholder" => __("drama","indoxxi"),
    "desc" => __("Enter Taxonomy slug","indoxxi"),
	"default" => ("action")),
// tab5	
array (
	"under_section" => "latest-mov",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 5", "indoxxi" ),
),	

array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Tab 5","indoxxi"), //Required
    "id" => "mtb5_title", //Required
    "placeholder" => __("Tab Title","indoxxi"),
    "desc" => __("Leave blank to use default title.","indoxxi"),
	"default" => ("Tab 5")),
array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","indoxxi"), //Required
    "id" => "mtb5_tax", //Required
	"placeholder" => __("category","indoxxi"),
    "desc" => __("Enter Taxonomy","indoxxi"),
	"default" => ("category")),
	
array(
    "under_section" => "latest-mov", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","indoxxi"), //Required
    "id" => "mtb5_slug", //Required
	"placeholder" => __("drama","indoxxi"),
    "desc" => __("Enter Taxonomy slug","indoxxi"),
	"default" => ("comedy")),
	
// Footer Widget Module
array(
    "under_section" => "footer-wmodule",
    "type" => "checkbox",
    "name" => __("Latest TV Shows Module","psythemes"),
    "id" => array("fwmodule-activated"),
    "options" => array( __("Activate","psythemes"), ), 
    "default" => array("checked")),
array (
	"under_section" => "footer-wmodule",
	"type" => "small_heading",
	"title" => __( "Kolom 1", "psythemes" ),
),	
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule1_title", //Required
    "placeholder" => __("Tab 01","psythemes"),
    "desc" => __("Judul Kolom.","psythemes"),
    "default" => ("Tab 1")),
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule1_url", //Required
    "placeholder" => __("#","psythemes"),
    "desc" => __("Link yang dituju","psythemes"),
    "default" => ("#")),
array (
	"under_section" => "footer-wmodule",
	"type" => "small_heading",
	"title" => __( "Kolom 2", "psythemes" ),
),	
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule2_title", //Required
    "placeholder" => __("Tab 02","psythemes"),
    "desc" => __("Judul Kolom.","psythemes"),
    "default" => ("Tab 2")),
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule2_url", //Required
    "placeholder" => __("#","psythemes"),
    "desc" => __("Link yang dituju","psythemes"),
    "default" => ("#")),
array (
    "under_section" => "footer-wmodule",
    "type" => "small_heading",
    "title" => __( "Kolom 3", "psythemes" ),
),	
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule3_title", //Required
    "placeholder" => __("Tab 03","psythemes"),
    "desc" => __("Judul Kolom.","psythemes"),
    "default" => ("Tab 3")),
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule3_url", //Required
    "placeholder" => __("#","psythemes"),
    "desc" => __("Link yang dituju","psythemes"),
    "default" => ("#")),
array (
    "under_section" => "footer-wmodule",
    "type" => "small_heading",
    "title" => __( "Kolom 4", "psythemes" ),
),	
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule4_title", //Required
    "placeholder" => __("Tab 04","psythemes"),
    "desc" => __("Judul Kolom.","psythemes"),
    "default" => ("Tab 4")),
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule4_url", //Required
    "placeholder" => __("#","psythemes"),
    "desc" => __("Link yang dituju","psythemes"),
    "default" => ("#")),
array (
    "under_section" => "footer-wmodule",
    "type" => "small_heading",
    "title" => __( "Kolom 5", "psythemes" ),
),	
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule5_title", //Required
    "placeholder" => __("Tab 05","psythemes"),
    "desc" => __("Judul Kolom.","psythemes"),
    "default" => ("Tab 5")),
array(
    "under_section" => "footer-wmodule", //Required
    "type" => "text", //Required
    "name" => __("Title","psythemes"), //Required
    "id" => "fwmodule5_url", //Required
    "placeholder" => __("#","psythemes"),
    "desc" => __("Link yang dituju","psythemes"),
    "default" => ("#")),
    
// Latest TV-Series Module 
	
array(
    "under_section" => "latest-tv",
    "type" => "checkbox",
    "name" => __("Latest TV Shows Module","psythemes"),
    "id" => array("tvmodule"),
    "options" => array( __("Activate","psythemes"), ), 
    "default" => array("checked")),
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Module Title","psythemes"), //Required
    "id" => "latesttv_title", //Required
    "placeholder" => __("Latest TV Series","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Latest TV Series")),
array(
    "under_section" => "latest-tv", //Required
    "type" => "number", //Required
    "name" => __("Items","psythemes"), //Required
    "id" => "latesttv_num", //Required
    "desc" => __("Enter amount of tv series you want to display in homepage","psythemes"),
	"default" => ("16")),
	
array (
	"under_section" => "latest-tv",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 1", "psythemes" ),
),	

array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Tab 1","psythemes"), //Required
    "id" => "stb1_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 1")),

array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "stb1_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("category")),
	
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "stb1_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("drama")),
// tab2	
array (
	"under_section" => "latest-tv",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 2", "psythemes" ),
),	

array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Tab 2","psythemes"), //Required
    "id" => "stb2_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 2")),

array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "stb2_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("country")),
	
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "stb2_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("us")),
	
// tab3	
array (
	"under_section" => "latest-tv",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 3", "psythemes" ),
),	

array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Tab 3","psythemes"), //Required
    "id" => "stb3_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 3")),
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "stb3_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("release-year")),
	
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "stb3_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("2017")),
// tab4	
array (
	"under_section" => "latest-tv",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 4", "psythemes" ),
),	

array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Tab 4","psythemes"), //Required
    "id" => "stb4_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 4")),
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "stb4_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("studio")),
	
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "stb4_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("20th-century-fox-television")),
// tab5	
array (
	"under_section" => "latest-tv",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 5", "psythemes" ),
),	

array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Tab 5","psythemes"), //Required
    "id" => "stb5_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 5")),
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "stb5_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("networks")),
	
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "stb5_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
    "default" => ("nickelodeon")),
// tab6	
array (
	"under_section" => "latest-tv",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 6", "psythemes" ),
),	

array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Tab 6","psythemes"), //Required
    "id" => "stb6_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 6")),
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "stb6_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("networks")),
	
array(
    "under_section" => "latest-tv", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "stb6_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
    "default" => ("nickelodeon")),
    
    
// Streaming Module 
	
array(
    "under_section" => "streaming",
    "type" => "checkbox",
    "name" => __("Streaming Module","psythemes"),
    "id" => array("stremodule"),
    "options" => array( __("Activate","psythemes"), ), 
    "default" => array("checked")),
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Module Title","psythemes"), //Required
    "id" => "streaming_title", //Required
    "placeholder" => __("Streaming","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Streaming")),
array(
    "under_section" => "streaming", //Required
    "type" => "number", //Required
    "name" => __("Items","psythemes"), //Required
    "id" => "streaming_num", //Required
    "desc" => __("Enter amount of tv series you want to display in homepage","psythemes"),
	"default" => ("16")),
	
array (
	"under_section" => "streaming",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 1", "psythemes" ),
),	

array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Tab 1","psythemes"), //Required
    "id" => "str1_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 1")),

array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "str1_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("category")),
	
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "str1_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("drama")),
// tab2	
array (
	"under_section" => "streaming",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 2", "psythemes" ),
),	

array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Tab 2","psythemes"), //Required
    "id" => "str2_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 2")),

array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "str2_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("country")),
	
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "str2_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("us")),
	
// tab3	
array (
	"under_section" => "streaming",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 3", "psythemes" ),
),	

array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Tab 3","psythemes"), //Required
    "id" => "str3_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 3")),
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "str3_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("release-year")),
	
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "str3_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("2017")),
// tab4	
array (
	"under_section" => "streaming",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 4", "psythemes" ),
),	

array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Tab 4","psythemes"), //Required
    "id" => "str4_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 4")),
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "str4_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("studio")),
	
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "str4_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("20th-century-fox-television")),
// tab5	
array (
	"under_section" => "streaming",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 5", "psythemes" ),
),	

array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Tab 5","psythemes"), //Required
    "id" => "str5_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 5")),
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "str5_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("networks")),
	
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "str5_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
    "default" => ("nickelodeon")),
// tab6	
array (
	"under_section" => "streaming",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 6", "psythemes" ),
),	

array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Tab 6","psythemes"), //Required
    "id" => "str6_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 6")),
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "str6_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("networks")),
	
array(
    "under_section" => "streaming", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "str6_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
    "default" => ("nickelodeon")),
    
    
//Latest All Modules Start
	
array(
    "under_section" => "latest-all",
    "type" => "checkbox",
    "name" => __("Latest All Module","psythemes"),
    "id" => array("allmodule"),
    "options" => array( __("Activate","psythemes"), ), 
    "default" => array("checked")),
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Module Title","psythemes"), //Required
    "id" => "latestall_title", //Required
    "placeholder" => __("Latest TV Series","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Latest All Modules")),
array(
    "under_section" => "latest-all", //Required
    "type" => "number", //Required
    "name" => __("Items","psythemes"), //Required
    "id" => "latestall_num", //Required
    "desc" => __("Enter amount of you want to display in homepage","psythemes"),
	"default" => ("16")),
	
array (
	"under_section" => "latest-all",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 1", "psythemes" ),
),	

array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Tab 1","psythemes"), //Required
    "id" => "xtb1_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 1")),

array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "xtb1_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("category")),
	
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "xtb1_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("drama")),
// tab2	
array (
	"under_section" => "latest-all",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 2", "psythemes" ),
),	

array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Tab 2","psythemes"), //Required
    "id" => "xtb2_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 2")),

array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "xtb2_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("country")),
	
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "xtb2_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("us")),
	
// tab3	
array (
	"under_section" => "latest-all",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 3", "psythemes" ),
),	

array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Tab 3","psythemes"), //Required
    "id" => "xtb3_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 3")),
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "xtb3_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("release-year")),
	
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "xtb3_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("2017")),
// tab4	
array (
	"under_section" => "latest-all",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 4", "psythemes" ),
),	

array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Tab 4","psythemes"), //Required
    "id" => "xtb4_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 4")),
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "xtb4_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("studio")),
	
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "xtb4_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
	"default" => ("20th-century-fox-television")),
// tab5	
array (
	"under_section" => "latest-all",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 5", "psythemes" ),
),	

array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Tab 5","psythemes"), //Required
    "id" => "xtb5_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 5")),
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "xtb5_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("networks")),
	
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "xtb5_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
    "default" => ("nickelodeon")),
// tab6	
array (
	"under_section" => "latest-all",
	"type" => "small_heading",
	"title" => __( "Config Hompage Tabs 6", "psythemes" ),
),	

array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Tab 6","psythemes"), //Required
    "id" => "xtb6_title", //Required
    "placeholder" => __("Tab Title","psythemes"),
    "desc" => __("Leave blank to use default title.","psythemes"),
	"default" => ("Tab 6")),
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy","psythemes"), //Required
    "id" => "xtb6_tax", //Required
	"placeholder" => __("category","psythemes"),
    "desc" => __("Enter Taxonomy","psythemes"),
	"default" => ("networks")),
	
array(
    "under_section" => "latest-all", //Required
    "type" => "text", //Required
    "name" => __("Taxonomy Slug","psythemes"), //Required
    "id" => "xtb6_slug", //Required
	"placeholder" => __("drama","psythemes"),
    "desc" => __("Enter Taxonomy slug","psythemes"),
    "default" => ("nickelodeon")),
// Latest All Modules Stop 

### ADVERTISING ###

// ADS - HOME PAGE

array (
	"under_section" => "ads-homepage-config",
	"type" => "small_heading",
	"title" => __( "Location: Before Suggestion Module", "psythemes" )
),

array(

    "under_section" => "ads-homepage-config",

    "type" => "checkbox",

    "name" => __("Display ad", "psythemes"),

    "id" => array("homepage-ad-above"),

    "options" => array("Activate"), 

),


array(

    "under_section" => "ads-homepage-config", //Required

    "type" => "text", //Required

    "name" => __( "Title", "psythemes" ), //Required

    "id" => "ads-homepage-1-title", //Required

    "display_checkbox_id" => "toggle_checkbox_id",
    
	"placeholder" => __( "Interesting for you", "psythemes" ),
	
	"desc" => __( "Leave blank to disable title.", "psythemes" ),

    "default" => ""

),

array(

    "under_section" => "ads-homepage-config", //Required

    "type" => "textarea", //Required

    "name" => __( "Codes", "psythemes" ), //Required

    "id" => "ads-homepage-1-code", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Add HTML code. Responsive ads is recommended.", "psythemes" ),

    "default" => ""

),
/* ----------------------------------------Custom 02---------------------------------------- */
array (
	"under_section" => "ads-playerpage-config",
	"type" => "small_heading",
	"title" => __( "Iklan Diatas Player", "psythemes" )
),
array(

    "under_section" => "ads-playerpage-config",

    "type" => "checkbox",

    "name" => __("Display ad", "psythemes"),

    "id" => array("homepage-playerpage-atas"),

    "options" => array("Activate"), 

),
array(

    "under_section" => "ads-playerpage-config", //Required

    "type" => "textarea", //Required

    "name" => __( "Kode Iklan", "psythemes" ), //Required

    "id" => "ads-playerpage-atas", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Pastekan code HTML Iklan ke form diatas (Khusus Bagian <b>Iklan Atas Player</b>)", "psythemes" ),

    "default" => ""

),
array (
	"under_section" => "ads-playerpage-config",
	"type" => "small_heading",
	"title" => __( "Iklan Dibawah Player", "psythemes" )
),
array(

    "under_section" => "ads-playerpage-config",

    "type" => "checkbox",

    "name" => __("Display ad", "psythemes"),

    "id" => array("homepage-playerpage-bawah"),

    "options" => array("Activate"), 

),
array(

    "under_section" => "ads-playerpage-config", //Required

    "type" => "textarea", //Required

    "name" => __( "Kode Iklan", "psythemes" ), //Required

    "id" => "ads-playerpage-bawah", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Pastekan code HTML Iklan ke form diatas (Khusus Bagian <b>Iklan Bawah Player</b>)", "psythemes" ),

    "default" => ""

),
array (
	"under_section" => "ads-playerpage-config",
	"type" => "small_heading",
	"title" => __( "Iklan Dikiri Player", "psythemes" )
),
array(

    "under_section" => "ads-playerpage-config",

    "type" => "checkbox",

    "name" => __("Display ad", "psythemes"),

    "id" => array("homepage-playerpage-kiri"),

    "options" => array("Activate"), 

),
array(

    "under_section" => "ads-playerpage-config", //Required

    "type" => "textarea", //Required

    "name" => __( "Kode Iklan", "psythemes" ), //Required

    "id" => "ads-playerpage-kiri", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Pastekan code HTML Iklan ke form diatas (Khusus Bagian <b>Iklan DiKiri Player</b>)", "psythemes" ),

    "default" => ""

),
array (
	"under_section" => "ads-playerpage-config",
	"type" => "small_heading",
	"title" => __( "Iklan Dikanan Player", "psythemes" )
),
array(

    "under_section" => "ads-playerpage-config",

    "type" => "checkbox",

    "name" => __("Display ad", "psythemes"),

    "id" => array("homepage-playerpage-kanan"),

    "options" => array("Activate"), 

),
array(

    "under_section" => "ads-playerpage-config", //Required

    "type" => "textarea", //Required

    "name" => __( "Kode Iklan", "psythemes" ), //Required

    "id" => "ads-playerpage-kanan", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Pastekan code HTML Iklan ke form diatas (Khusus Bagian <b>Iklan DiKanan Player</b>)", "psythemes" ),

    "default" => ""

),
/*---------------------------------------- Custom 02 End ----------------------------------------*/


array (
	"under_section" => "ads-homepage-config",
	"type" => "small_heading",
	"title" => __( "Location: After Suggestion Module", "psythemes" )
),


array(

    "under_section" => "ads-homepage-config",

    "type" => "checkbox",

    "name" => __("Display ad", "psythemes"),

    "id" => array("homepage-ad-after"),

    "options" => array("Activate"), 

),


array(

    "under_section" => "ads-homepage-config", //Required

    "type" => "text", //Required

    "name" => __( "Title", "psythemes" ), //Required

    "id" => "ads-homepage-2-title", //Required

    "display_checkbox_id" => "toggle_checkbox_id",
    
	"placeholder" => __( "Interesting for you", "psythemes" ),
	
	"desc" => __( "Leave blank to disable title.", "psythemes" ),

    "default" => ""

),

array(

    "under_section" => "ads-homepage-config", //Required

    "type" => "textarea", //Required

    "name" => __( "Codes", "psythemes" ), //Required

    "id" => "ads-homepage-2-code", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Add HTML code. Responsive ads is recommended.", "psythemes" ),

    "default" => ""

),

array (
	"under_section" => "ads-homepage-config",
	"type" => "small_heading",
	"title" => __( "Location: Before Footer", "psythemes" )
),


array(

    "under_section" => "ads-homepage-config",

    "type" => "checkbox",

    "name" => __("Display ad", "psythemes"),

    "id" => array("homepage-ad-before"),

    "options" => array("Activate"), 

),


array(

    "under_section" => "ads-homepage-config", //Required

    "type" => "text", //Required

    "name" => __( "Title", "psythemes" ), //Required

    "id" => "ads-homepage-3-title", //Required

    "display_checkbox_id" => "toggle_checkbox_id",
    
	"placeholder" => __( "Interesting for you", "psythemes" ),
	
	"desc" => __( "Leave blank to disable title.", "psythemes" ),

    "default" => ""

),

array(

    "under_section" => "ads-homepage-config", //Required

    "type" => "textarea", //Required

    "name" => __( "Codes", "psythemes" ), //Required

    "id" => "ads-homepage-3-code", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Add HTML code. Responsive ads is recommended.", "psythemes" ),

    "default" => ""

),


// Fake Buttons 
array(

    "under_section" => "ads-buttons-config",

    "type" => "checkbox",

    "name" => __("Fake Buttons", "psythemes"),

    "id" => array("fake-buttons"),

	"img_desc" => "https://image.prntscr.com/image/izcZgUs8Tgqqi5STA2K4vg.png",
	
    "options" => array( __("Activate","psythemes"), ), 

    "desc" => __("Display fake 'Stream' & 'Download' buttons.", "psythemes"),

    "default" => array("not")

),

array (

	"under_section" => "ads-buttons-config",
	"type" => "small_heading",
	"title" => __( "Fake Button 1", "psythemes" )
),

array(

    "under_section" => "ads-buttons-config",

    "type" => "text",

    "name" => __("Title", "psythemes"),

    "id" => "ads-button-1-title",

    "default" => "Stream in HD",
	
	"desc" => __( "Leave blank to use default.", "psythemes" )

),

array(

    "under_section" => "ads-buttons-config",

    "type" => "text",

    "name" => __("URL", "psythemes"),

    "id" => "ads-button-1-url",
	
	"placeholder" => "http://"

),



array (

	"under_section" => "ads-buttons-config",
	"type" => "small_heading",
	"title" => __( "Fake Button 2", "psythemes" )
),

array(

    "under_section" => "ads-buttons-config",

    "type" => "text",

    "name" => __("Title", "psythemes"),

    "id" => "ads-button-2-title",

    "default" => __( "Download in 1080P", "psythemes" ),
	
	"desc" => __( "Leave blank to use default.", "psythemes" )

),

array(

    "under_section" => "ads-buttons-config",

    "type" => "text",

    "name" => __("URL", "psythemes"),

    "id" => "ads-button-2-url",
	
	"placeholder" => "http://"

),

array (

	"under_section" => "ads-buttons-config",
	"type" => "small_heading",
	"title" => __( "Fake Button 3", "psythemes" )
),

array(

    "under_section" => "ads-buttons-config",

    "type" => "text",

    "name" => __("Title", "psythemes"),

    "id" => "ads-button-3-title",

    "default" => __( "Download in SD", "psythemes" ),
	
	"desc" => __( "Leave blank to use default.", "psythemes" )

),

array(

    "under_section" => "ads-buttons-config",

    "type" => "text",

    "name" => __("URL", "psythemes"),

    "id" => "ads-button-3-url",
	
	"placeholder" => "http://"

),

array (

	"under_section" => "ads-buttons-config",
	"type" => "small_heading",
	"title" => __( "Fake Button 4", "psythemes" )
),

array(

    "under_section" => "ads-buttons-config",

    "type" => "text",

    "name" => __("Title", "psythemes"),

    "id" => "ads-button-4-title",

    "default" => __( "Download in HD", "psythemes" ),
	
	"desc" => __( "Leave blank to use default.", "psythemes" )

),

array(

    "under_section" => "ads-buttons-config",

    "type" => "text",

    "name" => __("URL", "psythemes"),

    "id" => "ads-button-4-url",
	
	"placeholder" => "http://"

),

## DEVELOPER AREA 

// Code Integrations


array(

    "under_section" => "dev-config", //Required

    "type" => "textarea", //Required

    "name" => __( "Extra integration code", "psythemes" ), //Required

    "id" => "html_integration", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Make your HTML integration with the theme code.", "psythemes" ),

    "default" => ""

),

array(

    "under_section" => "dev-config",

    "type" => "checkbox",

    "name" => __("Custom CSS","psythemes"),

    "id" => array("activate_css"),

    "options" =>array( __("Enable","psythemes"), ), 

	"desc" => __("Enable custom CSS codes", "psythemes"),

    "default" => array("not"),
),

array(

    "under_section" => "dev-config", //Required

    "type" => "textarea", 

    "name" => __( "CSS Codes", "psythemes" ), //Required

    "id" => "code_css", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Add only CSS code without &lt;style&gt;&lt;/style&gt;", "psythemes" ),

),

array(

    "under_section" => "dev-config",

    "type" => "checkbox",

    "name" => __("Custom Javascript","psythemes"),

    "id" => array("activate_js"),

    "options" =>array( __("Enable","psythemes"), ), 

	"desc" => __("Enable custom Java Script code", "psythemes"),

    "default" => array("not")

),

array(

    "under_section" => "dev-config", //Required

    "type" => "textarea", 

    "name" => __( "Java Script Codes", "psythemes" ), //Required

    "id" => "code_js", //Required

    "display_checkbox_id" => "toggle_checkbox_id",

    "desc" => __( "Add only Javascript codes without &lt;script&gt;&lt;/script&gt;", "psythemes" ),

),


// Minify HTML
array(
    "under_section" => "minify-config",
    "type" => "radio",
    "name" => __("Minify HTML","psythemes"),
    "id" => "minify_html_active",
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array(
		"yes" => __('Enable','psythemes'),
		"no" => __('Disable','psythemes'),
	),
    "desc" => __('Enable or disable Minify HTML','psythemes'),
    "default" => "no"
),

array(
    "under_section" => "minify-config",
    "type" => "radio",
    "name" => __("Code comments","psythemes"),
    "id" => "minify_html_comments",
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array(
		"yes" => __('Yes','psythemes'),
		"no" => __('No','psythemes'),
	),
    "desc" => __('Remove HTML, JavaScript and CSS comments, this option is typically safe to set to (Yes)','psythemes'),
    "default" => "yes"
),


array(
    "under_section" => "minify-config",
    "type" => "radio",
    "name" => __("HTML5 void elements","psythemes"),
    "id" => "minify_html_xhtml",
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array(
		"yes" => __('Yes','psythemes'),
		"no" => __('No','psythemes'),
	),
    "desc" => __('Remove XHTML closing tags from HTML5 void elements','psythemes'),
    "default" => "no"
),

array(
	// minify_html_scheme
    "under_section" => "minify-config",
    "type" => "radio",
    "name" => __("Schemes (HTTP: and HTTPS:)","psythemes"),
    "id" => "minify_html_scheme",
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array(
		"yes" => __('Yes','psythemes'),
		"no" => __('No','psythemes'),
	),
    "desc" => __('Remove schemes (HTTP: and HTTPS:) from all URLs','psythemes'),
    "default" => "no"
),


array(
    "under_section" => "minify-config",
    "type" => "radio",
    "name" => __("Relative domain","psythemes"),
    "id" => "minify_html_relative",
    "display_checkbox_id" => "toggle_checkbox_id",
    "options" => array(
		"yes" => __('Yes','psythemes'),
		"no" => __('No','psythemes'),
	),
    "desc" => __('Remove relative domain from internal URLs','psythemes'),
    "default" => "no"
),


## SEO

// Basic Config
array (

	"under_section" => "seo-config",
	"type" => "tips",
	"text" => __( "Disable Basic SEO if you're using any other SEO plugin. That way the theme's SEO features won't conflict with the other seo plugin. Activate it only if you dont have any other seo plugin installed.", "psythemes" ),
),

array(
    "under_section" => "seo-config",
    "type" => "checkbox",
    "name" => __("Basic SEO", "psythemes"),
    "id" => array("basic-seo"),
    "options" => array( __("Activate","psythemes"), ), 
    "default" => array("checked")
),	

array(

    "under_section" => "seo-config", //Required
    "type" => "text", //Required
    "name" => __( "Site Title", "psythemes" ), //Required
    "id" => "blogname", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
),
array(

    "under_section" => "seo-config", //Required
    "type" => "text", //Required
    "name" => __( "Site Tagline", "psythemes" ), //Required
    "id" => "blogdescription", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "In a few words, explain what this site is about.", "psythemes" ),
),
array (
	"under_section" => "seo-config",
	"type" => "small_heading",
	"title" => __( "Site Information", "psythemes" ),
),

array(

    "under_section" => "seo-config", //Required
    "type" => "text", //Required
    "name" => __( "Main Keywords", "psythemes" ), //Required
    "id" => "seo-main-keywords", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Add main keywords. Separated by comma. Ex: key1, key2, key3", "psythemes" ),
),

array(

    "under_section" => "seo-config", //Required
    "type" => "textarea", //Required
    "name" => __( "Meta Description", "psythemes" ), //Required
    "id" => "seo-meta-description", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Add meta description.", "psythemes" ),
),


// Site Verification


array(

    "under_section" => "verify-config", //Required
    "type" => "text", //Required
    "name" => __( "Google Search Console", "psythemes" ), //Required
    "id" => "veri_google", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Get your verification code <a href='https://www.google.com/webmasters/verification/' target='_blank'>here</a>", "psythemes" ),
	"placeholder" =>__("a7lfzzbajVeMUroaLoypnLWlo-2v7Cj9ijd-Binzqws","psythemes"),
),

array(

    "under_section" => "verify-config", //Required
    "type" => "text", //Required
    "name" => __( "Alexa Verification ID", "psythemes" ), //Required
    "id" => "veri_alexa", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Get your verification code <a href='https://www.alexa.com/siteowners/claim/' target='_blank'>here</a>", "psythemes" ),
	"placeholder" =>__("jwbHtpHudFeOXI1-WKw5tNyCpFQ","psythemes"),
),


array(

    "under_section" => "verify-config", //Required
    "type" => "text", //Required
    "name" => __( "Bing Webmaster Tools", "psythemes" ), //Required
    "id" => "veri_bing", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Get your verification code <a href='https://www.bing.com/toolbox/webmaster/' target='_blank'>here</a>", "psythemes" ),
	"placeholder" =>__("CF37B212DE4857D8DCB5756C26CCC732","psythemes"),
),



array(

    "under_section" => "verify-config", //Required
    "type" => "text", //Required
    "name" => __( "Yandex Webmaster Tools", "psythemes" ), //Required
    "id" => "veri_yandex", //Required
    "display_checkbox_id" => "toggle_checkbox_id",
    "desc" => __( "Get your verification code <a href='https://yandex.com/support/webmaster/service/rights.xml#how-to' target='_blank'>here</a>", "psythemes" ),
	"placeholder" =>__("d1e2bff8b0cbaf00","psythemes"),
),





    );
?>