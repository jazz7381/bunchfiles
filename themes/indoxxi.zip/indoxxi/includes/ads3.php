<?php $active = get_option('homepage-ad-after'); if ($active == "true") { ?>
	<?php if ($ads = get_option('ads-homepage-3-code')) { ?><?php echo stripslashes($ads); ?><?php }?>
<?php }?>