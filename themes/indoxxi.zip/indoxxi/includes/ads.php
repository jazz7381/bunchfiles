<?php $active = get_option('homepage-ad-above'); if ($active == "true") { ?>
	<?php if ($ads = get_option('ads-homepage-1-code')) { ?><?php echo stripslashes($ads); ?><?php }?>
<?php }?>