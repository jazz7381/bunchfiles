<?php $active = get_option('homepage-playerpage-atas'); if ($active == "true") { ?>
	<?php if ($ads = get_option('ads-playerpage-atas')) { ?><?php echo stripslashes($ads); ?><?php }?>
<?php }?>