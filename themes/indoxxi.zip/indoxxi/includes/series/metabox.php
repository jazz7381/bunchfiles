<?php


function series_get_meta( $value ) {
	global $post;

	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}
function series_add_meta_box() {
	add_meta_box(
		'psy-content-info',
		__( 'TV Series Information', 'psythemes' ),
		'series_html',
		'tvshows',
		'normal',
		'default'
	);
}
add_action( 'add_meta_boxes', 'series_add_meta_box' ); function series_html( $post) { wp_nonce_field( '_series_nonce', 'series_nonce' ); ?>


<table class="options-table-responsive psy-details-table">
	<tbody>
		<tr id="ids_box">
		<td class="label">
			<label for="ids"><?php _e('Generate Data','psythemes'); ?></label>
			<p class="description"><?php _e('Generate data from','psythemes'); ?> <strong>tmdb.org</strong></p>
		</td>
		<td style="background: #f7f7f7" class="field">
		<input class="extra-small-text" type="text" name="id" id="id" value="<?php echo series_get_meta( 'id' ); ?>" placeholder="<?php _e('1402','psythemes'); ?>">
		<input class="extra-small-text" type="text" name="temporada" id="temporada" value="<?php echo series_get_meta( 'temporada' ); ?>" placeholder="<?php _e('1','psythemes'); ?>">
		<input type="button" class="button button-primary generate" name="generartv" value="<?php _e('Generate Data','psythemes'); ?>">

			<p class="description">E.g. https://www.themoviedb.org/tv/<strong>1402</strong>-the-walking-dead</p>
			<p id="verify" style="display:none"><a class="button button-secondary" id="comprovate"><?php _e('Check duplicate content','psythemes'); ?></a><p>
		</p></td>
	</tr>
	<tr>
		<td colspan="2"><h3><?php _e('Images and Trailer','psythemes'); ?></h3></td>
	</tr>
			
		<tr id="psy_poster_box">
		<td class="label">
			<label for="psy_poster"><?php _e('Poster','psythemes'); ?></label>
			<p class="description"><?php _e('Add url image','psythemes'); ?></p>
		</td>
		<td class="field">
		<input class="regular-text" type="text" name="poster_url" id="poster_url" value="<?php echo series_get_meta( 'poster_url' ); ?>">
<input id="boton" class="up_images upaa button-secondary" type="button" value="<?php _e('Upload', 'psythemes'); ?>" />
		</td>
	</tr>
	<tr id="psy_backdrop_box">
		<td class="label">
			<label for="psy_backdrop"><?php _e('Main Backdrop','psythemes'); ?></label>
			<p class="description"><?php _e('Add url image','psythemes'); ?></p>
		</td>
		<td class="field">
<input class="regular-text" type="text" name="fondo_player" id="fondo_player" value="<?php echo info_movie_get_meta( 'fondo_player' ); ?>">
<input id="boton" class="up_images upaa button-secondary" type="button" value="<?php _e('Upload', 'psythemes'); ?>" />
		</td>
	</tr>
	<tr id="imagenes_box">
		<td class="label">
			<label for="imagenes"><?php _e('Backdrops','psythemes'); ?></label>
			<p class="description"><?php _e('Place each image url below another','psythemes'); ?></p>
		</td>
		<td class="field">
<textarea name="imagenes" id="imagenes" rows="5"><?php echo info_movie_get_meta( 'imagenes' ); ?></textarea>
<input id="boton" class="up_images upaa button-secondary" type="button" value="<?php _e('Upload', 'psythemes'); ?>" />
		</td>
	</tr>
	<tr id="youtube_id_box">
		<td class="label">
			<label for="youtube_id"><?php _e('Video trailer','psythemes'); ?></label>
			<p class="description"><?php _e('Add id Youtube video','psythemes'); ?></p>
		</td>
		<td class="field">
			<input class="small-text" type="text" name="youtube_id" id="youtube_id" value="<?php echo info_movie_get_meta( 'youtube_id' ); ?>" placeholder="[RllJtOw0USI]">
			<p class="description">[id_video_youtube]</p>
		</td>
	</tr>
		
			<tr>
		<td colspan="2"><h3><?php _e('TV Series Data','psythemes'); ?></h3></td>
	</tr>
	<tr id="original_title_box">
		<td class="label">
			<label for="original_title"><?php _e('Original title','psythemes'); ?></label>
		</td>
		<td class="field">
		<input class="regular-text" type="text" name="original_name" id="original_name" value="<?php echo series_get_meta( 'original_name' ); ?>">
		</td>
	</tr>
	<tr id="first_air_date_box">
			<td class="label">
				<label for="first_air_date"><?php _e('Firt air date','psythemes'); ?></label>
			</td>
			<td class="field">
			<input class="small-text" type="date" name="first_air_date" id="first_air_date" value="<?php echo series_get_meta( 'first_air_date' ); ?>">
			</td>
		</tr>
<tr id="last_air_date_box">
			<td class="label">
				<label for="last_air_date"><?php _e('Last air date','psythemes'); ?></label>
			</td>
			<td class="field">
				<input class="small-text" type="date" name="last_air_date" id="last_air_date" value="">
			</td>
		</tr>
	<tr id="rating_tmdb_box">
		<td class="label">
			<label for="vote_average"><?php _e('Rating TMDb','psythemes'); ?></label>
			<p class="description"><?php _e('Average / votes','psythemes'); ?></p>
		</td>
		<td class="field">
		<input class="extra-small-text" type="text" name="serie_vote_average" id="serie_vote_average" value="<?php echo series_get_meta( 'serie_vote_average' ); ?>"> - 
			<input class="extra-small-text" type="text" name="serie_vote_count" id="serie_vote_count" value="<?php echo series_get_meta( 'serie_vote_count' ); ?>">
		</td>
	</tr>
		<tr id="total_episodes_box">
		<td class="label">
			<label for="number_of_episodes"><?php _e('Number of episodes','psythemes'); ?></label>
		</td>
		<td class="field">
		<input class="regular-text" type="text" name="number_of_episodes" id="number_of_episodes" value="<?php echo series_get_meta( 'number_of_episodes' ); ?>">
		</td>
	</tr>
	<tr id="runtime_box">
		<td class="label">
			<label for="runtime"><?php _e('Runtime','psythemes'); ?></label>
		</td>
		<td class="field">
		<input class="regular-text" type="text" name="episode_run_time" id="episode_run_time" value="<?php echo series_get_meta( 'episode_run_time' ); ?>">
		</td>
	</tr>
	<tr id="status_box">
			<td class="label">
				<label for="status"><?php _e('Status','psythemes'); ?></label>
			</td>
			<td class="field">
			<input class="regular-text" type="text" name="status" id="status" value="<?php echo series_get_meta( 'status' ); ?>">
			</td>
		</tr>
	</tbody>
</table>




















<?php  }
function series_save( $post_id ) {
if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
if ( ! isset( $_POST['series_nonce'] ) || ! wp_verify_nonce( $_POST['series_nonce'], '_series_nonce' ) ) return;
if ( ! current_user_can( 'edit_post', $post_id ) ) return;
insert_genres($post_id, 'tv');
if ( isset( $_POST['id'] ) )
update_post_meta( $post_id, 'id', esc_attr( $_POST['id'] ) );
if ( isset( $_POST['temporada'] ) )
update_post_meta( $post_id, 'temporada', esc_attr( $_POST['temporada'] ) );
if ( isset( $_POST['poster_url'] ) )
update_post_meta( $post_id, 'poster_url', esc_attr( $_POST['poster_url'] ) );
if ( isset( $_POST['fondo_player'] ) )
update_post_meta( $post_id, 'fondo_player', esc_attr( $_POST['fondo_player'] ) );
if ( isset( $_POST['imagenes'] ) )
update_post_meta( $post_id, 'imagenes', esc_attr( $_POST['imagenes'] ) );
if ( isset( $_POST['youtube_id'] ) )
update_post_meta( $post_id, 'youtube_id', esc_attr( $_POST['youtube_id'] ) );
if ( isset( $_POST['number_of_episodes'] ) )
update_post_meta( $post_id, 'number_of_episodes', esc_attr( $_POST['number_of_episodes'] ) );
if ( isset( $_POST['number_of_seasons'] ) )
update_post_meta( $post_id, 'number_of_seasons', esc_attr( $_POST['number_of_seasons'] ) );
if ( isset( $_POST['original_name'] ) )
update_post_meta( $post_id, 'original_name', esc_attr( $_POST['original_name'] ) );
if ( isset( $_POST['status'] ) )
update_post_meta( $post_id, 'status', esc_attr( $_POST['status'] ) );
if ( isset( $_POST['serie_vote_average'] ) )
update_post_meta( $post_id, 'serie_vote_average', esc_attr( $_POST['serie_vote_average'] ) );
if ( isset( $_POST['serie_vote_count'] ) )
update_post_meta( $post_id, 'serie_vote_count', esc_attr( $_POST['serie_vote_count'] ) );
if ( isset( $_POST['episode_run_time'] ) )
update_post_meta( $post_id, 'episode_run_time', esc_attr( $_POST['episode_run_time'] ) );
if ( isset( $_POST['number_of_episodes'] ) )
update_post_meta( $post_id, 'number_of_episodes', esc_attr( $_POST['number_of_episodes'] ) );
if ( isset( $_POST['homepage'] ) )
update_post_meta( $post_id, 'homepage', esc_attr( $_POST['homepage'] ) );
if ( isset( $_POST['first_air_date'] ) )
update_post_meta( $post_id, 'first_air_date', esc_attr( $_POST['first_air_date'] ) );
if ( isset( $_POST['last_air_date'] ) )
update_post_meta( $post_id, 'last_air_date', esc_attr( $_POST['last_air_date'] ) );
if ( isset( $_POST['popularity'] ) )
update_post_meta( $post_id, 'popularity', esc_attr( $_POST['popularity'] ) );
if ( isset( $_POST['type'] ) )
update_post_meta( $post_id, 'type', esc_attr( $_POST['type'] ) );
$titleid = $_POST['id'];

}
add_action( 'save_post', 'series_save' );
function custom_admin_js2() { 
global $post_type; if( $post_type == 'tvshows' ) {	?> 
<style>
.wp-core-ui .generate.button-primary {
	background: #6db535;
    border-color: #6db535 #6db535 #4e901b;
    -webkit-box-shadow: 0 1px 0 #4e901b;
    box-shadow: 0 1px 0 #4e901b;
    color: #fff;
    text-decoration: none;
    text-shadow: 0 0 0 rgba(0, 0, 0, 0.3), 0 0 0 rgba(0, 0, 0, 0.3), 0 0 0 rgba(0, 0, 0, 0.3), 0 0 0 rgba(0, 0, 0, 0.3);
}
.wp-core-ui .generate.button-primary:hover {
	background: #62a72c;
    border-color: #6db535 #6db535 #3f7713;
    -webkit-box-shadow: 0 1px 0 #3f7713;
    box-shadow: 0 1px 0 #3f7713;
}
</style>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/includes/framework/js/idtabstbb.js"></script>
<script>
	jQuery('input[name=generartv]').click(function() {
	var input = jQuery('input[name=id]').get(0).value;
	var psyseason = jQuery('input[name=temporada]').get(0).value;
	var psytemp = '/season/' + psyseason;
	var url = "https://api.themoviedb.org/3/tv/";
	var agregar = "?append_to_response=images,trailers";
	var idioma = "&language=<?php echo get_option('tmdbidioma') ?>&include_image_language=<?php echo get_option('tmdbidioma')?>,null";
	var apikey = "&api_key=<?php echo get_option('tmdbkey')?>";
		// Send Request
    jQuery.getJSON(url + input + psytemp + agregar + idioma + apikey, function(tmdbdata) {
		var valImg = "";
		jQuery.each(tmdbdata, function(key, val) {
		if (key == "poster_path") {
            valImg += "https://image.tmdb.org/t/p/w185" + val + "";
        }
		if (key == "air_date") {
            jQuery('#new-tag-release-year').val(val.slice(0, 4));
        }
		if (key == "episodes") {
            jQuery('#number_of_episodes').val(val.length);
        }
		});
		jQuery('#poster_url').val(valImg);
	});
	// Send Request
    jQuery.getJSON(url + input + agregar + idioma + apikey, function(tmdbdata) {
    var valPlo = "";
    var valImg = "";
    var valBac = "";
	var valTit = "";
    jQuery.each(tmdbdata, function(key, val) {
        jQuery('input[name=' + key + ']').val(val);
			jQuery('#message').remove();
            jQuery('#psy-content-info .inside').prepend('<div id=\"message\" class=\"notice rebskt updated \"><p><?php if(info_movie_get_meta( 'id' )){ _e("The data have been updated, check please","mtms"); } else { _e("Data were completed, check please","mtms"); } ?></p></div>');
			jQuery("#verify").show();			  
        if (key == "name") {
			valTit += val + " " + "Season" + " " + psyseason;
        }
        if (key == "vote_count") {
            jQuery('#serie_vote_count').val(val);
        }
        if (key == "vote_average") {
		
            jQuery('#serie_vote_average').val(val);
        }
				if (key == "overview") {
                    if (typeof tinymce != "undefined") {
                        var editor = tinymce.get('content');
                        if (editor && editor instanceof tinymce.Editor) {
                            editor.setContent(val);
                            editor.save({
                                no_events: true
                            });
                        } else {
                            $('textarea#content').val(val);
                        }
                    }
                }

        if (key == "backdrop_path") {
            valBac += "https://image.tmdb.org/t/p/original" + val + "";
        }
        <?php //$api = get_option('apigenero'); if ($api == "true") { ?>
        if (key == "genres") {
            var genr = "";
            jQuery.each(tmdbdata.genres, function(i, item) {
       	 		genr += "" + item.name + ", ";
				genr1 = item.name;
				jQuery('input[name=newcategory]').val( genr1 );
				jQuery('#category-add-submit').trigger('click');
				jQuery('#category-add-submit').prop("disabled", false);
				jQuery('input[name=newcategory]').val("");
            });
            jQuery('input[name=' + key + ']').val(genr);
        }
        <?php //} ?>
        if (key == "images") {
            var imgt = "";
            jQuery.each(tmdbdata.images.backdrops, function(i, item) {
                imgt += "https://image.tmdb.org/t/p/w300" + item.file_path + "\n";
            });
            jQuery('textarea[name="imagenes"]').val(imgt);
        }
        
		
		       if (key == "created_by") {
            var crea = "";
            jQuery.each(tmdbdata.created_by, function(i, item) {
                crea += item.name + ",";
            });
            jQuery('#new-tag-director').val(crea);
        }
        if (key == "production_companies") {
            var pro = "";
            jQuery.each(tmdbdata.production_companies, function(i, item) {
                pro += item.name + ",";
            });
            jQuery('#new-tag-studio').val(pro);
        }
        if (key == "networks") {
            var net = "";
            jQuery.each(tmdbdata.networks, function(i, item) {
                net += item.name + ",";
            });
            jQuery('#new-tag-networks').val(net);
        }
		if (key == "origin_country") {
            var con = "";
            jQuery.each(tmdbdata.origin_country, function(i, item) {
                con += item + ",";
            });
            jQuery('#new-tag-country').val(con);
        }
        jQuery.getJSON(url + input + "/credits?" + apikey, function(tmdbdata) {
            jQuery.each(tmdbdata, function(key, val) {
                if (key == "cast") {
                    var valCast = "";
                    jQuery.each(tmdbdata.cast, function(i, item) {
                        valCast += "" + item.name + ", "; //
                    });
                    jQuery('#new-tag-stars').val(valCast);
                }
            });
            jQuery.getJSON(url + input + "/videos?" + apikey, function(tmdbdata) {
                jQuery.each(tmdbdata, function(key, val) {
                    var videomt = "";
                    jQuery.each(tmdbdata.results, function(i, item) {
                        videomt += "[" + item.key + "]";
                    });
                    jQuery('#youtube_id').val(videomt.slice(0, 13));
                });
            });
        });
    });
    jQuery('#content').val(valPlo);  
    jQuery('#fondo_player').val(valBac);
	jQuery('#title').val(valTit);
    });
    });
</script>
<?php 
  } }
add_action('admin_footer', 'custom_admin_js2');
function mostrar_trailer_tv($id) {
	if (!empty($id)) { 
		$val = str_replace(
			array("[","]",),
			array('<div class="youtube_id_tv"><iframe width="600" height="450" src="//www.youtube.com/embed/','" frameborder="0" allowfullscreen></iframe></div>',),$id);
		echo $val;
		} else {
			echo '<div class="nodata">'. __('No trailer available','psythemes') .'</div>'; 
		}
}
