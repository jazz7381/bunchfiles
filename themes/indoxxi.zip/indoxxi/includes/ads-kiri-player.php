<?php $active = get_option('homepage-playerpage-kiri'); if ($active == "true") { ?>
<!--start: floating ads-->
<div id="teaser2" style="width:autopx; height:0; text-align:left; display:scroll;position:fixed; top:0px;left:0px;">
<div><a id="close-teaser" onclick="document.getElementById('teaser2').style.display = 'none';" style="cursor:pointer;"><center><img src='http://4.bp.blogspot.com/-9MWyoN5VsJM/TivTpPyUuhI/AAAAAAAABL0/ldO739MTRBg/s1600/close3.png' alt='close' title='close button'/></center></a></div>
<!--Mulai Iklan Kiri-->
<?php if ($ads = get_option('ads-playerpage-kiri')) { ?><?php echo stripslashes($ads); ?><?php }?>
<!--Akhir Iklan Kiri-->
</div>
<!--end: floating ads--> 
<?php }?>
