<?php $activar = "get_option('activar_notice')"; if ($activar == "true") { ?>
<?php if($notice_note = get_option('notice')){?>
<div class="ml-anno" style="margin:2vw"><?php echo stripslashes($notice_note); ?></div>
<?php } }?>