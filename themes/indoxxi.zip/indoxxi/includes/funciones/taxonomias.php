<?php
	register_taxonomy 
	( 'director', 'post', array(
	/* ============================================= */
	'public' => true, 'hierarchical' => false,  'label' => __( 'Directors', 'indoxxi' ),
	'query_var' => true, 'rewrite' => true)
	);
	register_taxonomy 
	( 'stars', 'post', array(
	/* ============================================= */
	'public' => true, 'hierarchical' => false,  'label' => __( 'Actors', 'indoxxi' ),
	'query_var' => true, 'rewrite' => true)
	);
	register_taxonomy 
    ( 'film', array( 'post','tvshows' ), array(
	/* ============================================= */
    'public' => true, 'hierarchical' => false,  'label' => __( 'Film', 'indoxxi' ),
    'query_var' => true, 'rewrite' => true)
    );
	register_taxonomy 
	( 'country', 'post', array(
	/* ============================================= */
	'public' => true, 'hierarchical' => false,  'label' => __( 'Country', 'indoxxi' ),
	'query_var' => true, 'rewrite' => true)
	);
	register_taxonomy 
	( 'release-year', 'post', array(
	/* ============================================= */
	'public' => true, 'hierarchical' => false,  'label' => __( 'Year', 'indoxxi' ),
	'query_var' => true, 'rewrite' => true)
	);
	register_taxonomy 
	( 'quality', 'post', array(
	/* ============================================= */
	'public' => true, 'hierarchical' => false,  'label' => __( 'Quality', 'indoxxi' ),
	'query_var' => true, 'rewrite' => true)
	);
