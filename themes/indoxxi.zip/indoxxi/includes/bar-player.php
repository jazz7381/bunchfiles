                    <div id="bar-player">

                        <div style="float:left">
                            <a class="btn bp-btn-full" onclick="fullscreen('content-embed')"><i class="fa fa-arrows-alt"></i><span></span></a>
                        </div>
<div id="pilsub" class="pil-sub" style="float:right">
</div>
 <div style="float:right" id="dlsub" onclick="downloadS()">
            <a class="btn bp-btn-download"><i class="fa fa-download"></i><span>SUB</span></a>
        </div>
<div id="downloadmv" class="dlmv" style="float: right; display: block;" onclick="downloadMovie()">
<a class="btn bp-btn-download fv"><i class="fa fa-download"></i><span>DOWNLOAD</span></a>
</div>

<?php $active = get_option('fake-buttons'); if ($active == "true") { ?>

                        <div style="float:right">
                            <a id="1080p" style="" href="<?php if ($note = get_option('ads-button-1-url') ) { echo $note; } else { echo '#' ;} ?>" class="btn bp-btn-quality"><span> <?php if ($note = get_option('ads-button-1-title') ) { echo $note; } else { echo 'Stream in HD' ;} ?></span></a>
                        </div>
                        <div style="float:right">
                            <a id="1080p" style="" href="<?php if ($note = get_option('ads-button-2-url') ) { echo $note; } else { echo '#' ;} ?>" class="btn bp-btn-quality"><span> <?php if ($note = get_option('ads-button-2-title') ) { echo $note; } else { echo 'Download in HD' ;} ?></span></a>
                        </div>
						<div style="float:right">
                            <a id="1080p" style="" href="<?php if ($note = get_option('ads-button-3-url') ) { echo $note; } else { echo '#' ;} ?>" class="btn bp-btn-quality"><span> <?php if ($note = get_option('ads-button-3-title') ) { echo $note; } else { echo 'HD 1080p' ;} ?></span></a>
                        </div>
<?php }?>
                        <div id="lampu" style="float:left" onclick='bioskopOn()'>
                            <a href="#mv-info" class="btn bp-btn-light"><i class="fa fa-lightbulb-o"></i><span></span></a>
						</div>
                        <div id="tview" style="float:left">
                            <a class="btn bp-btn-views"><i class="fa fa-eye"></i><span><?php if(function_exists('the_views')) { the_views(); } ?></span></a>
                        </div>
<?php $active = get_option('fake-buttons'); if ($active == "true") { ?>
						 <div id="4" style="float:left">
                            <a id="1080p" style="" href="<?php if ($note = get_option('ads-button-4-url') ) { echo $note; } else { echo '#' ;} ?>" class="btn bp-btn-quality"><span> <?php if ($note = get_option('ads-button-4-title') ) { echo $note; } else { echo 'Download 1080p' ;} ?></span></a>
                        </div>
<?php }?>
                        <style>
                            .facebook-share {
                                background-color: #3b5998;
                                border-radius: 5px;
                                height: 26px;
                                width: 90px;
                                color: white;
                                padding: 0px 0px 0px 6px;
                                font-family: "Lucida Grande", "Tahoma", "Helvetica", "Roboto";
                                font-size: 18px;
                                cursor: pointer;
                                cursor: hand;
                            }
                            
                            .facebook-share span {
                                font-size: 14px;
                            }
                        </style>
                        <div class="clearfix">
                        </div>
                    </div>