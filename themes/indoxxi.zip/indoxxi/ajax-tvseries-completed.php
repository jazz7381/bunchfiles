<?php
include("../../../wp-config.php");
$suggnum = get_option('archive_posts');
$numerado = 1; { query_posts(
array('posts_per_page' => $suggnum,
    'post_type' => array('tvshows'),
    'tax_query' => array(
        array(
          'taxonomy' => 'film',
          'field' => 'slug',
          'terms' => array( 'completed', ),
        )
      )));
while ( have_posts() ) : the_post(); 
$imdbRating = get_post_meta($post->ID, "imdbRating", $single = true); 
if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
$imgsrc = wp_get_attachment_image_src($postimage->ID, 'full');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = get_post_custom_values($imagefix)){
$imgsrc = $img[0];
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
}
$dt_player	= get_post_meta($post->ID, 'repeatable_fields', true);
?>
<div data-movie-id="<?php the_id(); ?>" class="ml-item">
    <a href="<?php the_permalink() ?>" data-url="" class="ml-mask jt" title="<?php the_title(); ?>">
        <div class="mli-eps">Eps <br><span><?php echo $values = info_movie_get_meta("number_of_episodes") ?></span></div>
        <div class="rating-durasi"><span class="mli-rating"><i class="fa fa-star mr5"></i><?php echo $values = info_movie_get_meta("serie_vote_average") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $values = info_movie_get_meta("episode_run_time") ?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div>
        <img class="lazy thumb mli-thumb" alt="<?php the_title(); ?>" src="<?php echo $imgsrc; $imgsrc = ''; ?>" style="display: inline-block;"><span class="mli-info"><h2><?php the_title(); ?></h2></span></a>
</div><?php $numerado++; ?>
<?php endwhile; wp_reset_query(); ?>
<?php } ?>