<?php 
/*
Template Name: DT - jwplayer
*/
if( isset($_GET['source']) and isset($_GET['id']) ) { 
global $post;
$id	= $_GET['id'];
$epis	= $_GET['epis'];
$type	= $_GET['type'];
$source = base64_decode( $_GET['source'] );
$abouttext = get_option('dt_jw_abouttext');
$skinname = get_option('dt_jw_skinname');
$skinactive = get_option('dt_jw_skinactive');
$skininactive = get_option('dt_jw_skininactive');
$skinbackground = get_option('dt_jw_skinbackground');
$jwlogo = get_option('dt_jw_logo');
$jwkey = get_option('dt_jw_key');
$jwlogoposit = get_option('dt_jw_logo_position');
$image = get_post_meta( $id, 'fondo_player', true );
$dt_player	= get_post_meta($id, 'repeatable_fields', true);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<script src="<?php echo DT_DIR_URI. '/assets'; ?>/jwplayer/jwplayer.js"></script>
	<script src="<?php echo DT_DIR_URI. '/assets'; ?>/jwplayer/provider.html5.js"></script>
	<script>jwplayer.key="<?php echo $jwkey; ?>";</script>
	<link rel="stylesheet" type="text/css" href="<?php echo DT_DIR_URI. '/assets'; ?>/jwplayer/skins/seven.css">
	<style>
	html,body{
		height: 100%;
		width: 100%;
		margin: 0;
		overflow: hidden;
	}
	</style>
</head>
<body>
	<div id="video"></div>
	<script type="text/JavaScript">
		var playerInstance = jwplayer("video");
		playerInstance.setup({
			image: '<?php echo esc_url($image); ?>',
			file: '<?php echo esc_url($source); ?>',
			mute: "false",
			autostart: "true",
			repeat: "false",
			abouttext: "<?php echo $abouttext; ?>",
			aboutlink: "<?php echo esc_url( home_url() ); ?>",
			height: "100%",
			width: "100%",
			stretching: "uniform",
			primary: "html5",
			flashplayer: "<?php echo DT_DIR_URI. '/assets'; ?>/jwplayer/jwplayer.flash.swf",
			preload:"none",
			skin: {
				name: "<?php echo $skinname; ?>",
				active: "<?php echo $skinactive; ?>",
				inactive: "<?php echo $skininactive; ?>",
				background: "<?php echo $skinbackground; ?>"
			},
			logo: {
				file: '<?php echo $jwlogo; ?>',
				hide: true,
				link: '<?php echo esc_url( home_url() ); ?>',
				position: '<?php echo $jwlogoposit; ?>',
				},
<?php if($type == 'series') {  ?>
tracks: [
<?php  if ( $dt_player ) : ?>
<?php $numerado = 1; { foreach ( $dt_player as $field ) { ?>
<?php if($field['select'] == "subtitle"){ ?>
<?php if($field['mid'] == $epis){ ?>
{file: "<?php echo $field['url']; ?>", label: "<?php echo $field['name']; ?>",kind: "captions","default": true },
<?php }} $numerado++; } } ?> 
<?php endif; ?>],
<?php } else { ?>
tracks: [
<?php  if ( $dt_player ) : ?>
<?php $numerado = 1; { foreach ( $dt_player as $field ) { ?>
<?php if($field['select'] == 'subtitle') {  ?>
{file: "<?php echo $field['url']; ?>", label: "<?php echo $field['name']; ?>",kind: "captions"},
<?php } $numerado++; } } ?> 
<?php endif; ?>],
<?php } ?>
captions:{color:'#ffff00',fontSize:20,backgroundOpacity:30},
});
</script>
</body>
</html>
<?php } else { 
	_d('Access denied'); 
} ?>