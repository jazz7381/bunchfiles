<?php
/*
Template Name: Country
*/
get_header(); ?>
<div id="main" class="page-category" style="padding-top:70px;">
        <div class="container">
<div class="pad"></div>

<div class="main-content main catagory" style="min-height:461.4px;width:100%">
<div class="jumbotron jumbotron-carousel hidden-print-negara">
<div class="container">
<div class="row">
<div class="col-md-12 text-center"><h1><?php echo get_the_title(); ?></h1><p><?php bloginfo('name'); ?></p> <p><?php bloginfo('description'); ?> </p><div class="actions"></div></div>
</div>
</div>
</div>

<div class="movies-list-wrap mlw-catagory">
<div class="ml-title ml-title-page-negara">
<?php echo dt_show_country() ?>
<div class="clearfix"></div>
</div>
</div>
</div>
</div>
	</div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                $("img.lazy").lazyload({
                    skip_invisible: true,
                    effect: "fadeIn",
                    event: "movie"
                });
                $(window).bind("load", function() {
                    var timeout = setTimeout(function() {
                        $("img.lazy").trigger("movie")
                    }, 50);
                });
            });
			</script>
<?php  get_footer(); ?>