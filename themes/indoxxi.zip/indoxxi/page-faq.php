<?php get_header(); 
/*
Template Name: Page FAQ
*/		
?>
<div id="main" class="page-category" style="padding-top:70px;">
<div class="container">
<div class="pad"></div>
<div class="main-content main-detail">
<div id="bread">
<ol class="breadcrumb">
<li><a href="/"><?php _e('Page faq ', 'indoxxi'); ?></a></li>
<li class="active"><?php the_title(); ?></li>
</ol>
</div>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<div class="infopage">
<div class="infopage-head"><h1><?php the_title(); ?></h1></div>
<div class="content">
<?php the_content(); ?>
</div>
</div>
<?php endwhile; ?>						
<?php else : ?>
<h3 style="margin-left: 10px"><?php _e('No content available', 'indoxxi'); ?></h3>
<?php endif; ?>
</div>
</div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                $("img.lazy").lazyload({
                    skip_invisible: true,
                    effect: "fadeIn",
                    event: "movie"
                });
                $(window).bind("load", function() {
                    var timeout = setTimeout(function() {
                        $("img.lazy").trigger("movie")
                    }, 50);
                });
            });
			
		</script>
<?php  get_footer(); ?>