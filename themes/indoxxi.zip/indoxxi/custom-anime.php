<?php
/*
Template Name: Anime Page
*/
get_header(); ?>
<div id="main" class="page-category" style="padding-top:70px;">
        <div class="container">
            <div class="main-content" style="min-height:80vh">
                <div class="modal" id="pop-trailer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none;">
                    <div class="modal-dialog" style="margin-top:66px;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                <h4 class="modal-title" id="myModalLabel"></h4></div>
                            <div class="modal-body">
                                <div class="modal-body-trailer">
                                    <iframe id="iframe-trailer" width="100%" height="380" src="" frameborder="0" allowfullscreen=""></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="extend" style="margin-top:1em;text-align:center;">
				 <?php get_template_part('includes/ads'); ?>
				</div>
<?php $active = get_option('modleter'); if ($active == "true") { ?>
<div class="extend">
<div class="ml-announce" style="margin-top:1em;text-align:center;">
<ul class="pagination">
<li><a <?php echo $s == '09' ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>">#</a><li>
	<?php for ($l="a";$l!="aa";$l++){?>
	<li><a <?php echo $s == "$l" ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>"><?php echo strtoupper($l); ?></a><li>
	<?php } ?>
</ul>
<div class="clearfix"></div>
</div>
<div class="items_glossary"></div>					
</div>
<?php }?>
<div class="movies-list-wrap mlw-topview mt20">
<?php get_template_part('includes/mobile-menu'); ?>
<?php $active = get_option('movsmodule'); if ($active == "true") { ?>
<div class="ml-title"><span class="pull-left"><?php if($title = get_option('latestmov_title2')){ echo $title; } else { echo 'Anime'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="/nonton-anime/" id="lihatutama" class="pull-right cat-more"><?php _e('View More', 'indoxxi'); ?></a>
<ul role="tablist" class="nav nav-tabs">
<li class="active"><a data-toggle="tab" id="ongoing-anime" role="tab" href="#ongoinganime" aria-expanded="false">Ongoing</a></li>
<li><a onclick="getContent('romance')" data-toggle="tab" id="movies-romance" role="tab" href="#animation-romance" aria-expanded="false">Romance</a></li>
<li><a onclick="getContent('actionadventure')" data-toggle="tab" id="movies-actionadventure" role="tab" href="#animation-actionadventure" aria-expanded="false">Action & Adventure</a></li>
<li><a onclick="getContent('scififantasy')" data-toggle="tab" id="movies-scififantasy" role="tab" href="#animation-scififantasy" aria-expanded="false">Sci-Fi & Fantasy</a></li>
<li><a onclick="getContent('animecompleted')" data-toggle="tab" id="movies-completed" role="tab" href="#animation-animecompleted" aria-expanded="false">Completed</a></li>
<li><a onclick="getContent('movie')" data-toggle="tab" id="movies-movie" role="tab" href="#animation-movie" aria-expanded="false">Movie</a></li>
</ul>
</div>
<div class="tab-content">
<div id="ongoinganime" class="movies-list movies-list-full tab-pane in fade active">
<?php 
$suggnum = get_option('archive_posts');
$numerado = 1; { query_posts(
array('posts_per_page' => '16',
    'post_type' => array('tvshows'),
    'tax_query' => array(
        array(
          'taxonomy' => 'film',
          'field' => 'slug',
          'terms' => array( 'ongoinganime', ),
        )
      )));
while ( have_posts() ) : the_post(); 
$imdbRating = get_post_meta($post->ID, "imdbRating", $single = true); 
if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
$imgsrc = wp_get_attachment_image_src($postimage->ID, 'full');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = info_movie_get_meta('poster_url')){
$imgsrc = $img;
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
}
$dt_player	= get_post_meta($post->ID, 'repeatable_fields', true);
?>
<?php if( get_post_type() == 'tvshows' ) {?>
	<div data-movie-id="<?php the_id(); ?>" class="ml-item">
    <a href="<?php the_permalink() ?>" data-url="" class="ml-mask jt" title="<?php the_title(); ?>">
        <div class="mli-eps">Eps <br><span><?php echo $values = info_movie_get_meta("number_of_episodes") ?></span></div>
        <div class="rating-durasi"><span class="mli-rating"><i class="fa fa-star mr5"></i><?php echo $values = info_movie_get_meta("serie_vote_average") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $values = info_movie_get_meta("episode_run_time") ?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div>
        <img class="lazy thumb mli-thumb" alt="<?php the_title(); ?>" src="<?php echo $imgsrc; $imgsrc = ''; ?>" style="display: inline-block;"><span class="mli-info"><h2><?php the_title(); ?></h2></span></a>
</div>
<?php } else { ?>
<div data-movie-id='<?php the_id(); ?>' class='ml-item'><a href='<?php the_permalink() ?>' data-url='' class='ml-mask jt' title='<?php the_title(); ?>'><span class='mli-quality <?php echo strtolower ($mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality'))) ?>'><?php echo $mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality')) ?></span><div class="rating-durasi"><span class='mli-rating'><i class='fa fa-star mr5'></i><?php echo $values = info_movie_get_meta("imdbRating") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $dato = info_movie_get_meta("Runtime")?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div><img src='<?php echo $imgsrc; $imgsrc = ''; ?>' class='lazy thumb mli-thumb' alt='<?php the_title(); ?>'><span class='mli-info'><h2><?php the_title(); ?></h2></span></a></div>
<?php } ?><?php endwhile; ?>
</div>
<div id="ongoinganime" class="movies-list movies-list-full tab-pane in fade active"></div>
<div id="animation-romance" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="animation-actionadventure" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="animation-scififantasy" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="animation-animecompleted" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="animation-movie" class="movies-list movies-list-full tab-pane in fade"></div>
</div>
<?php }?>
</div>
<div class="extend" style="margin-top:1em;text-align:center;">
<?php get_template_part('includes/ads2'); ?>
</div>
<div class="movies-list-wrap mlw-topview mt20">
<?php get_template_part('includes/mobile-menu'); ?>
<?php $active = get_option('movsmodule'); if ($active == "true") { ?>
<div class="ml-title"><span class="pull-left"><?php if($title = get_option('latestmov_title2')){ echo $title; } else { echo 'Kartun'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="/animation/" id="lihatutama" class="pull-right cat-more"><?php _e('View More', 'indoxxi'); ?></a>
                        <ul role="tablist" class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" id="movie-terbaru" role="tab" href="#animation-terbaru" aria-expanded="false">Latest</a></li>
                            <li><a onclick="getContent('action')" data-toggle="tab" id="movie-action" role="tab" href="#animation-action" aria-expanded="false"><?php $title = get_option('stb2_titlee'); echo $title;?>Action</a></li>
                            <li><a onclick="getContent('adventure')" data-toggle="tab" id="movie-adventure" role="tab" href="#animation-adventure" aria-expanded="false"><?php $title = get_option('stb3_titlee'); echo $title;?>Adventure</a></li>
                            <li><a onclick="getContent('comedy')" data-toggle="tab" id="movie-comedy" role="tab" href="#animation-comedy" aria-expanded="false"><?php $title = get_option('stb4_titlee'); echo $title;?>Comedy</a></li>
                            <li><a onclick="getContent('kartuncompleted')" data-toggle="tab" id="movie-movies" role="tab" href="#animation-kartuncompleted" aria-expanded="false"><?php $title = get_option('stb5_titlee'); echo $title;?>Completed</a></li>
                            <li><a onclick="getContent('movies')" data-toggle="tab" id="movie-movies" role="tab" href="#animation-movies" aria-expanded="false"><?php $title = get_option('stb6_titlee'); echo $title;?>Movie</a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
<div class="tab-content">
<div id="animation-terbaru" class="movies-list movies-list-full tab-pane in fade active">
<?php 
$suggnum = get_option('archive_posts');
$numerado = 1; { query_posts(
array('posts_per_page' => '16',
    'post_type' => array('tvshows'),
    'tax_query' => array(
        array(
          'taxonomy' => 'film',
          'field' => 'slug',
          'terms' => array( 'animation', ),
        )
      )));
while ( have_posts() ) : the_post(); 
$imdbRating = get_post_meta($post->ID, "imdbRating", $single = true); 
if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
$imgsrc = wp_get_attachment_image_src($postimage->ID, 'full');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = info_movie_get_meta('poster_url')){
$imgsrc = $img;
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
}
$dt_player	= get_post_meta($post->ID, 'repeatable_fields', true);
?>
<?php if( get_post_type() == 'tvshows' ) {?>
	<div data-movie-id="<?php the_id(); ?>" class="ml-item">
    <a href="<?php the_permalink() ?>" data-url="" class="ml-mask jt" title="<?php the_title(); ?>">
        <div class="mli-eps">Eps <br><span><?php echo $values = info_movie_get_meta("number_of_episodes") ?></span></div>
        <div class="rating-durasi"><span class="mli-rating"><i class="fa fa-star mr5"></i><?php echo $values = info_movie_get_meta("serie_vote_average") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $values = info_movie_get_meta("episode_run_time") ?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div>
        <img class="lazy thumb mli-thumb" alt="<?php the_title(); ?>" src="<?php echo $imgsrc; $imgsrc = ''; ?>" style="display: inline-block;"><span class="mli-info"><h2><?php the_title(); ?></h2></span></a>
</div>
<?php } else { ?>
<div data-movie-id='<?php the_id(); ?>' class='ml-item'><a href='<?php the_permalink() ?>' data-url='' class='ml-mask jt' title='<?php the_title(); ?>'><span class='mli-quality <?php echo strtolower ($mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality'))) ?>'><?php echo $mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality')) ?></span><div class="rating-durasi"><span class='mli-rating'><i class='fa fa-star mr5'></i><?php echo $values = info_movie_get_meta("imdbRating") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $dato = info_movie_get_meta("Runtime")?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div><img src='<?php echo $imgsrc; $imgsrc = ''; ?>' class='lazy thumb mli-thumb' alt='<?php the_title(); ?>'><span class='mli-info'><h2><?php the_title(); ?></h2></span></a></div>
<?php } ?><?php endwhile; ?>
</div>
<div id="animation-terbaru" class="movies-list movies-list-full tab-pane in fade active"></div>
<div id="animation-action" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="animation-adventure" class="movies-list movies-list-full tab-pane in fade active"></div>
<div id="animation-comedy" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="animation-kartuncompleted" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="animation-movies" class="movies-list movies-list-full tab-pane in fade"></div>
<div class="clearfix"></div>
</div>
<?php } ?>
<div class="extend" style="margin-top:1em;text-align:center;">
                    <?php get_template_part('includes/ads3'); ?>
                </div>
                <div class="ml-announce">
					<?php get_template_part('includes/funciones/announce'); ?>
                </div>
            </div>
        </div>
	</div>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
                $("img.lazy").lazyload({
                    skip_invisible: true,
                    effect: "fadeIn",
                    event: "movie"
                });
                $(window).bind("load", function() {
                    var timeout = setTimeout(function() {
                        $("img.lazy").trigger("movie")
                    }, 50);
                });
            });

function getContent(e) {
   $.ajax({
     type: "GET",
     url: "<?php echo get_template_directory_uri(); ?>/ajax-animation-" + e + ".php",
     success: function(data) {
     $("#animation-"  + e).html(data);
    }
   });
}
</script>
<?php } ?>
<?php } ?>
<?php  get_footer(); ?>