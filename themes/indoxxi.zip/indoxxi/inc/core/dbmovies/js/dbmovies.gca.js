jQuery(document).ready(function($){var wrg='Warning'
var nte='Note'
var ero='Error'
var delay=(function(){var timer=0;return function(callback,ms){clearTimeout(timer);timer=setTimeout(callback,ms);}})();var constyle='color:#119c17;font-family:helvetica,arial;font-size:15px'
$('.nav-tab').click(function(){var type=$(this).attr('data-type')
$('.nav-tab').removeClass('nav-tab-active')
$(this).addClass('nav-tab-active')
$('.cctype').val(type)
$('.genres').removeClass('current_genres')
$('#gn_'+type).addClass('current_genres')
$("#import_all").hide()});$('#show_dbmovies_settings').click(function(){$('.settbox').toggle()
$('.dbmovies_sett_modal').toggle()});$('#hidde_dbmovies_settings').click(function(){$('.settbox').hide()
$('.dbmovies_sett_modal').hide()});$('.dbmovies_sett_modal').click(function(){$('.settbox').hide()
$('.dbmovies_sett_modal').hide()});$(document).on('submit','#dbmovies-save',function(){var that=$(this)
var ajaxurl=dBa.url
$('.perico').addClass("saving")
$('#save_sdbmvs').prop('disabled',true)
$('#save_sdbmvs').val(dBa.saving)
$.ajax({url:ajaxurl,type:'post',data:that.serialize(),error:function(response){console.log(response);},success:function(response){$('.perico').removeClass('saving')
$('#save_sdbmvs').prop('disabled',false)
$('#save_sdbmvs').val(dBa.save)},});return false;});function show_history(){$('#dbmovies_response_history').show()
$("#welcm").after('<li class="jump">'+dBa.completed+'</li>')}

function cimport(id,nonce,type){$('#c'+id).hide()
$('#'+id).removeClass('dbimport')
$('#'+id).addClass('fadeInDown')
$('#'+id).addClass('preimport')
$("#import_all").hide()
$.ajax({url:dBa.url,type:'post',data:{id:id,nonce:nonce,type:type,action:'dt_dbmovies_app_post'},error:function(response){console.log(response)},success:function(response){$("#welcm").after(response)
$('#'+id).removeClass('preimport')
$('#'+id).addClass('dbimported')
$('#'+id).addClass('jump')}});};

function search_dbmovies(){var ajaxurl=dBa.url
var term=$('#term').val();var type=$('#stype').val();var action=$('#saction').val();var page=$('#spage').val();var nonce=$('#nonce').val();$('#dbmovies_response').addClass('dbclick')
$('#dbmsearch').prop('disabled',true)
$('#dbmsearch').val(dBa.loading)
$("#import_all").hide()
$.ajax({url:ajaxurl,type:'POST',data:{type:type,term:term,page:page,action:action,nonce:nonce},error:function(response){console.log(response);},success:function(response){show_history()
$('#dbmovies_response').removeClass('dbclick')
$('#dbmsearch').prop('disabled',false)
$('#dbmsearch').val(dBa.search)
$('#dbmovies_response').html(response)
$('.pagex').click(function(){var page=$(this).data('page')
$('#spage').val(page);$('#dbmsearch').trigger('click');});$('.cimport').click(function(){var id=$(this).data('id')
var type=$(this).data('type')
var nonce=$(this).data('nonce')
cimport(id,nonce,type);return false;});},});
};

$(document).on('submit','#dbmovies-filter',function(){var that=$(this)
var ajaxurl=dBa.url
$('#dbmovies_response').addClass('dbclick')
$('#dbmfilter').prop('disabled',true)
$('#dbmfilter').val(dBa.filtering)
$.ajax({url:ajaxurl,type:'post',data:that.serialize(),error:function(response){console.log(response);},success:function(response){show_history()
$('#dbmovies_response').removeClass('dbclick')
$('#dbmfilter').prop('disabled',false)
$('#dbmfilter').val(dBa.filter)
$('#dbmovies_response').html(response)
$("#import_all").show();$('.pagex').click(function(){var page=$(this).data('page')
$('#page').val(page);$('#dbmfilter').trigger('click');$("#import_all").hide();});$('.cimport').click(function(){var id=$(this).data('id')
var type=$(this).data('type')
var nonce=$(this).data('nonce')
cimport(id,nonce,type);return false;});},});return false;});

$(document).on('submit','#dbmovies-search',function(){search_dbmovies();return false;});
$("#dbmovies-search").keyup(function(){delay(function(){search_dbmovies();},500);return false;});$('.resetfil').click(function(){$('#page').val('1')
$('#spage').val('1')});
$('#activate_dbmovies').click(function(){
	$('#activate_dbmovies').hide()
$('#dbmv').val(dBa.loading)
$('#dbmv').prop('disabled',true)
$.ajax({url:dBa.url,type:'post',data:{action:'register_dbmv'},error:function(response){console.log(response);},success:function(response){$('#dbmv').val(response)
$('#dbmv').removeClass('alert')
$('#dbmv').addClass('keyva')

setTimeout(function(){window.location.reload(1);},2000);}});return false;
}
);



$(document).keyup(function(e){
		if(e.keyCode==27){
			$("#hidde_dbmovies_settings").trigger('click')}
		if(e.keyCode==18){
			$("#show_dbmovies_settings").trigger('click')}
		if(e.keyCode==39){
			$("#nexty").trigger('click')}
		if(e.keyCode==37){
			$("#prevty").trigger('click')}
		}
);

$('#import_all').click(function(){
	$("#import_all").hide()
	$(".cimport").trigger('click')
	return false;
	}
);

}
);