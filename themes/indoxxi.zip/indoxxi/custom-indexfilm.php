<?php
/*
Template Name: Index Film
*/
get_header(); ?>
<div id="main" class="page-category" style="padding-top:70px;">
        <div class="container">
            <div class="main-content" style="min-height:80vh">
                <div class="modal" id="pop-trailer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none;">
                    <div class="modal-dialog" style="margin-top:66px;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                <h4 class="modal-title" id="myModalLabel"></h4></div>
                            <div class="modal-body">
                                <div class="modal-body-trailer">
                                    <iframe id="iframe-trailer" width="100%" height="380" src="" frameborder="0" allowfullscreen=""></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="extend" style="margin-top:1em;text-align:center;">
				 <?php get_template_part('includes/ads'); ?>
				</div>
<div class="ml-title ml-title-page ml-filter" style="margin-top:10px; text-align:center;">
    <h1><?php _e('INDEKS FILM', 'indoxxi'); ?></h1>
</div>
<?php $active = "true"; if ($active == "true") { ?>
<div class="extend" style="margin-bottom: 100px;">
<div class="ml-announce" style="margin-top:1em;text-align:center;">
<ul class="pagination">
<li><a <?php echo $s == '09' ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>">#</a><li>
	<?php for ($l="a";$l!="aa";$l++){?>
	<li><a <?php echo $s == "$l" ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>"><?php echo strtoupper($l); ?></a><li>
	<?php } ?>
</ul>
<div class="clearfix"></div>
</div>
<div class="items_glossary"></div>					
</div></div></div></div>
<?php }?>

<?php  get_footer(); ?>