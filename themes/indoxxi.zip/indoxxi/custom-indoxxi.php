<?php
/*
Template Name: INDOXXI Page
*/
define('WPAS_DEBUG', false); get_header();
?>
<div id="main" class="page-category" style="padding-top:70px;">
        <div class="container">
            <div class="main-content" style="min-height:80vh">
                <div class="modal" id="pop-trailer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none;">
                    <div class="modal-dialog" style="margin-top:66px;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                <h4 class="modal-title" id="myModalLabel"></h4></div>
                            <div class="modal-body">
                                <div class="modal-body-trailer">
                                    <iframe id="iframe-trailer" width="100%" height="380" src="" frameborder="0" allowfullscreen=""></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="sosial" class="social-home">
				   <?php get_template_part('includes/featured/social'); ?>
                </div>
				<div class="extend" style="margin-top:1em;text-align:center;">
				 <?php get_template_part('includes/ads'); ?>
				</div>
<?php $active = get_option('modleter'); if ($active == "true") { ?>
<div class="extend">
<div class="ml-announce" style="margin-top:1em;text-align:center;">
<ul class="pagination">
<li><a <?php echo $s == '09' ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>">#</a><li>
	<?php for ($l="a";$l!="aa";$l++){?>
	<li><a <?php echo $s == "$l" ? 'class="btn btn-letter lglossary"' : 'class="btn btn-letter lglossary"'; ?>  data-type="all" data-glossary="<?php echo $l; ?>"><?php echo strtoupper($l); ?></a><li>
	<?php } ?>
</ul>
<div class="clearfix"></div>
</div>
<div class="items_glossary"></div>					
</div>
<?php }?>
                <div class="movies-list-wrap mlw-topview mt20">
				<?php get_template_part('includes/mobile-menu'); ?>
<?php $active = get_option('movsmodule'); if ($active == "true") { ?>
                    <div class="ml-title"><span class="pull-left"><?php if($title = get_option('latestmov_titlee')){ echo $title; } else { echo 'INDOXXI'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="/21cineplex/" id="lihatutama" class="pull-right cat-more"><?php _e('View More ', 'indoxxi'); ?></a>
                        <ul role="tablist" class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" id="featured-movie" role="tab" href="#featured" aria-expanded="false">Featured</a></li>
                            <li><a onclick="getContent('popular')" data-toggle="tab" id="movies-popular" role="tab" href="#top-popular" aria-expanded="false"><?php $title = get_option('mtb1_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('latest')" data-toggle="tab" id="movies-latest" role="tab" href="#top-latest" aria-expanded="false"><?php $title = get_option('mtb2_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('topmovie')" data-toggle="tab" id="movies-topmovie" role="tab" href="#top-topmovie" aria-expanded="false"><?php $title = get_option('mtb3_title'); echo $title;?></a></li>
							<li><a onclick="getContent('serial')" data-toggle="tab" id="movies-serial" role="tab" href="#top-serial" aria-expanded="false"><?php $title = get_option('mtb4_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('animation')" data-toggle="tab" id="movies-animation" role="tab" href="#top-animation" aria-expanded="false"><?php $title = get_option('mtb5_title'); echo $title;?></a></li>
			                
                        </ul>
                    </div>
<div class="tab-content">
<div id="featured" class="movies-list movies-list-full tab-pane in fade active">
<?php 
$suggnum = get_option('archive_posts');
$numerado = 1; { query_posts(
array('posts_per_page' => $suggnum,
    'post_type' => array('post','tvshows'),
    'tax_query' => array(
        array(
          'taxonomy' => 'release-year',
          'field' => 'slug',
          'terms' => array( '2019','2018','2017','2016','2015','2014', ),
        )
      )));
while ( have_posts() ) : the_post(); 
$imdbRating = get_post_meta($post->ID, "imdbRating", $single = true); 
if (has_post_thumbnail()) {
$imgsrc = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
$imgsrc = $imgsrc[0];
} elseif ($postimages = get_children("post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=0")) {
foreach($postimages as $postimage) {
$imgsrc = wp_get_attachment_image_src($postimage->ID, 'full');
$imgsrc = $imgsrc[0];
}
} elseif (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', get_the_content(), $match) != FALSE) {
$imgsrc = $match[1];
} else {
if($img = info_movie_get_meta('poster_url')){
$imgsrc = $img;
} else {
$img = get_template_directory_uri().'/images/noimg.png';
$imgsrc = $img;
} 
}
$dt_player	= get_post_meta($post->ID, 'repeatable_fields', true);
?>
<?php if( get_post_type() == 'tvshows' ) {?>
	<div data-movie-id="<?php the_id(); ?>" class="ml-item">
    <a href="<?php the_permalink() ?>" data-url="" class="ml-mask jt" title="<?php the_title(); ?>">
        <div class="mli-eps">Eps <br><span><?php echo $values = info_movie_get_meta("number_of_episodes") ?></span></div>
        <div class="rating-durasi"><span class="mli-rating"><i class="fa fa-star mr5"></i><?php echo $values = info_movie_get_meta("serie_vote_average") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $values = info_movie_get_meta("episode_run_time") ?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div>
        <img class="lazy thumb mli-thumb" alt="<?php the_title(); ?>" src="<?php echo $imgsrc; $imgsrc = ''; ?>" style="display: inline-block;"><span class="mli-info"><h2><?php the_title(); ?></h2></span></a>
</div>
<?php } else { ?>
<div data-movie-id='<?php the_id(); ?>' class='ml-item'><a href='<?php the_permalink() ?>' data-url='' class='ml-mask jt' title='<?php the_title(); ?>'><span class='mli-quality <?php echo strtolower ($mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality'))) ?>'><?php echo $mostrar = $terms = strip_tags( $terms = get_the_term_list( $post->ID, 'quality')) ?></span><div class="rating-durasi"><span class='mli-rating'><i class='fa fa-star mr5'></i><?php echo $values = info_movie_get_meta("imdbRating") ?></span><span class="mli-durasi"><i class="fa fa-clock-o mr5"></i><?php echo $dato = info_movie_get_meta("Runtime")?></span></div><div class="mli-subtitle"><?php $i=0; if ( $dt_player ) : foreach ( $dt_player as $field ) {if($field['select'] == 'subtitle') { if($i==2) break; if($field['idioma']) { ?><div class="mli-subtitle-<?php echo $field['idioma']; ?>"></div><?php } $i++; }} endif; ?></div><img src='<?php echo $imgsrc; $imgsrc = ''; ?>' class='lazy thumb mli-thumb' alt='<?php the_title(); ?>'><span class='mli-info'><h2><?php the_title(); ?></h2></span></a></div>
<?php } ?><?php endwhile; ?>
</div>
<div id="top-popular" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="top-latest" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="top-topmovie" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="top-serial" class="movies-list movies-list-full tab-pane in fade"></div>
<div id="top-animation" class="movies-list movies-list-full tab-pane in fade"></div>
                    </div>
<?php }?>
                </div>
                <div class="extend" style="margin-top:1em;text-align:center;">
                    <?php get_template_part('includes/ads2'); ?>
                </div>
<?php $active = get_option('tvmodule'); if ($active == "true") { ?>
                <div class="movies-list-wrap mlw-latestmovie">
                    <div class="ml-title"><span class="pull-left"><?php if($title = get_option('latesttv_title')){ echo $title; } else { echo 'Latest TV Series'; }?><i class="fa fa-chevron-right ml10"></i></span><a href="/tv-series/" id="lihatrekomen" class="pull-right cat-more"><?php _e('View More ', 'indoxxi'); ?></a>
                        <ul role="tablist" class="nav nav-tabs">
                            <li><a onclick="getContent('nowplaying')" data-toggle="tab" id="serial-nowplaying" role="tab" href="#top-nowplaying" aria-expanded="false"><?php $title = get_option('stb1_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('todaypopular')" data-toggle="tab" id="serial-todaypopular" role="tab" href="#top-todaypopular" aria-expanded="false"><?php $title = get_option('stb2_titlee'); echo $title;?>Today Popular</a></li>
                            <li><a onclick="getContent('animeanimation')" data-toggle="tab" id="serial-animeanimation" role="tab" href="#top-animeanimation" aria-expanded="false"><?php $title = get_option('stb2_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('actionadventure')" data-toggle="tab" id="serial-actionadventure" role="tab" href="#top-actionadventure" aria-expanded="false"><?php $title = get_option('stb3_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('horrorthriller')" data-toggle="tab" id="serial-horrorthriller" role="tab" href="#top-horrorthriller" aria-expanded="false"><?php $title = get_option('stb4_title'); echo $title;?></a></li>
                            <li><a onclick="getContent('comedyromance')" data-toggle="tab" id="serial-comedyromance" role="tab" href="#top-comedyromance" aria-expanded="false"><?php $title = get_option('stb5_title'); echo $title;?></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab-content">
                        <div id="top-nowplaying" class="movies-list movies-list-full tab-pane in fade active"></div>
                        <div id="top-todaypopular" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-animeanimation" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-actionadventure" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-horrorthriller" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div id="top-comedyromance" class="movies-list movies-list-full tab-pane in fade"></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
<?php } ?>
                <div class="ml-announce">
					<?php get_template_part('includes/funciones/announce'); ?>
                </div>
            </div>
        </div>
	</div>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
                $("img.lazy").lazyload({
                    skip_invisible: true,
                    effect: "fadeIn",
                    event: "movie"
                });
                $(window).bind("load", function() {
                    var timeout = setTimeout(function() {
                        $("img.lazy").trigger("movie")
                    }, 50);
                });
            });

function getContent(e) {
   $.ajax({
     type: "GET",
     url: "<?php echo get_template_directory_uri(); ?>/ajax-top-" + e + ".php",
     success: function(data) {
     $("#top-"  + e).html(data);
    }
   });
}
</script>
<?php } ?>
<?php  get_footer(); ?>