/*
	jQuery.flexMenu 1.5.1
	https://github.com/352Media/flexMenu
	Description: If a list is too long for all items to fit on one line, display a popup menu instead.
	Dependencies: jQuery, Modernizr (optional). Without Modernizr, the menu can only be shown on click (not hover).
*/

/**
	- TieLabs 06/06/20
	-- Performance Improv.

	- TieLabs 06/03/19
	-- Check if the menu has items if the item is not exists it gives a js error because of .top
	-- Remove active class
	-- Remove the usage of windowHeight | this shouldn't affect the Flexmenu | Performance
*/

(function (factory) {
	if (typeof define === 'function' && define.amd) {
		// AMD. Register as an anonymous module.
		define(['jquery'], factory);
	} else {
		// Browser globals
		factory(jQuery);
	}
}(function ($) {

	var windowWidth  = window.innerWidth;
	var flexObjects  = [], // Array of all flexMenu objects
      resizeTimeout;

	// When the page is resized, adjust the flexMenus.
	$(window).resize(function () {
		clearTimeout(resizeTimeout);
		resizeTimeout = setTimeout(function () {

			var newWidth = window.innerWidth;
			if ( newWidth !== windowWidth ) {
				windowWidth = newWidth;
				$(flexObjects).each(function () {
					$(this).flexMenu({
						'undo' : true
					}).flexMenu(this.options);
				});
			}

		}, 200);
	});

	function collapseAllExcept($menuToAvoid) {
		var $activeMenus,
        $menusToCollapse;

		$activeMenus     = $('li.flexMenu-viewMore.active');
		$menusToCollapse = $activeMenus.not($menuToAvoid);
		$menusToCollapse.find('> ul').hide();
	}


	$.fn.flexMenu = function (options) {

		var checkFlexObject,
			s = $.extend({
				'threshold'     : 2,                           // [integer] If there are this many items or fewer in the list, we will not display a "View More" link and will instead let the list break to the next line. This is useful in cases where adding a "view more" link would actually cause more things to break  to the next line.
				'cutoff'        : 2,                           // [integer] If there is space for this many or fewer items outside our "more" popup, just move everything into the more menu. In that case, also use linkTextAll and linkTitleAll instead of linkText and linkTitle. To disable this feature, just set this value to 0.
				'linkText'      : 'More',                      // [string] What text should we display on the "view more" link?
				'linkTitle'     : 'View More',                 // [string] What should the title of the "view more" button be?
				'linkTextAll'   : 'Menu',                      // [string] If we hit the cutoff, what text should we display on the "view more" link?
				'linkTitleAll'  : 'Open/Close Menu',           // [string] If we hit the cutoff, what should the title of the "view more" button be?
				'shouldApply'   : function() { return true; }, // [function] Function called before applying flexMenu. If it returns false, it will not be applied.
				'showOnHover'   : true,                        // [boolean] Should we we show the menu on hover? If not, we'll require a click. If we're on a touch device - or if Modernizr is not available - we'll ignore this setting and only show the menu on click. The reason for this is that touch devices emulate hover events in unpredictable ways, causing some taps to do nothing.
				'popupAbsolute' : true,                        // [boolean] Should we absolutely position the popup? Usually this is a good idea. That way, the popup can appear over other content and spill outside a parent that has overflow: hidden set. If you want to do something different from this in CSS, just set this option to false.
				'popupClass'    : '',                          // [string] If this is set, this class will be added to the popup
				'undo'          : false                        // [boolean] Move the list items back to where they were before, and remove the "View More" link.
			}, options);

		this.options = s; // Set options on object

		checkFlexObject = $.inArray(this, flexObjects); // Checks if this object is already in the flexObjects array

		if (checkFlexObject >= 0) {
			flexObjects.splice(checkFlexObject, 1); // Remove this object if found
		}
		else {
			flexObjects.push(this); // Add this object to the flexObjects array
		}

		return this.each(function () {

			var $this    = $(this),
			    $items   = $this.find('> li'),
			    numItems = $items.length;


			if( numItems ){

				var firstItemTop = getTop($items) + 20,
				    allInPopup   = false,
				    $lastChild,
				    keepLooking,
				    $moreItem,
				    $moreLink,
				    numToRemove,
				    $menu,
				    i;

				function getTop( $item ) {
					return $item[0].offsetTop;
					//return $item.offset().top;
					//var result = $item[0].getBoundingClientRect();
					//return result.top;
				}

				function needsMenu( $itemOfInterest ) {
					return getTop($itemOfInterest) >= firstItemTop ? true : false;
				}


				if( needsMenu( $items.last() ) && numItems > s.threshold && !s.undo && (s.shouldApply())) { //  && $this.is(':visible')

					var $popup = $('<ul class="flexMenu-popup" style="display:none;' + ((s.popupAbsolute) ? ' position: absolute;' : '') + '"></ul>');

					// Add class if popupClass option is set
					if( s.popupClass ){
						$popup.addClass(s.popupClass);
					}

					// Move all list items after the first to this new popup ul
					for (i = numItems; i > 1; i--) {

						// Find all of the list items that have been pushed below the first item. Put those items into the popup menu. Put one additional item into the popup menu to cover situations where the last item is shorter than the "more" text.
						$lastChild  = $this.find('li:last-child');
						keepLooking = needsMenu( $lastChild );

						// If there only a few items left in the navigation bar, move them all to the popup menu.
						if ((i - 1) <= s.cutoff) { // We've removed the ith item, so i - 1 gives us the number of items remaining.
							$($this.children().get().reverse()).appendTo($popup);
							allInPopup = true;
							break;
						}

						if ( ! keepLooking ){
							break;
						}
						else {
							$lastChild.appendTo( $popup );
						}
					}


					if (allInPopup) {
						$this.append('<li class="flexMenu-viewMore flexMenu-allInPopup"><a href="#" title="' + s.linkTitleAll + '">' + s.linkTextAll + '</a></li>');
					}
					else {
						$this.append('<li class="flexMenu-viewMore"><a href="#" title="' + s.linkTitle + '">' + s.linkText + '</a></li>');
					}

					$moreItem = $this.find('> li.flexMenu-viewMore');

					// Check to see whether the more link has been pushed down. This might happen if the link immediately before it is especially wide.
					if (needsMenu($moreItem)) {
						$this.find('> li:nth-last-child(2)').appendTo($popup);
					}

					// Our popup menu is currently in reverse order. Let's fix that.
					$popup.children().each(function (i, li) {
						$popup.prepend(li);
					});

					$moreItem.append($popup);
					$moreLink = $this.find('> li.flexMenu-viewMore > a');


					$moreLink.click(function (e) {
						// Collapsing any other open flexMenu
						collapseAllExcept($moreItem);
						//Open and Set active the one being interacted with.
						$popup.toggle();
						// $moreItem.toggleClass('active'); By TieLabs
						e.preventDefault();
					});


					if (s.showOnHover && (typeof Modernizr !== 'undefined') && !Modernizr.touch) { // If requireClick is false AND touch is unsupported, then show the menu on hover. If Modernizr is not available, assume that touch is unsupported. Through the magic of lazy evaluation, we can check for Modernizr and start using it in the same if statement. Reversing the order of these variables would produce an error.
						$moreItem.hover(
							function () {
								$popup.show();
								// $(this).addClass('active'); By TieLabs
							},
							function () {
								$popup.hide();
								// $(this).removeClass('active'); By TieLabs
							});
					}
				}

				else if (s.undo && $this.find('ul.flexMenu-popup')) {

					$menu = $this.find('ul.flexMenu-popup');
					numToRemove = $menu.find('li').length;
					for (i = 1; i <= numToRemove; i++) {
						$menu.find('> li:first-child').appendTo($this);
					}
					$menu.remove();
					$this.find('> li.flexMenu-viewMore').remove();
				}


			} // The Number Check Added By TieLabs

		});
	};
}));
