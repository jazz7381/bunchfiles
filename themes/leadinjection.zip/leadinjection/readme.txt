Leadinjection Wordpress Theme
===

Leadinjection is a Wordpress landing page theme built with HTML5, CSS3 and Bootstrap.
It was designed for professional marketers, business owners and affiliates to launch
landing pages within minutes.

* For features list and theme updates log visit:
  https://dev.leadinjection.io/

* Theme documentation is available here:
  https://dev.leadinjection.io/documentation/

* For theme support please open support ticket here:
  http://themeinjection.ticksy.com/


Thanks, Themeinjection