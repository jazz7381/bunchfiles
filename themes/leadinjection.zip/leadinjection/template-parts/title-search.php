<section class="page-title">
    <div class="container">
        <div class="row">
            <div class="col-md-6"><h1><?php esc_html_e('Search Results', 'leadinjection') ?></h1></div>
            <div class="col-md-6">
                <?php custom_breadcrumbs(); ?>
            </div>
        </div>
    </div>
</section>