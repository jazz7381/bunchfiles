<section class="page-title">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1><?php the_archive_title(); ?></h1>
            </div>
        </div>
    </div>
</section>