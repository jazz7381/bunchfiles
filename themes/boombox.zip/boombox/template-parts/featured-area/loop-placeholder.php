<?php
/**
 * The template part for displaying featured area empty placeholder
 *
 * @package BoomBox_Theme
 * @since   2.0.0
 * @version 2.0.0
 */
?>

<article class="featured-item"></article>