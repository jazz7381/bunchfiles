<?php
/**
 * Boombox admin functions
 *
 * @package BoomBox_Theme
 * @since 2.5.0
 * @version 2.5.0
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

require_once 'mycred' . DIRECTORY_SEPARATOR . 'data.php';