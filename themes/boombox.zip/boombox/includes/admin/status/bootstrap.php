<?php
/**
 * Boombox theme status bootstrapping
 *
 * @package BoomBox_Theme
 * @since 2.0.0
 * @version 2.0.0
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

/**
 * Functions
 */
require_once( 'functions.php' );