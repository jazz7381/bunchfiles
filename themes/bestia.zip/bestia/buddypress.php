<?php
get_header();
?>
<div class="container">
<div class="row">
<div class="col-md-2 sidebar" id="sidebar">
    <?php
    if ( is_active_sidebar( 'buddy-left' ) ) {
        dynamic_sidebar( 'buddy-left' );
       } else {
        echo '<p></p>';
      }
    ?>
</div>
    <div class="col-md-7">
      <!--
      <div class="heading pull-left">
      <?php  //$h_tag = $awpt['general_title_heading']; the_title( '<'.$h_tag.'>', '</'.$h_tag.'>' ); ?>
      </div>
      -->
      <div class="clearfix"></div>
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <?php the_content(); ?>
    <?php endwhile; else: ?>
    <p><?php _e('Nothing Found'); ?></p>
    <?php endif; ?>
    </div>
    <div class="col-md-3 sidebar">
      <?php
      if ( is_active_sidebar( 'buddy-right' ) ) {
          dynamic_sidebar( 'buddy-right' );
         } else {
          echo '<p></p>';
        }
      ?>
    </div>
</div>
</div>
<?php get_footer(); ?>
