<?php get_header();
global $awpt; $category_id = get_query_var('cat');
$category_link = get_category_link( $category_id );
?>
<div class="container">
<div class="heading pull-left">
  <?php  $h_tag = $awpt['general_title_heading']; single_cat_title( '<'.$h_tag.'>', '</'.$h_tag.'>' ); ?>
  </div>
  <?php do_action('bestia_orderblock_videos',null); ?>
  <div class="clear"></div>
  <?php
  $category_description = category_description();
  if ( ! empty( $category_description ) )
  echo apply_filters( 'category_archive_meta', '<div class="category-description">' . $category_description . '</div>' );
  ?>
<div class="row">

<div class="col-lg-2 sidebar" id="sidebar">
    <?php get_sidebar(); ?>
</div>

<div class="col-lg-10">
  <?php
  get_template_part( 'inc/preview', get_post_format() );
  adultwpthemes_pagination();
  ?>
</div>

</div>
</div>
<?php get_footer();?>
