<?php
get_header();
global $awpt;
$sidebar = get_post_meta( $post->ID, 'sidebar_position', true );
if ($sidebar == "0side-cm") {
  $col1 = 'hidden';
  $col2 = 'col-md-12 page_large';
  $col3 = 'hidden';
} elseif ($sidebar == "1side-cr") {
  $col1 = 'col-md-2 sidebar';
  $col2 = 'col-md-10';
  $col3 = 'hidden';
} elseif ($sidebar == "1side-cl") {
  $col1 = 'hidden';
  $col2 = 'col-md-9';
  $col3 = 'col-md-3 sidebar-right';
} elseif ($sidebar == "2side-cl") {
  $col1 = 'col-md-2 sidebar';
  $col2 = 'col-md-7';
  $col3 = 'col-md-3 sidebar sidebar-right';
}
?>
<div class="container">
<div class="row">
  <div class="<?php echo $col1; ?>" id="sidebar">
    <?php do_action('page_sidebar'); ?>
  </div>
    <div class="<?php echo $col2; ?>">
      <div class="heading pull-left">
      <?php  $h_tag = $awpt['general_title_heading']; the_title( '<'.$h_tag.'>', '</'.$h_tag.'>' ); ?>
      </div>
      <div class="clearfix"></div>
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <?php the_content(); ?>
    <?php endwhile; else: ?>
    <p><?php _e('Nothing Found'); ?></p>
    <?php endif; ?>
    </div>

    <div class="<?php echo $col3; ?>">
        <?php
        if ( is_active_sidebar( 'sidebar-page-right' ) ) {
    			dynamic_sidebar( 'sidebar-page-right' );
    		 } else {
    			echo '<p></p>';
    		}
        ?>
    </div>

</div>
</div>
<?php get_footer(); ?>
