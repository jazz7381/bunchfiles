<?php get_header();
global $awpt;
global $wp_query;
$category_tax_layout = $awpt['category-archive-layout'];
$h_tag = $awpt['general_title_heading'];
if ($category_tax_layout == "1") {
  $col1 = 'hidden';
  $col2 = 'col-md-12 no_sidebar';
  $col3 = 'hidden';
} elseif ($category_tax_layout == "2") {
  $col1 = 'col-md-2 sidebar';
  $col2 = 'col-md-10';
  $col3 = 'hidden';
} elseif ($category_tax_layout == "3") {
  $col1 = 'hidden';
  $col2 = 'col-md-10 bnr_fix';
  $col3 = 'col-md-2 sidebar sidebar-right';
}
?>
<div class="container category_taxonomy">
<div class="row">
  <?php if ($category_tax_layout == "2") { ?>
  <div class="<?php echo $col1; ?>" id="sidebar">
   <?php echo do_action('category_sidebar'); ?>
  </div>
  <?php } ?>
<div class="<?php echo $col2; ?>">
  <div class="heading pull-left">
  <?php $h_tag = $awpt['general_title_heading'];
  single_cat_title( '<' . $h_tag .'>', '</' . $h_tag . '>' );
  ?>
  </div>
  <?php do_action('bestia_orderblock_videos',null); ?>
  <div class="clearfix"></div>
  <?php
  $category_description = category_description();
  if ( ! empty( $category_description ) )
  echo apply_filters( 'category_archive_meta', '<div class="category-description">' . $category_description . '</div>' );
  ?>
  <?php
  get_template_part( 'inc/preview', get_post_format() );
  adultwpthemes_pagination();
  ?>
</div>
<?php if ($category_tax_layout == "3") { ?>
<div class="<?php echo $col3; ?>">
<?php do_action('category_sidebar'); ?>
</div>
<?php } ?>
</div>
</div>
<?php get_footer();?>
