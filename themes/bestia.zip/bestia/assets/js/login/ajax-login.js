jQuery(document).ready(function(a) {
    jQuery("#login-form-modal").on("submit", function(a) {
        jQuery("#login-form-modal p.status").show().text(ajax_login_object.loadingmessage), jQuery.ajax({
            type: "POST",
            dataType: "json",
            url: ajax_login_object.ajaxurl,
            data: {
                action: "ajaxlogin",
                username: jQuery("#login-form-modal #username").val(),
                password: jQuery("#login-form-modal #password").val(),
                security: jQuery("#login-form-modal #security").val()
            },
            success: function(a) {
                jQuery("#login-form-modal p.status").text(a.message), 1 == a.loggedin && (document.location.href = ajax_login_object.redirecturl)
            }
        }), a.preventDefault()
    })
});
