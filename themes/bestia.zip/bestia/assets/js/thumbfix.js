jQuery(document).ready(function() {
        Video_SetThumbsHeight();
        jQuery( window ).resize(function() {
            Video_SetThumbsHeight();
        });
        function Video_SetThumbsHeight(){
            var eltWidthMain = jQuery('.Thumbnail_List li.thumi img:first-child').width();
            jQuery('.Thumbnail_List li.thumi img').height( eltWidthMain * 6 / 9 );
        }
});
