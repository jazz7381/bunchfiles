jQuery(function() {
    if (jQuery("body.single-post").length > 0) {
        var e = jQuery("article.post").attr("id").replace("post-", "");
        jQuery.ajax({
            type: "post",
            url: ajax_var.url,
            dataType: "json",
            data: {
                action: "post-views",
                nonce: ajax_var.nonce,
                post_id: e
            }
        }).done(function(e) {
            console.log(e)
        }).fail(function(e) {
            console.error(e)
        }).always(function(t) {
            jQuery.ajax({
                type: "post",
                url: ajax_var.url,
                dataType: "json",
                data: {
                    action: "get-post-data",
                    nonce: ajax_var.nonce,
                    post_id: e
                }
            }).done(function(e) {
                e.views && jQuery(".Thumbnail_List li .post-views").text(e.views), e.likes && jQuery(".nb-votes").text(e.likes), e.dislikes && jQuery(".rate_thumb").text(e.dislikes), e.rating && (jQuery(".progress_bar").text(e.rating), jQuery(".progress like-bar").css("width", e.rating))
            }).fail(function(e) {
                console.error(e)
            }).always(function() {})
        })
    }
});
