function bestia_show_request(e, o, r) {
    return jQuery("form#awpt-submit-video-form #loading").show(), jQuery('form#awpt-submit-video-form button[type="submit"]').hide(), !0
}

function bestia_show_response(e, o, r, t) {
    "error" == e.resp ? "undefined" != typeof e.element_id && (jQuery("div." + e.element_id).addClass("has-error"), jQuery("#" + e.element_id).focus(), jQuery("div." + e.element_id + " > span.help-block").text("*" + e.message)) : "publish" == e.resp ? window.location.href = e.redirect_to : "success" == e.resp && ("undefined" != typeof e.redirect_to ? window.location.href = e.redirect_to : (jQuery("form#awpt-submit-video-form").remove(), jQuery("form#awpt-submit-video-form").slideUp("slow", function() {
        jQuery("form#awpt-submit-video-form").remove()
    }), jQuery("div.holder").append('<div class="alert alert-success">' + e.message + "</div>"))), jQuery("form#awpt-submit-video-form #loading").hide(), jQuery('form#awpt-submit-video-form button[type="submit"]').show()
}! function(e) {
    "use strict";
    jQuery(document).ready(function() {
        jQuery('input[name="chb_video_type"]').click(function() {
            var o = e(this).val();
            jQuery("div.video-type").slideUp(), jQuery("div." + o).slideDown()
        }), jQuery("form#awpt-submit-video-form").submit(function() {
            var e = {
                beforeSubmit: bestia_show_request,
                success: bestia_show_response,
                url: ajaxurl,
                type: "post",
                dataType: "json"
            };
            return jQuery("form#awpt-submit-video-form").ajaxSubmit(e), !1
        })
    })
}(jQuery);
