jQuery(document).ready(function($){

    // hide the topbutton on page load/ready.
    $('.TopButton').hide();

    //Check to see if the window is top if not then display button
    $(window).scroll(function(){
        if ($(this).scrollTop() > 100) {
            $('.TopButton').show().fadeIn();
        } else {
            $('.TopButton').fadeOut().hide();
        }
    });
    //Click event to scroll to top
    $('.TopButton').click(function(){
        $('html, body').animate({scrollTop : 0},360);
        return false;
    });
});
