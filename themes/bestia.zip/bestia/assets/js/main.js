jQuery(function(e) {
  e(".close_lek").click(function() {
        e(".v-overlay").css("display", "none")
    }), e("#open").click(function() {
        e("#second_related").css("display", "grid"), e("#open").hide()
    }), e("#search-button").click(function() {
        e(".mobile_search").fadeIn().css("margin-top", "-74.2px"), e(".navbar-brand").slideDown("slow")
    }), e(".closer").click(function() {
        e(".mobile_search").fadeIn().css("margin-top", "-200px"), e(".navbar-brand").css("display", "block")
    }), e("#search-btn_mobile").click(function() {
        e(".mobile_search").toggle()
    }), RightMenu = e(".slidemenu-right"), NavListRight = e(".open_bar"), NavListRight.click(function() {
        e(this).toggleClass("opened"), e("body").toggleClass("slidemenu-push-toleft"), RightMenu.toggleClass("slidemenu-open"), e(".open_bar .fa").toggleClass("fa-bars fa-times")
    }), LeftMenu = e(".slidemenu-left"), NavListLeft = e(".open_bar_left"), NavListLeft.click(function() {
        e(this).toggleClass("opened"), e("body").toggleClass("slidemenu-push-toright"), LeftMenu.toggleClass("slidemenu-open"), e(".open_bar_left .fa").toggleClass("fa-bars fa-times")
    }), e(".rotate").click(function() {
        e(this).toggleClass("down")
    }), e(".filter_rotate").click(function() {
        e(this).toggleClass("down")
    }), e(".slidemenu ul.sub-menu").hide(), e(".slidemenu .sub-menu").parent().find("a:first").removeAttr("href").css("cursor", "default"), e(".carousel-inner .item:first").addClass("active"), e(".slidemenu .menu-item-has-children").length > 0 && e(".slidemenu .menu-item-has-children").click(function(s) {
        s.stopPropagation(), e(this).addClass("toggled"), e(this).hasClass("toggled") && e(this).children("ul").slideToggle("fast")
    }), e('#performer-list [data-toggle="owlcarousel"], #performer-list [data-toggle="owl-carousel"]').each(function() {
        var e = jQuery(this),
            s = e.data("owlcarousel-settings") || {};
        e.owlCarousel(s)
    }), e('.hm-slide [data-toggle="owlcarousel"], .hm-slide [data-toggle="owl-carousel"]').each(function() {
        var e = jQuery(this),
            s = e.data("owlcarousel-settings") || {};
        e.owlCarousel(s)
    }), // hide the topbutton on page load/ready.
    e('.TopButton').hide(),
    //Check to see if the window is top if not then display button
    e(window).scroll(function(){
        if (e(this).scrollTop() > 100) {
            e('.TopButton').show().fadeIn();
        } else {
            e('.TopButton').fadeOut().hide();
        }
    }),
    //Click event to scroll to top
    e('.TopButton').click(function(){
        e('html, body').animate({scrollTop : 0},360);
        return false;
    }), e('.open-info').on('click', function(y){
        y.preventDefault();
        y.stopPropagation()
        e('.sli-overlay a').slideToggle();
    }), e('#user_login').attr( 'placeholder', 'User Name' ),
        e('#user_pass').attr( 'placeholder', 'Password' )
});
