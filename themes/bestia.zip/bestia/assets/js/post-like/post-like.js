jQuery.noConflict();
jQuery("body").on("click", "li.item_rate a", function(e) {
    e.preventDefault();
    var t = jQuery(this),
        a = t.data("post_id"),
        r = t.data("post_like");
    return jQuery.ajax({
        type: "post",
        url: ajax_var.url,
        dataType: "json",
        data: "action=post-like&nonce=" + ajax_var.nonce + "&post_like=" + r + "&post_id=" + a,
        success: function(e, t, a) {
            e.already !== !0 && (
            jQuery(".note-bar").removeClass("not-rated-yet"),
            jQuery(".rating").text(Math.floor(e.pourcentage) + "%"),
            jQuery("#flagging_success").fadeIn('slow').delay(2000).hide(0),
            jQuery(".rating").show(),
            jQuery(".percent").text(Math.floor(e.pourcentage) + "%"),
            jQuery(".percent").show(),
            jQuery(".nb-votes").text(e.nbvotes),
            jQuery(".post-like"), e.nbvotes > 0 && jQuery(".like-bar").animate({
                width: e.barre + "%"
            }, "fast", function() {}))
        }
    }), !1
});
