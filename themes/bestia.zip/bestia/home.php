<?php
get_header();
global $awpt;
$home_layout = $awpt['homepage-layout'];
if ($home_layout == "1") {
  $col1 = 'hidden';
  $col2 = 'col-md-12 no_sidebar';
  $col3 = 'hidden';
} elseif ($home_layout == "2") {
  $col1 = 'col-md-2 sidebar';
  $col2 = 'col-md-10';
  $col3 = 'hidden';
} elseif ($home_layout == "3") {
  $col1 = 'hidden';
  $col2 = 'col-md-10 bnr_fix';
  $col3 = 'col-md-2 sidebar sidebar-right';
}
?>
<?php get_template_part( 'inc/slider', get_post_format() ); ?>
<div class="container homepage">
<div class="row">
  <?php if ($home_layout == "2") { ?>
  <div class="<?php echo $col1; ?>" id="sidebar">
      <?php
      do_action('general_sidebar');
      ?>
  </div>
  <?php } ?>
<div class="<?php echo $col2; ?>">
     <?php
     do_action( 'bestia_homepage_manager' );
     ?>
</div>
<?php if ($home_layout == "3") { ?>
<div class="<?php echo $col3; ?>">
    <?php
    do_action('general_sidebar');
    ?>
</div>
<?php } ?>
</div>
</div>
<?php get_footer();?>
