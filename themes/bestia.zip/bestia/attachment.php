<?php
get_header();
setPostViews(get_the_ID());
global $awpt;
$lazyLoading = $awpt['mtn_lazyloading'];
$single_layout = $awpt['single-photo-layout'];
if ($single_layout == "2") {
  $col1 = 'col-md-3 sidebar';
  $col2 = 'col-md-9';
  $col3 = 'hidden';
} elseif ($single_layout == "3") {
  $col1 = 'hidden';
  $col2 = 'col-md-9';
  $col3 = 'col-md-3 sidebar';
} elseif ($single_layout == "4") {
  $col1 = 'col-md-2 sidebar';
  $col2 = 'col-md-7';
  $col3 = 'col-md-3 sidebar';
}
?>
<div class="container">
<div class="row">
<div class="<?php echo $col1; ?>" id="sidebar">
  <?php do_action('single_gallery_sidebar'); ?>
</div>
    <div class="<?php echo $col2; ?>">
      <?php while ( have_posts() ) : the_post(); ?>
        <nav id="image-navigation" class="navigation image-navigation">
            <div class="nav-links">
                 <?php previous_image_link( false, '<div class="previous-image btn btn-default"> ' . $awpt['image_prev'] . '</div>' ); ?>
                 <?php echo back_to_gallery(); ?>
                 <?php //echo get_permalink( $post->ID ); ?>
                 <?php next_image_link( false, '<div class="next-image btn btn-default">' . $awpt['image_next'] . '</div>' ); ?>
             </div><!-- .nav-links -->
        </nav><!-- #image-navigation -->
        <div id="album">
        <div id="Video_Player" style="background: #292929;text-align:center;">
        <?php if ( wp_attachment_is_image( get_the_ID() ) ) : ?>
        <div class="clearfix"></div>
        <div style="text-align:center;" id="attachment-img">
        <a target="_blank" href="<?php echo wp_get_attachment_url(); ?>">
        <?php
          if ($lazyLoading == "jquery_lazy" || $lazyLoading == "unveil_lazy") {
            echo '<img class="lazy" src="'.get_template_directory_uri().'/images/1pixel.gif" alt="'.get_the_title().'" data-original="'.wp_get_attachment_url().'" />';
            } else {
            echo '<img src="'.wp_get_attachment_url().'" alt="'.get_the_title().'" />';
           } ?>
        </a>
        <div class="addtoany_attachment">
        <?php do_action('bestia_addtoany'); ?>
        </div>
        </div>
        <?php endif; ?>
        <div class="clearfix"></div>
        <div class="resolutions">
          <span><?php echo _e( 'Downloads', 'bestia'); ?>:</span>
        		<?php
        			$images = array();
        			$image_sizes = get_intermediate_image_sizes();
        			array_unshift( $image_sizes, 'full' );
        			foreach( $image_sizes as $image_size ) {
        				$image = wp_get_attachment_image_src( get_the_ID(), $image_size );
        				$name = $image_size . ' (' . $image[1] . 'x' . $image[2] . ')';
        				$images[] = '<a href="' . $image[0] . '">' . $name . '</a>';
        			}
        			echo implode( ' | ', $images );
        		?>
        </div>
        </div>

        <?php do_action('bestia_bottom_video_ads'); ?>
        <div class="tool_bar">
				<div class="col_bar">
        <div class="content-title-holder">
          <div class="content-title">
            <?php $h_tag = $awpt['general_title_heading']; the_title( '<'.$h_tag.' class="singletitle pull-left">', '</'.$h_tag.'>' ); ?>
          </div>
        </div>
			</div>
					<div class="col_bar rate_bar_view" id="rating-results">
						<div class="rate_view">
			         <span class="rate_precent rating">
                <?php echo adultwpthemes_getItemPostLikeRate( get_the_ID() ); ?>
               </span>

				       <span class="view_count">
                 <span class="nb-votes"><?php echo (int) get_post_meta( $post->ID, 'likes_count', true) + (int) get_post_meta( $post->ID, 'dislikes_count', true); ?></span>
                 <?php _e('Rates' , 'bestia'); ?>
               </span>

						 </div>
             <?php $not_rated_yet = adultwpthemes_getPostLikeRate(get_the_ID()) === false ? " not-rated-yet" : ''; ?>
						  <div class="progress_bar note-bar<?php echo $not_rated_yet;?> border-radius-5">
							 <div class="progress like-bar" style="width:<?php echo adultwpthemes_getPostLikeRate(get_the_ID());?>%;"></div>
						  </div>

					</div>

					<div class="col_bar rate_hand">
						<?php do_action( 'bestia_like_buttons' ); ?>
            <?php if(adultwpthemes_hasAlreadyVoted($post->ID)) { $vote_msg = $awpt['vote_rated']; } else { $vote_msg = $awpt['vote_thanks']; } ?>
            <div id="flagging_success" class="g_hint green g_hidden" style="display:none;">
              <?php echo $vote_msg; ?>
            </div>
					</div>
				</div>
       <div class="clearfix"></div>
       <div id="singleTabs">
          <ul class="nav nav-tabs">
       			<li class="active">
               <a  href="#details" data-toggle="tab"><?php _e('Details', 'bestia'); ?></a>
       			</li>
       			<li>
               <a href="#comments" data-toggle="tab"><?php _e('Comments', 'bestia'); ?> <!--<span class="badge"><?php //comments_number( '0', '1', '%' ); ?></span>--></a>
       			</li>
             <?php if (function_exists('crf_report_form')) { ?>
               <li>
                 <a href="#report" data-toggle="tab"><?php _e('Report', 'bestia'); ?></a>
         			</li>
             <?php } ?>
       		</ul>

       			<div class="tab-content ">
       			  <div class="tab-pane active" id="details">
                 <div class="about-content">
                 <div class="content-data clearfix">
                 <div class="col left-col">
                   <p class="data-row">
                   <span class="heading"><i class="fa fa-eye" aria-hidden="true"></i> <?php _e('Views', 'bestia'); ?>:</span>
                   <?php do_action( 'bestia_post_views_mode' ); ?>
                   </p>
                   <p class="data-row">
                   <span class="heading"><i class="fa fa-calendar" aria-hidden="true"></i> <?php _e('Added', 'bestia'); ?>:</span> <?php echo time_ago(); ?> <?php _e('ago', 'bestia'); ?>
                   </p>
                 </div>
                 <div class="col right-col">

                 <?php if( false != get_the_term_list( $post->ID, 'phototype' ) ) : ?>
                     <p class="data-row">
                     <span class="heading"><i class="fa fa-folder-open" aria-hidden="true"></i> <?php _e('Categories:', 'bestia'); ?> </span>
                   <?php foreach (get_the_terms(get_the_ID(), 'phototype' ) as $phototype) : ?><a href="<?php echo get_term_link($phototype->term_id, 'phototype'); ?>" rel="tag"><?php echo $phototype->name; ?></a>
                   <?php endforeach; ?>
                 </p>
                 <?php endif; ?>

                   <?php
                   $tags = comma_tags( wp_get_post_terms($post->ID, 'photo_tag'));
                   if($tags){ ?>
                   <p class="data-row">
                   <span class="heading"><i class="fa fa-tags" aria-hidden="true"></i> <?php _e('Tags:', 'bestia'); ?></span>
                   <?php echo $tags; ?>
                   </p>
                   <?php } ?>

                 </div>
                 <div class="clearfix"></div>
                 </div>
                 </div>

       				</div>
       				<div class="tab-pane" id="comments">
                 <?php comments_template(); ?>
       				</div>
               <?php if (function_exists('crf_report_form')) { ?>
                 <div class="tab-pane" id="report">
               <?php echo crf_report_form(); ?>
         				</div>
               <?php } ?>
       			</div>
               <div class="clearfix"></div>
             </div>
      </div>
      <?php endwhile; ?>
    </div>
    <div class="<?php echo $col3; ?>">
      <?php if ( is_active_sidebar( 'gallery-right' ) ) {
  			dynamic_sidebar( 'gallery-right' );
  		 } else {
  			echo '<p></p>';
  		}
      ?>
    </div>
</div>
</div>
<div class="container related_posts">
<div class="row">
  <div class="col-md-12">
    <div class="clearfix"></div>
    <?php $h_tag_general = $awpt['related_title_heading']; $related_photos_title = $awpt['mtn_related_photos_title'];
    echo '<div class="heading">', getBestiaHeadingtags($h_tag_general,$related_photos_title), '</div>'; ?>
    <div class="clearfix"></div>
    <?php get_template_part('inc/related/random-photos',get_post_format()); ?>
    </div>
</div>
</div>
<?php get_footer(); ?>
