<?php if ( post_password_required() ) { return; }
$fields =  array(
  'author' =>
    '<p class="comment-form-author"><div class="form-group">
    <input id="author" class="form-control" name="author" placeholder="' . __( 'Name', 'bestia' ) . '" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
    '" ' . $aria_req . ' /></div></p>',

  'email' =>
    '<p class="comment-form-email"><div class="form-group">
    <input id="email" name="email" placeholder="' . __( 'Email', 'bestia' ) . '" class="form-control" type="email" value="' . esc_attr(  $commenter['comment_author_email'] ) .
    '" ' . $aria_req . ' /></div></p>',
  'url' =>
    '<p class="comment-form-url"><div class="form-group"><label for="url">' . __( 'Website', 'bestia' ) . '</label>' .
    '<input id="url" name="url" class="form-control" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) .
    '"   /></p>',
);
    $comments_args = array(

        // change "Leave a Reply" to "Comment"
        'title_reply'=> 'Discuss this post ?',
        'fields' => apply_filters( 'comment_form_default_fields', $fields ),
        'comment_field' => '
				<p class="comment-form-comment">
				 <div class="form-group">
				   <textarea id="comment" name="comment" placeholder="' . _x( 'Write your comment here', 'bestia' ) .'" class="form-control"  rows="8" aria-required="true">' .'</textarea>
				 </div>
				</p>',
        'comment_notes_after' => ' ');
?>
<div id="comments" class="comments-area">
  <?php comment_form($comments_args); ?>
	<?php if ( have_comments() ) { ?>
		<h4 class="comments-title"><?php comments_number(__('No Comments', 'bestia'), __('1 Comment', 'bestia'), '% ' . __('Comments', 'bestia') ); ?></h4>
		<span class="title-line"></span>
		<ol class="comment-list">
			<?php wp_list_comments( array( 'avatar_size' => 70, 'style' => 'ul', 'callback' => 'your_theme_slug_comments', 'type' => 'all', 'reverse_top_level' => 'DESC' ) ); ?>
		</ol>
		<?php the_comments_pagination( array( 'prev_text' => '<i class="fa fa-angle-left" aria-hidden="true"></i> <span class="screen-reader-text">' . __( 'Previous', 'bestia') . '</span>', 'next_text' => '<span class="screen-reader-text">' . __( 'Next', 'bestia') . '</span> <i class="fa fa-angle-right" aria-hidden="true"></i>', ) ); ?>
	<?php } ?>
	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) { ?>
		<p class="no-comments"><?php _e( 'Comments are closed.', 'bestia'); ?></p>
	<?php } ?>
</div>
