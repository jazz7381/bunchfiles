<?php
if( !defined('ABSPATH') ) exit;
require_once( TEMPLATEPATH."/functions/enqueue.php" );
require_once( TEMPLATEPATH."/functions/bestia_functions.php");
require_once( TEMPLATEPATH."/admin/admin_pages/admin.php");
require_once( TEMPLATEPATH."/admin/extras/loader.php"); //redux extensions loader
/* Bestia Theme Admin mytubepress.com ----------------------------------------------------*/
require get_template_directory() . '/admin/admin-init.php';
/* Bestia Theme Basic Theme Functions adultwpthemes.eu . ------------------------------------*/
require_once( TEMPLATEPATH."/functions/bestia_compatibility.php");

//January 2018 news start here -------------------------------------
require_once( TEMPLATEPATH."/functions/bestia_media.php");
require_once( TEMPLATEPATH."/functions/bestia_player.php");
require_once( TEMPLATEPATH."/admin/extras/class-tgm-plugin-activation.php");
require_once( TEMPLATEPATH."/admin/extras/class-wp-bootstrap-navwalker.php");
require_once( TEMPLATEPATH."/admin/extras/bestia_aq_resizer.php");

require_once( TEMPLATEPATH."/inc/tools/addon/integrated/advanced-custom-fields/acf.php");
require_once( TEMPLATEPATH."/inc/tools/addon/integrated/acf-gallery/acf-gallery.php");
require_once( TEMPLATEPATH."/inc/tools/addon/integrated/comment-press/comment-press.php");
require_once( TEMPLATEPATH."/inc/tools/addon/integrated/disable-gutenberg/disable-gutenberg.php");
if ( function_exists( 'pmpro_activation' ) ) {
  require_once( TEMPLATEPATH . '/inc/plugins/pmpro.php');
}
//Bestia Move Admin Menu Items
function remove_submenus() {
  global $submenu;
	 unset($submenu['themes.php'][7]);
   unset($submenu['themes.php'][10]);
}
add_action('admin_menu', 'remove_submenus');

function new_nav_menu () {
	  add_submenu_page( 'mytubepress', __('WordPress Menu Locations', 'bestia'), __('Menus', 'bestia'),'edit_themes', 'nav-menus.php', null );
}
add_action('admin_menu', 'new_nav_menu');

function new_widgets_menu () {
		add_submenu_page( 'mytubepress', __('Sidebar & Widget Manager', 'bestia'), __('Widgets', 'bestia'), 'edit_themes', 'widgets.php');
}
add_action('admin_menu', 'new_widgets_menu');

//Bestia Dasboard latest topics widget
function custom_dashboard_widget() {
	echo '<p><iframe src="https://mytubepress.com/bestia-live-topics/" scrolling="no" style=" width: 100%; height:auto;  overflow: hidden;"></iframe></p>';
}
function add_custom_dashboard_widget() {
	wp_add_dashboard_widget('custom_dashboard_widget', 'Bestia Forum', 'custom_dashboard_widget');
}
add_action('wp_dashboard_setup', 'add_custom_dashboard_widget');

require_once( TEMPLATEPATH."/functions/bestia_slider.php" );

require_once( TEMPLATEPATH."/functions/bestia_sidebars.php" );
require_once( TEMPLATEPATH."/functions/bestia_required_plugins.php" );
//january 2018 news close here -------------------------------------

require_once( TEMPLATEPATH."/functions/bestia_outputs.php" );
require_once( TEMPLATEPATH."/functions/bestia_adv_outputs.php" );
require_once( TEMPLATEPATH."/functions/bestia_post_limit.php" );
require_once( TEMPLATEPATH."/functions/bestia_custom_style_options.php" );
require_once( TEMPLATEPATH."/functions/bestia_heading_tags.php" );
require_once( TEMPLATEPATH."/inc/fileupload/bestia_submit_form.php" );
require_once( TEMPLATEPATH."/inc/fileupload/uploader_functions.php" );
add_action( 'after_setup_theme', 'prefix_theme_updater');
//merlinWP
require_once( TEMPLATEPATH."/merlin/vendor/autoload.php" );
require_once( TEMPLATEPATH."/merlin/class-merlin.php" );
require_once( TEMPLATEPATH."/merlin/merlin-config.php" );
require_once( TEMPLATEPATH."/merlin/merlin-filters.php" );

//metaboxes
require_once( TEMPLATEPATH."/admin/metaboxes/metaboxes.php" );
require_once( TEMPLATEPATH."/admin/metaboxes/performer_meta.php" );

include_once( TEMPLATEPATH."/functions/bestia_order_videos_by.php" );
include_once( TEMPLATEPATH."/functions/bestia_post_like.php" );
include_once( TEMPLATEPATH."/functions/bestia_ajax_post_like.php" );
require_once( TEMPLATEPATH."/functions/bestia_gifs_post_type.php" );
require_once( TEMPLATEPATH."/functions/bestia_gifs_taxonomies.php" );
require_once( TEMPLATEPATH."/functions/bestia_blog_post_type.php" );
require_once( TEMPLATEPATH."/functions/bestia_blog_taxonomies.php" );
require_once( TEMPLATEPATH."/functions/bestia_photo_gallery.php" );
require_once( TEMPLATEPATH."/functions/bestia_photo_gallery_taxonomies.php" );
require_once( TEMPLATEPATH."/functions/bestia-widgets.php" );
require_once( TEMPLATEPATH."/functions/bestia_pagination.php" );
require_once( TEMPLATEPATH."/functions/bestia_categories_images.php" );
require_once( TEMPLATEPATH."/functions/bestia_channels.php" );
require_once( TEMPLATEPATH."/functions/bestia-system-snapshot-report.php" );
//require_once( TEMPLATEPATH."/functions/bestia_html_minifier.php" );
require_once( TEMPLATEPATH."/functions/taxonomy-funcitons.php" );
require_once( TEMPLATEPATH."/functions/bestia_performer_tax.php" );
require_once( TEMPLATEPATH."/functions/bestia_flyout_taxonomies.php" );
/* Bestia TubeACE Plugin Functions adultwpthemes.eu . ------------------------------------*/
if (function_exists('tubeace_activate')) { //checks if tubeace is active
require_once( TEMPLATEPATH."/functions/bestia-tubeace-functions.php" );

//Login and Logout Redirections
function redirect_to_request( $redirect_to, $request, $user ){

    return $request; // this is the URL the user is coming from
}
add_filter('login_redirect', redirect_to_request, 10, 3);

remove_action( 'init', 'tubeace_performers_taxonomy', 10, 1 );
}
function bestia_search_post_types($template) {
global $wp_query,$awpt;
  $post_type = get_query_var('post_type');
  if( $wp_query->is_search && $post_type == 'gallery' && $awpt['gallery_cpt'] == 1 ) {
		return locate_template('search-gallery.php');
	} elseif( $wp_query->is_search && $post_type == 'blogs' && $awpt['blogs_cpt'] == 1 ) {
		return locate_template('search-blogs.php');
	} elseif( $wp_query->is_search && $post_type == 'gif' && $awpt['gifs_cpt'] == 1 ) {
	  return locate_template('search-gif.php');
	}
	return $template;
}
add_filter('template_include', 'bestia_search_post_types');


/* BuddyPress compatibility */
if ( class_exists( 'BuddyPress' ) ) {
  require_once( TEMPLATEPATH . '/inc/plugins/buddypress/buddypress.php');
  require_once( TEMPLATEPATH . '/functions/bestia_ajax-login.php');

  function customize_page_tracking_args() {
    // Check if the Activity component is active before using it.
    if ( ! bp_is_active( 'activity' ) ) {
        return;
    }

    // Don't forget to add the 'buddypress-activity' support!
    add_post_type_support( 'post', 'buddypress-activity' );

    /**
     * Also don't forget to allow comments from the WordPress Edit Page screen
     * see this screencap https://cldup.com/nsl4TxBV_j.png
     */

    bp_activity_set_post_type_tracking_args( 'post', array(
        'action_id'                         => 'new_blog_page',
        'bp_activity_admin_filter'          => __( 'Published a new video', 'custom-textdomain' ),
        'bp_activity_front_filter'          => __( 'Videos', 'custom-textdomain' ),
        'bp_activity_new_post'              => __( '%1$s posted a new <a href="%2$s">video</a>', 'custom-textdomain' ),
        'bp_activity_new_post_ms'           => __( '%1$s posted a new <a href="%2$s">video</a>, on the site %3$s', 'custom-textdomain' ),
        'contexts'                          => array( 'activity', 'member' ),
        'comment_action_id'                 => 'new_blog_page_comment',
        'bp_activity_comments_admin_filter' => __( 'Commented a video', 'custom-textdomain' ),
        'bp_activity_comments_front_filter' => __( 'Video Comments', 'custom-textdomain' ),
        'bp_activity_new_comment'           => __( '%1$s commented on a <a href="%2$s">video</a>', 'custom-textdomain' ),
        'bp_activity_new_comment_ms'        => __( '%1$s commented on a <a href="%2$s">video</a>, on the site %3$s', 'custom-textdomain' ),
        'position'                          => 100,
    ) );
}
add_action( 'bp_init', 'customize_page_tracking_args' );
  // Add new tab only if the user has post (is author of any post)
  add_action( 'bp_setup_nav', 'user_videos' );
  function user_videos(){
      // Do the query only if is displayed any user page
      if (bp_is_current_component('videos') || bp_is_current_component('profile') ||bp_is_current_component('media') || bp_is_current_component('activity') || bp_is_current_component('notifications') || bp_is_current_component('messages') || bp_is_current_component('groups') || bp_is_current_component('settings')){
          $args = array(
              'post_type'      => 'post',
              'post_status'    => 'publish',
              'posts_per_page' => 6,
              'author'         => bp_displayed_user_id(),
              'paged'          => get_query_var('pag',1)
          );
          //The Query
          $wp_query = new WP_Query( $args );
      	if( $wp_query->have_posts()){
      		bp_content_setup_myposts();
      	}else{}
      }
  }
  function get_user_posts_count() {
      return count_user_posts( bp_displayed_user_id() , "post"  );
  }
    // Tab "Mis articulos"
    function bp_content_setup_myposts() {
        global $bp;
        $count = get_user_posts_count(bp_displayed_user_id(), array(
          'post_type' =>'post',
          'post_status'=> 'publish'
        ));
  	    $class  = ( 0 === $count ) ? 'no-count' : 'count';
  	    $name = sprintf( __( 'Videos <span class="%s">%s</span>', 'sample' ), esc_attr( $class ), number_format_i18n( $count ) );

        bp_core_new_nav_item( array(
          'name'                  => $name,
          'slug'                  => 'videos',
          'parent_url'            => trailingslashit( bp_displayed_user_domain() . '/' ),
          'screen_function'       => 'my_posts',
          'position' => 120,
          //'default_subnav_slug'   => '/',
        ));
    }
    function my_posts() {
        add_action( 'bp_template_content', 'my_posts_content' );
        bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
    }
    function my_posts_content() {
       global $awpt;
       if ( wp_is_mobile() ) {
        $ranger = '1'; $pagination_next = '<i class="fa fa-arrow-right"></i>'; $pagination_prev = '<i class="fa fa-arrow-left"></i>';
       } else {
        $ranger = '3'; $pagination_next = $awpt['pagination_next']; $pagination_prev = $awpt['pagination_prev'];
       }

        $args = array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 8,
            'author'         => bp_displayed_user_id(),
            'paged'          => get_query_var('pag',1)
        );
        //The Query
        $wp_query = new WP_Query( $args );
        // The Loop
        if ( $wp_query->have_posts() ) {
            echo "<ul class=\"Thumbnail_List profile-videos\">";
            while ( $wp_query->have_posts() ) {
                    $wp_query->the_post();
                    do_action( 'bestia_thumbnail_compatibility' );
            }
            echo "</ul><div class=\"pager\">";
            echo paginate_links( array(
                    'base' =>  @add_query_arg('pag','%#%'),
                    'format' => '',
                    'range' => $ranger,
                    'gap' => $ranger,
                    'anchor' => 1,
                    'type' => 'list',
                    'current' => max( 1, get_query_var('pag') ),
                    'next_text' => $pagination_next,
                    'class' => 'pagination-site',
                    'prev_text' => $pagination_prev,
                    'total' => $wp_query->max_num_pages
            ) );
            echo '</div>';
        }
    }
    /* New query_vars to get pagination working
     * https://codex.wordpress.org/Plugin_API/Filter_Reference/query_vars
     * https://premium.wpmudev.org/forums/topic/woocommerce-breaks-the-pagination-on-a-buddypress-page#post-961665
     */
    function bestia_query_vars( $qvars ) {
      $qvars[] = 'pag';
      return $qvars;
    }
    add_filter( 'query_vars', 'bestia_query_vars' , 10, 1 );


  function bp_uploader_tab_screen() {
      // Add title and content here - last is to call the members plugin.php template.
      add_action( 'bp_template_title', 'bp_uploader_tab_title' );
      add_action( 'bp_template_content', 'bp_uploader_tab_content' );
      bp_core_load_template( 'buddypress/members/single/plugins' );
  }

  function bp_my_videos_sub_nav() {
    global $bp;
    $parent_slug = 'videos';
    $slug = '';
    //Add subnav item
    //Add subnav item
    bp_core_new_subnav_item( array(
    'name'            => __( 'Videos', 'bestia' ),
    'slug'            => 'videos',
    'parent_url'      => $bp->loggedin_user->domain . $slug.'/',
    'parent_slug'     => $parent_slug,
    'user_has_access' => true,
    'screen_function' => 'bp_myposts_tab_screen',
    'position'        => 60,
    'link'            => $bp->loggedin_user->domain . $parent_slug . '/' . $slug.'/',
    ) );
  }
  if ( is_user_logged_in() ) {
  add_action( 'bp_setup_nav', 'bp_my_videos_sub_nav' );
  }

  add_action( 'bp_setup_nav', 'bp_uploader_sub_nav' );
  function bp_uploader_sub_nav() {
    global $bp;
    if ( bp_is_my_profile() ) {
    $parent_slug = 'videos';
    $slug = 'video-upload';

    //Add subnav item
    bp_core_new_subnav_item( array(
    'name'            => __( 'Upload', 'bestia' ),
    'slug'            => 'video-upload',
    'parent_url'      => $bp->loggedin_user->domain . $slug.'/',
    'parent_slug'     => $parent_slug,
    'user_has_access' => true,
    'screen_function' => 'bp_uploader_tab_screen',
    'position'        => 61,
    'link'            => $bp->loggedin_user->domain . $parent_slug . '/' . $slug.'/',
    ) );
  }
  }

      function bp_uploader_tab_title() {
        echo 'Video Uploader';
      }

      function bp_uploader_tab_content($atts) {
         echo do_shortcode('[upload]');
      }
}
function adultwpthemes_statsdiv_block() {
        add_meta_box(
            'statsdivVideo',
            	'Bestia - ' . __('Video stats', 'bestia'),
            		'adultwpthemes_stats_video_display_meta_box',
            		 'post',
            		  'side',
            		   'high'
                  );
                 }
function adultwpthemes_stats_video_display_meta_box($post){
  ?>
<div class="misc-pub-section" style="background:#FEDBFB; text-shadow: 1px 1px 2px rgba(255,255,255,0.1);">
    <?php _e('Views', 'bestia'); ?> : <strong><?php echo getPostViews( $post->ID, 'views', true ); ?></strong>
</div>
<?php global $awpt; $avarage = $awpt['mtn_vote']; if ($avarage == "default") { ?>
<div class="misc-pub-section" style="background:#BBDCFF; text-shadow:1px 1px 2px rgba(255,255,255,0.1);">
    <?php _e('Rates', 'bestia'); ?> : <strong><?php echo (int) get_post_meta( $post->ID, 'likes_count', true) + (int) get_post_meta( $post->ID, 'dislikes_count', true);?></strong>
    <span class="rating-img"></span>  - <?php _e('Avarage', 'bestia'); ?> : <strong><span class="rating<?php echo $is_rated_yet;?>"><?php echo adultwpthemes_getItemPostLikeRate( $post->ID, 'like', true )?adultwpthemes_getItemPostLikeRate( $post->ID, 'like', true ) : _e('No rating', 'bestia');?></span></strong>
</div>
<?php } elseif ($avarage == "stars") { ?>
<div class="misc-pub-section" style="background:#BBDCFF; text-shadow:1px 1px 2px rgba(255,255,255,0.1);">
<?php _e('Avarage', 'bestia'); ?> : <?php if(function_exists('the_ratings')) { echo ''.expand_ratings_template('<span class="rating-images">%RATINGS_IMAGES%</span>', get_the_ID()); } ?>
</div>
<?php }
 }
add_action( 'admin_menu' , 'adultwpthemes_statsdiv_block' );

/* Display Admin Bar Only to Admin mytubepress.com . ------------------------------------*/
if (!current_user_can('manage_options')) {
	add_filter('show_admin_bar', '__return_false');
}

//Get current url after login submission
function bestia_get_requested_url() {
	$url  = is_ssl() ? 'https://' : 'http://';
	$url .= $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

	return apply_filters( 'bestia_get_requested_url', esc_url($url));
}

function remove_redux_notices() {
    if ( class_exists('ReduxFrameworkPlugin') ) {
        remove_filter( 'plugin_row_meta', array( ReduxFrameworkPlugin::get_instance(), 'plugin_metalinks'), null, 2 );
    }
    if ( class_exists('ReduxFrameworkPlugin') ) {
        remove_action('admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );
    }
}
add_action('init', 'remove_redux_notices');
