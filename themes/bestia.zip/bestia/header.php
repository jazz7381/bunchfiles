<!DOCTYPE html>
<?php global $awpt; ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
<?php if( $awpt['rounded-pagination'] == 1 ){ ?>
<style type="text/css">.pager a{border-radius: 50% !important;margin: 0 5px;}.pager span.current{border-radius: 50% !important;}</style>
<?php } if( $awpt['center-pagination'] == 1 ){ ?>
<style type="text/css">.pager {text-align: center !important;}</style>
<?php }
if( $awpt['mtn_hidemenus'] == 0 ) { echo '<style type="text/css">#head {height: 76px !important;}.navbar-default {margin-top: 0 !important;}@media (max-width: 1260px) {#head {height: 0 !important;}}</style>';
}
$header_msg = isset($awpt['head_messagge']) ? $awpt['head_messagge'] : '';
if ( class_exists( 'BuddyPress' ) ) { ?>
<style type="text/css">
.bp-single-vert-nav .item-body:not(#group-create-body) {border-left: 1px solid <?php echo $awpt['bp_itembody_bg']; ?> !important;padding-right: 10px !important;}
.buddypress-wrap.bp-vertical-navs .main-navs.user-nav-tabs ul li.selected {border: 1px solid <?php echo $awpt['bp_itembody_bg']; ?> !important;color: <?php echo $awpt['bp_itembody_color']; ?> !important;}
.bp-list {border-top: 1px solid <?php echo $awpt['bp_itembody_bg']; ?> !important;}
.bp-single-vert-nav .item-body:not(#group-create-body) #subnav:not(.tabbed-links) li.current a {color: <?php echo $awpt['bp_itembody_color']; ?> !important;}
#buddypress .item-body, .bp-messages, .bp-single-vert-nav .item-body:not(#group-create-body),
.buddypress-wrap.bp-vertical-navs .main-navs.user-nav-tabs ul li.selected, .bp-navs,
.activity-list.bp-list, .activity-list.bp-list .activity-item, #buddypress .bp-list .action, form.ac-form .ac-reply-content .ac-textarea textarea, .buddypress-wrap button.ac-reply-cancel, .buddypress-wrap button.bp-icons {background: <?php echo $awpt['bp_itembody_bg']; ?> !important;color: <?php echo $awpt['bp_itembody_color']; ?> !important;}
.bp-vertical-navs .main-navs.user-nav-tabs ul li.selected a {color: <?php echo $awpt['bp_itembody_color']; ?> !important;}
</style>
<?php } if (!empty($awpt['vibrate_logo'])) { ?>
<style type="text/css">
.navbar-brand:hover {
  animation: shake 0.42s cubic-bezier(.3,.10,.16,.2) both;
  transform: translate3d(0, 0, 0);
  backface-visibility: hidden;
  perspective: 1000px;
}
</style>
<?php } ?>
<style type="text/css">
.Thumbnail_List li.5890:hover {background: none;}
.Thumbnail_List li .post-views span.bestia_view_text,
.Thumbnail_List li .time_thumb span.duration {
  color: #fff !important;
}
.widget_text {display: block !important;text-align: left;}
.item-list-tabs li.selected a span,.item-list-tabs li.selected span {color: #fff;}
</style>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div id="head">
<?php if( $awpt['mtn_hidemenus'] == 1 ){ ?>
  <div class="top-bar navbar-fixed-top">
  	<div class="container top-menux">
  		<div class="clearfix">
        <div class="pull-left left">
         <div class="top-bar-left">
           <?php
           if( has_nav_menu('primary') ){
                wp_nav_menu( array(
               'theme_location'	=> 'primary',
               'container_class' => 'collapse navbar-collapse',
               'depth'				=> 10, // 1 = with dropdowns, 0 = no dropdowns.
               'menu_class'		=> 'nav navbar-nav',
               'fallback_cb'		=> 'Bestia_Walker_Nav_Menu::fallback',
               'walker'			=> new Bestia_Walker_Nav_Menu()
              ) );
            }
          ?>
         </div>
      </div>
  			<div class="pull-right right">
         <div class="top-bar-right">
           <?php get_template_part('inc/pmpro_levels_menu.php',get_post_format()); ?>
          <?php get_template_part('inc/ajax_notifications',get_post_format()); ?>
         </div>
  		</div>
  	</div>
  </div>
</div>
<?php	} ?>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
    <div class="container second-bar">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <a class="navbar-brand <?php if( $awpt['centered_logo'] == 1 ){ ?>navbar-brand-centered<?php } ?>" href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>">
        <?php $logo = $awpt['mtn_logo']['url']; if (!empty($logo)) { ?>
        <img src="<?php echo $logo; ?>" alt="<?php bloginfo('name'); ?>" />
        <?php } else { ?>
        <img src="<?php bloginfo('template_directory'); ?>/images/logo.png">
        <?php } ?>
        </a>
      </div>
      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="slide-navbar-collapse">
        <div class="navbar-form navbar-right navbar-form-search">
        <button type="submit" class="btn btn-default" name="search" id="search-button"><span class="fa fa-search" aria-hidden="true"></span></button>
      </div>
      <div class="main_navigations">
        <?php

        if( has_nav_menu('secondary') ){
             wp_nav_menu( array(
            'theme_location'	=> 'secondary',
            'container_class' => 'collapse navbar-collapse',
            'depth'				=> 10, // 1 = with dropdowns, 0 = no dropdowns.
            'menu_class'		=> 'nav navbar-nav',
            'fallback_cb'		=> 'Bestia_Walker_Nav_Menu::fallback',
            'walker'			=> new Bestia_Walker_Nav_Menu()
           ) );
         }
         else{
         ?>
             <ul class="nav navbar-nav list-inline menu"><li class="active"><a href="<?php print home_url();?>"><?php _e('Home','bestia')?></a></li></ul>
         <?php } ?>

          <?php if( has_nav_menu('secondary-right') ){
          wp_nav_menu( array(
            'theme_location'	=> 'secondary-right',
            'depth'				=> 10, // 1 = with dropdowns, 0 = no dropdowns.
            'menu_class'		=> 'nav navbar-nav navbar-right',
            'fallback_cb'		=> 'Bestia_Walker_Nav_Menu::fallback',
            'walker'			=> new Bestia_Walker_Nav_Menu()
        ) );
      }

    ?>
  </div>
      </div>
    </div>
    </div>
  </nav>
</div>
<div class="menu-overlay"></div>
<?php get_template_part( 'inc/slide_menu_right', get_post_format() );  ?>
<?php get_template_part( 'inc/slide_menu_left', get_post_format() );  ?>
<div class="mobile_header">
<div class="container">
<div class="holder">
<?php if( $awpt['mtn_hidemenus'] == 1 && has_nav_menu('primary') ){ ?>
<div class="btn_top left_toggle" style="position: relative; z-index: 2;">
<span class="filter_rotate open_bar_left btn_menu pull-left"><i class="fa fa-sliders" aria-hidden="true"></i></span>
</div>
<?php } ?>
<a class="logo" href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>">
  <?php $logo = $awpt['mtn_logo']['url']; if (!empty($logo)) { ?>
  <img src="<?php echo $logo; ?>" alt="<?php bloginfo('name'); ?>" />
  <?php } else { ?>
  <img src="<?php bloginfo('template_directory'); ?>/images/logo.png">
  <?php } ?>
</a>

<div class="btn_top" style="position: relative; z-index: 2;">
<span class="btn_menu search_btn" id="search-btn_mobile"><i class="fa fa-search"></i></span>
<span class="rotate open_bar btn_menu"><i class="fa fa-bars"></i></span>
</div>
</div>
</div>
</div>
<?php
if( $awpt['flyout-performers'] == 1 && !wp_is_mobile() ){
get_template_part( 'flyout-content/flyout-performers', get_post_format() );
} if( $awpt['flyout-channels'] == 1 && !wp_is_mobile() ){
get_template_part( 'flyout-content/flyout-channels', get_post_format() );
} if( $awpt['flyout-categories'] == 1 && !wp_is_mobile() ){
get_template_part( 'flyout-content/flyout-categories', get_post_format() );
}
get_template_part( 'inc/tools/search_box', get_post_format() ); ?>
<div class="clearfix"></div>
<!-- Page Content -->
<?php
if (!empty($header_msg)) { ?>
<div class="messagge alert"><?php echo $header_msg; ?></div>
<?php } ?>
<?php do_action( 'bestia_mobile_top_ad' ); ?>
<div class="clearfix"></div>
<?php if ( function_exists('yoast_breadcrumb') ) { yoast_breadcrumb('<div class="container"><div class="breadcrumbs">','</div></div>'); } ?>
