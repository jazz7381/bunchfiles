<?php
/**
 * ReduxFramework Barebones Sample Config File
 * For full documentation, please visit: http://docs.reduxframework.com/
 */

if (!class_exists('Redux')) {
    return;
}
if ( class_exists( 'BuddyPress' ) ) {
  $bp_active = true;
} else {
  $bp_active = false;
}
if ( function_exists( 'pmpro_activation' ) ) {
  $pmpro_active = true;
} else {
  $pmpro_active = false;
}
$page_options = array();
$page_options_obj = get_pages('sort_column=post_parent,menu_order');
$page_options[''] = 'Select a page:';
foreach ($page_options_obj as $page) {
    $page_options[$page->ID] = $page->post_title;
}
// This is your option name where all the Redux data is stored.
$opt_name = 'awpt';
$bestia_settings_icon      = get_template_directory_uri() . '/images/settings.png';
/**
 * ---> SET ARGUMENTS
 * All the possible arguments for Redux.
 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
 * */
//$get_jwplayer_key = '<a target="_blank" href="https://dashboard.jwplayer.com/">Get a Jwplayer 7 Key, The Pro now is Free!</a>';
$theme                     = wp_get_theme(); // For use with some settings. Not necessary.
$args                      = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name' => $opt_name,
    // This is where your data is stored in the database and also becomes your global variable name.
    'display_name' => $theme->get('Name'),
    // Name that appears at the top of your panel
    'display_version' => $theme->get('Version'),
    // Version that appears at the top of your panel
    'menu_type' => 'submenu',
    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu' => true,
    // Show the sections below the admin menu item or not
    'menu_title' => __('Settings Panel', 'bestia'),
    'page_title' => __('Bestia Theme Options', 'bestia'),
    // You will need to generate a Google API key to use this feature.
    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
    'google_api_key' => '',
    // Set it you want google fonts to update weekly. A google_api_key value is required.
    'google_update_weekly' => false,
    // Must be defined to add google fonts to the typography module
    'async_typography' => false,
    // Use a asynchronous font on the front end or font string
    //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
    'admin_bar' => false,
    // Show the panel pages on the admin bar
    'admin_bar_icon' => 'dashicons-schedule',
    // Choose an icon for the admin bar menu
    'admin_bar_priority' => 50,
    // Choose an priority for the admin bar menu
    'global_variable' => '',
    // Set a different name for your global variable other than the opt_name
    'dev_mode' => false,
    // Show the time the page took to load, etc
    'update_notice' => false,
    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
    'customizer' => true,
    // Enable basic customizer support
    //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

    // OPTIONAL -> Give you extra features
    'page_priority' => null,
    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_parent'   => 'mytubepress',
    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
    'page_permissions' => 'manage_options',
    // Permissions needed to access the options panel.
    'menu_icon' => false,
    // Specify a custom URL to an icon
    'last_tab' => '',
    // Force your panel to always open to a specific tab (by id)
    'page_icon' => 'icon-themes',
    // Icon displayed in the admin panel next to your menu_title
    'page_slug' => 'bestia-settings',
    // Page slug used to denote the panel
    'save_defaults' => true,
    // On load save the defaults to DB before user clicks save or not
    'default_show' => false,
    // If true, shows the default value next to each field that is not the default value.
    'default_mark' => '',
    // What to print by the field's title if the value shown is default. Suggested: *
    'show_import_export' => true,
    // Shows the Import/Export panel when not used as a field.

    // CAREFUL -> These options are for advanced use only
    'transient_time' => 60 * MINUTE_IN_SECONDS,
    'output' => true,
    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag' => true,
    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
    // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
    'database' => '',
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

    'use_cdn' => true,
    // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

    //'compiler'             => true,

    // HINTS
    'hints' => array(
        'icon' => 'el el-question-sign',
        'icon_position' => 'right',
        'icon_color' => 'lightgray',
        'icon_size' => 'normal',
        'tip_style' => array(
            'color' => 'light',
            'shadow' => true,
            'rounded' => false,
            'style' => ''
        ),
        'tip_position' => array(
            'my' => 'top left',
            'at' => 'bottom right'
        ),
        'tip_effect' => array(
            'show' => array(
                'effect' => 'slide',
                'duration' => '500',
                'event' => 'mouseover'
            ),
            'hide' => array(
                'effect' => 'slide',
                'duration' => '500',
                'event' => 'click mouseleave'
            )
        )
    )
);

/*
// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
$args['admin_bar_links'][] = array(
    'id' => 'redux-docs',
    'href' => 'http://docs.reduxframework.com/',
    'title' => __('Documentation', 'bestia')
);

$args['admin_bar_links'][] = array(
    //'id'    => 'redux-support',
    'href' => 'https://github.com/ReduxFramework/redux-framework/issues',
    'title' => __('Support', 'bestia')
);

$args['admin_bar_links'][] = array(
    'id' => 'redux-extensions',
    'href' => 'reduxframework.com/extensions',
    'title' => __('Extensions', 'bestia')
);

// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
$args['share_icons'][] = array(
    'url' => 'https://www.facebook.com/adultwpthemes/',
    'title' => 'Like us on Facebook',
    'icon' => 'el el-facebook'
);
$args['share_icons'][] = array(
    'url' => 'https://twitter.com/adult_wp_themes',
    'title' => 'Follow us on Twitter',
    'icon' => 'el el-twitter'
);
$args['share_icons'][] = array(
    'url' => 'https://plus.google.com/u/0/101100876733742686564',
    'title' => 'Follow us on Google',
    'icon' => 'el el-googleplus'
);
$args['share_icons'][] = array(
    'url' => 'https://www.youtube.com/channel/UCYPWpWPGoUhq_yv9ERivDTQ',
    'title' => 'Follow us on Youtube',
    'icon' => 'el el-youtube'
);
*/
// Panel Intro text -> before the form
if (!isset($args['global_variable']) || $args['global_variable'] !== false) {
    if (!empty($args['global_variable'])) {
        $v = $args['global_variable'];
    } else {
        $v = str_replace('-', '_', $args['opt_name']);
    }

} else {
    $args['intro_text'] = __('<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'bestia');
}

// Add content after the form.
//$args['footer_text'] = __('<p class="footer-tab"><a href="' . admin_url('themes.php?page=bestia-license') . '">' . __('Bestia License Key', 'bestia') . '</a> | <a href="' . admin_url('themes.php?page=documentation') . '">' . __('Documentation', 'bestia') . '</a> | <a target="_blank" href="https://mytubepress.com/forums/forum/theme-support/bestia-theme/">' . __('Support', 'bestia') . '</a></p>', 'bestia');

Redux::setArgs($opt_name, $args);

// Set the help sidebar
$content = __('<p>This is the sidebar content, HTML is allowed.</p>', 'bestia');
Redux::setHelpSidebar($opt_name, $content);

// -> START Basic Fields
Redux::setSection($opt_name, array(
    'title' => __('Dashboard', 'bestia'),
    'customizer' => false,
    'desc' => __('Bestia Dashboard - General Settings.', 'bestia'),
    'icon' => 'el el-dashboard'
));

Redux::setSection($opt_name, array(
    'title' => __('Home', 'bestia'),
    'subsection' => true,
    'customizer' => false,
    'icon' => 'el el-laptop',
    'fields' => array(
      array(
          'id'       => '57898594-start',
          'type'     => 'osc_accordion', // field type
          'title'    => '<i class="el el-paper-clip"></i> Logo & Favicon', // here you can set the title for accordion

          'position'  => 'start', // to start accordion
          'open'=>false, // set this true in case you want to open it by default
      ),
      array(
          'id' => 'mtn_logo',
          'type' => 'media',
          'url' => true,
          'title' => __('Logo', 'bestia'),
          'compiler' => 'true',
          'desc' => __('Upload your logo.', 'bestia'),
          'subtitle' => __('', 'bestia'),
          'default' => array(
              'url' => ''
          )
      ),
      array(
          'id' => 'mtn_favicon',
          'type' => 'media',
          'url' => true,
          'title' => __('Favicon', 'bestia'),
          'compiler' => 'true',
          'desc' => __('Upload your favicon.', 'bestia'),
          'subtitle' => __('', 'bestia'),
          'default' => array(
              'url' => ''
          )
      ),
      array(
          'id' => 'head_messagge',
          'type' => 'editor',
          'title' => __('Header Notification Bar', 'bestia'),
          'subtitle' => __('This section appears below the site header with your affiliate url, offer, welcome message or anything else.', 'bestia'),
          'args' => array(
              'wpautop' => false,
              'media_buttons' => false,
              'textarea_rows' => 5,
              //'tabindex' => 1,
              //'editor_css' => '',
              'teeny' => true,
              //'tinymce' => array(),
              'quicktags' => true
          )
      ),
      array(
          'id' => 'footer_copyright',
          'title' => __('Footer Copyright', 'bestia'),
          'subtitle' => __('Here you can change the default footer copyright text.', 'bestia'),
          'type' => 'text',
          'placeholder' => '© 2020 Yoursite all rights reserved.',
          'default' => '© 2020 Yoursite all rights reserved.'
      ),
      array(
            'id'       => '57898594-end',
            'type'     => 'osc_accordion', // field type
            'position'  => 'end', // to close the accordion
        ),
        array(
            'id'       => '8029378493-start',
            'type'     => 'osc_accordion', // field type
            'title'    => '<i class="el el-th-large"></i> Sections & Blocks', // here you can set the title for accordion

            'position'  => 'start', // to start accordion
            'open'=>false, // set this true in case you want to open it by default
        ),
        array(
            'id' => 'home_page_layout',
            'desc' => __('Drag and drop items. Disabled section will hide elements from the homepage', 'bestia'),
            'type' => 'sorter',
            'title' => 'Home Page Manager',
            'compiler' => 'true',
            'options' => array(
                'disabled' => array(
                    'video_listing' => 'Videos+Pagination',
                    'latest_gifs' => 'Latest Gifs',
                    'popular_performers' => 'Performers',
                ), 'enabled' => array(
                    'random_listing' => 'Random Videos',
                    'last_listing' => 'Lastest Videos',
                    'galleries' => 'Latest Photos',
                    'popular_categories' => 'Video Categories',
                )
            )
        ),
        array(
            'id' => 'watched_now_videos',
            'type' => 'text',
            'title' => __('Random Videos Block', 'bestia'),
            'subtitle' => __('Posts per page limit for the random videos block on home page.', 'bestia'),
            'default' => '5'
        ),
        array(
            'id' => 'beingwatched_title',
            'title' => __('Random Videos Title', 'bestia'),
            'subtitle' => __('The option where you can change the random videos title. Example: Being Watched Now! ', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Being Watched Now',
            'default' => 'Being Watched Now'
        ),
        array(
        'id'	=>	'feel_lucky',
        'title'	=>	__('I feel lucky - button','popcorn'),
        'subtitle' => __( 'This button is visible on the right side of you random videos block on homepage.', 'popcorn' ),
        'desc' => __('This button redirects user to any video post randomly.', 'redux-framework-demo'),
        'type'	=>	'text',
        'placeholder'	=>	'I feel lucky',
        'default'  => 'I feel lucky'
        ),
        array(
            'id' => 'homepage_videos',
            'type' => 'text',
            'title' => __('Home Page Videos + Pagination)', 'bestia'),
            'desc' => __('Homepage right ads section is visible with this block only.', 'bestia'),
            'subtitle' => sprintf('This option will change your videos to display on homepage or custom videos page template. Please do not forget to go in %s for changing the default 10 number to 5 or to any other lower number in Blog pages show at most field ', '<a target="_blank" href="' . admin_url('options-reading.php') . '">' . __('Settings/Rading', 'bestia') . '</a>'),
            'default' => '30'
        ),
        array(
            'id' => 'homepage_photos',
            'type' => 'text',
            'class' => 'gallery_option',
            'title' => __('Latest Photos Block', 'bestia'),
            'subtitle' => __('Limit photo galleries on the latest photos block for home page.', 'bestia'),
            'default' => '5'
        ),
        array(
            'id' => 'all_galleries_btn',
            'title' => __('View all %total_photos% photos - button', 'bestia'),
            'desc' => __('<b>%total_photos%</b>: Total photo galleries count.', 'bestia'),
            'subtitle' => __('This button is visible on homepage photo galleries section, you can change the text to your language or just use the default one.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'View all %total_photos% photo galleries',
            'default' => 'View all %total_photos% photo galleries'
        ),
        array(
            'id' => 'latest_videos_block',
            'type' => 'text',
            'title' => __('Latest Videos Block', 'bestia'),
            'subtitle' => __('You can set a posts per page limit at any time here. This is an option of (latest videos block) without pagination.', 'bestia'),
            'default' => '5'
        ),
        array(
            'id' => 'all_videos_btn',
            'title' => __('View all %total_videos% videos - button', 'bestia'),
            'subtitle' => __('This button is visible on homepage latest videos section, you can change the text to your language.', 'bestia'),
            'desc' => __('<b>%total_videos%</b>: Total videos count.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'View all %total_videos% videos',
            'default' => 'View all %total_videos% videos'
        ),
        array(
            'id' => 'video_categories_limit',
            'type' => 'text',
            'title' => __('Video Categories Block', 'bestia'),
            'subtitle' => __('In fact this section displays popular categories. You can change limit at any time you wish.', 'bestia'),
            'default' => '3'
        ),
        array(
            'id' => 'cat_desc_vic',
            'type' => 'switch',
            'title' => __('Enable category description?', 'bestia'),
            'desc' => __('Video Categories Block.', 'bestia'),
            "default" => 0,
            'on' => __('Yes', 'bestia'),
            'off' => __('No', 'bestia')
        ),
        array(
            'id' => 'view_all_in_term',
            'desc' => '<b>%term_videos%</b> : Total videos count for each category.<br><b>%category_name%</b> :  Displays the category name in link.',
            'title' => __('View all %term_videos% videos in Category', 'bestia'),
            'subtitle' => __('This is the button below any category displayed by video categories block on homepage.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'View all %term_videos% videos in %category_name%',
            'default' => 'View all %term_videos% videos in %category_name%'
        ),

        array(
            'id' => 'homepage_gifs',
            'type' => 'text',
            'class' => 'gif_option',
            'title' => __('Latest Gifs Block', 'bestia'),
            'subtitle' => __('Limit gif galleries on the latest gifs block for homepage.', 'bestia'),
            'default' => '10'
        ),
          array(
        'id' => 'home_gif_title',
        'title' => __('Latest Gifs - Title', 'bestia'),
        'subtitle' => __('The option where you can change the latest gifs block title. Example: Latest Gif Galleries! ', 'bestia'),
        'type' => 'text',
        'placeholder' => 'Latest Gif Galleries',
        'default' => 'Latest Gif Galleries'
        ),
        array(
            'id' => 'all_gifs_btn',
            'title' => __('View all %total_gifs% gifs - button', 'bestia'),
            'desc' => __('<b>%total_gifs%</b>: Total gif galleries count.', 'bestia'),
            'subtitle' => __('This button is visible on homepage gif galleries section, you can change the text to your language or just use the default one.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'View all %total_gifs% gif galleries',
            'default' => 'View all %total_gifs% gif galleries'
        ),
        array(
            'id' => 'performers_block',
            'type' => 'text',
            'title' => __('Performers Block (Popular)', 'bestia'),
            'subtitle' => __('Performers limit for the popular performers block on home page.', 'bestia'),
            'default' => '40'
        ),
        array(
            'id' => 'performers_block_title',
            'title' => __('Performers Block - Title', 'bestia'),
            'subtitle' => __('The option where you can change the performers block title. Example: Popular Models ', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Popular Models',
            'default' => 'Popular Models'
        ),
        array(
        'id'	=>	'all_performers_btn',
        'title' => __('View all %total_terms% performers - button', 'bestia'),
        'desc' => __('<b>%total_terms%</b>: Total performers count.', 'bestia'),
        'subtitle' => __('This button is visible on homepage popular performers section, you can change the text to your language or just use the default one.', 'bestia'),
        'type' => 'text',
        'placeholder' => 'View all %total_terms% performers',
        'default' => 'View all %total_terms% performers'
      ),
        array(
              'id'       => '8029378493-end',
              'type'     => 'osc_accordion', // field type
              'position'  => 'end', // to close the accordion
          ),
          array(
              'id'       => '989848489393-start',
              'type'     => 'osc_accordion', // field type
              'title'    => '<i class="el el-wrench-alt"></i> Settings & Layout', // here you can set the title for accordion

              'position'  => 'start', // to start accordion
              'open'=>true, // set this true in case you want to open it by default
          ),
          array(
              'id' => 'homepage-layout',
              'type' => 'image_select',
              'title' => __('Home Page Sidebar', 'bestia'),
              'subtitle' => __('Move or disable sidebar from your homepage.', 'bestia'),
              'desc' => __('Choose your favorite homepage layout.', 'bestia'),
              //Must provide key => value(array:title|img) pairs for radio options
              'options' => array(
                  '1' => array(
                      'img' => ReduxFramework::$_url . 'assets/img/1c.png'
                  ),
                  '2' => array(
                      'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                  ),
                  '3' => array(
                      'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                  )
              ),
              'default' => '2'
          ),
          array(
              'id' => 'home_videos_by',
              'type' => 'switch',
              'title' => __('Display latest videos on home page in random mode?', 'bestia'),
              'subtitle' => __('This option works only for the homepage videos with pagination.', 'bestia'),
              //Must provide key => value pairs for radio options
              "default" => 0,
              'on' => __('Yes', 'bestia'),
              'off' => __('No', 'bestia')
          ),
          array(
                'id'       => '989848489393-end',
                'type'     => 'osc_accordion', // field type
                'position'  => 'end', // to close the accordion
            ),
    )
));

Redux::setSection($opt_name, array(
    'title' => __('Language', 'bestia'),
    'desc' => __('Here you can edit some important phrases and titles.If you are using a non-English site you can translate default.po wich is located in languages folder.', 'bestia'),
    'subsection' => true,
    'icon' => 'el el-globe',
    'fields' => array(
      array(
          'id'       => '62083902-start',
          'type'     => 'osc_accordion', // field type
          'title'    => 'General', // here you can set the title for accordion

          'position'  => 'start', // to start accordion
          'open'=>true, // set this true in case you want to open it by default
      ),
        array(
            'id' => 'mtn_newest_title',
            'title' => __('New Videos Title', 'bestia'),
            'subtitle' => __('The option where you can change the newest videos title.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Latest Videos',
            'default' => 'Latest Videos'
        ),
        array(
            'id' => 'mtn_newest_galleries_title',
            'title' => __('New Photo Galleries Title', 'bestia'),
            'subtitle' => __('The option where you can change the newest galleries title.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Newest Photos',
            'default' => 'Newest Photos'
        ),
        array(
            'id' => 'mtn_related_title',
            'title' => __('Related Videos Title', 'bestia'),
            'subtitle' => __('The option where you can change the related videos title.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Related Videos',
            'default' => 'Related Videos'
        ),
        array(
            'id' => 'mtn_related_photos_title',
            'title' => __('Related Photo Galleries Title', 'bestia'),
            'subtitle' => __('The option where you can change the related photos title.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Related Photos',
            'default' => 'Related Photos'
        ),
        array(
            'id' => 'mtn_related_gifs_title',
            'title' => __('Related Gif Galleries Title', 'bestia'),
            'subtitle' => __('The option where you can change the related gif galleries title.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Related Gifs',
            'default' => 'Related Gifs'
        ),
        array(
            'id' => 'mtn_rated_title',
            'title' => __('Most Rated Videos Page Title', 'bestia'),
            'subtitle' => __('The option where you can change the highest rated videos template title.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Highest Rated',
            'default' => 'Highest Rated'
        ),
        array(
            'id' => 'mtn_viewed_title',
            'title' => __('Most Viewed Videos Page Title', 'bestia'),
            'subtitle' => __('The option where you can change the most viewed videos template title.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Most Viewed Videos',
            'default' => 'Most Viewed Videos'
        ),
        array(
            'id' => 'mtn_commented_title',
            'title' => __('Most Commented Videos Page Title', 'bestia'),
            'subtitle' => __('Here you can change the most commented videos page title.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Most Commented Videos',
            'default' => 'Most Commented Videos'
        ),
        array(
              'id'       => '62083902-end',
              'type'     => 'osc_accordion', // field type
              'position'  => 'end', // to close the accordion
          ),
          array(
              'id'       => '620239487-start',
              'type'     => 'osc_accordion', // field type
              'title'    => 'Advertising', // here you can set the title for accordion

              'position'  => 'start', // to start accordion
              'open'=>false, // set this true in case you want to open it by default
          ),
        array(
            'id' => 'ad_text',
            'title' => __('Advertisement Text', 'bestia'),
            'subtitle' => __('The option where you can change Advertisement text in your player ads.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'ADVERTISEMENT',
            'default' => 'ADVERTISEMENT'
        ),
        array(
            'id' => 'ad_close',
            'title' => __('Inplayer ADS Close and Play Text', 'bestia'),
            'subtitle' => __('If you wish with this option you can change the close and play text which is visible in player advertisements', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Continue to content',
            'default' => 'Continue to content'
        ),
        array(
              'id'       => '620239487-end',
              'type'     => 'osc_accordion', // field type
              'position'  => 'end', // to close the accordion
          ),
          array(
              'id'       => '698754-start',
              'type'     => 'osc_accordion', // field type
              'title'    => 'Paginations', // here you can set the title for accordion

              'position'  => 'start', // to start accordion
              'open'=>false, // set this true in case you want to open it by default
          ),
        array(
            'id' => 'pagination_next',
            'title' => __('Pagination - Next Page text', 'bestia'),
            'subtitle' => __('Change here the next page text of your pagination.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Next &raquo;',
            'default' => 'Next &raquo;'
        ),
        array(
            'id' => 'pagination_prev',
            'title' => __('Pagination - Previous Page text', 'bestia'),
            'subtitle' => __('Change here the previous page text of your pagination.', 'bestia'),
            'type' => 'text',
            'placeholder' => '&laquo; Previous',
            'default' => '&laquo; Previous'
        ),
        array(
            'id' => 'part_btn',
            'title' => __('Multiple videos pagination button', 'bestia'),
            'subtitle' => __('This theme allows you to add multiple embedded or self hosted videos and it displays a pagination like, Part 1, Part 2 etc. You can translate into your language without editing media file.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Part',
            'default' => 'Part'
        ),
        array(
            'id' => 'image_next',
            'title' => __('Attachment - Next Image', 'bestia'),
            'subtitle' => __('Change here the next image text of your image gallery.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Next Image &raquo;',
            'default' => 'Next Image &raquo;'
        ),
        array(
            'id' => 'image_prev',
            'title' => __('Attachment - Previous Image', 'bestia'),
            'subtitle' => __('Change here the previous image text for your image gallery.', 'bestia'),
            'type' => 'text',
            'placeholder' => '&laquo; Previous Image',
            'default' => '&laquo; Previous Image'
        ),
        array(
            'id' => 'image_back',
            'title' => __('Attachment - Back to Gallery', 'bestia'),
            'subtitle' => __('Here you can change back to gallery button text which is in your attachment image page.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Back to Gallery',
            'default' => 'Back to Gallery'
        ),
        array(
              'id'       => '698754-end',
              'type'     => 'osc_accordion', // field type
              'position'  => 'end', // to close the accordion
          ),
          array(
              'id'       => '66597033-start',
              'type'     => 'osc_accordion', // field type
              'title'    => 'Post Like & Dislike', // here you can set the title for accordion

              'position'  => 'start', // to start accordion
              'open'=>false, // set this true in case you want to open it by default
          ),
        array(
            'id' => 'vote_thanks',
            'title' => __('Bestia Like Dislike Thankyou Messagge', 'bestia'),
            'subtitle' => __('Here you can change thankyou messagge to display when user votes a post', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Thankyou for your vote!',
            'default' => 'Thankyou for your vote!'
        ),
        array(
            'id' => 'vote_rated',
            'title' => __('Bestia Like Dislike Already Rated Messagge', 'bestia'),
            'subtitle' => __('Here you can change already rated messagge to display if the user has already voted', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Already Rated!',
            'default' => 'Already Rated!'
        ),
        array(
              'id'       => '66597033-end',
              'type'     => 'osc_accordion', // field type
              'position'  => 'end', // to close the accordion
          ),
          array(
              'id'       => '6167819-start',
              'type'     => 'osc_accordion', // field type
              'title'    => 'Sorters', // here you can set the title for accordion

              'position'  => 'start', // to start accordion
              'open'=>false, // set this true in case you want to open it by default
          ),
        array(
            'id' => 'sort_by_mobile',
            'title' => __('Filter By (Mobile)', 'bestia'),
            'subtitle' => __('Option to change sort by text into your language.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Filter by',
            'default' => 'Filter by'
        ),
        array(
            'id' => 'newest_btn',
            'title' => __('Newest', 'bestia'),
            'subtitle' => __('Newest posts button text in sorter section.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Newest',
            'default' => 'Newest'
        ),
        array(
            'id' => 'viewed_btn',
            'title' => __('Most Viewed', 'bestia'),
            'subtitle' => __('Most viewed posts button text in sorter section.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Most Viewed',
            'default' => 'Most Viewed'
        ),
        array(
            'id' => 'rating_btn',
            'title' => __('Rating', 'bestia'),
            'subtitle' => __('Most rated posts button text in sorter section.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Rating',
            'default' => 'Rating'
        ),
        array(
            'id' => 'discussed_btn',
            'title' => __('Discussed', 'bestia'),
            'subtitle' => __('Most discussed posts button text in sorter section.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Discussed',
            'default' => 'Discussed'
        ),
        array(
            'id' => 'gender_btn',
            'title' => __('Gender Sorting Button', 'bestia'),
            'subtitle' => __('Gender sorting button text in the performer list template.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Gender Sorting',
            'default' => 'Gender Sorting'
        ),
        array(
            'id' => 'men_btn',
            'title' => __('Men', 'bestia'),
            'subtitle' => __('Men text for gender sorting in the performer list.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Men',
            'default' => 'Men'
        ),
        array(
            'id' => 'women_btn',
            'title' => __('Women', 'bestia'),
            'subtitle' => __('Women text for gender sorting in the performer list.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Women',
            'default' => 'Women'
        ),
        array(
            'id' => 'trans_btn',
            'title' => __('Transgender', 'bestia'),
            'subtitle' => __('Transgender text for gender sorting in the performer list.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Transgender',
            'default' => 'Transgender'
        ),
        array(
              'id'       => '6167819-end',
              'type'     => 'osc_accordion', // field type
              'position'  => 'end', // to close the accordion
          ),
          array(
              'id'       => '6966696-start',
              'type'     => 'osc_accordion', // field type
              'title'    => 'Buttons', // here you can set the title for accordion

              'position'  => 'start', // to start accordion
              'open'=>false, // set this true in case you want to open it by default
          ),
        array(
            'id' => 'show_more_btn',
            'title' => __('Button - Show More Related Videos', 'bestia'),
            'subtitle' => __('This button is visible below the related videos, you can change the text to your language or just use the default one.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Show more related videos',
            'default' => 'Show more related videos'
        ),

        array(
            'id' => 's_opt_video',
            'title' => __('Video option', 'bestia'),
            'subtitle' => __('Video is visible in the search options list, on the left side of your searchbox.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Video',
            'default' => 'Video'
        ),
        array(
            'id' => 's_opt_video_search',
            'desc' => 'use <b>%total_videos%</b> to display total videos count of your site.',
            'title' => __('Search %total_videos% Videos', 'bestia'),
            'subtitle' => __('This is the placeholder text in your searchform input, when you change the post type option this text will come up as a placeholder.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Search %total_videos% videos...',
            'default' => 'Search %total_videos% videos...'
        ),

        array(
            'id' => 's_opt_photo',
            'title' => __('Photo option', 'bestia'),
            'subtitle' => __('Photo is visible in the search options list, on the left side of your searchbox.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Photo',
            'default' => 'Photo'
        ),
        array(
            'id' => 's_opt_photo_search',
            'desc' => 'use <b>%total_photos%</b> to display total photo galleries count of your site.',
            'title' => __('Search %total_photos% Photos', 'bestia'),
            'subtitle' => __('This is the placeholder text in your searchform input, when you change the post type option this text will come up as a placeholder.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Search %total_photos% photos...',
            'default' => 'Search %total_photos% photos...'
        ),

        array(
            'id' => 's_opt_gif',
            'title' => __('Gif option', 'bestia'),
            'subtitle' => __('Gif option is visible in the search options list, the drop down menu on the left side of your searchbox.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Gif',
            'default' => 'Gif'
        ),
        array(
            'id' => 's_opt_gif_search',
            'desc' => 'use <b>%total_gifs%</b> to display total gif galleries count of your site.',
            'title' => __('Search %total_gifs% Gifs', 'bestia'),
            'subtitle' => __('This is the placeholder text in your searchform input, when you change the post type option this text will come up as a placeholder.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Search %total_gifs% gifs...',
            'default' => 'Search %total_gifs% gifs...'
        ),

        array(
            'id' => 's_opt_blog',
            'title' => __('Blog option', 'bestia'),
            'subtitle' => __('Blog option is visible in the search options list, the drop down menu on the left side of your searchbox.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Blog',
            'default' => 'Blog'
        ),
        array(
            'id' => 's_opt_blog_search',
            'desc' => 'use <b>%total_blogs%</b> to display total blog articles count of your site.If you change the blog post type slug to anything else ex: story you can rename blog using this key.',
            'title' => __('Search %total_blogs% Blogs', 'bestia'),
            'subtitle' => __('This is the placeholder text in your searchform input, when you change the post type option this text will come up as a placeholder.', 'bestia'),
            'type' => 'text',
            'placeholder' => 'Search %total_blogs% blogs...',
            'default' => 'Search %total_blogs% blogs...'
        ),
        /*
        array(
            'id' => 'read_more',
            'title' => __('Video Description - Click to read more', 'tubemobile'),
            'subtitle' => __('By changing this key you will overwrite the text click to read more button text which is under the video description.', 'tubemobile'),
            'type' => 'text',
            'placeholder' => 'Click to read more',
            'default' => 'Click to read more'
        ),
        array(
            'id' => 'collapse',
            'title' => __('Video Description - Click to collapse', 'tubemobile'),
            'subtitle' => __('By changing this key you will overwrite the text click to collapse button text which is under the video description.', 'tubemobile'),
            'type' => 'text',
            'placeholder' => 'Click to collapse',
            'default' => 'Click to collapse'
        )
        */
        array(
              'id'       => '6966696-end',
              'type'     => 'osc_accordion', // field type
              'position'  => 'end', // to close the accordion
          ),
    )
));

Redux::setSection($opt_name, array(
    'title' => __('Heading Tags', 'bestia'),
    'desc' => sprintf('Heading tags define which parts of your content are important, and show how they’re interconnected. Please read more about heading tags on %s.', '<a target="_blank" href="https://yoast.com/how-to-use-headings-on-your-site/">' . __('Yoast Blog', 'bestia') . '</a>'),
    'customizer' => false,
    'subsection' => true,
    'id' => 'heading-tags',
    'icon' => 'el el-zoom-in',
    'fields' => array(
      array(
          'id' => 'general_title_heading',
          'type' => 'select',
          'title' => __('Heading Tag for general site titles', 'bestia'),
          'subtitle' => __('The option where you can change general site titles heading tag for example: Latest Updates, Latest Photo Galleries etc...', 'bestia'),
          'desc' => __('Select a heading tag for the general site titles', 'bestia'),
          'options' => array(
              'h1' => 'h1',
              'h2' => 'h2',
              'h3' => 'h3',
              'h4' => 'h4',
              'h5' => 'h5',
              'h6' => 'h6',
              'span' => 'span'
          ),
          'default' => 'h1'
      ),
      array(
          'id' => 'live_videos_heading',
          'type' => 'select',
          'title' => __('Heading Tag for the being whatched now section.', 'bestia'),
          'subtitle' => __('having more than one h1 tag in a page is a very bad way for seo but the bestia hompage have multiple sections, so here you can change the heading tag for this section.', 'bestia'),
          'desc' => __('Select a heading tag for the random videos (being whatched now)', 'bestia'),
          'options' => array(
              'h1' => 'h1',
              'h2' => 'h2',
              'h3' => 'h3',
              'h4' => 'h4',
              'h5' => 'h5',
              'h6' => 'h6',
              'span' => 'span'
          ),
          'default' => 'span'
      ),
      array(
          'id' => 'sidebar_title_heading',
          'type' => 'select',
          'title' => __('Heading Tag for widget titles', 'bestia'),
          'subtitle' => __('Here you can change heading tags for widget titles on your sidebars', 'bestia'),
          'desc' => __('Select a heading tag for your widget titles', 'bestia'),
          'options' => array(
              'h1' => 'h1',
              'h2' => 'h2',
              'h3' => 'h3',
              'h4' => 'h4',
              'h5' => 'h5',
              'h6' => 'h6',
              'span' => 'span'
          ),
          'default' => 'span'
      ),
      array(
          'id' => 'thumbnail_title_heading',
          'type' => 'select',
          'title' => __('Heading Tag for thumbnail title', 'bestia'),
          'subtitle' => __('Here you can change the default heading tag for the title under the thumbnails.If you are a seo expert and you want to change it this is the right option.Default is h3', 'bestia'),
          'desc' => __('Select a heading tag for the titles in thumblist', 'bestia'),
          //Must provide key => value pairs for select options
          'options' => array(
              'h1' => 'h1',
              'h2' => 'h2',
              'h3' => 'h3',
              'h4' => 'h4',
              'h5' => 'h5',
              'h6' => 'h6',
              'span' => 'span'
          ),
          'default' => 'h3'
      ),
      array(
          'id' => 'footer_title_heading',
          'type' => 'select',
          'title' => __('Heading Tag for footer widget titles', 'bestia'),
          'subtitle' => __('Here you can change the default heading tag for the titles of your footer widgets', 'bestia'),
          'desc' => __('Select a heading tag for the titles of your footer widgets', 'bestia'),
          //Must provide key => value pairs for select options
          'options' => array(
              'h1' => 'h1',
              'h2' => 'h2',
              'h3' => 'h3',
              'h4' => 'h4',
              'h5' => 'h5',
              'h6' => 'h6',
              'span' => 'h6'
          ),
          'default' => 'h6'
      ),
      array(
          'id' => 'related_title_heading',
          'type' => 'select',
          'title' => __('Heading Tag for related posts.', 'bestia'),
          'subtitle' => __('The opion where you can easyly change the heading tag for bestia related posts (video and photo)', 'bestia'),
          'desc' => __('Select a heading tag for the related posts', 'bestia'),
          //Must provide key => value pairs for select options
          'options' => array(
              'h1' => 'h1',
              'h2' => 'h2',
              'h3' => 'h3',
              'h4' => 'h4',
              'h5' => 'h5',
              'h6' => 'h6',
              'span' => 'span'
          ),
          'default' => 'span'
      ),
    )
));

$user_db = NULL;
$users   = get_users(array(
    'role' => null
));
foreach ($users as $user) {
    $user_db[$user->ID] = $user->user_login;
}

Redux::setSection($opt_name, array(
    'title' => __('Extra Settings', 'bestia'),
    'customizer' => false,
    'subsection' => true,
    'icon' => 'el el-wrench',
    'fields' => array(
      array(
          'id'       => '956578923-start',
          'type'     => 'osc_accordion', // field type
          'title'    => '<i class="el el-compass-alt"></i> Compatibility', // here you can set the title for accordion

          'position'  => 'start', // to start accordion
          'open'=>false, // set this true in case you want to open it by default
      ),
      array(
          'id' => 'mtn_video_grabber',
          'panel' => false,
          'type' => 'button_set',
          'title' => __('Compatibility', 'bestia'),
          'desc' => __('Custom key is for developers only (bestia/compatibility/custom)', 'bestia'),
          //Must provide key => value pairs for radio options
          'options' => array(
              'default' => __('Default (NO PLUGIN)', 'bestia'),
              'custom' => __('Custom', 'bestia')
              //'tubeace' => __('Tube ACE','bestia'),
              //'wpscript' => __('WP-Script','bestia'),
          ),
          'default' => 'default'
      ),
      array(
          'id' => 'post_description_type',
          'type' => 'switch',
          'title' => __('Video Description Type', 'bestia'),
          'subtitle' => __('By default the post content allows to use it as a video description but if you have an actual old site which uses via custom field you can change it here.', 'bestia'),
          "default" => 1,
          'on' => __('Post Content', 'bestia'),
          'off' => __('Custom Field', 'bestia')
      ),
      array(
          'id' => 'thumb',
          'title' => __('Custom field name for THUMBNAIL', 'bestia'),
          'subtitle' => __('Here you can change the thumbnail custom field name.', 'bestia'),
          'type' => 'text',
          'default' => 'thumb_url',
          'placeholder' => 'thumb_url'
      ),
      array(
          'id' => 'duration',
          'title' => __('Custom field name for VIDEO DURATION', 'bestia'),
          'subtitle' => __('Here you can change the thumbnail custom field name.', 'bestia'),
          'type' => 'text',
          'default' => 'video_duration',
          'placeholder' => 'video_duration'
      ),
      array(
          'id' => 'video_duration_seconds',
          'type' => 'switch',
          'title' => __('Duration - Seconds Converter', 'bestia'),
          'subtitle' => __('Some video grabber plugins catch video duration in seconds and its not possible to convert it to minutes by default, if you have a similar problem enable this key.', 'bestia'),
          "default" => 0,
          'on' => __('Yes', 'bestia'),
          'off' => __('No', 'bestia')
      ),
      array(
          'id' => 'embed',
          'title' => __('Custom field name for EMBED CODE', 'bestia'),
          'subtitle' => __('Here you can change the embed videos custom field name.', 'bestia'),
          'type' => 'text',
          'default' => 'embed_code',
          'placeholder' => 'embed_code'
      ),
      array(
          'id' => 'videourl',
          'title' => __('Custom field name for VIDEO URL', 'bestia'),
          'subtitle' => __('Here you can change the video url custom field name(mp4,flv etc.(NOTE: Do not change it to video_url or video_file since both fields are enabled by default.))', 'bestia'),
          'type' => 'text',
          'default' => 'video_format',
          'placeholder' => 'video_format'
      ),
      array(
          'id' => 'vide_description',
          'title' => __('Custom field name for VIDEO Description', 'bestia'),
          'subtitle' => __('Here you can change the video description custom field name(mp4,flv etc.)', 'bestia'),
          'type' => 'text',
          'default' => 'video_description',
          'placeholder' => 'video_description'
      ),
      array(
            'id'       => '956578923-end',
            'type'     => 'osc_accordion', // field type
            'position'  => 'end', // to close the accordion
        ),
        array(
            'id'       => '7878642-start',
            'type'     => 'osc_accordion', // field type
            'title'    => '<i class="el el-eye-close"></i> Fake Post Views', // here you can set the title for accordion

            'position'  => 'start', // to start accordion
            'open'=>false, // set this true in case you want to open it by default
        ),
        array(
            'id' => 'fake-post-views',
            'type' => 'switch',
            'class' => 'fpv_first',
            'title' => __('Fake Post Views', 'bestia'),
            'subtitle' => __('Using this key on you can display fake post views for each post randomly, you can manage the minimum and maximum numbers below', 'bestia'),
            //Must provide key => value pairs for radio options
            'options' => array(
                'on' => __('ON', 'bestia'),
                'off' => __('OFF', 'bestia')
            ),
            'default' => '0'
        ),
        array(
            'id' => 'fake-views-min-value',
            'class' => 'fpv',
            'title' => __('Minimum Views Value', 'bestia'),
            'subtitle' => __('Default is 1000, this means that fake views will display different number from 1000 to maximum value given below.', 'bestia'),
            'type' => 'text',
            'default' => '1000',
            'placeholder' => '1000'
        ),
        array(
            'id' => 'fake-views-max-value',
            'class' => 'fpv',
            'title' => __('Maximum Views Value', 'bestia'),
            'subtitle' => __('You can change the default number of maximum fake views value to another one.', 'bestia'),
            'type' => 'text',
            'default' => '9999',
            'placeholder' => '9999'
        ),
        array(
              'id'       => '7878642-end',
              'type'     => 'osc_accordion', // field type
              'position'  => 'end', // to close the accordion
          ),
          array(
              'id'       => '598983294-start',
              'type'     => 'osc_accordion', // field type
              'title'    => '<i class="el el-thumbs-up"></i> Fake Post Ratings', // here you can set the title for accordion

              'position'  => 'start', // to start accordion
              'open'=>false, // set this true in case you want to open it by default
          ),
          array(
              'id' => 'fake-post-rating',
              'class' => 'fpr_first',
              'type' => 'switch',
              'title' => __('Fake Post Rating', 'bestia'),
              'subtitle' => __('Using this key on you can display fake post rating avarage for each post randomly, you can manage the minimum and maximum numbers below', 'bestia'),
              //Must provide key => value pairs for radio options
              'options' => array(
                  'on' => __('ON', 'bestia'),
                  'off' => __('OFF', 'bestia')
              ),
              'default' => '0'
          ),
          array(
              'id' => 'fake-rating-min-value',
              'class' => 'fpr',
              'title' => __('Minimum Rating Value', 'bestia'),
              'subtitle' => __('Default is 60, this means that rating avarage will display a different number from 60 to maximum value given below, you can change it to 40, 30 or anything lower than the maximum rating value.', 'bestia'),
              'type' => 'text',
              'default' => '60',
              'placeholder' => '60'
          ),
          array(
              'id' => 'fake-rating-max-value',
              'class' => 'fpr',
              'title' => __('Maximum Rating Value', 'bestia'),
              'subtitle' => __('You can change the default number of maximum fake rating avarage to another one.(not more than 100)', 'bestia'),
              'type' => 'text',
              'default' => '100',
              'placeholder' => '100'
          ),
          array(
                'id'       => '598983294-end',
                'type'     => 'osc_accordion', // field type
                'position'  => 'end', // to close the accordion
            ),
            array(
                'id'       => '43904348-start',
                'type'     => 'osc_accordion', // field type
                'title'    => '<i class="el el-gift"></i> Extra Magic Tools', // here you can set the title for accordion

                'position'  => 'start', // to start accordion
                'open'=>false, // set this true in case you want to open it by default
            ),
            array(
                'id' => 'thumbfix',
                'type' => 'switch',
                'title' => __('Resize Preview Images via Javascript?', 'bestia'),
                'subtitle' => __('This key by default is disabled because our mission is to deliver high-quality & fast WordPress themes.Less javascript codes mean a faster website, if you do not have any problem with the thumbnails do not change this key.', 'bestia'),
                'desc' => __('There are various reasons about the thumbnail height issues, normaly theme must crop the video preview images in the same size but sometimes you do not have php gd library installed or you have a diffrent video grabber which does not support it, so enable this key to resize all thumbs in the same size.', 'bestia'),
                "default" => 0,
                'on' => __('Yes', 'bestia'),
                'off' => __('No', 'bestia')
            ),
            array(
                  'id'       => '43904348-end',
                  'type'     => 'osc_accordion', // field type
                  'position'  => 'end', // to close the accordion
              ),
              array(
                  'id'       => '7729389-start',
                  'type'     => 'osc_accordion', // field type
                  'title'    => '<i class="el el-upload"></i> Submit Form', // here you can set the title for accordion

                  'position'  => 'start', // to start accordion
                  'open'=>false, // set this true in case you want to open it by default
              ),
              array(
                    'id'       => '4form-information',
                    'desc' => sprintf('This theme allows you to have an user video sharing page, please give a minute to checkout our %s for more details. <strong style="float:right;">shortcode: <span>[upload]</span></strong>', '<a target="_blank" href="https://mytubepress.com/knowledge-base/bestia-video-submission-form/">' . __('documentation page', 'bestia') . '</a>'),
                    'type'     => 'info', // field type
                ),
              array(
                  'id' => 'submit_roles',
                  'type' => 'select',
                  'multi' => true,
                  'data' => 'roles',
                  'title' => __('Who can submit the video?', 'bestia'),
                  'desc' => __('You can choose one or multi-roles to limit the permission.', 'bestia'),
              ),
              array(
                  'id' => 'video-type',
                  'type' => 'select',
                  'multi' => true,
                  'title' => __('Video Type', 'bestia'),
                  'subtitle' => __('Choose the Video Type, which is available in Submit Form at Frontend.', 'bestia'),
                  'options' => array(
                      'videolink' => __('Link', 'bestia'),
                      'embedcode' => __('Embed Code', 'bestia'),
                      'videofile' => __('File', 'bestia')
                  ), //Must provide key => value pairs for select options
                  'desc' => __('Note: The link option works with wordpress wp_oembed function which transforms only youtube and vimeo urls to an embed code.', 'bestia'),
                  'default' => 'videofile'
              ),
              array(
                  'id' => 'videosize',
                  'title' => __('Video File Size', 'bestia'),
                  'type' => 'text',
                  'desc' => __('The maximum video file size allowed, 10MB is default size, -1 is no limit.', 'bestia'),
                  'default' => 10
              ),
              array(
                  'id' => 'imagesize',
                  'title' => __('Preview Image Size', 'bestia'),
                  'type' => 'text',
                  'desc' => __('The maximum Preview Image size allowed, 10MB is default size, -1 is no limit.', 'bestia'),
                  'default' => 2
              ),
              array(
                  'id' => 'submit_redirect_to',
                  'type' => 'select',
                  'data' => 'pages',
                  'title' => __('Redirect to', 'bestia'),
                  'desc' => __('Redirect the user to this page when successfully submitted the video.', 'bestia')
              ),
              array(
                  'id' => 'submit_assigned_user',
                  'type' => 'select',
                  'title' => __('Assignment User', 'bestia'),
                  'subtitle' => __('The video will be assigned for this user if you allow Guest Submit The Video.', 'bestia'),
                  'options' => $user_db,
                  'default' => '1'
              ),
              array(
                  'id' => 'submit_status',
                  'type' => 'button_set',
                  'title' => __('Default Video Status', 'bestia'),
                  'subtitle' => __('The Public status will be shown on Frontend.', 'bestia'),
                  'options' => array(
                      'publish' => __('Publish', 'bestia'),
                      'pending' => __('Pending', 'bestia'),
                      'draft' => __('draft', 'bestia')
                  ),
                  'default' => 'pending'
              ),
              array(
                  'id' => 'submit_editor',
                  'type' => 'switch',
                  'title' => __('Use WP Visual Editor', 'bestia'),
                  "default" => 0,
                  'on' => __('Yes', 'bestia'),
                  'off' => __('No', 'bestia')
              ),
              array(
                  'id'       => '7729389-end',
                  'type'     => 'osc_accordion', // field type
                  'position'  => 'end', // to close the accordion
              ),
    )
));
Redux::setSection($opt_name, array(
    'title' => __('Miscellaneous', 'bestia'),
    'class' => 'misc_sec',
    'customizer' => false,
    'subsection' => true,
    'icon' => 'el el-wordpress',
    'fields' => array(
      array(
          'id' => 'comment_permission',
          'type' => 'switch',
          'title' => __('Enable comment form and comment list for Guests?', 'bestia'),
          "default" => 0,
          'on' => __('Yes', 'bestia'),
          'off' => __('No', 'bestia')
      ),
      array(
          'id' => '404_redirection',
          'type' => 'switch',
          'title' => __('Redirect 404 Errors to:', 'bestia'),
          //'subtitle' => __('Two ways for the not found page.', 'bestia'),
          "default" => 1,
          'on' => __('Home Page', 'bestia'),
          'off' => __('404 Page', 'bestia')
      ),
      /*
        array(
            'id' => 'thumb_info',
            'type' => 'button_set',
            'title' => __('Left info under the post thumbnail (video & photo)', 'bestia'),
            'desc' => __('Change the default added time ago with views or post categories for each thumbnail', 'bestia'),
            'options' => array(
            //'added' => __('Post Age', 'bestia'),
            'viewed' => __('Post Views', 'bestia'),
            'the_category' => __('Post Catgeories', 'bestia')
            ),
            'default' => 'the_category'
        ),
        */
        array(
            'id' => 'mtn_footwidgets',
            'type' => 'button_set',
            'title' => __('Footer Widgets Display', 'bestia'),
            'subtitle' => __('You can disable or enable footer widgets in different ways, you can show on homepage only or using the default everywhere key.', 'bestia'),
            //Must provide key => value pairs for radio options
            'options' => array(
                'ftdefault' => __('Default(Everywhere)', 'bestia'),
                'fthome' => __('Only Home', 'bestia'),
                'ftdisable' => __('Disabled', 'bestia')
            ),
            'default' => 'ftdefault'
        ),
        array(
            'id' => 'mtn_lazyloading',
            'type' => 'button_set',
            'title' => __('Image LazyLoad', 'bestia'),
            'subtitle' => __('Lazyloading images is a good way for the page speed, however we are giving this option to disable it at any time.', 'bestia'),
            //Must provide key => value pairs for radio options
            'options' => array(
            'unveil_lazy' => __('No effect', 'bestia'),
            'jquery_lazy' => __('Fade effect', 'bestia'),
            'disabled' => __('Disable Lazy-Load', 'bestia')
            ),
            'default' => 'unveil_lazy'
        ),
        array(
            'id' => 'google-analytics',
            'title' => __('Google Analytics ID', 'bestia'),
            'desc' => sprintf('Add your Google Analystics ID below in order to track your website. If you are a starter please read the documentation about google analystics account creation %s.', '<a target="_blank" href="https://support.google.com/analytics/answer/1008015?hl=en">' . __('here', 'bestia') . '</a>'),
            'type' => 'text',
            'placeholder' => 'UA-39642846-1'
        ),
        array(
            'id' => 'submit_permission',
            'type' => 'switch',
            'title' => __('Allow Guest submit the video on frontend upload page.', 'bestia'),
            'subtitle' => __('By default, Only register can submit the video, you can limit the role in below selectbox', 'bestia'),
            "default" => 0,
            'on' => __('Yes', 'bestia'),
            'off' => __('No', 'bestia')
        ),
        array(
            'id' => 'custom-analytics',
            'title' => __('Custom Stat Counters', 'bestia'),
            'subtitle' => sprintf('There are many other analystic tools to track your visitors please read %s for more details.', '<a target="_blank" href="https://www.sitepoint.com/10-web-analytics-packages-for-tracking-your-visitors/">' . __('this article', 'bestia') . '</a>'),
            'desc' => __('If you have a different web site tracker than google analystics please add the code above.', 'bestia'),
            'type' => 'textarea'
        ),
    )
));

Redux::setSection($opt_name, array(
    'title' => __('Post Types', 'bestia'),
    'customizer' => false,
    'desc' => __('Bestia post types.', 'bestia'),
    'icon' => 'el el-briefcase'
));
Redux::setSection($opt_name, array(
    'title' => __('Video', 'bestia'),
    'subsection' => true,
    'desc' => sprintf('WordPress default post type is used for videos when Bestia theme is active, read more about %s', '<a href="https://wordpress.org/support/article/post-types/">' . __('WordPress Post Types', 'bestia') . '</a>'),
    'customizer' => false,
    'icon' => 'el el-facetime-video',
    'fields' => array(
        array(
            'id' => 'mtn_rel_op',
            'type' => 'button_set',
            'title' => __('Related Videos by?', 'bestia'),
            'subtitle' => __('Here you can choose the related videos base', 'bestia'),
            //Must provide key => value pairs for radio options
            'options' => array(
                'random' => __('Random', 'bestia'),
                'tags' => __('Tags', 'bestia'),
                'category' => __('Category', 'bestia')
            ),
            'default' => 'random'
        ),
        array(
            'id' => 'single-video-layout',
            'type' => 'image_select',
            'title' => __('Single [Video] Page - Sidebar Layout Options', 'bestia'),
            'subtitle' => __('You can disable or enable single page sidebar if you wish a larger player.', 'bestia'),
            'desc' => __('In this key you can manage the single page of your bestia theme.', 'bestia'),
            //Must provide key => value(array:title|img) pairs for radio options
            'options' => array(
                '2' => array(

                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                ),
                '3' => array(

                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                ),
                '4' => array(

                    'img' => ReduxFramework::$_url . 'assets/img/3cm.png'
                )
            ),
            'default' => '4'
        ),
        array(
            'id' => 'video_hd_all',
            'type' => 'switch',
            'class' => 'video_hd_all',
            'title' => __('Enable HD icon for all videos?', 'bestia'),
            'desc' => __('If you do not want to add hd icon for each video manualy you can enable this key.This option will disable HD button from sorters.', 'bestia'),
            "default" => 0,
            'on' => __('Yes', 'bestia'),
            'off' => __('No', 'bestia')
        ),
        array(
            'id' => 'tax_videos',
            'type' => 'text',
            'title' => __('[Videos] to display in category/taxonomy/search', 'bestia'),
            'subtitle' => __('here you can change the number of videos to display in category and taxonomies.', 'bestia'),
            'default' => '30'
        ),
        array(
            'id' => 'related_videos_per_page',
            'type' => 'text',
            'title' => __('[Related Videos] to display', 'bestia'),
            'subtitle' => __('Related videos number to display in single video page.', 'bestia'),
            'default' => '15'
        ),
        array(
            'id' => 'related_more_per_page',
            'type' => 'text',
            'title' => __('[Related Videos - Load More]', 'bestia'),
            'subtitle' => __('Related Videos have a load more button which opens continuing videos, you can change the number of videos to display when load more button is clicked.', 'bestia'),
            'default' => '30'
        )
    )
));

Redux::setSection($opt_name, array(
    'title' => __('Photo', 'bestia'),
    'subsection' => true,
    'customizer' => false,
    'icon' => 'el el-camera',
    'fields' => array(
      array(
          'id' => 'gallery_cpt',
          'type' => 'switch',
          'class' => 'gallery_option_first',
          'title' => __('Enable Photo Gallery?', 'bestia'),
          'desc' => __('Photo Gallery is a custom post type of bestia theme, if you do not want to use this feature it is nutty to keep enabled.', 'bestia'),
          "default" => 1,
          'on' => __('Yes', 'bestia'),
          'off' => __('No', 'bestia')
      ),
      array(
          'id' => 'single-photo-layout',
          'type' => 'image_select',
          'class' => 'gallery_option',
          'title' => __('Single [Photo Gallery] Page - Sidebar Layout Options', 'bestia'),
          'subtitle' => __('You can disable or enable single page sidebar if you wish a larger content.', 'bestia'),
          'desc' => __('In this key you can manage the single page of your photo gallery post type.', 'bestia'),
          //Must provide key => value(array:title|img) pairs for radio options
          'options' => array(
              '2' => array(

                  'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
              ),
              '3' => array(

                  'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
              ),
              '4' => array(

                  'img' => ReduxFramework::$_url . 'assets/img/3cm.png'
              )
          ),
          'default' => '4'
      ),
      array(
          'id' => 'photo_hd_all',
          'type' => 'switch',
          'class' => 'gallery_option',
          'title' => __('Enable HD icon for all photo galleries?', 'bestia'),
          'desc' => __('If you do not want to add hd icon for each photo gallery manualy you can enable this key.This option will disable HD button from sorters.', 'bestia'),
          "default" => 0,
          'on' => __('Yes', 'bestia'),
          'off' => __('No', 'bestia')
      ),
        array(
            'id' => 'tax_photos',
            'class' => 'gallery_option',
            'type' => 'text',
            'title' => __('[Photos] to display on galery archives', 'bestia'),
            'subtitle' => __('here you can change the number of photo albums to display in category and photo gallery template.', 'bestia'),
            'default' => '30'
        ),
        array(
            'id' => 'phototype-archive-layout',
            'type' => 'image_select',
            'class' => 'gallery_option',
            'title' => __('[Photo Gallery Archives & Gallery Search Template] sidebar position', 'bestia'),
            'subtitle' => __('This option works for the photo gallery archives.', 'bestia'),
            'desc' => __('This key doesnt change the position of photo gallery template since its a page and you can use metaboxes in page editor instead.', 'bestia'),
            //Must provide key => value(array:title|img) pairs for radio options
            'options' => array(
                '1' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/1c.png'
                ),
                '2' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                ),
                '3' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                )
            ),
            'default' => '2'
        ),
        array(
            'id' => 'related_photos_per_page',
            'type' => 'text',
            'class' => 'gallery_option',
            'title' => __('[Related Photos] to display', 'bestia'),
            'subtitle' => __('Related Photos number to display in single video page.', 'bestia'),
            'default' => '10'
        ),
        array(
            'id' => 'gallery_rewrite_slug',
            'type' => 'text',
            'class' => 'gallery_option',
            'title' => __('[Photo Gallery] Slug', 'bestia'),
            'desc' => __('This key must not be same with the photo gallery page slug', 'bestia'),
            'default' => 'gallery',
            'subtitle' => sprintf('This option will change the default slug of the photo gallery post type, if you change this key, you must go to %s and click on Save Changes button', '<a href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        ),
        array(
            'id' => 'rewrite_slug_gallery_category',
            'type' => 'text',
            'class' => 'gallery_option',
            'title' => __('[Photo Gallery] Category Slug', 'bestia'),
            'default' => 'phototype',
            'subtitle' => sprintf('This option will change the default slug of the photo gallery category taxonomy, if you change this key, you must go to %s and click on Save Changes button', '<a href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        ),
        array(
            'id' => 'rewrite_slug_gallery_tag',
            'class' => 'gallery_option',
            'type' => 'text',
            'title' => __('[Photo Gallery] Tag Slug', 'bestia'),
            'default' => 'photo_tag',
            'subtitle' => sprintf('This option will change the default slug of the photo gallery tag taxonomy, if you change this key, you must go to %s and click on Save Changes button', '<a href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        )
    )
));

Redux::setSection($opt_name, array(
    'title' => __('Blog', 'bestia'),
    'subsection' => true,
    'customizer' => false,
    'icon' => 'el el-edit',
    'fields' => array(
      array(
          'id' => 'blogs_cpt',
          'class' => 'blog_option_first',
          'type' => 'switch',
          'title' => __('Enable Blog?', 'bestia'),
          'desc' => __('The Blog in bestia theme is created as a wordpress custom post type, if you do not want to use this feature it is nutty to keep enabled.', 'bestia'),
          "default" => 1,
          'on' => __('Yes', 'bestia'),
          'off' => __('No', 'bestia')
      ),
      array(
          'id' => 'single-blog-layout',
          'type' => 'image_select',
          'class' => 'blog_option',
          'title' => __('Single [BLOG] Page - Sidebar Layout Options', 'bestia'),
          'subtitle' => __('You can disable or enable single page sidebar if you wish a larger content.', 'bestia'),
          'desc' => __('In this key you can manage the single page of your blog post type.', 'bestia'),
          //Must provide key => value(array:title|img) pairs for radio options
          'options' => array(
              '2' => array(

                  'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
              ),
              '3' => array(

                  'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
              ),
              '4' => array(

                  'img' => ReduxFramework::$_url . 'assets/img/3cm.png'
              )
          ),
          'default' => '4'
      ),
        array(
            'id' => 'blogs_per_page',
            'type' => 'text',
            'class' => 'blog_option',
            'title' => __('[Blogs] to display in blog archives', 'bestia'),
            'subtitle' => __('Option where you can change the limit of blog items to display in blog page.', 'bestia'),
            'default' => '10'
        ),
        array(
            'id' => 'related_blogs_per_page',
            'type' => 'text',
            'class' => 'blog_option',
            'title' => __('[Related Blogs] to display', 'bestia'),
            'subtitle' => __('Related blogs number to display in single video page.', 'bestia'),
            'default' => '5'
        ),
        array(
            'id' => 'blogtype-archive-layout',
            'type' => 'image_select',
            'class' => 'blog_option',
            'title' => __('[Blog Archives] sidebar position', 'bestia'),
            'subtitle' => __('This option works for the blog archive and category pages.', 'bestia'),
            'desc' => __('This key doesnt change the position of custom blog page template since its a page and you can use metaboxes in page editor instead.', 'bestia'),
            //Must provide key => value(array:title|img) pairs for radio options
            'options' => array(
                '1' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/1c.png'
                ),
                '2' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                ),
                '3' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                )
            ),
            'default' => '2'
        ),
        array(
            'id' => 'blog_rewrite_slug',
            'type' => 'text',
            'class' => 'blog_option',
            'title' => __('[Blog] Slug', 'bestia'),
            'desc' => __('This key must not be same with the blog page slug', 'bestia'),
            'default' => 'blogs',
            'subtitle' => sprintf('This option will change the default slug of the blog post type, if you change this key, you must go to %s and click on Save Changes button', '<a href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        ),
        array(
            'id' => 'rewrite_slug_blog_category',
            'type' => 'text',
            'class' => 'blog_option',
            'title' => __('[Blog] Category Slug', 'bestia'),
            'default' => 'blogtype',
            'subtitle' => sprintf('This option will change the default slug of the blog category taxonomy, if you change this key, you must go to %s and click on Save Changes button', '<a href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        ),
        array(
            'id' => 'rewrite_slug_blog_tag',
            'type' => 'text',
            'class' => 'blog_option',
            'title' => __('[Blog] Tag Slug', 'bestia'),
            'default' => 'blog_tag',
            'subtitle' => sprintf('This option will change the default slug of the blog tag taxonomy, if you change this key, you must go to %s and click on Save Changes button', '<a href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        )
    )
));

Redux::setSection($opt_name, array(
    'title' => __('Gif', 'bestia'),
    'subsection' => true,
    'customizer' => false,
    'icon' => 'el el-picture',
    'fields' => array(
      array(
          'id' => 'gifs_cpt',
          'class' => 'gif_option_first',
          'type' => 'switch',
          'title' => __('Enable Gif Section?', 'bestia'),
          'desc' => __('The gif section in bestia theme is created as a wordpress custom post type, if you do not want to use this feature it is nutty to keep enabled.', 'bestia'),
          "default" => 1,
          'on' => __('Yes', 'bestia'),
          'off' => __('No', 'bestia')
      ),
      array(
          'id' => 'single-gif-layout',
          'type' => 'image_select',
          'class' => 'gif_option',
          'title' => __('Single [GIF] Page - Sidebar Layout Options', 'bestia'),
          'subtitle' => __('You can disable or enable single page sidebar if you wish a larger content.', 'bestia'),
          'desc' => __('In this key you can manage the single page of your blog post type.', 'bestia'),
          //Must provide key => value(array:title|img) pairs for radio options
          'options' => array(
              '2' => array(

                  'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
              ),
              '3' => array(

                  'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
              ),
              '4' => array(

                  'img' => ReduxFramework::$_url . 'assets/img/3cm.png'
              )
          ),
          'default' => '4'
      ),
      array(
            'id' => 'gifs_per_page',
            'type' => 'text',
            'class' => 'gif_option',
            'title' => __('[GIFS] to display in gif archives', 'bestia'),
            'subtitle' => __('Option where you can change the limit of gif items to display in gifs page.', 'bestia'),
            'default' => '24'
        ),
        array(
            'id' => 'related_gifs_per_page',
            'type' => 'text',
            'class' => 'gif_option',
            'title' => __('[Related Gifs] to display', 'bestia'),
            'subtitle' => __('Related gifs number to display in single gif area.', 'bestia'),
            'default' => '16'
        ),
        array(
            'id' => 'giftype-archive-layout',
            'type' => 'image_select',
            'class' => 'gif_option',
            'title' => __('[GIF Archives] sidebar position', 'bestia'),
            'subtitle' => __('This option works for the gifs archive and category pages.', 'bestia'),
            'desc' => __('This key doesnt change the position of custom gif page template since its a page and you can use metaboxes in page editor instead.', 'bestia'),
            //Must provide key => value(array:title|img) pairs for radio options
            'options' => array(
                '1' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/1c.png'
                ),
                '2' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                ),
                '3' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                )
            ),
            'default' => '2'
        ),
        array(
            'id' => 'gif_rewrite_slug',
            'type' => 'text',
            'class' => 'gif_option',
            'title' => __('[GIFS] Slug', 'bestia'),
            'desc' => __('This key must not be same with the gif page slug', 'bestia'),
            'default' => 'gif',
            'subtitle' => sprintf('This option will change the default slug of the gif post type, if you change this key, you must go to %s and click on Save Changes button', '<a href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        ),
        array(
            'id' => 'rewrite_slug_gif_category',
            'type' => 'text',
            'class' => 'gif_option',
            'title' => __('[GIFS] Category Slug', 'bestia'),
            'default' => 'giftype',
            'subtitle' => sprintf('This option will change the default slug of the gif category taxonomy, if you change this key, you must go to %s and click on Save Changes button', '<a href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        ),
        array(
            'id' => 'rewrite_slug_gif_tag',
            'type' => 'text',
            'class' => 'gif_option',
            'title' => __('[GIFS] Tag Slug', 'bestia'),
            'default' => 'gif_tag',
            'subtitle' => sprintf('This option will change the default slug of the gif tag taxonomy, if you change this key, you must go to %s and click on Save Changes button', '<a target="_blank" href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        )
    )
));
Redux::setSection($opt_name, array(
    'title' => __('Taxonomies', 'bestia'),
    'customizer' => false,
    'desc' => __('Bestia custom taxonomies.', 'bestia'),
    'icon' => 'el-icon-folder'
));
Redux::setSection($opt_name, array(
    'title' => __('Category', 'bestia'),
    'subsection' => true,
    'desc' => sprintf('The default post category in bestia is used as a part of your videos since we are using the default wordpress post type for the video posts. Ckick to read more about %s', '<a target="_blank" href="https://wordpress.org/support/article/post-types/">' . __('WordPress Post Types', 'bestia') . '</a>'),
    'customizer' => false,
    'icon' => 'el el-folder-open',
    'fields' => array(
        array(
            'id' => 'categories_per_page',
            'type' => 'text',
            'title' => __('[Categories] to display per page', 'bestia'),
            'subtitle' => __('Categories to display in categories list page', 'bestia'),
            'default' => '60'
        ),
        array(
            'id' => 'flyout-categories',
            'type' => 'switch',
            'title' => __('Flyout Content - Categories', 'bestia'),
            'subtitle' => sprintf('Please read %s.', '<a target="_blank" href="https://mytubepress.com/knowledge-base/bestia-flyout-menus/">' . __('this documentation', 'bestia') . '</a>'),
            "default" => 0,
            'on' => __('Yes', 'bestia'),
            'off' => __('No', 'bestia')
        ),
        array(
            'id' => 'category-archive-layout',
            'type' => 'image_select',
            'title' => __('[Category Archives & Video Search Template] sidebar position', 'bestia'),
            'subtitle' => __('This option works for category archives only.', 'bestia'),
            'desc' => __('In this key you can manage your category archives sidebars.', 'bestia'),
            //Must provide key => value(array:title|img) pairs for radio options
            'options' => array(
                '1' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/1c.png'
                ),
                '2' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                ),
                '3' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                )
            ),
            'default' => '2'
        ),
    )
));
Redux::setSection($opt_name, array(
    'title' => __('Performer', 'bestia'),
    'subsection' => true,
    'customizer' => false,
    'icon' => 'el el-adult',
    'fields' => array(
        array(
            'id' => 'performers_per_page',
            'type' => 'text',
            'title' => __('[Performers] to display per page', 'bestia'),
            'subtitle' => __('Performers to display in performer list page', 'bestia'),
            'default' => '30'
        ),
        array(
            'id' => 'rewrite_slug_performer',
            'type' => 'text',
            'title' => __('[Performers] Slug', 'bestia'),
            'desc' => __('This key must not be same with the slug of performers page template.', 'bestia'),
            'default' => 'performer',
            'subtitle' => sprintf('This option will change the default slug of the performer custom taxonomy, if you change this key, you must go to %s and click on Save Changes button', '<a target="_blank" href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        ),
        array(
            'id' => 'performer-archive-layout',
            'type' => 'image_select',
            'title' => __('[Performer Archives] sidebar position', 'bestia'),
            'subtitle' => __('This option works for performer archives only.', 'bestia'),
            'desc' => __('Manage your performer archives sidebars.', 'bestia'),
            //Must provide key => value(array:title|img) pairs for radio options
            'options' => array(
                '1' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/1c.png'
                ),
                '2' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                ),
                '3' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                )
            ),
            'default' => '2'
        ),
        array(
            'id' => 'performer_list_type',
            'type' => 'button_set',
            'title' => __('Performer List Page By', 'bestia'),
            'subtitle' => __('With this option you can change performer list page using the last post image for each performer or just showing your own uploaded performer image.', 'bestia'),
            'desc' => sprintf('If you change this key, you have to go to %s in order to disable custom image upload function for this taxonomy', '<a target="_blank" href="' . admin_url('options-general.php?page=zci-options') . '">' . __('Categories Images settings', 'bestia') . '</a>'),
            //Must provide key => value pairs for radio options
            'options' => array(
                'custom_image' => __('Custom Image', 'bestia'),
                'last_post_image' => __('Last Post Image', 'bestia'),
                'random_post_image' => __('Random Post Image', 'bestia')
            ),
            'default' => 'custom_image'
        ),
        array(
            'id' => 'flyout-performers',
            'type' => 'switch',
            'title' => __('Flyout Content - Performers', 'bestia'),
            'subtitle' => sprintf('Please read %s.', '<a target="_blank" href="https://mytubepress.com/knowledge-base/bestia-flyout-menus/">' . __('this documentation', 'bestia') . '</a>'),
            "default" => 0,
            'on' => __('Yes', 'bestia'),
            'off' => __('No', 'bestia')
        ),
    )
));
Redux::setSection($opt_name, array(
    'title' => __('Channel', 'bestia'),
    'subsection' => true,
    'customizer' => false,
    'desc' => sprintf('This is a custom post type coded for bestia theme users, you can read more about %s', '<a target="_blank" href="https://wordpress.org/support/article/taxonomies/">' . __('WordPress Taxonomies', 'bestia') . '</a>'),
    'icon' => 'el el-folder-open',
    'fields' => array(
        array(
            'id' => 'channels_per_page',
            'type' => 'text',
            'title' => __('[Channels] to display per page', 'bestia'),
            'subtitle' => __('Channels to display in channels list page', 'bestia'),
            'default' => '60'
        ),
        array(
            'id' => 'rewrite_slug_channel',
            'type' => 'text',
            'title' => __('[Channels] Slug', 'bestia'),
            'desc' => __('This key must not be same with the channels page slug', 'bestia'),
            'default' => 'channel',
            'subtitle' => sprintf('This option will change the default slug of the channel custom taxonomy, if you change this key, you must go to %s and click on Save Changes button', '<a target="_blank" href="' . admin_url('options-permalink.php') . '">' . __('Settings/Permalink', 'bestia') . '</a>')
        ),
        array(
            'id' => 'flyout-channels',
            'type' => 'switch',
            'title' => __('Flyout Content - Channels', 'bestia'),
'subtitle' => sprintf('Please read %s.', '<a target="_blank" href="https://mytubepress.com/knowledge-base/bestia-flyout-menus/">' . __('this documentation', 'bestia') . '</a>'),            "default" => 0,
            'on' => __('Yes', 'bestia'),
            'off' => __('No', 'bestia')
        ),
        array(
            'id' => 'channel-archive-layout',
            'type' => 'image_select',
            'title' => __('[Channel Archives] sidebar position', 'bestia'),
            'subtitle' => __('This option works for channel archives only.', 'bestia'),
            'desc' => __('In this key you can manage your channel archives sidebars.', 'bestia'),
            //Must provide key => value(array:title|img) pairs for radio options
            'options' => array(
                '1' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/1c.png'
                ),
                '2' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                ),
                '3' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                )
            ),
            'default' => '2'
        ),
        array(
         'id'   =>'divider_tag_tax',
         //'desc' => __('This is the description field, again good for additional info.', 'redux-framework-demo'),
         'type' => 'divide'
      ),
        array(
            'id' => 'tags_per_page',
            'type' => 'text',
            'title' => __('[Popular Tags] to display', 'bestia'),
            'subtitle' => __('Limit tags in tag cloud template', 'bestia'),
            'default' => '180'
        )
    )
));

Redux::setSection($opt_name, array(
    'title' => __('Tag', 'bestia'),
    'subsection' => true,
    'customizer' => false,
    'desc' => sprintf('This is the default wordpress post_tag options page, you can manage your post tag permalink structure in %s', '<a target="_blank" href="' . admin_url('options-permalink.php') . '">' . __('WordPress Permalink Settings', 'bestia') . '</a>'),
    'icon' => 'el el-folder-open',
    'fields' => array(
        array(
            'id' => 'tags_per_page',
            'type' => 'text',
            'title' => __('[Popular Tags] to display', 'bestia'),
            'subtitle' => __('Limit tags in tag cloud template', 'bestia'),
            'default' => '180'
        )
    )
));
//------------------ Submit Video ---------------
Redux::setSection($opt_name, array(
    'title' => __('Advertisements', 'bestia'),
    'customizer' => false,
    'desc' => __('Bestia Advertisement Spots', 'bestia'),
    'icon' => 'el el-usd'
));
Redux::setSection($opt_name, array(
    'title' => __('AD Locations', 'bestia'),
    'customizer' => false,
    'id' => 'ads-settings',
    'subsection' => true,
    'icon' => 'el el-website',
    'fields' => array(
        array(
            'id' => 'mtn_adsindex',
            'type' => 'textarea',
            'title' => __('Right Banner', 'bestia'),
            'subtitle' => __('Appears on the right side of your videos template.', 'bestia'),
            'desc' => __('Html Validated (300x250), Shortcode Accepted', 'bestia'),
            'default' => ''
        ),
        array(
            'id' => 'mtn_adsbottom',
            'type' => 'textarea',
            'title' => __('Bottom ADS', 'bestia'),
            'subtitle' => __('Appears over the footer. Shortcodes allowed here.', 'bestia'),
            'desc' => __('Html Validated you can use some banners of (300x250) inline or a bigger one like 1000px.', 'bestia'),
            'default' => ''
        ),
        array(
            'id' => 'mtn_adsvideo',
            'type' => 'editor',
            'title' => __('Post Content - Bottom ADS', 'bestia'),
            'subtitle' => __('This ads place is hidden if you do not put any code if you add any ads code it will be visible under your post content, video/photo/blog', 'bestia'),
            'desc' => __('Html Validated you can use any 728x60 banner or write anything using visual editor.NOTE: Click on text editor to add banner codes.', 'bestia'),
            'default' => ''
        ),
        array(
            'id' => 'mtn_afterpost',
            'type' => 'textarea',
            'title' => __('Post ADS (300x250)', 'bestia'),
            'subtitle' => __('This ADS Will be displayed with the same look of a video preview after the sixth post.', 'bestia'),
            'desc' => __('Html Validated (max-width 300px)', 'bestia'),
            'default' => ''
        ),
        array(
            'id' => 'mtn_mobiletop',
            'type' => 'textarea',
            'title' => __('Mobile Header ADS', 'bestia'),
            'subtitle' => __('This ADS Will be displayed on the top in mobile devices', 'bestia'),
            'desc' => __('Html Validated (max-width 300px)', 'bestia'),
            'default' => ''
        ),
        array(
            'id' => 'mtn_mobilebottom',
            'type' => 'textarea',
            'title' => __('Mobile Bottom ADS', 'bestia'),
            'subtitle' => __('This ADS Will be displayed at the bottom in mobile devices', 'bestia'),
            'desc' => __('Html Validated (max-width 300px)', 'bestia'),
            'default' => ''
        ),
        array(
            'id' => 'mtn_inembed',
            'type' => 'textarea',
            'title' => __('Player Overlay', 'bestia'),
            'subtitle' => __('This advertisement appears over the video content.', 'bestia'),
            'desc' => __('Html Validated (300x250) One banner only', 'bestia'),
            'default' => ''
        ),
    )
));
Redux::setSection($opt_name, array(
    'title' => __('POP-UNDERS', 'bestia'),
    'customizer' => false,
    'id' => 'l-popunders',
    'subsection' => true,
    'icon' => 'el el-retweet',
    'fields' => array(
        array(
            'id' => 'popunders',
            'type' => 'textarea',
            'title' => __('Popunders (DESKTOP)', 'bestia'),
            'subtitle' => __('The place where you can put your desktop popunder codes', 'bestia'),
            'desc' => __('Visible only for desktop users.', 'bestia'),
            'default' => ''
        ),
        array(
            'id' => 'pop_desk_position',
            'type' => 'button_set',
            'title' => __('Popunders (DESKTOP) Position', 'bestia'),
            'subtitle' => __('Here you can move your desktop code to header or footer, check your ads provider description.', 'bestia'),
            //Must provide key => value pairs for radio options
            'options' => array(
                'header' => __('Header', 'bestia'),
                'footer' => __('Footer', 'bestia')
            ),
            'default' => 'footer'
        ),
        array(
            'id' => 'popunders_mobile',
            'type' => 'textarea',
            'title' => __('Popunders (MOBILE)', 'bestia'),
            'subtitle' => __('The place where you can put your mobile popunder codes', 'bestia'),
            'desc' => __('Visible only for mobile users.', 'bestia'),
            'default' => ''
        ),
        array(
            'id' => 'pop_mob_position',
            'type' => 'button_set',
            'title' => __('Popunders (MOBILE) Position', 'bestia'),
            'subtitle' => __('Here you can move your mobile code to header or footer, check your ads provider description.', 'bestia'),
            //Must provide key => value pairs for radio options
            'options' => array(
                'header' => __('Header', 'bestia'),
                'footer' => __('Footer', 'bestia')
            ),
            'default' => 'footer'
        )
    )
));

// -> START Styling Fields
Redux::setSection($opt_name, array(
    'title' => __('Design & Layout', 'bestia'),
    'desc' => __('Bestia style settings.', 'bestia'),
    'icon' => 'el el-tint'
));
    Redux::setSection($opt_name, array(
                  'title' => __('Layout & Colors', 'bestia'),
                  'icon' => 'el el-magic',
                  'subsection' => true,
                  'customizer' => true,
                  'border-color'  => false,
                  'fields' => array(
                    array(
                         'id'       => '44499389-start',
                         'type'     => 'osc_accordion', // field type
                         'title'    => 'Site Body', // here you can set the title for accordion

                         'position'  => 'start', // to start accordion
                          'open'=>false, // set this true in case you want to open it by default
                      ),

                              array(
                                  'id' => 'body-background',
                                  'type' => 'background',
                                  'transparent' => false,
                                  'output' => array(
                                      'body, .video-sponsor, .twPc-div'
                                  ),
                                  'title' => __('Body Background', 'bestia'),
                                  'subtitle' => __('Body background with image, color, etc.', 'bestia'),
                                  'default' => '#f2f2f2'
                              ),
                              array(
                                  'id' => 'general_links_color',
                                  'type' => 'link_color',
                                  'title' => __('General Site Links Color Options', 'bestia'),
                                  'subtitle' => __('Only color validation can be done on this field type', 'bestia'),
                                  'desc' => __('Choose link color your site.', 'bestia'),
                                  'output' => array(
                                      'a'
                                  ),
                                  'default' => array(
                                      'regular' => '#175b79',
                                      'hover' => '#3068B5',
                                      'active' => '#175b79'
                                  )
                              ),
                              array(
                              'id'          => 'content-font-typography',
                              'type'        => 'typography',
                              'title'       => __('Content Font Options', 'redux-framework-demo'),
                              'google'      => true,
                              'font-backup' => true,
                              'font-size'   => true,
                              'line-height' => true,
                              'text-transform' => true,
                              'text-align' => false,
                              'color' => true,
                              'output'      => array('.col-md-7, .col-md-12, .activity,.twPc-divName,.twPc-StatLabel,.tab-content,.list-group-item,.performer-item-footer, .video-sponsor p strong,.video-sponsor p span, .pager span.current, .dots, .container p, .dropdown-menu'),
                              'units'       =>'px',
                              'subtitle'    => __('Typography option for all content types, post content, post information, post description etc.', 'redux-framework-demo'),
                              'default'     => array(
                                  'font-style'  => '400',
                                  'color'       => '#333',
                                  'font-size'   => '14px',
                                  'line-height' => '14px',
                                  'text-transform' => 'none',
                                  'font-family' => 'Arial, Helvetica, sans-serif',
                                  'google'      => false,
                              ),
                              ),
                              array(
                                  'id'          => 'content-title-typography',
                                  'type'        => 'typography',
                                  'title'       => __('Content Titles (Heading Tag Typography Options)', 'redux-framework-demo'),
                                  'google'      => true,
                                  'font-backup' => true,
                                  'font-size'   => true,
                                  'line-height' => true,
                                  'text-align' => false,
                                  'text-transform' => true,
                                  'color' => true,
                                  'output'      => array('.heading h1,.heading h2,.heading h3,.heading h4,.heading h5,.heading h6, .heading span, #footer .footer-top .widget h1, #footer .footer-top .widget h2,#footer .footer-top .widget h3,
                                  #footer .footer-top .widget h4,
                                  #footer .footer-top .widget h5,
                                  #footer .footer-top .widget h6,
                                  #footer .footer-top .widget span'),
                                  'units'       =>'%',
                                  'subtitle'    => __('Typography option for site titles, includes all heading tags', 'redux-framework-demo'),
                                  'default'     => array(
                                      'font-style'  => '400',
                                      'font-family' => 'Arial, Helvetica, sans-serif',
                                      'font-size'   => '127%',
                                      'color'       => '#333',
                                      'line-height' => '127%',
                                      'text-transform' => 'uppercase',
                                      'google'      => false,
                  ),
                ),

                array(
                    'id'       => '44499389-end',
                    'type'     => 'osc_accordion', // field type
                    'position'  => 'end', // to close the accordion
                ),

                array(
                    'id'       => '4tgsh9877-start',
                    'type'     => 'osc_accordion', // field type
                    'title'    => 'Top Bar', // here you can set the title for accordion

                    'position'  => 'start', // to start accordion
                    'open'=>false, // set this true in case you want to open it by default
                ),
                array(
                    'id' => 'mtn_hidemenus',
                    'type' => 'switch',
                    'class' => 'topbar_first',
                    'title' => __('Top-Bar', 'bestia'),
                    'subtitle' => __('Use this key to disable top bar.', 'bestia'),
                    'desc' => __('Must be enabled if you have buddypres active.', 'bestia'),
                    'options' => array(
                        'on' => __('ON', 'bestia'),
                        'off' => __('OFF', 'bestia')
                    ),
                    'default' => '1'
                ),
                array(
                    'id'          => 'top-bar-typography',
                    'type'        => 'typography',
                    'title'       => __('Top-Bar Typography', 'redux-framework-demo'),
                    'google'      => true,
                    'font-backup' => true,
                    'font-size'   => true,
                    'line-height' => false,
                    'text-align' => true,
                    'text-transform' => true,
                    //'color' => true,
                    'output' => array(
                        '.top-bar .top-bar-left .nav li,.first-fas,.top-bar .logged-user .btn .name, .top-bar-right .dropdown-toggle'
                    ),
                    'units'       =>'px',
                    'subtitle'    => __('Typography option for header top bar.', 'redux-framework-demo'),
                    'default'     => array(
                        'font-style'  => '',
                        'font-size' => '12',
                        'text-align' => 'left',
                        'color' => '#fff',
                        'text-transform' => 'uppercase',
                        'font-family' => 'Arial, Helvetica, sans-serif',
                        'google'      => true,
                    ),
                    ),
                array(
                    'id' => 'top_bar_bg',
                    'type' => 'background',
                    'class' => 'topbar-half',
                    'transparent' => false,
                    'preview' => false,
                    'background-repeat' => false,
                    'background-attachment' => false,
                    'background-position' => false,
                    'background-image' => false,
                    'background-clip' => false,
                    'background-size' => false,
                    'output' => array(
                        '.top-bar, .top-bar-left ul, .top-bar-left, .slidemenu, .top-bar .notifications .notification-item .open .circle'
                    ),
                    'title' => __('Top-Bar Background', 'bestia'),
                    'subtitle' => __('Pick a background color for bestia top bar whcih is over the main navigation.', 'bestia'),
                    'default'  => array(
                       'background-color' => '#000',
                    ),
                ),
                array(
                    'id' => 'top_bar_bg_hover',
                    'type' => 'background',
                    'class' => 'topbar-half',
                    'transparent' => false,
                    'background-repeat' => false,
                    'background-attachment' => false,
                    'background-position' => false,
                    'background-image' => false,
                    'preview' => false,
                    'background-clip' => false,
                    'background-size' => false,
                    'title' => __('Top-Bar Menu Hover Background', 'bestia'),
                    'output' => array(
                        '.top-bar .top-bar-left .navbar-nav > li > a:hover, .top-bar .top-bar-left .navbar-nav > .active > a, .top-bar .top-bar-left .navbar-nav > .active > a:hover, .top-bar .top-bar-left .navbar-nav > .active > a:focus'
                    ),
                    'subtitle' => __('Pick a background color for the top-bar menu hover.', 'bestia'),
                    'default'  => array(
                       'background-color' => '#fff',
                    ),
                ),
                array(
                    'id' => 'top_bar_menu_color',
                    'type' => 'color',
                    'class' => 'topbar',
                    'transparent' => false,
                    'title' => __('Top-Bar Menu Hover Color', 'bestia'),
                    'output' => array(
                        '.top-bar .top-bar-left .navbar-nav > li > a:hover, .top-bar .top-bar-left .navbar-nav > .active > a, .top-bar .top-bar-left .navbar-nav > .active > a:hover, .top-bar .top-bar-left .navbar-nav > .active > a:focus'
                    ),
                    'subtitle' => __('Pick a background color for the top-bar menu hover.', 'bestia'),
                    'default' => '#000',
                    'validate' => 'color'
                ),
                array(
                   'id'       => '4tgsh9877-end',
                   'type'     => 'osc_accordion', // field type
                   'position'  => 'end', // to close the accordion
                  ),
                array(
                    'id'       => '46738829-start',
                    'type'     => 'osc_accordion', // field type
                    'title'    => 'Header', // here you can set the title for accordion
                    'position'  => 'start', // to start accordion
                    'open'=>false, // set this true in case you want to open it by default
                ),
                  array(
                      'id' => 'centered_logo',
                      'type' => 'switch',
                      'title' => __('Centered Logo', 'bestia'),
                      'subtitle' => __('Enable this key if you wish to display the site logo in the middle of two navigations bar on desktop devices.', 'bestia'),
                      'options' => array(
                          'on' => __('ON', 'bestia'),
                          'off' => __('OFF', 'bestia')
                      ),
                      'default' => '0'
                  ),

                  array(
                      'id' => 'vibrate_logo',
                      'type' => 'switch',
                      'title' => __('Shake logo on mouse over', 'bestia'),
                      'subtitle' => __('Enable this key if you wish to give a shake effect to the site logo on mouse over.', 'bestia'),
                      'options' => array(
                          'on' => __('ON', 'bestia'),
                          'off' => __('OFF', 'bestia')
                      ),
                      'default' => '1'
                  ),

               array(
                    'id'       => '46738829-end',
                    'type'     => 'osc_accordion', // field type
                    'position'  => 'end', // to close the accordion
                ),
                array(
                    'id'       => 'srch-frm-start',
                    'type'     => 'osc_accordion', // field type
                    'title'    => 'Search Form', // here you can set the title for accordion
                    'position'  => 'start', // to start accordion
                    'open'=>false, // set this true in case you want to open it by default
                ),

                array(
                    'id' => 'srchfrm_btns_bg',
                    'type' => 'background',
                    'transparent' => false,
                    'background-repeat' => false,
                    'background-attachment' => false,
                    'background-position' => false,
                    'background-image' => false,
                    'preview' => false,
                    'background-clip' => false,
                    'background-size' => false,
                    'title' => __('Search Form Background Color', 'bestia'),
                    'output' => array(
                        '.mobile_search button.closer, .mobile_search button.df, .mobile_search input.form-control,.search_type, .mobile_search .btn-default:active:hover,.mobile_search .open>.dropdown-toggle.btn-default:focus,.mobile_search .open>.dropdown-toggle.btn-default:hover'
                    ),
                    'subtitle' => __('Pick a background color for the search form buttons and inputs.', 'bestia'),
                    'default'  => array(
                       'background-color' => '#fff',
                    ),
                ),
                array(
                    'id' => 'srchfrm_borders',
                    'type' => 'color',
                    'transparent' => false,
                    'title' => __('Search Form Borders', 'bestia'),
                    'subtitle' => __('Pick a border color for your search form elements.', 'bestia'),
                    'default' => '#e7e7e7',
                    'validate' => 'color'
                ),
                array(
                    'id' => 'searchfrm_fnt_color',
                    'type' => 'color',
                    'transparent' => false,
                    'title' => __('Search Form Font/Text Color', 'bestia'),
                    'subtitle' => __('Pick a color for your search form inputs and buttons.', 'bestia'),
                    'output' => array(
                        '.mobile_search button.closer, .mobile_search button.df, .mobile_search input.form-control'
                    ),
                    'default' => '#333',
                    'validate' => 'color'
                ),
                array(
                      'id'       => 'srch-frm-end',
                      'type'     => 'osc_accordion', // field type
                      'position'  => 'end', // to close the accordion
                  ),
                array(
                    'id'       => 'navbar-opts-start',
                    'type'     => 'osc_accordion', // field type
                    'title'    => 'Main Navigation', // here you can set the title for accordion

                    'position'  => 'start', // to start accordion
                    'open'=>false, // set this true in case you want to open it by default
                ),
                array(
                    'id' => 'head_bg',
                    'type' => 'color',
                    'transparent' => false,
                    'title' => __('Navbar Background Color', 'bestia'),
                    'subtitle' => __('Pick a background color for your main navigation section (default: #fafafa).', 'bestia'),
                    'default' => '#fafafa',
                    'validate' => 'color'
                ),
                array(
                    'id' => 'nav_border_top',
                    'type' => 'color',
                    'transparent' => false,
                    'title' => __('Navbar Top Border', 'bestia'),
                    'subtitle' => __('Pick a border-top color for your main navigation section (default: #e7e7e7).', 'bestia'),
                    'default' => '#e7e7e7',
                    'validate' => 'color'
                ),
                array(
                    'id' => 'nav_border_bottom',
                    'type' => 'color',
                    'transparent' => false,
                    'title' => __('Navbar Bottom Border', 'bestia'),
                    'subtitle' => __('Pick a border-bottom color for your main navigation section (default: #e7e7e7).', 'bestia'),
                    'default' => '#e7e7e7',
                    'validate' => 'color'
                ),

                array(
                    'id' => 'main_menu_colors',
                    'type' => 'link_color',
                    'title' => __('Navbar - Link Color Options', 'bestia'),
                    'subtitle' => __('Only color validation can be done on this field type', 'bestia'),
                    'desc' => __('Choose link color for your main menu wich appears on the top, near search form.', 'bestia'),
                    'output' => array(
                        '#head .navbar-default .navbar-nav > li > a,.navbar-form-search .btn,.btn_menu, .messagge_menu,.slidemenu-push-toright .btn_menu'
                    ),
                    'default' => array(
                        'regular' => '#333',
                        'hover' => '#333',
                        'active' => '#333'
                    )
                ),

                array(
                    'id'          => 'main-nav-typography',
                    'type'        => 'typography',
                    'title'       => __('Navbar - Typography', 'redux-framework-demo'),
                    'google'      => true,
                    'font-backup' => true,
                    'font-size'   => true,
                    'line-height' => true,
                    'text-align' => false,
                    'text-transform' => true,
                    'color' => true,
                    'output' => array(
                        '.second-bar, .flyout-menu-content,.navbar-form-search .btn,#head .navbar-default .navbar-nav > li > a,.navbar-form-search .btn,.btn_menu, .messagge_menu,.slidemenu-push-toright .btn_menu'
                    ),
                    'units'       =>'%',
                    'subtitle'    => __('Typography option for the header main navigation section.', 'redux-framework-demo'),
                    'default'     => array(
                    'font-style'  => '400',
                    'color' => '#333',
                    'line-height' => '100%',
                    'font-size' => '100%',
                    'text-transform' => 'uppercase',
                    'font-family' => 'Arial, Helvetica, sans-serif',
                    'google'      => true,
                    ),
                    ),

                array(
                    'id' => 'main_menu_hover',
                    'type' => 'color',
                    'transparent' => false,
                    'title' => __('Navbar - Current menu item background color', 'bestia'),
                    'subtitle' => __('Pick a background color for main menu current and hover item (default: #333).', 'bestia'),
                    'default' => '#333',
                    'validate' => 'color'
                ),


                array(
                    'id' => 'current_menu_color',
                    'type' => 'color',
                    'title' => __('Navbar - Current menu item foint color', 'bestia'),
                    'subtitle' => __('Pick a background color for main menu current and hover item (default: #a31197).', 'bestia'),
                    'output' => array(
                        '#head .navbar-default .navbar-nav > .active > a, #head .navbar-default .navbar-nav > .active > a:hover, #head .navbar-default .navbar-nav > .active > a:focus'
                    ),
                    'default' => '#efefef',
                    'validate' => 'color'
                ),
                array(
                     'id'       => 'navbar-opts-end',
                     'type'     => 'osc_accordion', // field type
                     'position'  => 'end', // to close the accordion
                 ),
                  array(
                      'id'       => '07890938-start',
                      'type'     => 'osc_accordion', // field type
                      'title'    => 'Thumbnails', // here you can set the title for accordion

                      'position'  => 'start', // to start accordion
                      'open'=>false, // set this true in case you want to open it by default
                  ),

      array(
          'id' => 'preview-style',
          'type' => 'image_select',
          'title' => __('Preview', 'zetatube'),
          'subtitle' => __('You can change preview styles here.', 'zetatube'),
          'desc' => __('Choose your favorite layout.', 'zetatube'),
          //Must provide key => value(array:title|img) pairs for radio options
          'options' => array(
              '1' => array(
                  'img' => ReduxFramework::$_url . 'assets/img/thumb-styles/preview-1.png'
              ),
              '2' => array(
                  'img' => ReduxFramework::$_url . 'assets/img/thumb-styles/preview-2.png'
              ),
              '3' => array(
                  'img' => ReduxFramework::$_url . 'assets/img/thumb-styles/preview-3.png'
              ),
              '4' => array(
                  'img' => ReduxFramework::$_url . 'assets/img/thumb-styles/preview-4.png'
              ),
          ),
          'default' => '2'
      ),
      array(
      'id'             => 'thumb-padding',
      'type'           => 'spacing',
      'output'         => array('.Thumbnail_List li'),
      'mode'           => 'padding',
      'units'          => array('em', '%', 'px'),
      'units_extended' => 'false',
      'title'          => __('Video List - Thumbnail Box Padding', 'redux-framework-demo'),
      'subtitle'       => __('The CSS padding properties are used to generate space around an elements content, inside of any defined borders.', 'redux-framework-demo'),
      'desc'           => __('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'redux-framework-demo'),
      'default'            => array(
          'padding-top'     => '1',
          'padding-right'   => '1',
          'padding-bottom'  => '1',
          'padding-left'    => '1',
          'units'          => 'px',
        )
      ),
      array(
         'id'             => 'thumb-margin',
         'type'           => 'spacing',
         'output'         => array('.Thumbnail_List li'),
         'mode'           => 'margin',
         'units'          => array('em', '%', 'px'),
         'units_extended' => 'false',
         'title'          => __('Video List - Thumbnail Box Margin', 'redux-framework-demo'),
         'subtitle'       => __('The CSS margin properties are used to create space around elements, outside of any defined borders.', 'redux-framework-demo'),
         'desc'           => __('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'redux-framework-demo'),
         'default'            => array(
         'margin-top'     => '2',
         'margin-right'   => '2',
         'margin-bottom'  => '2',
         'margin-left'    => '2',
         'units'          => 'px',
       )
  ),
        array(
            'id' => 'thumb_bg',
            'type' => 'color',
            'title' => __('Video List - Thumbnail Box Background Color', 'bestia'),
            'subtitle' => __('Pick a background color for thumbnail item (default: transparent).', 'bestia'),
            'default' => 'transparent',
            'validate' => 'color'
        ),
        array(
                            'id'          => 'thumbs-typography',
                            'type'        => 'typography',
                            'title'       => __('Video List - Typography Options', 'redux-framework-demo'),
                            'google'      => true,
                            'font-backup' => true,
                            'font-size'   => true,
                            'line-height' => true,
                            'text-align' => true,
                            'text-transform' => true,
                            'color' => true,
                            'output' => array(
                                '.activity-list .activity-item .activity-content .activity-inner,.buddypress-wrap .grid.bp-list>li .list-wrap ,.Category_List a.tax-title,.Thumbnail_List li a.title, .WidgetThumbs li a.title, #blog li a, #blog li h3, .thumi h1, .thumi span, .thumi h2, .thumi h3, .thumi h4, .thumi h5, .thumi h6, .thumbphoto h1,.thumbphoto span, .thumbphoto h2, .thumbphoto h3, .thumbphoto h4, .thumbphoto h5, .thumbphoto h6, .post-category a, .breadcrumbs'
                            ),
                            'units'       =>'px',
                            'subtitle'    => __('Typography option for all thumbnail information like duration, post-title etc.', 'redux-framework-demo'),
                            'default'     => array(
                                'font-style'  => '400',
                                'color'       => '#333',
                                'text-align'  => 'left',
                                'text-transform' => 'uppercase',
                                'font-size'   => '11px',
                                'line-height' => '11px',
                                'font-family' => 'Arial, Helvetica, sans-serif',
                                'google'      => true,
                            ),
                            ),
        array(
            'id' => 'thumb_bg_hover',
            'type' => 'color',
            'title' => __('Video List - Thumbnail Box Hover Background Color', 'bestia'),
            'subtitle' => __('Pick a mouse hover background color for thumbnail item (default: #ffffff).', 'bestia'),
            'default' => '#ffffff',
            'validate' => 'color'
        ),
        array(
            'id' => 'thumb_color_hover',
            'type' => 'color',
            'title' => __('Video List - Thumbnail Box Hover Text Color', 'bestia'),
            'subtitle' => __('Pick a text color for thumbnail items in mouse hover, ago text,video title etc. (default: #616161).', 'bestia'),
            'default' => '#616161',
            'validate' => 'color'
        ),
        array(
            'id' => 'hd_icon_bg',
            'type' => 'color',
            'transparent' => false,
            'title' => __('HD Icon Background', 'bestia'),
            'subtitle' => __('Pick a background color for your hd icons over thumbnails.', 'bestia'),
            'default' => '#c10060',
            'validate' => 'color'
        ),
        array(
            'id' => 'likes_icon_bg',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Likes Avarage Background', 'bestia'),
            'subtitle' => __('Pick a background color for your likes avarage visible over preview images.', 'bestia'),
            'default' => '#dd3333',
            'validate' => 'color'
        ),
     array(
            'id'       => '07890938-end',
            'type'     => 'osc_accordion', // field type
            'position'  => 'end', // to close the accordion
          ),
    array(
        'id'       => '9569273-start',
        'type'     => 'osc_accordion', // field type
        'title'    => 'Sidebar', // here you can set the title for accordion

        'position'  => 'start', // to start accordion
        'open'=>false, // set this true in case you want to open it by default
    ),


    array(
        'id' => 'sidebar_bg',
        'type' => 'color',
        'title' => __('Sidebar background color', 'bestia'),
        'subtitle' => __('Pick a background color for sidebar (default: transparent).', 'bestia'),
        'default' => 'transparent',
        'validate' => 'color'
    ),
    array(
        'id'          => 'sidebar-title-typography',
        'type'        => 'typography',
        'title'       => __('Widget Titles - Heading Tag Typography Options', 'redux-framework-demo'),
        'google'      => true,
        'font-backup' => true,
        'font-size'   => true,
        'line-height' => true,
        'text-align' => true,
        'text-transform' => true,
        'color' => true,
        'output' => array(
            'h1.widget-title, h2.widget-title, h3.widget-title, h4.widget-title, h5.widget-title, h6.widget-title, span.widget-title'
        ),
        'units'       =>'%',
        'subtitle'    => __('Typography option for sidebar widget titles, includes all sidebar heading tags.', 'redux-framework-demo'),
        'default'     => array(
            'font-style'  => '400',
            'font-family' => 'Arial, Helvetica, sans-serif',
            'google'      => true,
            'text-align' => 'left',
            'font-size' => '110%',
            'line-height' => '110%',
            'color'       => '#333',
            'text-transform' => 'uppercase',
        ),
        ),
        array(
            'id'          => 'sidebar-content-typography',
            'type'        => 'typography',
            'title'       => __('Widget Font Options', 'redux-framework-demo'),
            'google'      => true,
            'font-backup' => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align' => true,
            'text-transform' => true,
            'color' => true,
            'output' => array(
                '.widget, .recent-post, .textwidget, .sidebar'
            ),
            'units'       =>'%',
            'subtitle'    => __('Typography option for all widget fonts, includes all sidebar widget font and links.', 'redux-framework-demo'),
            'default'     => array(
                'font-style'  => '400',
                'font-size'   => '100%',
                'line-height' => '100%',
                'text-align' => 'left',
                'color' => '#333',
                'font-family' => 'Arial, Helvetica, sans-serif',
                'google'      => true,
            ),
            ),
    array(
      'id' => 'sidebar_link_color',
      'type' => 'link_color',
      'title' => __('Widget - Link and font color', 'bestia'),
      'subtitle' => __('Pick a color for sidebar menu and link items (default: #333).', 'bestia'),
        'output' => array(
            '.sidebar a, ul.Menu_List li a, li.cat-item .count'
        ),
        'default' => array(
            'regular' => '#333',
            'hover' => '#333',
            'active' => '#333'
        )
    ),
    array(
        'id' => 'side_menu_border_bottom',
        'type' => 'color',
        'transparent' => false,
        'title' => __('Border-bottom color for widget menu elements.', 'bestia'),
        'subtitle' => __('Pick a border-bottom color for sidebar menu items (default: #e6e6e6).', 'bestia'),
        'default' => '#e6e6e6',
        'validate' => 'color'
    ),

    array(
        'id' => 'slide_line',
        'type' => 'color',
        'title' => __('Animated Border Color', 'bestia'),
        'subtitle' => __('Pick a color for the animated bottom border on mouse hover.', 'bestia'),
        'default' => '#e840cc',
        'validate' => 'color'
    ),
array(
                    'id'       => '9569273-end',
                    'type'     => 'osc_accordion', // field type
                    'position'  => 'end', // to close the accordion
                ),


    array(
        'id'       => '8915215-start',
        'type'     => 'osc_accordion', // field type
        'title'    => 'Footer', // here you can set the title for accordion

        'position'  => 'start', // to start accordion
        'open'=>false, // set this true in case you want to open it by default
    ),

    array(
        'id' => 'foot_widgets_bg',
        'type' => 'color',
        'transparent' => false,
        'title' => __('Footer Widgets (footer top) - Background Color', 'bestia'),
        'subtitle' => __('Pick a background color for the footer widgets section.An active widget is required.', 'bestia'),
        'default' => '#fff',
        'validate' => 'color'
    ),
    array(
        'id' => 'foot_heading_color',
        'type' => 'color',
        'transparent' => false,
        'title' => __('Footer Widgets Title & Font Color', 'bestia'),
        'subtitle' => __('Pick a color for the footer widget titles (default: #333).', 'bestia'),
        'output' => array(
           '#footer .footer-top .widget h1,
            #footer .footer-top .widget h2,
            #footer .footer-top .widget h3,
            #footer .footer-top .widget h4,
            #footer .footer-top .widget h5,
            #footer .footer-top .widget h6,
            #footer .footer-top .widget span,
            #footer .footer-top .widget p,#footer .footer-top .widget .textwidget'
        ),
        'default' => '#333',
        'validate' => 'color'
    ),
    array(
        'id' => 'foot_heading_border_1',
        'type' => 'color',
        'transparent' => false,
        'title' => __('Footer Widgets Title - First Border Color', 'bestia'),
        'subtitle' => __('Pick the first 60px border color for the footer widget titles.', 'bestia'),
        'default' => '#dd84e7',
        'validate' => 'color'
    ),
    array(
        'id' => 'foot_heading_border_2',
        'type' => 'color',
        'transparent' => false,
        'title' => __('Footer Widgets Title - Second Border Color', 'bestia'),
        'subtitle' => __('Pick the second border color for the footer widget titles.', 'bestia'),
        'default' => '#f2f2f2',
        'validate' => 'color'
    ),
    array(
        'id' => 'footer_links',
        'type' => 'link_color',
        'title' => __('Footer - Links/Menu Color Options', 'bestia'),
        'subtitle' => __('Only color validation can be done on this field type', 'bestia'),
        'desc' => __('Choose links color for the footer section', 'bestia'),
        'output' => array(
            '#footer .footer-top .widget ul a'
        ),
        'default' => array(
            'regular' => '#666',
            'hover' => '#dd84e7',
            'active' => '#666'
        )
    ),
      array(
          'id' => 'foot_bg',
          'transparent' => false,
          'type' => 'color',
          'title' => __('Footer Bottom - Background Color', 'bestia'),
          'subtitle' => __('Pick a background color for the footer copyright section (default: #fafafa).', 'bestia'),
          'default' => '#fafafa',
          'validate' => 'color'
      ),
      array(
          'id' => 'foot_text_color',
          'type' => 'color',
          'transparent' => false,
          'title' => __('Footer Bottom Font Color', 'bestia'),
          'subtitle' => __('Pick a text color for footer  copyright section (default: #333).', 'bestia'),
          'output' => array(
              '#footer, #footer a'
          ),
          'default' => '#333',
          'validate' => 'color'
      ),
array(
  'id'       => '8915215-end',
  'type'     => 'osc_accordion', // field type
  'position'  => 'end', // to close the accordion
),
      array(
          'id'       => '70299839-start',
          'type'     => 'osc_accordion', // field type
          'title'    => 'Like & Dislike', // here you can set the title for accordion

          'position'  => 'start', // to start accordion
          'open'=>false, // set this true in case you want to open it by default
      ),
      array(
          'id'       => 'toolbar-border',
          'type'     => 'border',
          'title'    => __('Toolbar Border Option', 'bestia'),
          'subtitle' => __('Only color validation can be done on this field type', 'redux-framework-demo'),
          'output'   => array('.nav-tabs>li>a:hover,.tool_bar,.nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover,.nav-tabs'),
          'desc'     => __('Toolbar border color options in single page, this div includes content title , rating avarage and like dislike buttons.', 'redux-framework-demo'),
          'default'  => array(
             'border-color'  => '#eee',
             'border-style'  => 'solid',
             'border-top'    => '1px',
             'border-right'  => '1px',
             'border-bottom' => '1px',
             'border-left'   => '1px'
    )
),

        array(
            'id' => 'single_content_title_background',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Content title background color.', 'bestia'),
            'subtitle' => __('Pick a background color for the right title section.', 'bestia'),
            'default' => '#fafafa'
        ),
        array(
            'id' => 'single_content_title_color',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Content title font color.', 'bestia'),
            'subtitle' => __('Pick a font color for the single content tile.', 'bestia'),
            'default' => '#000'
        ),
        array(
             'id'   =>'divider_content_rating_avarage',
             'desc' => __('Rating avarage and Votes count.', 'bestia'),
             'type' => 'divide'
        ),
        array(
            'id' => 'r_avarage_bg',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Colbar - Rating avarage background color.', 'bestia'),
            'subtitle' => __('Pick a background color for the middle rating avarage section.', 'bestia'),
            'default' => '#fafafa'
        ),
        array(
            'id' => 'r_avarage_border_left',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Colbar - Border left color.', 'bestia'),
            'subtitle' => __('Pick a left border color for the middle rating avarage section.', 'bestia'),
            'default' => '#eee'
        ),
        array(
            'id' => 'r_avarage_progress',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Progressbar - Rating progressbar color.', 'bestia'),
            'subtitle' => __('Pick a color for the progressbar whcih is under the rating avarage.', 'bestia'),
            'default' => '#e840cc'
        ),
        array(
            'id' => 'r_avarage_counter',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Votes count color.', 'bestia'),
            'subtitle' => __('Pick a color for the vote counter.', 'bestia'),
            'default' => '#606060'
        ),
        array(
             'id'   =>'divider_content_rating_buttons',
             'desc' => __('Rating Buttons.', 'bestia'),
             'type' => 'divide'
        ),
        array(
            'id' => 'r_avarage_like_buttons_bg',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Like & Dislike Buttons - Background Color.', 'bestia'),
            'subtitle' => __('Pick a background color for the like buttons.', 'bestia'),
            'default' => '#fafafa'
        ),
        array(
            'id' => 'r_avarage_like_buttons_color',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Like & Dislike Buttons Icons Color.', 'bestia'),
            'subtitle' => __('Pick a font color for the like and dislike buttons.', 'bestia'),
            'output' => array(
                '.item_rate .fa'
            ),
            'default' => '#3f3f3f'
        ),
        array(
             'id'   =>'divider_like_button',
             'desc' => __('Like Button.', 'bestia'),
             'type' => 'divide'
        ),
        array(
            'id' => 'r_avarage_like_btn_bg',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Like Button Hover Background Color.', 'bestia'),
            'subtitle' => __('Pick a background color for the like button on mouse over.', 'bestia'),
            'default' => '#e840cc'
        ),
        array(
            'id' => 'r_avarage_like_btn_color',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Like Button Hover Font Color.', 'bestia'),
            'subtitle' => __('Pick a font color for the like button on mouse over.', 'bestia'),
            'default' => '#fff'
        ),
        array(
             'id'   =>'divider_dislike_button',
             'desc' => __('Dislike Button.', 'bestia'),
             'type' => 'divide'
        ),
        array(
            'id' => 'r_avarage_dislike_btn_bg',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Dislike Button Hover Background Color.', 'bestia'),
            'subtitle' => __('Pick a background color for the dislike button on mouse over.', 'bestia'),
            'default' => '#9421ce'
        ),
        array(
            'id' => 'r_avarage_dislike_btn_color',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Dislike Button Hover Font Color.', 'bestia'),
            'subtitle' => __('Pick a font color for the dislike button on mouse over.', 'bestia'),
            'default' => '#fff'
        ),
        array(
            'id' => 'dislike_btn_border_left_color',
            'type' => 'color',
            'transparent' => false,
            'title' => __('Dislike Button Border Left Color.', 'bestia'),
            'subtitle' => __('Pick a font left border color for the dislike button.', 'bestia'),
            'default' => '#c9c9c9'
        ),
        array(
          'id'       => '70299839-end',
          'type'     => 'osc_accordion', // field type
          'position'  => 'end', // to close the accordion
        ),
        array(
            'id'       => '57886993-start',
            'type'     => 'osc_accordion', // field type
            'title'    => 'Buttons', // here you can set the title for accordion

            'position'  => 'start', // to start accordion
            'open'=>false, // set this true in case you want to open it by default
        ),
        array(
            'id'          => 'buttons-typography',
            'type'        => 'typography',
            'title'       => __('Buttons & Sorters Typography', 'redux-framework-demo'),
            'google'      => true,
            'font-backup' => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align' => true,
            'text-transform' => true,
            'color' => true,
            'output' => array('.bp-navsul li a,aw-whats-new-submit,.saic-cancel-btn,.video_sorter a.btn, .viewall a.btn, .btn-default,input[type="submit"],input[type="reset"],.saic-wrapper .saic-wrap-form .saic-container-form input[type="submit"]'
            ),
              'units'       =>'px',
              'subtitle'    => __('Typography option all button and filter options.', 'redux-framework-demo'),
              'default'     => array(
              'font-style'  => '400',
              'font-size'   => '12px',
              'text-transform' => 'uppercase',
              'text-align'  => 'left',
              'line-height' => '12px',
              'color'       => '#333',
              'font-family' => 'Arial, Helvetica, sans-serif',
              'google'      => true,
            ),
          ),
          array(
             'id'       => 'btns-border',
             'type'     => 'border',
             'title'    => __('Buttons & Sorters Border', 'redux-framework-demo'),
             'subtitle' => __('Only color validation can be done on this field type', 'redux-framework-demo'),
             'output' => array('aw-whats-new-submit,.saic-cancel-btn,.video_sorter a.btn, .viewall a.btn, .btn-default,input[type="submit"],input[type="reset"],.saic-wrapper .saic-wrap-form .saic-container-form input[type="submit"]'),
             //'desc'     => __('This is the description field, again good for additional info.', 'redux-framework-demo'),
             'default'  => array(
             'border-color'  => '#ccc',
             'border-style'  => 'solid',
             'border-top'    => '1px',
             'border-right'  => '1px',
             'border-bottom' => '1px',
             'border-left'   => '1px'
           ),
         ),
         array(
             'id' => 'btns-background',
             'type' => 'background',
             'class' => 'topbar-half',
             'transparent' => true,
             'preview' => false,
             'background-repeat' => false,
             'background-attachment' => false,
             'background-position' => false,
             'background-image' => false,
             'background-clip' => false,
             'background-size' => false,
             'output' => array('.bp-navsul li a,aw-whats-new-submit,.saic-cancel-btn,.video_sorter a.btn, .viewall a.btn, .btn-default,input[type="submit"],input[type="reset"]'),
             'title' => __('Buttons & Sorters Background Color', 'bestia'),
             'subtitle' => __('Pick a background color sorters or basic buttons.', 'bestia'),
             'default'  => array(
                'background-color' => 'transparent',
             ),
         ),
         array(
            'id'       => 'btns-border-hover',
            'type'     => 'border',
            'title'    => __('Buttons & Sorters Mouse Over Border', 'redux-framework-demo'),
            'subtitle' => __('Only color validation can be done on this field type', 'redux-framework-demo'),
            'output' => array('.bp-navsul li a:hover,.saic-cancel-btn:hover,.video_sorter a.btn:hover, .viewall a.btn:hover, .viewall .btn.active, .video_sorter .btn.active, .btn-default:hover,input[type="submit"]:hover,input[type="reset"]:hover'),
            //'desc'     => __('This is the description field, again good for additional info.', 'redux-framework-demo'),
            'default'  => array(
            'border-color'  => '#ccc',
            'border-style'  => 'solid',
            'border-top'    => '1px',
            'border-right'  => '1px',
            'border-bottom' => '1px',
            'border-left'   => '1px'
          ),
        ),
        array(
            'id' => 'btns-background-hover',
            'type' => 'background',
            'class' => 'topbar-half',
            'transparent' => true,
            'preview' => false,
            'background-repeat' => false,
            'background-attachment' => false,
            'background-position' => false,
            'background-image' => false,
            'background-clip' => false,
            'background-size' => false,
            'output' => array('.bp-navsul li a:hover,.saic-cancel-btn:hover,.video_sorter a:hover, .viewall a:hover, .viewall .btn.active, .video_sorter .btn.active, .btn-default:hover,input[type="reset"]:hover, input[type="submit"]:hover'),
            'title' => __('Buttons & Sorters Mouse Over Background Color', 'bestia'),
            'subtitle' => __('Pick a button:hover background color sorters or basic buttons.', 'bestia'),
            'default'  => array(
               'background-color' => '#f7f7f7',
            ),
        ),

        array(
            'id' => 'buttons-sorters-hover-color',
            'type' => 'color',
            //'transparent' => false,
            'output' => array('.saic-cancel-btn:hover,.video_sorter a.btn:hover, .viewall a.btn:hover, .btn-default:hover,.btn-pd:hover'),
            'title' => __('Buttons & Sorters Mouse Over Font Color', 'bestia'),
            'subtitle' => __('Pick a hover color for your buttons font.', 'bestia'),
            'default' => '#333'
        ),
array(
    'id'       => '989938894-end',
    'type'     => 'osc_accordion', // field type
    'position'  => 'end', // to close the accordion
),
array(
    'id'       => '987687289-start',
    'type'     => 'osc_accordion', // field type
    'title'    => 'Pagination', // here you can set the title for accordion

    'position'  => 'start', // to start accordion
    'open'=>false, // set this true in case you want to open it by default
),
array(
    'id' => 'pagination_style',
    'type' => 'button_set',
    'title' => __('Pagination Style', 'bestia'),
    'subtitle' => __('Choose a pagination style,inherit can be used also for dark colors.', 'bestia'),
    'desc' => __('Dark pagination must be used with dark body background.', 'bestia'),
    //Must provide key => value pairs for radio options
    'options' => array(
        'default' => __('Default', 'bestia'),
        'inherit' => __('Inherit', 'bestia'),
        'light' => __('Light', 'bestia'),
        'dark' => __('Dark', 'bestsia')
    ),
    'default' => 'default'
),
array(
    'id' => 'rounded-pagination',
    'type' => 'switch',
    'title' => __('Pagination Rounded Borders', 'bestia'),
    "default" => 0,
    'on' => __('Yes', 'bestia'),
    'off' => __('No', 'bestia')
),
array(
    'id' => 'center-pagination',
    'type' => 'switch',
    'title' => __('Center Pagination', 'bestia'),
    'desc' => __('This option does nothing to the dark pagination.', 'bestia'),
    "default" => 0,
    'on' => __('Yes', 'bestia'),
    'off' => __('No', 'bestia')
),
array(
  'id'       => '987687289-end',
  'panel'    => $bp_active,
  'type'     => 'osc_accordion', // field type
  'position'  => 'end', // to close the accordion
),

          array(
              'id'       => 'buddypress9-start',
              'type'     => 'osc_accordion', // field type
              'title'    => 'BuddyPress', // here you can set the title for accordion
              'panel'    => $bp_active,
              'position'  => 'start', // to start accordion
              'open'=>false, // set this true in case you want to open it by default
          ),
          array(
            'panel'    => $bp_active,
            'id'       => 'bp-information',
            'desc'     => '',
            'type'     => 'info', // field type
          ),
         array(
            'id'             => 'bp_itembody_bg',
            'type'           => 'color',
            'transparent'  => false,
            'panel'         => $bp_active,
            'title'          => __('BuddyPress Content Background', 'redux-framework-demo'),
            'subtitle'       => __('This option includes the BuddyPress content and nav section.', 'redux-framework-demo'),
            'default'         => array(
            'color'          => '#ccc',
          ),
        ),
        array(
           'id'             => 'bp_itembody_color',
           'type'           => 'color',
           'transparent'  => false,
           'panel'         => $bp_active,
           'title'          => __('BuddyPress Content Font Color', 'redux-framework-demo'),
           'subtitle'       => __('This option includes the BuddyPress content and nav section.', 'redux-framework-demo'),
           'default' => '#333',
       ),

       array(
           'id' => 'bp_links_color',
           'type' => 'link_color',
           'title' => __('BuddyPress Link Options', 'bestia'),
           'subtitle' => __('Only color validation can be done on this field type', 'bestia'),
           'desc' => __('Choose links color for the buddypres content', 'bestia'),
           'output' => array(
               '#buddypress ul#activity-stream.activity-list > li .activity-content .activity-inner,.activity-list .activity-item .activity-meta.action .button, #aw-whats-new-reset, #buddypress .item-body a, a.view activity-time-since'
           ),
           'default' => array(
               'regular' => '#175b79',
               'hover' => '#3068B5',
               'active' => '#175b79'
           )
       ),
          array(
            'id'       => 'buddypress9-end',
            'panel'    => $bp_active,
            'type'     => 'osc_accordion', // field type
            'position'  => 'end', // to close the accordion
          ),
    )
));
Redux::setSection($opt_name, array(
    'title' => __('Additional JS/CSS', 'bestia'),
    'subsection' => true,
    'icon' => 'el el-css',
    'fields' => array(
        array(
            'id' => 'mtn_stil',
            'type' => 'ace_editor',
            'title' => __('Additional CSS', 'bestia'),
            'subtitle' => __('This is the place where you can put your additional stylesheet.', 'bestia'),
            'mode' => 'css',
            'default' => ".exampleclass {\nbackground: #303030; color: #C5C5C5;\n}"
        ),
        array(
            'id' => 'mtn_headerhook',
            'type' => 'ace_editor',
            'title' => __('Header Hook', 'bestia'),
            'subtitle' => __('Paste your JS code here.', 'bestia'),
            'mode' => 'javascript',
            'theme' => 'chrome'
        ),
        array(
            'id' => 'mtn_analtik',
            'type' => 'ace_editor',
            'title' => __('Footer Hook', 'bestia'),
            'subtitle' => __('Paste your JS code here.', 'bestia'),
            'mode' => 'javascript',
            'theme' => 'chrome'
        )
    )
));
