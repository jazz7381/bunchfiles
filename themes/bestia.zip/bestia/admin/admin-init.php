<?php
    if ( file_exists( dirname( __FILE__ ) . '/tgm/tgm-init.php' ) ) {
        require_once dirname( __FILE__ ) . '/tgm/tgm-init.php';
    }
    if ( file_exists( dirname( __FILE__ ).'/bestia-framework/bestia_framework.php' ) ) {
        require_once dirname(__FILE__).'/bestia-framework/bestia_framework.php';
    }
    if ( file_exists( dirname( __FILE__ ) . '/bestia_admin.php' ) ) {
        require_once dirname( __FILE__ ) . '/bestia_admin.php';
    }

