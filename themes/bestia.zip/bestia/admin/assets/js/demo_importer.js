(function($){
    "use strict";

    $(document).ready( function() {

        function showImportMessage( selected_demo, message, count, index ) {
            var html = '', percent = 0;

            if ( selected_demo ) {
                html += '<h3>Installing ' + $('.demo-info').html() + '</h3>';
            }
            if ( message ) {
                html += '<strong>' + message + '</strong>';
            }

            if ( count && index ) {
                percent = index / count * 100;
                if ( percent > 100 )
                    percent = 100;

                html += '<div class="import-progress-bar"><div style="width:' + percent + '%;"></div></div>';
            }

            $('.bestia-theme-demo #import-status').stop().show().html(html);
        }

        // tab switch ( Demo Importer / System Status )
        $('.bestia-theme-demo .demo-tab-switch').click( function(e) {
            e.preventDefault();

            $('.bestia-theme-demo .demo-tab-switch').removeClass('active');
            $(this).addClass('active');

            var container_id = $(this).attr('href');

            $('.bestia-theme-demo .demo-tab').hide();

            $(container_id).show();
        } );

        $('.status_toggle2').click( function(e) {
            e.preventDefault();

            $('.bestia-theme-demo .demo-tab-switch').removeClass('active');
            $('.bestia-theme-demo .demo-tab-switch#status_toggle').addClass('active');

            var container_id = $(this).attr('href');

            $('.bestia-theme-demo .demo-tab').hide();
            $(container_id).show();
        } );
    });

})( jQuery );
