<?php
if( !function_exists('bestia_wp_nav_menu_args') ){
	function bestia_wp_nav_menu_args( $args = '' ) {
		$args['container'] = false;
		return $args;
	}
	add_filter( 'wp_nav_menu_args', 'bestia_wp_nav_menu_args' );
}
if( !class_exists('Bestia_Walker_Nav_Menu') ){
	class Bestia_Walker_Nav_Menu extends Walker_Nav_Menu {
	   function start_lvl(&$output, $depth = 0, $args = array()) {
	      $output .= "\n<ul class=\"dropdown-menu\">\n";
	   }
	   function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
	       $item_html = '';
	       parent::start_el($item_html, $item, $depth, $args);

	       if ( $item->is_dropdown && $depth === 0 ) {
	       		if( wp_is_mobile() ){
	       			$item_html = str_replace( '<a', '<a class="dropdown-toggle" data-toggle="dropdown"', $item_html );
	       		}
	       		else{
	       			$item_html = str_replace( '<a', '<a', $item_html );
	       		}
	           $item_html = str_replace( '</a>', ' <b class="caret"></b></a>', $item_html );
	       }
	       $output .= $item_html;
	    }
	    function display_element($element, &$children_elements, $max_depth, $depth = 1, $args, &$output) {
	        if ( $element->current )
	        $element->classes[] = 'active';

	        $element->is_dropdown = !empty( $children_elements[$element->ID] );

	        if ( $element->is_dropdown ) {
	            if ( $depth === 0 ) {
	                $element->classes[] = 'dropdown';
	            } elseif ( $depth === 1 ) {
	                // Extra level of dropdown menu,
	                // as seen in http://twitter.github.com/bootstrap/components.html#dropdowns
	                $element->classes[] = 'dropdown-submenu';
	            }
	        }
	    	parent::display_element($element, $children_elements, $max_depth, $depth, $args, $output);
	    }
	}
}
if( !function_exists('bestia_add_parent_css') ){
	function bestia_add_parent_css($classes, $item){
	     global  $dd_depth, $dd_children;
	     $classes[] = 'depth'.$dd_depth;
	     if($dd_children)
	         $classes[] = 'dropdown';
	    return $classes;
	}
	add_filter('nav_menu_css_class','bestia_add_parent_css',10,2);
}
