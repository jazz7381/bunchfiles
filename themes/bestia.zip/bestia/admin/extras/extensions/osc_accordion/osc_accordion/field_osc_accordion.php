<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'ReduxFramework_osc_accordion' ) ) {
    class ReduxFramework_osc_accordion {

        /**
         * Field Constructor.
         * Required - must call the parent constructor, then assign field and value to vars, and obviously call the render field function
         *
         * @since ReduxFramework 1.0.0
         */
        function __construct( $field = array(), $value = '', $parent ) {
            $this->parent = $parent;
            $this->field  = $field;
            $this->value  = $value;
            //print_r($value);
            //print_r($field);

            if ( empty( $this->extension_dir ) ) {
                $this->extension_dir = trailingslashit( str_replace( '\\', '/', dirname( __FILE__ ) ) );
                $this->extension_url = site_url( str_replace( trailingslashit( str_replace( '\\', '/', ABSPATH ) ), '', $this->extension_dir ) );
            }
        }

        /**
         * Field Render Function.
         * Takes the vars and outputs the HTML for the field in the settings
         *
         * @since ReduxFramework 1.0.0
         */
        function render() {

            //print_r($this->field);
            // If options is NOT empty, the process

            if ($this->field['position'] == 'start') {
                echo '</td></tr></table><div id="' . $this->field['id'] . '" class="redux-oscitas-accordion redux-field-init " data-oscclose="'.(isset($this->field['open']) && $this->field['open'] ? '0':'1').'" data-id="'. $this->field['id'] .'" data-type="osc_accordion">';
                echo '<div id="' . $this->field['id'] . '-header"  style="" class="redux-oscitas-accordion-header" >';
                echo '<h1>' . $this->field['title'] . '</h1>';
                //echo '<span>' . $this->field['subtitle'] . '</span>';
                echo '</div>';
                echo '<div id="' . $this->field['id'] . '-accordion-area" class="redux-oscitas-accordion-accordion-area" >';
                echo '<table class="form-table no-border" style="margin-top: 0;"><tbody><tr style="border-bottom:0; display:none;"><th style="padding-top:0;"></th><td style="padding-top:0;">';
            } else if ($this->field['position'] == 'end') {
                echo '</td></tr></table></div>';
                echo '</div>';
                echo '<table class="form-table no-border" style="margin-top: 0;"><tbody><tr style="border-bottom:0; display:none;"><th style="padding-top:0;"></th><td style="padding-top:0;">';
            }
        } //function

        /**
         * Enqueue Function.
         * If this field requires any scripts, or css define this function and register/enqueue the scripts/css
         *
         * @since ReduxFramework 1.0.0
         */
        function enqueue() {
            wp_enqueue_script(
                'redux-field-accordion-js',
                //$this->extension_url .'field_osc_accordion' . Redux_Functions::isMin() . '.js',
                $this->extension_url .'field_osc_accordion.js',
                array( 'jquery', 'redux-js' ),
                time(),
                true
            );
//
            //if ($this->parent->args['dev_mode']) {
                wp_enqueue_style(
                    'redux-field-accordion-css',
                    $this->extension_url .'field_osc_accordion.css',
                    array(),
                    time(),
                    'all'
                );
            //}
        } //function

    } //class
}
