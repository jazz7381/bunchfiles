/*global redux_change, redux*/

(function( $ ) {
    "use strict";

    redux.field_objects = redux.field_objects || {};
    redux.field_objects.osc_accordion = redux.field_objects.osc_accordion || {};

    $( document ).ready(
        function() {
            //redux.field_objects.osc_accordion.init();
        }
    );

    $( window ).load(

        function() {
            //setTimeout(
            //    function () {
            //        var selector = jQuery(document).find(".redux-group-tab:visible").find('.redux-oscitas-accordion:visible');
            //        jQuery(selector).each(
            //            function () {
            //                var el = jQuery(this);
            //                var parent = el;
            //                var id = el.attr('id');
            //                if (el.data('oscclose') == 1) {
            //                    jQuery('#' + id + '-accordion-area').hide();
            //                }
            //            }
            //        );
            //    }, 3000);
        }
    );



    redux.field_objects.osc_accordion.init = function( selector ) {
        if ( !selector ) {
            selector = jQuery(document).find(".redux-group-tab:visible").find('.redux-oscitas-accordion:visible');
        }

        //console.log(selector);

        $( selector ).each(
            function() {
                var el = $( this );
                //console.log(el);
                var parent = el;
                var id = el.attr('id');
                if (el.data('oscclose') == 1) {
                    //jQuery('#'+id+'-accordion-area').hide();
                }
                if (el.hasClass('redux-field-init')) {
                    el.removeClass('redux-field-init');
                    setTimeout (function(){
                        redux.field_objects.osc_accordion.init(el);
                    }, 1000);
                } else {
                    var elsToSkip = [
                        '.redux-container-osc_accordion',
                        'checkbox',
                        'radio',
                        'text',
                        'info',
                        'textarea',
                        'password',
                        'divide',
                        'editor',
                        'section',
                        'raw',
                        'button_set',
                    ];
                    var initCount = el.find('.redux-field-init')
                        .not(el.find(elsToSkip.join(',.redux-container-')))
                        .length;
                    //console.log(initCount);
                    if ( !initCount && el.data('oscclose') == '1') {
                        el.find('.redux-oscitas-accordion-accordion-area').hide();
                    } else if (initCount) {
                        setTimeout (function(){
                            redux.field_objects.osc_accordion.init(el);
                        }, 1000);
                    }
                    return;
                }
                el.find('#'+id+'-header').click(function() {
                   jQuery('#'+id+'-accordion-area').slideToggle( "slow" );
                });


            }
        );
    };
})( jQuery );