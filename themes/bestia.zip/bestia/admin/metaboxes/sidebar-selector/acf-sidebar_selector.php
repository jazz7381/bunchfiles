<?php

add_action('acf/include_field_types', 'include_field_types_sidebar_selector');
/**
 * ACF 5 Field
 *
 * Loads the field for ACF 5
 *
 * @author Daniel Pataki
 * @since 3.0.0
 *
 */
function include_field_types_sidebar_selector( $version ) {
	include_once('acf-sidebar_selector-v5.php');
}


add_action('acf/register_fields', 'register_fields_sidebar_selector');
/**
 * ACF 4 Field
 *
 * Loads the field for ACF 4
 *
 * @author Daniel Pataki
 * @since 3.0.0
 *
 */
function register_fields_sidebar_selector() {
	include_once('acf-sidebar_selector-v4.php');
}



?>
