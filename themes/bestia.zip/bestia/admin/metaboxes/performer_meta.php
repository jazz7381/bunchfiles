<?php
//include the main class file
require_once("performer-meta-class/Tax-meta-class.php");
if (is_admin()){
  /*
   * prefix of meta keys, optional
   */
  $prefix = 'awpt_';
  /*
   * configure your meta box
   */
  $config = array(
    'id' => 'performer_meta_boxes',          // meta box id, unique per meta box
    'title' => 'Demo Meta Box',          // meta box title
    'pages' => array('performer'),        // taxonomy name, accept categories, post_tag and custom taxonomies
    'context' => 'normal',            // where the meta box appear: normal (default), advanced, side; optional
    'fields' => array(),            // list of meta fields (can be added by field arrays)
    'local_images' => true,          // Use local or hosted images (meta box images for add/remove)
    'use_with_theme' => true         //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
  );


  /*
   * Initiate your meta box
   */
  $my_meta =  new Tax_Meta_Class($config);

  /*
   * Add fields to your meta box
   */

  //text field
 /* $my_meta->addText($prefix.'text_field_id',array('name'=> __('My Text ','bestia'),'desc' => 'this is a field desription'));
  //textarea field
  $my_meta->addTextarea($prefix.'textarea_field_id',array('name'=> __('My Textarea ','bestia')));
  //checkbox field
  $my_meta->addCheckbox($prefix.'checkbox_field_id',array('name'=> __('My Checkbox ','bestia')));
  //select field*/

  $my_meta->addSelect($prefix.'gender',
  array('female'=>'Female','male'=>'Male', 'transgender' => 'Transgender'),
  array('name'=> __('Gender','bestia'),
  'std'=> ''));
  $my_meta->addText($prefix.'age',array('name'=> __('Age ','bestia'),));

  $my_meta->addSelect($prefix.'eye_color',
  array('amber'=>'Amber','blue'=>'Blue','brown'=>'Brown','gray'=>'Gray','green'=>'Green','hazel'=>'Hazel'),
  array('name'=> __('Eye Color','bestia'),
  'std'=> ''));

   $my_meta->addSelect($prefix.'hair_color',
  array('black'=>'Black','brown'=>'Brown','blond'=>'Blond','auburn'=>'Auburn','chestnut'=>'Chestnut','red'=>'Red'),
  array('name'=> __('Hair Color','bestia'),
  'std'=> ''));

  $my_meta->addText($prefix.'performer_weight',array('name'=> __('Weight','bestia'),));
  $my_meta->addText($prefix.'performer_height',array('name'=> __('Height','bestia'),));
  $my_meta->addText($prefix.'cupsize',array('name'=> __('Cupsize','bestia'),));
  $my_meta->addText($prefix.'ethnicity',array('name'=> __('Ethnicity','bestia'),));
  $my_meta->addText($prefix.'performer_country',array('name'=> __('Country','bestia'),));
  $my_meta->addText($prefix.'performer_city',array('name'=> __('City ','bestia'),));
  $my_meta->addText($prefix.'facebook_url',array('name'=> __('Facebook URL','bestia'),'desc' => 'Paste facebook url of this performer (optional)'));
  $my_meta->addText($prefix.'twitter_url',array('name'=> __('Twitter URL','bestia'),'desc' => 'Paste twitter url of this performer (optional)'));
  $my_meta->addText($prefix.'instagram_url',array('name'=> __('Instagram URL','bestia'),'desc' => 'Paste instagram url of this performer (optional)'));
  $my_meta->addText($prefix.'official_site',array('name'=> __('Official Site','bestia'),'desc' => 'Paste official site url of this performer (optional)'));
  $my_meta->addImage($prefix.'cover_image',array('name'=> __('Performer Cover Image ','bestia')));
  //$my_meta->addColor($prefix.'color_field_id',array('name'=> __('My Color ','bestia')));

  //radio field
/*  $my_meta->addRadio($prefix.'radio_field_id',array('radiokey1'=>'Radio Value1','radiokey2'=>'Radio Value2'),array('name'=> __('My Radio Filed','bestia'), 'std'=> array('radionkey2')));

  $my_meta->addDate($prefix.'date_field_id',array('name'=> __('My Date ','bestia')));
  //Time field
  $my_meta->addTime($prefix.'time_field_id',array('name'=> __('My Time ','bestia')));
  //Color field
  $my_meta->addColor($prefix.'color_field_id',array('name'=> __('My Color ','bestia')));
  //Image field
  $my_meta->addImage($prefix.'image_field_id',array('name'=> __('My Image ','bestia')));
  //file upload field
  $my_meta->addFile($prefix.'file_field_id',array('name'=> __('My File ','bestia')));
  //wysiwyg field
  $my_meta->addWysiwyg($prefix.'wysiwyg_field_id',array('name'=> __('My wysiwyg Editor ','bestia')));
  //taxonomy field
  $my_meta->addTaxonomy($prefix.'taxonomy_field_id',array('taxonomy' => 'category'),array('name'=> __('My Taxonomy ','bestia')));
  //posts field
  $my_meta->addPosts($prefix.'posts_field_id',array('args' => array('post_type' => 'page')),array('name'=> __('My Posts ','bestia')));

  /*
   * To Create a reapeater Block first create an array of fields
   * use the same functions as above but add true as a last param


  $repeater_fields[] = $my_meta->addText($prefix.'re_text_field_id',array('name'=> __('My Text ','bestia')),true);
  $repeater_fields[] = $my_meta->addTextarea($prefix.'re_textarea_field_id',array('name'=> __('My Textarea ','bestia')),true);
  $repeater_fields[] = $my_meta->addCheckbox($prefix.'re_checkbox_field_id',array('name'=> __('My Checkbox ','bestia')),true);
  $repeater_fields[] = $my_meta->addImage($prefix.'image_field_id',array('name'=> __('My Image ','bestia')),true);
  /*
   * Then just add the fields to the repeater block
   */
  //repeater block
  /*$my_meta->addRepeaterBlock($prefix.'re_',array('inline' => true, 'name' => __('This is a Repeater Block','bestia'),'fields' => $repeater_fields));*/
  /*
   * Don't Forget to Close up the meta box decleration
   */
  //Finish Meta Box Decleration
  $my_meta->Finish();
}
