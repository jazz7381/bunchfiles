<?php
/**
 * MyTubePress MetaBox
 * Add Video MetaBox, ACF is required.
 * @author 		Shpend Berisha
 * @category 	Core
 * @version     1.0.0
 */
if( !defined('ABSPATH') ) exit;
require_once( TEMPLATEPATH."/admin/metaboxes/sidebar-selector/acf-sidebar_selector.php" );
if( !class_exists('MyTubePress_MetaBoxes') ){
	class MyTubePress_MetaBoxes {
		function __construct() {
			add_action('admin_init', array($this,'video_metabox'));
			add_filter( 'mytubepress_video_type' , array( $this, 'video_type' ), 20, 1);
			add_filter( 'mytubepress_video_object' , array( $this, 'video_object' ), 20, 1 );
		}
		function video_type( $post_id ){
			if( !isset( $post_id ) || get_post_type( $post_id ) != 'post' )
				return;
			// first check the File field.
			$type = get_post_meta( $post_id, 'video_file', true ) ? true : false;
			if( $type == true ){
				return 'files';
			}
			return 'normal';
		}
		function video_object($post_id){
			if( !isset( $post_id ) || get_post_type( $post_id ) != 'post' )
				return;
			$video_object = get_post_meta( $post_id, 'video_frame', true ) ? get_post_meta( $post_id, 'video_frame', true ) : null;
			return get_post_meta( $post_id, 'video_url', true ) ? get_post_meta( $post_id, 'video_url', true ) : $video_object;
		}
		function video_metabox(){
			global $wp_post_types;
			$exclude_pt = array('revision','nav_menu_item','acf','attachment','deprecated_log','page');
			$post_id = isset( $_REQUEST['post'] ) ? (int)$_REQUEST['post'] : null;
			//$custom_template = isset( $_REQUEST['post'] ) ? (int)$_REQUEST['post'] : null;
			$template_file = get_post_meta($post_id, '_wp_page_template', TRUE);
			$post_type_array = array();
			foreach ( $wp_post_types as $pt ) {
				if( !empty( $pt->name ) && !in_array( $pt->name, $exclude_pt ) ){
					$post_type_array[ $pt->name ] = $pt->label;
				}
			}
			//$categories_page = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-categories.php') );
      if ($template_file == 'template-categories.php' || $template_file == 'template-performers.php' || $template_file == 'template-videos.php' || $template_file == 'template-gifs.php' || $template_file == 'template-photo-gallery.php' || $template_file == 'template-blog.php' || $template_file == 'template-channel-list.php' || $template_file == 'template-tags.php' || $template_file == 'template-home.php') {
				$layouts = array(
						'0side-cm' => __('No Sidebars'),
						'1side-cl' => __('1 Sidebar - Content Left'),
						'1side-cr' => __('1 Sidebar - Content Right'),
					);
			  } else {
			  $layouts = array(
					'0side-cm' => __('No Sidebars'),
					'1side-cl' => __('1 Sidebar - Content Left'),
					'1side-cr' => __('1 Sidebar - Content Right'),
					'2side-cl' => __('2 Sidebars - Content Center'),
				);
      }

			$default_slider = '
			<ul>
 	     <li>Weekly photo / movie updates</li>
 	     <li>Allvideos downloadable in 1080P and 720P</li>
 	     <li>More than 2000 minutes of high definition scenes</li>
 	     <li>Over 10000 high quality images and various sizes</li>
 	     <li>Optimized access for mobile &amp; tablet included</li>
 	     <li>Full access to all exclusive scenes &amp; private facts</li>
 	     <li>Unlimited streaming and picture slideshows</li>
     </ul>
      [button  link="#" text="Join Now!"]';
				$page_fields	=	array (
				  'id' => 'acf_page_settings',
				  'title' => 'Layout Settings',
				  'fields' => array (
						array (
							'key' => 'field_535765',
							'label' => __('Sidebar Position','bestia'),
							'name' => 'sidebar_position',
							'type' => 'select',
							'instructions' => __('This key will give you possibilities to change sidebar position of this page.','bestia'),
							'choices' => $layouts,
							'default_value' => '1side-cr',
							'allow_null' => 0,
							'multiple' => 0,
						),

/*
						array (
							'key' => 'yla_sidebar',
							'label' => __('Sidebar','bestia'),
							'name' => 'yla_sidebar',
							'type' => 'sidebar_selector',
							'instructions' => __('This is the sidebar selector key, here you can attach your favorite bestia sidebar for this page.','bestia'),
							'choices' => $layouts,
							'default_value' => '1side-cr',
							'allow_null' => 0,
							'multiple' => 0,
						),
*/

				  ),
				  'location' => array (
				array (
				    array (
				        'param' => 'post_type',
				        'operator' => '==',
				        'value' => 'page',
				        'order_no' => 0,
				        'group_no' => 0,
				  ),
				),
				),
				  'options' => array (
				    'position' => 'acf_after_title',
				    'layout' => 'default',
				    'hide_on_screen' => array (
				    ),
				  ),
				  'menu_order' => 0,
				);

				$gallery_fields	=	array (
				  'id' => 'acf_gallery_settings',
				  'title' => 'Bestia - Photo Gallery',
				  'fields' => array (
						array (
							'key' => 'field_53eb79f33936e678',
							'label' => __('Upload your files here','bestia'),
							'instructions' => __('Press and hold SHIFT to select multiple images in media library.','bestia'),
							'name' => 'gallery_files',
							'type' => 'gallery',
							'conditional_logic' => array (
							'status' => 1,
							'allorany' => 'all',
							),
							'preview_size' => 'thumbnail',
							'library' => 'all',
						),
						array (
							'key' => 'sponsor_link_txt',
							'label' => 'Sponsor Text',
							'name' => 'sponsor_link_txt',
							'type' => 'text',
							'prefix' => '',
							'required' => 0,
							'placeholder'	=>	'Sponsor Text!',
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
					),
					array (
						'key' => 'sponsor_link_url',
						'label' => 'Sponsor URL',
						'name' => 'sponsor_link_url',
						'type' => 'text',
						'prefix' => '',
						'placeholder'	=>	'http://exapmple-url.com',
						'required' => 0,
						'conditional_logic' => 0,
						'wrapper' => array (
							'width' => '',
							'class' => '',
							'id' => '',
						),
				),
				array (
					'key' => 'awpt_adv',
					'label' => 'Horizontal AD Banner',
					'instructions' => __('This ads code appears under the photo gallery.','bestia'),
					'name' => 'awpt_adv',
					'type' => 'textarea',
					'prefix' => '',
					'required' => 0,
					'conditional_logic' => 0,
					'wrapper' => array (
						'width' => '',
						'class' => 'awpt_adv_field',
						'id' => '',
						),
					),
				  ),
				  'location' => array (
				array (
				    array (
				        'param' => 'post_type',
				        'operator' => '==',
				        'value' => 'gallery',
				        'order_no' => 0,
				        'group_no' => 0,
				  ),
				),
				),
				  'options' => array (
				    'position' => 'acf_after_title',
				    'layout' => 'default',
				    'hide_on_screen' => array (
				    ),
				  ),
				  'menu_order' => 0,
				);

			$video_fields	=	array (
				'id' => 'acf_video',
				'title' => 'Video',
				'fields' => array (
					array (
						'key' => 'field_53eb79f33936e',
						'label' => __('Choose the Video type','bestia'),
						'name' => 'video_type',
						'type' => 'select',
						'choices' => array (
							'normal' => 'Link/iFrame Code',
							'files' => 'Files',
						),
						'default_value' => isset( $_GET['post'] ) ?  apply_filters( 'mytubepress_video_type' , $_GET['post']) : 'normal',
						'allow_null' => 0,
						'multiple' => 0,
					),
					array (
						'key' => 'field_53eb7a453936f',
						'label' => __('Enter the link(youtube,vimeo,external mp4) or embed code here(other sources).','bestia'),
						'name' => 'video_url',
						'type' => 'textarea',
						'instructions' => __('Here you can put multiple video object, one object/line.','bestia'),
						'conditional_logic' => array (
						'status' => 1,
						'rules' => array (
							array (
								'field' => 'field_53eb79f33936e',
								'operator' => '==',
								'value' => 'normal',
							),
						),
						'allorany' => 'all',
						),
						'default_value' =>  '',
						'value'		=>	isset( $_GET['post'] ) ? apply_filters( 'mytubepress_video_object' , $_GET['post']) : null,
						'placeholder' => '',
						'maxlength' => '',
						'rows' => '',
						'formatting' => 'none',
					),
					array (
						'key' => 'field_53eb7aae942ae',
						'label' => __('Upload your files here','bestia'),
						'name' => 'video_file',
						'type' => 'gallery',
						'conditional_logic' => array (
						'status' => 1,
						'rules' => array (
							array (
								'field' => 'field_53eb79f33936e',
								'operator' => '==',
								'value' => 'files',
							),
						),
						'allorany' => 'all',
						),
						'preview_size' => 'thumbnail',
						'library' => 'all',
					),
					array (
						'key' => 'video_description',
						'label' => 'Video Description',
						'instructions' => __('Write a description for this video.','bestia'),
						'name' => 'video_description',
						'type' => 'textarea',
						'prefix' => '',
						'required' => 0,
						'conditional_logic' => 0,
						'wrapper' => array (
							'width' => '',
							'class' => 'video_description_field',
							'id' => '',
						),
				),
				array (
					'key' => 'sponsor_link_txt',
					'label' => 'Sponsor Text',
					'name' => 'sponsor_link_txt',
					'type' => 'text',
					'prefix' => '',
					'required' => 0,
					'placeholder'	=>	'Watch Full Movie!',
					'conditional_logic' => 0,
					'wrapper' => array (
						'width' => '',
						'class' => '',
						'id' => '',
					),
			),
			array (
				'key' => 'sponsor_link_url',
				'label' => 'Sponsor URL',
				'name' => 'sponsor_link_url',
				'type' => 'text',
				'prefix' => '',
				'placeholder'	=>	'http://exapmple-url.com',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
		),
		array (
			'key' => 'video_duration',
			'label' => 'Video Duration',
			'name' => 'video_duration',
			'type' => 'text',
			'prefix' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'placeholder'	=>	'03:45',
			'wrapper' => array (
				'width' => '',
				'class' => '',
				'id' => '',
			),
	),
	array (
		'key' => 'awpt_adv',
		'label' => 'Horizontal AD Banner',
		'instructions' => __('This ads code appears under the video.','bestia'),
		'name' => 'awpt_adv',
		'type' => 'textarea',
		'prefix' => '',
		'required' => 0,
		'conditional_logic' => 0,
		'wrapper' => array (
			'width' => '',
			'class' => 'awpt_adv_field',
			'id' => '',
		  ),
    ),
		array (
			'key' => 'field_53eb7aae942aes89',
			'label' => __('Video Thumbnails (Preview Images)','bestia'),
			'instructions' => __('Use this gallery for thumbnails rotation.','bestia'),
			'name' => 'image_rotator',
			'type' => 'gallery',
			'conditional_logic' => array (
			'status' => 0,
			'allorany' => 'all',
			),
			'preview_size' => 'thumbnail',
			'library' => 'all',
		),
	),
	'location' => array (
      array (
					array (
							'param' => 'post_type',
							'operator' => '==',
							'value' => 'post',
							'order_no' => 0,
							'group_no' => 0,
				),
		),
),
				    'options' => array (
					  'position' => 'acf_after_title',
					  'layout' => 'default',
					  'hide_on_screen' => array (
					),
				),
				'menu_order' => 0,
			);
			$performer_fields	=	array (
				'id' => 'acf_performer_settings',
				'title' => 'Bestia - Performer Fields',
				'fields' => array (
					array (
						'key' => 'cover_img',
						'label' => 'Cover Image',
						'instructions' => __('This cover image appears behind the profile image on performer taxonomy.','bestia'),
						'name' => 'cover_img',
						'type' => 'image',
						'prefix' => '',
						'required' => 0,
						'conditional_logic' => 0,
						'wrapper' => array (
							'width' => '',
							'class' => 'awpt_cover_image',
							'id' => '',
						  ),
				    ),
				),
				'location' => array (
			array (
					array (
							'param' => 'taxonomy',
							'operator' => '==',
							'value' => 'performer',
							'order_no' => 0,
							'group_no' => 0,
				  ),
			  ),
			),
				      'options' => array (
					    'position' => 'acf_after_title',
					    'layout' => 'default',
					    'hide_on_screen' => array (
					  ),
				  ),
				'menu_order' => 0,
			);

			$gif_fields	=	array (
				'id' => 'acf_gif_settings',
				'title' => 'Bestia - Gif Gallery',
				'fields' => array (
					array (
						'key' => 'field_53eb79f39850340',
						'label' => __('Upload your files here','bestia'),
						'instructions' => __('Press and hold SHIFT to select multiple images in media library.','bestia'),
						'name' => 'gif_files',
						'type' => 'gallery',
						'conditional_logic' => array (
						'status' => 1,
						'allorany' => 'all',
						),
						'preview_size' => 'thumbnail',
						'library' => 'all',
					),
			array (
				'key' => 'awpt_adv',
				'label' => 'Horizontal AD Banner',
				'instructions' => __('This ads code appears under the gif gallery.','bestia'),
				'name' => 'awpt_adv',
				'type' => 'textarea',
				'prefix' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => 'awpt_adv_field',
					'id' => '',
					),
				),
				),
				'location' => array (
			array (
					array (
							'param' => 'post_type',
							'operator' => '==',
							'value' => 'gif',
							'order_no' => 0,
							'group_no' => 0,
				),
			),
			),
				'options' => array (
					'position' => 'acf_after_title',
					'layout' => 'default',
					'hide_on_screen' => array (
					),
				),
				'menu_order' => 0,
			);


			$slider_fields	=	array (
				'id' => 'slider_fields',
				'title' => 'Content',
				'fields' => array (
					array (
						'key' => 'slider_content',
						'label' => 'Write a content here',
						'instructions' => __('Appears on the right side block of a slide.','bestia'),
						'name' => 'slider_content',
						'type' => 'wysiwyg',
						'prefix' => '',
						'required' => 0,
						'default_value' =>  $default_slider,
						'conditional_logic' => 0,
				),
					array (
						'key' => 'slider_image',
						'label' => 'Image',
						'instructions' => __('Only one image is allowed for a slide.','bestia'),
						'name' => 'slider_image',
						'type' => 'image',
						'prefix' => '',
						'required' => 0,
						'conditional_logic' => 0,
				),
				array (
					'key' => 'slider_or',
					'label' => 'OR',
					'name' => 'slider_or',
					'type' => 'colorx',
					'prefix' => '',
					'required' => 0,
					'conditional_logic' => 0,
			),
				array (
					'key' => 'slider_video',
					'label' => 'Video',
					'instructions' => __('Upload a trailer or a short video in mp4 format.','bestia'),
					'name' => 'slider_video',
					'type' => 'file',
					'prefix' => '',
					'required' => 0,
					'conditional_logic' => 0,
					'mime_types' => 'mp4',
			),
			array (
				'key' => 'slider_toggle',
				'label' => 'Slide Toggle',
				'instructions' => __('This toggle button appears in mobile devices','bestia'),
				'name' => 'slider_toggle',
				'type' => 'text',
				'prefix' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'placeholder'	=>	'Open Here!',
				'default_value'	=>	'Open Here!',
		),
			/*
			array (
				'key' => 'slider_background_color',
				'label' => 'Background Color',
				'instructions' => __('Slider content background color.','bestia'),
				'name' => 'slider_background_color',
				'type' => 'color_picker',
				'default-value' => '#ffffff',
				'prefix' => '',
				'required' => 0,
				'conditional_logic' => 0,
		),
		array (
			'key' => 'slider_font_color',
			'label' => 'Font Color',
			'instructions' => __('Font color of your content.','bestia'),
			'name' => 'slider_font_color',
			'type' => 'color_picker',
			'default-value' => '#ffffff',
			'prefix' => '',
			'required' => 0,
			'conditional_logic' => 0,
	),
			array (
				'key' => 'slider_list_color',
				'label' => 'List Icons Color',
				'instructions' => __('The color key for li::before elements, uses font awesome.','bestia'),
				'name' => 'slider_list_color',
				'type' => 'color_picker',
				'default-value' => '#ff0066',
				'prefix' => '',
				'required' => 0,
				'conditional_logic' => 0,
		),

		*/
),
				'location' => array (
			array (
					array (
							'param' => 'post_type',
							'operator' => '==',
							'value' => 'slider',
							'order_no' => 3,
							'group_no' => 3,
				),
			),
			),
				'options' => array (
					'position' => 'acf_after_title',
					'layout' => 'default',
					'hide_on_screen' => array (
					),
				),
				'menu_order' => 5,
			);

			if(function_exists("register_field_group")){
				register_field_group( apply_filters( 'awpt_video_meta_fields_args' , $video_fields ) );
				register_field_group( apply_filters( 'awpt_page_meta_fields_args' , $page_fields ) );
				register_field_group( apply_filters( 'awpt_slider_meta_fields_args' , $slider_fields ) );
				register_field_group( apply_filters( 'awpt_gallery_meta_fields_args' , $gallery_fields ) );
				register_field_group( apply_filters( 'awpt_gif_meta_fields_args' , $gif_fields ) );
				register_field_group( apply_filters( 'awpt_performer_meta_fields_args' , $performer_fields ) );
			}
		}
	}
	new MyTubePress_MetaBoxes();
}
