<?php
$theme = wp_get_theme();
$whitelist = array(
    '127.0.0.1',
    '::1'
);
if ( $theme->parent_theme ) {
    $template_dir =  basename( get_template_directory() );
    $theme = wp_get_theme( $template_dir );
}
?>

<div class="wrap about-wrap bestia-wrap">
    <h1><?php _e( 'Welcome to Bestia Dashboard!', 'bestia' ); ?></h1>

    <div class="about-text"><?php echo esc_html__( 'Bestia theme is now installed and ready to use! Read below for additional information. We hope you\'ll enjoy it!', 'bestia' ); ?></div>

    <h2 class="nav-tab-wrapper">
        <?php
        printf( '<a href="#" class="nav-tab nav-tab-active">%s</a>', __( 'Welcome', 'bestia' ) );
        printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=bestia-demo' ), __( 'Plugins', 'bestia' ) );
        printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'nav-menus.php' ), __( 'Menus', 'bestia' ) );
        printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'widgets.php' ), __( 'Widgets', 'bestia' ) );
        printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=snapshot-report' ), __( 'System Info', 'bestia' ) );
        printf( '<a href="%s" class="nav-tab right">%s</a>', admin_url( 'admin.php?page=bestia-settings' ), __( 'Settings Panel', 'bestia' ) );
        if(!in_array($_SERVER['REMOTE_ADDR'], $whitelist)){
        printf( '<a href="%s" class="nav-tab right-tab dashicons dashicons-admin-network" style="float:right;padding:7px 10px;">%s</a>', admin_url( 'admin.php?page=bestia-license' ), __( '', 'bestia' ) );
        }
        ?>
    </h2>

    <div class="bestia-section">
        <p class="about-description">
            <?php printf( __( 'Before you get started, please be sure to always check out <a href="%s" target="_blank">this documentation</a>. We outline all kinds of good information, and provide you with all the details you need to use Bestia.', 'bestia'), 'https://mytubepress.com/documentation'); ?>
        </p>
        <p class="about-description">
            <?php printf( __( 'If you are unable to find your answer in our documentation, please contact us via <a href="%s">email</a> directly with your purchase code, site CPanel (or FTP) and admin login info. <br><br>We are very happy to help you and you will get reply from us more faster than you expected.', 'bestia'), 'mailto:support@mytubepress.com'); ?>
        </p>
        <p class="about-description">
            <a target="_blank" href="https://mytubepress.com/store/bestia/?view=changelog" title="<?php _e('Change Logs', 'bestia') ?>"><?php _e('Click here to view change logs.', 'bestia') ?></a>
        </p>


        <p class="about-description">
            Regarding <b>customization services</b> based on Bestia theme or other WordPress projects, please contact us via <a target="_blank" href="https://mytubepress.com/hire-our-experts/" title="Customization Services">customization form</a> directly. We have an amazing team to provide customization service who have rich experience and work on reasonable quote.
        </p>
    </div>

    <div class="bestia-thanks">
        <p class="description">Thank you for using <strong>Bestia</strong> theme! Powered by <a href="https://mytubepress.com" target="_blank">MYTUBEPRESS</a></p>
    </div>
</div>
