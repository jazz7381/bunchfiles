<?php
global $awpt;
$performer_list = $awpt['performer_list_type'];
$args = array(
    'orderby' => 'count',
    'order' => 'desc',
    'number' => 9,
    'exclude'       => array(),
    'hide_empty' => 0,
    'exclude_tree'  => array(),
    'fields'        => 'all',
    'hierarchical'  => true,
    'child_of'      => 0,
    'pad_counts'    => false,
    'cache_domain'  => 'core' );
$taxonomy = 'performer';
$tax_terms = get_terms( $taxonomy, $args );
$performers_page = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-performers.php') ) ;
$performerSET = isset($performers_page[0]->ID) ? $performers_page[0]->ID : '#';
$performers_page_url = get_permalink( $performerSET );
if ($performer_list == "custom_image") { ?>
<div id="performers-block" class="flyout-menu-content" style="height:502px">
<ul class="list-wrap-custom">
<?php foreach ($tax_terms as $cat) : ?>
<?php $gender = get_term_meta($cat->term_id,'awpt_gender',true); if ($gender == "male") { $img_type = 'male'; } else { $img_type = 'female'; }
$performer_image = z_taxonomy_image_url($cat->term_id);
if( ! empty($performer_image)) :
  $img = aq_resize( $performer_image, 160, 200, true );
else :
  $img = get_template_directory_uri() . '/assets/css/images/'.$img_type.'.jpg';
endif;
?>
<li><a title="<?php echo $cat->name; ?>" href="<?php echo get_term_link($cat->slug, 'performer'); ?>"><span style="background-image:url(<?php echo $img; ?>);" class="thumb"></span> <?php echo $cat->name; ?></a></li>
<?php endforeach; ?>
<li><a class="view_all_performers" href="<?php echo $performers_page_url; ?>"><span style="background:url(<?php bloginfo('template_directory'); ?>/images/all.gif) no-repeat center;background-size: 150px;" class="thumb"></span> ALL</a></li>
</ul>
</div>
<?php } elseif ($performer_list == "last_post_image") { ?>
<div id="performers-block" class="flyout-menu-content">
<ul class="list-wrap">
<?php foreach ($tax_terms as $cat) : ?>
<?php $args = array (
'showposts' => 1,
'orderby' => 'date',
'order' => 'DESC',
'tax_query' => array(
 array(
'taxonomy' => 'performer',
'field'    => 'term_id',
'terms'    => $cat->term_id,
),
),
);
$new_query = new WP_Query( $args );
if ( $new_query->have_posts() ) {
while ( $new_query->have_posts() ) {
$new_query->the_post();
$post_id = get_the_ID();
if ( function_exists( 'tubeace_register_custom_menu_page' ) ) {
$image = tubeace_thumb('latest',$post->post_title);
} else {
$thumb_id = get_post_thumbnail_id();
$image = wp_get_attachment_image_src($thumb_id,'thumbnail-size', true);
}
}
} else {} wp_reset_postdata();
echo '<li><a title="'.$cat->name.'" href="'.get_term_link($cat->slug, 'performer').'"><span style="background-image:url('.$image[0].');" class="thumb"></span>'.$cat->name.'</a></li>'; ?>
<?php endforeach; ?>
<li><a class="view_all_tax" href="<?php echo $performers_page_url; ?>"><span style="background:url(<?php bloginfo('template_directory'); ?>/images/all.gif) no-repeat center;background-size: 150px;" class="thumb"></span> ALL</a></li>
</ul>
</div>
<?php } elseif ($performer_list == "random_post_image") { ?>
<div id="performers-block" class="flyout-menu-content">
<ul class="list-wrap">
<?php foreach ($tax_terms as $cat) : ?>
<?php $args = array (
'showposts' => 1,
'orderby' => 'rand',
'order' => 'DESC',
'tax_query' => array(
 array(
'taxonomy' => 'performer',
'field'    => 'term_id',
'terms'    => $cat->term_id,
),
),
);
$new_query = new WP_Query( $args );
if ( $new_query->have_posts() ) {
while ( $new_query->have_posts() ) {
$new_query->the_post();
$post_id = get_the_ID();
if ( function_exists( 'tubeace_register_custom_menu_page' ) ) {
$image = tubeace_thumb('latest',$post->post_title);
} else {
$thumb_id = get_post_thumbnail_id();
$image = wp_get_attachment_image_src($thumb_id,'thumbnail-size', true);
}
}
} else {} wp_reset_postdata();
echo '<li><a title="<?php echo $cat->name; ?>" href="'.get_term_link($cat->slug, 'performer').'"><span style="background-image:url('.$image[0].');" class="thumb"></span>'.$cat->name.'</a></li>'; ?>
<?php endforeach; ?>
<li><a class="view_all" href="<?php echo $performers_page_url; ?>"><span style="background:url(<?php bloginfo('template_directory'); ?>/images/all.gif) no-repeat center;background-size: 150px;" class="thumb"></span> ALL</a></li>
</ul>
</div>
<?php } ?>
