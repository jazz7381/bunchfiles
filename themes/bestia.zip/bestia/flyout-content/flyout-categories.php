<?php
global $awpt;
$args = array(
   'orderby' => 'count',
   'order' => 'desc',
    'number' => 9,
    'exclude'       => array(),
    'hide_empty' => 1,
    'exclude_tree'  => array(),
    'fields'        => 'all',
    'hierarchical'  => true,
    'child_of'      => 0,
    'pad_counts'    => false,
    'cache_domain'  => 'core' );
$taxonomy = 'category';
$tax_terms = get_terms( $taxonomy, $args );
$categories_page = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-categories.php') ) ;
$ctageorySET = isset($categories_page[0]->ID) ? $categories_page[0]->ID : '#';
$categories_page_url = get_permalink( $ctageorySET );
?>
<div id="categories-block" class="flyout-menu-content">
<ul class="list-wrap">
<?php foreach ($tax_terms as $cat) : ?>
<?php $args = array (
'showposts' => 1,
'orderby' => 'rand',
'order' => 'rand',
'tax_query' => array(
 array(
'taxonomy' => 'category',
'field'    => 'term_id',
'terms'    => $cat->term_id,
),
),
);
$fly_query = new WP_Query( $args );
if ( $fly_query->have_posts() ) {
while ( $fly_query->have_posts() ) {
$fly_query->the_post();
$post_id = get_the_ID();
$multiple_images = get_post_meta( $post_id, 'image_rotator', true );
$custom_category_image = z_taxonomy_image_url($cat->term_id,NULL);
if( $multiple_images ) :
$size = 'thumb-video';
foreach( $multiple_images as $image ):
$rotator_image = wp_get_attachment_image_url($image, $size);
break;
endforeach;
endif;
$thumb_id = get_post_thumbnail_id();
$post_image = wp_get_attachment_image_src($thumb_id,'thumb-video', true);
}
} else {
} wp_reset_postdata();
if( $multiple_images ) { $img = $rotator_image; } else { $img = $post_image[0]; }
if( ! empty($custom_category_image)) :
  $imageZ = aq_resize( $custom_category_image, 220, 150, true );
else :
  $imageZ = $img;
endif;
$kategori_image = $imageZ;
echo '<li><a title="'.$cat->name.'"  href="'.get_term_link($cat->slug, 'category').'"><span style="background-image:url('.$kategori_image.');" class="thumb"></span>'.$cat->name.'</a></li>'; ?>
<?php endforeach; ?>
<li><a class="view_all_tax" href="<?php echo $categories_page_url; ?>"><span style="background:url(<?php bloginfo('template_directory'); ?>/images/all.gif) no-repeat center;background-size: 150px;" class="thumb"></span> ALL</a></li>
</ul>
</div>
