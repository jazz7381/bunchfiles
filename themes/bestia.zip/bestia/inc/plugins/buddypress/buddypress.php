<?php
if ( ! defined( 'ABSPATH' ) ) exit;
function mytubepress_bp_friends_count() {
	global $bp, $current_user;
	$current_user_id = get_current_user_id();
	if ( is_user_logged_in() ) :
		if ( bp_is_active( 'friends' ) ) :
			echo bp_get_total_friend_count( $current_user_id );
		endif;
	endif;
}
function notifications_count() {
		global $bp, $current_user;
		$current_user_id = get_current_user_id();
		if ( bp_is_active( 'notifications' ) ) {
						if ( function_exists( 'bp_notifications_get_unread_notification_count' ) ) {
							$count = bp_notifications_get_unread_notification_count( $current_user_id );
							if ( $count > 0 ) {
                echo $count;
							}
						}
			}
}
function messages_count() {
		global $bp, $current_user;
		$current_user_id = get_current_user_id();
			if ( bp_is_active( 'messages' )  ) {
						if ( function_exists( 'messages_get_unread_count' ) ) {
							$count = messages_get_unread_count( $current_user_id );
							if ( $count > 0 ) {
								echo $count;
							} else {
								echo __('0', 'bestia');
							}
						}
          }
}
function mytubepress_bp_notifications_count() {
		global $bp, $current_user;
		$current_user_id = get_current_user_id();
		if ( bp_is_active( 'notifications' ) ) {
						if ( function_exists( 'bp_notifications_get_unread_notification_count' ) ) {
							$count = bp_notifications_get_unread_notification_count( $current_user_id );
							if ( $count > 0 ) {
                echo '<span class="count">' . $count . '</span>';
							}
						}
			}
}
function mytubepress_bp_messages_count() {
		global $bp, $current_user;
		$current_user_id = get_current_user_id();
			if ( bp_is_active( 'messages' )  ) {
						if ( function_exists( 'messages_get_unread_count' ) ) {
							$count = messages_get_unread_count( $current_user_id );
							if ( $count > 0 ) {
								echo '<span class="count">' . $count . '</span>';
							}
						}
          }
}
/* Remove BuddyPress loaded style */
add_action( 'wp_enqueue_scripts', 'mytubepress_bp_dequeue' );
function mytubepress_bp_dequeue() {
    wp_dequeue_style( 'bp-legacy-css' );
    wp_deregister_style( 'bp-legacy-css' );
}

add_action( 'body_class', 'mytubepress_bp_classes' );

function mytubepress_bp_classes( $classes ) {
    if ( ! bp_is_directory() && ( bp_is_group() || ( bp_is_user() && ! bp_is_single_activity()) ) ) {
        $classes[] = 'bp-is-single';
    }
    if (bp_is_current_component( 'buddydrive' )) {
        $classes[] = 'buddydrive';
    }

    return $classes;
}
/* Load our Less file */
add_filter('mytubepress_less_files', 'mytubepress_bp_add_less_file');
function mytubepress_bp_add_less_file( $less_files ) {
    if (! defined('LOCAL_DEVELOPMENT') ) {
        $less_files[TEMPLATEPATH . "/buddypress/css/dynamic/buddypress.less"] = '';
    }

    return $less_files;
}



add_action( 'wp_ajax_mytubepress_bp_ajax_call', 'mytubepress_bp_ajax_call' );

function mytubepress_bp_ajax_call() {

    $response = array();
    $response = apply_filters( 'mytubepress_bp_ajax_call', $response );

    if ( ! empty( $response ) ) {
        echo json_encode( $response );
    }
    exit;
}

/* Get User online */
if ( ! function_exists( 'mytubepress_is_user_online' ) ):
    /**
     * Check if a Buddypress member is online or not
     * @global object $wpdb
     * @param integer $user_id
     * @param integer $time
     * @return boolean
     */
    function mytubepress_is_user_online( $user_id, $time = 5 )
    {
        global $wpdb;
        $sql = $wpdb->prepare( "SELECT u.user_login FROM $wpdb->users u JOIN $wpdb->usermeta um ON um.user_id = u.ID
            WHERE u.ID = %d
            AND um.meta_key = 'last_activity'
            AND DATE_ADD( um.meta_value, INTERVAL %d MINUTE ) >= UTC_TIMESTAMP()", $user_id, $time);
        $user_login = $wpdb->get_var( $sql );
        if( isset( $user_login ) && $user_login != "" ) {
            return true;
        }
        else { return false; }
    }
endif;


if ( ! function_exists( 'mytubepress_get_online_status' ) ):
    function mytubepress_get_online_status( $user_id ) {
        $output = '';
        if ( mytubepress_is_user_online( $user_id ) ) {
            $output .= '<span class="bestia-online-status user-online"></span>';
        } else {
            $output .= '<span class="bestia-online-status"></span>';
        }
        return $output;
    }
endif;


/**
 * Render the html to show if a user is online or not
 */
if( ! function_exists( 'mytubepress_online_status' ) ) {
    function mytubepress_online_status( $user_id ) {
        echo mytubepress_get_online_status( $user_id );
    }
}
add_action( 'bp_member_online_status', 'mytubepress_online_status' );

/*
global $awpt;
if( $awpt['online-status'] == 1 ) {
add_action( 'bp_member_online_status', 'mytubepress_online_status' );
}
*/

if (defined('BP_LIKE_VERSION')) {

    remove_action('get_header', 'bp_like_insert_head');

    function mytubepress_bp_like_insert_head()
    {
        ?>
        <script type="text/javascript">
            /* <![CDATA[ */
            var bp_like_terms_like = '<?php echo bp_like_get_text('like'); ?>';
            var bp_like_terms_like_message = '<?php echo bp_like_get_text('like_this_item'); ?>';
            var bp_like_terms_unlike_message = '<?php echo bp_like_get_text('unlike_this_item'); ?>';
            var bp_like_terms_view_likes = '<?php echo bp_like_get_text('view_likes'); ?>';
            var bp_like_terms_hide_likes = '<?php echo bp_like_get_text('hide_likes'); ?>';
            var bp_like_terms_unlike_1 = '<?php echo bp_like_get_text('unlike'); ?> (1)';
            /* ]]> */


            <?php if ( bp_like_get_settings('remove_fav_button') == 1 ) { ?>
            jQuery(document).ready(function ($) {

                jQuery(".fav").remove();
                jQuery(".unfav").remove();
            });
            <?php } ?>
        </script>
        <?php
    }

    add_action('wp_head', 'mytubepress_bp_like_insert_head');
}
/* BuddyPress 2.4 compat */

if ( ! function_exists( 'bp_groups_front_template_part' ) ) {
    /**
     * Output the contents of the current group's home page.
     *
     * You should only use this when on a single group page.
     *
     * @since 2.4.0
     */
    function bp_groups_front_template_part()
    {
        $located = bp_groups_get_front_template();

        if (false !== $located) {
            $slug = str_replace('.php', '', $located);

            /**
             * Let plugins adding an action to bp_get_template_part get it from here
             *
             * @param string $slug Template part slug requested.
             * @param string $name Template part name requested.
             */
            do_action('get_template_part_' . $slug, $slug, false);

            load_template($located, true);

        } else if (bp_is_active('activity')) {
            bp_get_template_part('groups/single/activity');

        } else if (bp_is_active('members')) {
            bp_groups_members_template_part();
        }

        return $located;
    }
}
function mytubepress_bp_get_group_page_title() {

    $bp = buddypress();

    $current_item = bp_current_item();
    $single_item_component = bp_current_component();
    $action = bp_current_action();
    $output = '';

    if ($current_item === false || ! isset( $bp->{$single_item_component}->nav ) ) {
        return '';
    }

    if (version_compare(BP_VERSION, '2.6', '>=')) {
        $nav_items = $bp->groups->nav->get_secondary( array( 'parent_slug' => $current_item ) );
        foreach ($nav_items as $nav ) {
            if ( isset( $nav['slug'] ) && $nav['slug'] == $action ) {
                $output = preg_replace( '@<(\w+)\b.*?>.*?</\1>@si', '', $nav['name'] );
                break;
            }
        }
    } else {
        $bp_nav = $bp->bp_options_nav;
        if ( isset($bp_nav[$current_item]) && ! empty( $bp_nav[$current_item] ) ) {
            foreach ( $bp_nav[$current_item] as $nav ) {
                if ( isset( $nav['slug'] ) && $nav['slug'] == $action ) {
                    $output = preg_replace( '@<(\w+)\b.*?>.*?</\1>@si', '', $nav['name'] );
                    break;
                }
            }
        }
    }


    return $output;
}

function abcd_gettext( $translated, $original_text, $domain ) {

    if ( 'buddypress' !== $domain )
           return $translated;

    switch ( $original_text ) {
        case 'My Favorites %s':
            return 'All Buddies %s';

		case 'My Friends %s':
            return 'Liked Activity %s';

        default:
            return $translated;
    }
}
add_filter( 'gettext', 'abcd_gettext', 10, 3 );

add_filter('bp_blogs_activity_new_post_action', 'record_cpt_activity_action', 1, 3);
function record_cpt_activity_action( $activity_action,  $post, $post_permalink ) {

   if( $post->post_type == 'agency' ) {
	$activity_action  = sprintf( __( '%1$s posted a new video, %2$s', 'buddypress' ), bp_core_get_userlink( (int) $post->post_author ), '<a href="' . $post_permalink . '">' . $post->post_title . '</a>' );
   }

   return $activity_action;
}

/***************************************************
:: BuddyPress Cover Photo
 ***************************************************/
//require_once( TEMPLATEPATH . '/inc/plugins/buddypress/cover-photo.php' );
