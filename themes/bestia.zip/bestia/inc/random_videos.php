<?php if( !defined('ABSPATH') ) exit; global $awpt; ?>
<div class="being_watched">
<div class="heading pull-left">
<?php
$I_feel_Lucky = array(); $args = array( 'numberposts' => 1, 'offset'=> 1, 'orderby' => 'rand' );
$randomly = get_posts( $args );
$h_tag = $awpt['live_videos_heading']; $title = $awpt['beingwatched_title'];
echo '<'.$h_tag.'>'.$title.'</'.$h_tag.'>';
?>
</div>
<?php foreach( $randomly as $post ) :	setup_postdata($post); ?>
<div class="viewall visible-desktop">
  <a href="<?php the_permalink(); ?>" class="btn btn-default"><?php echo $awpt['feel_lucky']; ?></a>
</div>
<div class="clearfix"></div>
<?php endforeach; ?>
<ul class="Thumbnail_List">
<?php
$per_page = $awpt['watched_now_videos'];
query_posts('showposts='.$per_page.'&orderby=rand');
if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php do_action( 'bestia_thumbnail_compatibility' ); ?>
<?php endwhile; else: endif; ?>
<?php wp_reset_query(); ?>
</ul>
</div>
<div class="viewall visible-mobile">
  <a href="<?php the_permalink(); ?>" class="btn btn-default"><?php echo $awpt['feel_lucky']; ?></a>
</div>
