<?php
if( !defined('ABSPATH') ) exit;
?>
<div class="row">
            <div class="col-xs-12 col-sm-3 col-md-3">
                <a href="<?php the_permalink(); ?>">
                    <?php if ( has_post_thumbnail() ) {
                      $thumb_id = get_post_thumbnail_id();
                      $thumbnail_src = wp_get_attachment_image_src($thumb_id,'full', true);
                    ?>
                    <img src="<?php echo $thumbnail_src[0]; ?>" alt="<?php the_title(); ?>" class="img-responsive img-box img-thumbnail" />
                    <?php } else { ?>
                    <img src="<?php bloginfo('template_directory'); ?>/images/noimage-blog.jpg" class="img-responsive img-box img-thumbnail" alt="<?php bloginfo('name'); ?>">
                    <?php } ?>
                </a>
            </div>
            <div class="col-xs-12 col-sm-9 col-md-9">
              <?php if ( class_exists( 'BuddyPress' ) ) { ?>
                <div class="list-group">
                    <div class="list-group-item">
                        <div class="row-picture">
                            <a href="<?php echo bp_loggedin_user_domain(); ?>" title="<?php the_author(); ?>">
                                <?php echo get_avatar( get_the_author_meta('email'), '64' ); ?>
                            </a>
                        </div>
                        <div class="row-content">
                            <div class="list-group-item-heading">
                                <a href="<?php echo bp_loggedin_user_domain(); ?>" title="<?php the_author(); ?>">
                                    <small><?php the_author_meta('display_name', $post->post_author ); ?></small>
                                </a>
                            </div>
                            <small>
                                <i class="glyphicon glyphicon-time"></i> <?php the_time('F j, Y'); ?>
                                <br>

                            </small>
                        </div>
                    </div>
                </div>
              <?php } ?>
                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <p><?php echo mb_substr(get_the_excerpt(), 0,400); ?></p>
            </div>
        </div>
      <hr>
