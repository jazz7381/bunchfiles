<?php //if ( function_exists( 'pmpro_activation' ) ) { ?>
<!--<span class="premium_menu">
  <?php //if ( pmpro_has_membership_access() ) { ?>
  <a href="<?php //echo pmpro_url("account"); ?>"><i class="fa fa-user-o" aria-hidden="true"></i></a>
  <?php //} else { ?>
     <a href="<?php //echo pmpro_url("levels"); ?>">Premium</a>
  <?php //} ?>
</span>-->
<?php //} ?> 
