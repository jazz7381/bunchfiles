<div class="slidemenu slidemenu-left">
<div class="wrap_holder">
<?php
if( has_nav_menu('primary') ){
wp_nav_menu( array( 'theme_location' => 'primary' ) );
}
?>
</div>
</div>
