<?php if ( class_exists( 'BuddyPress' ) && is_user_logged_in() ) { ?>
<?php global $bp; $current_user = wp_get_current_user(); ?>
<div class="notifications">
    <ul>
      <!-- notification: inbox -->
      <li class="notification-item inbox">
        <div class="btn-group">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            <i class="fa fa-envelope first-fas"></i>
            <?php echo mytubepress_bp_messages_count(); ?>
            <span class="circle"></span>
          </a>
          <ul class="dropdown-menu" role="menu">
<?php if ( bp_is_active( 'messages' ) && bp_has_message_threads( 'per_page=10' ) ) : ?>
  <li class="notification-header">
    <em><?php _e('There are', 'bestia'); ?> <?php echo messages_count(); ?> <?php _e('unread messages', 'bestia'); ?>.</em>
  </li>
<?php while ( bp_message_threads() ) : bp_message_thread(); ?>
<?php if ( 'sentbox' != bp_current_action() ) : ?>
  <li class="inbox-item clearfix">
    <a href="<?php bp_message_thread_view_link() ?>">
      <div class="media">
        <div class="media-left">
          <?php bp_message_thread_avatar( array( 'width' => 34, 'height' => 34 ) ); ?>
        </div>
        <div class="media-body">
          <h5 class="media-heading name"><?php bp_message_thread_subject(); ?></h5>
          <p class="text"><?php bp_message_thread_excerpt() ?></p>
          <span class="timestamp2"><?php bp_message_thread_last_post_date(); ?></span>
        </div>
      </div>
    </a>
  </li>
<?php else : ?>
  <li class="notification-header">
    <em><?php _e('There are no messages to display.', 'bestia'); ?></em>
  </li>
<?php endif; ?>
<?php
endwhile;
endif;
?>
            <li class="notification-footer">
              <a href="<?php echo bp_loggedin_user_domain() . $bp->messages->slug; ?>"><?php _e('View All Messages', 'bestia'); ?></a>
            </li>
          </ul>
        </div>
      </li>


      <!-- end notification: inbox -->
      <!-- notification: general -->
      <li class="notification-item general second-note">
        <div class="btn-group">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            <i class="fa fa-bell first-fas"></i>
            <?php echo mytubepress_bp_notifications_count(); ?>
            <span class="circle"></span>
          </a>
          <ul class="dropdown-menu" role="menu">
            <?php if ( bp_has_notifications() ) : ?>
              <li class="notification-header">
                <em>You have <?php echo notifications_count(); ?> notifications</em>
              </li>
            <?php while ( bp_the_notifications() ) : bp_the_notification(); ?>
            <li>
              <a href="#">
                <span class="text"><?php bp_the_notification_description(); ?></span>
                <span class="timestamp1"><?php bp_the_notification_time_since(); ?></span>
              </a>
            </li>
          <?php endwhile; ?>
          <?php else : ?>
            <li class="notification-header">
              <em><?php _e('No new notification!','tubemobile'); ?></em>
            </li>
          <?php endif; ?>
          <li class="notification-footer">
            <a href="<?php echo bp_loggedin_user_domain() . $bp->notifications->slug; ?>"><?php _e('View All Notifications', 'bestia'); ?></a>
          </li>
          </ul>
        </div>
      </li>
      <!-- end notification: general -->
    </ul>
  </div>
  <!-- logged user and the menu -->
  <div class="logged-user">
    <div class="btn-group">
      <a href="<?php echo bp_loggedin_user_domain(); ?>" class="btn btn-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
        <?php bp_loggedin_user_avatar( 'width=' . bp_core_avatar_thumb_width() . '&height=' . bp_core_avatar_thumb_height() ); ?>
        <span class="name"><?php echo $current_user->user_login; ?></span>

      </a>
      <ul class="dropdown-menu" role="menu">
        <li>
          <a href="<?php echo bp_loggedin_user_domain(); ?>">
            <i class="fa fa-user"></i>
            <span class="text"><?php _e( 'Profile', 'bestia' ); ?></span>
          </a>
        </li>




        <?php if ( bp_is_active( 'friends' ) ) : ?>
          <li>
            <a href="<?php echo bp_loggedin_user_domain() . $bp->friends->slug; ?>">
              <i class="fa fa-users"></i>
              <span class="text"><?php _e( 'Friends', 'bestia' ); ?></span>
            </a>
          </li>
        <?php endif;?>


        <?php if ( bp_is_active( 'notifications' ) ) : ?>
          <li>
            <a href="<?php echo bp_loggedin_user_domain() . $bp->notifications->slug; ?>">
              <i class="fa fa-bell"></i>
              <span class="text"><?php _e( 'Notifications', 'bestia' ); ?></span>
            </a>
          </li>
        <?php endif;?>


        <?php if ( bp_is_active( 'messages' ) ) : ?>
          <li>
            <a href="<?php echo bp_loggedin_user_domain() . $bp->messages->slug; ?>">
              <i class="fa fa-envelope"></i>
              <span class="text"><?php _e( 'Messages', 'bestia' ); ?></span>
            </a>
          </li>
        <?php endif;?>

        <?php if ( bp_is_active( 'groups' ) ) : ?>
          <li>
            <a href="<?php echo bp_loggedin_user_domain() . $bp->groups->slug; ?>">
              <i class="fa fa-globe"></i>
              <span class="text"><?php _e( 'Groups', 'bestia' ); ?></span>
            </a>
          </li>
        <?php endif;?>

        <li>
          <a href="<?php echo bp_loggedin_user_domain() . $bp->settings->slug; ?>">
            <i class="fa fa-cog"></i>
            <span class="text"><?php _e( 'Settings', 'bestia' ); ?></span>
          </a>
        </li>
        <li>
          <a href="<?php echo wp_logout_url( $_SERVER['REQUEST_URI'] ); ?>">
            <i class="fa fa-power-off"></i>
            <span class="text"><?php _e( 'Logout', 'bestia' ); ?></span>
          </a>
        </li>
      </ul>
    </div>
  </div>
  <!-- end logged user and the menu -->
<?php } elseif ( class_exists( 'BuddyPress' ) && !is_user_logged_in() ) { ?>
 <?php echo bestia_ajax_login_form(); ?>
<?php } ?>
