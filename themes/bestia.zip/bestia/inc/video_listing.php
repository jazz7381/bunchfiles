<?php global $awpt;
$home_videos = $awpt['homepage_videos'];$posts_ids = wp_list_pluck( $wp_query->posts, 'ID' );
if($awpt['home_videos_by'] == 1 ){ $videosby = 'rand'; } else { $videosby = 'date'; }
$likes_key = 'likes_count';
$orderby = $videosby;
$order = isset( $_REQUEST['order'] ) ? trim( $_REQUEST['order'] ) : null;
if(isset($_GET['order']) && !empty($_GET['order'])) {
	switch($order)
	{
		case 'rate' :	$meta_key = $likes_key;
		               $orderby = 'meta_value_num';
			break;
		case 'views' :	$meta_key = 'post_views_count';
		               $orderby = 'meta_value_num';
			break;
		case 'newest' :	$orderby = 'date';
			break;
		case 'discussed' :	$orderby = 'comment_count';
		function comment_count_orderby( $orderby ) {
	    return "comment_count DESC";
	   }
		   add_filter('posts_orderby', 'comment_count_orderby');
			break;
		default :	 $orderby = $videosby;
			break;
	}
}
if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } else if ( get_query_var('page') ) { $paged = get_query_var('page'); } else { $paged = 1; }
$args = array(
'posts_per_page' => $home_videos,
'meta_key' => $meta_key,
'orderby' => $orderby,
'paged' => $paged
);
// The Query
$the_query = new WP_Query( $args );
$temp_query = $wp_query;
$wp_query   = NULL;
$wp_query   = $the_query;
echo '<div class="heading pull-left">';
do_action( 'bestia_get_ordered_title' );
echo '</div>';
echo '<div class="clearfix"></div>';
if ( $the_query->have_posts() ) : $count = 1; ?>
<ul class="Thumbnail_List">
<?php do_action( 'bestia_homepage_ads' );
while ( $the_query->have_posts() ) : $the_query->the_post();
do_action( 'bestia_thumbnail_compatibility' ); if ($count == 6) : ?>
<?php do_action( 'bestia_after_post_ad' ); ?>
<?php endif; $count++; ?>
<?php endwhile; else : ?>
<div class="clearfix"></div>
<p class="none"><?php _e('No Videos Found', 'bestia'); ?></p>
<?php endif; ?>
</ul>
<?php
  echo '<div class="clearfix"></div>';
  adultwpthemes_pagination();
?>
