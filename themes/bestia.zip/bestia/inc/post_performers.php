<?php
global $post;
if( false != get_the_term_list( $post->ID, 'performer' ) ) : ?>
<ul class="post_performers">
<?php foreach (get_the_terms(get_the_ID(), 'performer' ) as $cat) : ?>
<?php
$gender = get_term_meta($cat->term_id,'awpt_gender',true);
if ($gender == "male") {
  $img_type = 'male';
} elseif ($gender == "transgender") {
    $img_type = 'trans';
} else {
  $img_type = 'female';
}

$performer_image = z_taxonomy_image_url($cat->term_id,NULL);
if( ! empty($performer_image)) :
  $image = aq_resize( $performer_image, 100, 140, true );
else :
  $image = get_template_directory_uri() . '/assets/css/images/'.$img_type.'.jpg';
endif;
?>
<li>
<a href="<?php echo get_term_link($cat->term_id, 'performer'); ?>" data-toggle="tooltip" title="<?php echo $cat->name; ?>">
<img  src="<?php echo $image; ?>" />
</a>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>
