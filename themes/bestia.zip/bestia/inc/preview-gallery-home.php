<?php
if( !defined('ABSPATH') ) exit;
global $awpt;
$hd_key = 'hd_flag';
$thumb_layout = $awpt['preview-style'];
$gallery_is_hd = get_post_meta($post->ID, $hd_key, TRUE);
$home_page = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'videos-I-like.php') ) ;
$homeSET = isset($likes_page[0]->ID) ? $likes_page[0]->ID : '#';
if ($thumb_layout == "3" || $thumb_layout == "4") {
  $hide_info = 'hidden';
} else {
  $hide_info = '';
}
//$attachments = get_children( array( 'post_parent' => $post->ID ) );
//$count = count( $attachments );
if ( have_posts() ) : ?>
<ul class="Thumbnail_List">
<?php while ( have_posts() ) : the_post(); ?>
  <li id="post-<?php the_ID(); ?>" class="thumbphoto">
  <a href="<?php the_permalink() ?>" id="preview_image" title="<?php the_title_attribute(); ?>">
  <?php
  if (function_exists('wpscript_mode') ) {
    echo '<div id="rotator" data-thumbs="'.wpscript_get_multithumbs($post->ID).'"><img alt="' . get_the_title() . '" src="'.get_the_post_thumbnail_url($post->ID, 'thumb-video').'"></div>';
  } else {
    echo do_action('bestia_preview_image');
  }
  ?>
  </a>
  <div class="clearfix"></div>
  <div class="thumb_bar">
  <a href="<?php the_permalink(); ?>" class="title" title="<?php the_title_attribute(); ?>">
  <?php do_action( 'bestia_heading_title_thumbnail' ); ?>
  </a>
  <?php if ($thumb_layout == "1" || $thumb_layout == "3" ) { ?>
  <strong class="toolbar">
  <span class="rate_thumb">
    <i class="fa fa-thumbs-up"></i>
    <?php if (function_exists('adultwpthemes_getItemPostLikeRate')) {
      echo do_action('bestia_post_rating_mode');
    } ?>
  </span>
  <span class="time_thumb">
    <?php
    if ( $awpt['photo_hd_all'] == 1 ) {
    echo '<em><i class="quality">HD</i></em>';
    } elseif($video_is_hd != '') {
    echo '<em><i class="quality">HD</i></em>';
    }
    do_action('bestia_video_duration');
    ?>
  </span>
  </strong>
  <span class="post-views half-black">
  <?php do_action( 'bestia_post_views_mode' ); ?>
  <span class="bestia_view_text"> <?php _e('Views', 'bestia'); ?></span>
  </span>
  <?php } else {
    if ( $awpt['photo_hd_all'] == 1 ) {
    echo '<span class="hd-flag"></span>';
    } elseif($video_is_hd != '') {
    echo '<span class="hd-flag"></span>';
    }
  } ?>
  <span class="post-category half <?php echo $hide_info; ?>">
  <?php
if ($thumb_layout == "1") {
$category = get_the_category();
if ( $category[0] ) {
echo '<a href="' . get_category_link( $category[0]->term_id ) . '">' . $category[0]->cat_name . '</a>';
}
} else {
echo do_action( 'bestia_post_views_mode' ) . ' ' . __('Views', 'bestia');
}
?>
</span>
<span class="added <?php echo $hide_info; ?>">
<?php echo time_ago(); ?> <?php _e('ago', 'bestia'); ?>
</span>
</div>
</li>
<?php endwhile; ?>
</ul>
<?php else : ?>
<div class="clearfix"></div>
<p class="none"><?php _e('No Photo Galleries Found', 'bestia'); ?></p>
<?php endif; ?>
<div class="clearfix"></div>

<?php wp_reset_query(); ?>
