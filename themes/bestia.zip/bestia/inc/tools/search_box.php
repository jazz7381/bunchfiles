<?php
global $awpt;
$count_posts = wp_count_posts();
$count_galleries = wp_count_posts('gallery');
$count_gifs = wp_count_posts('gif');
$count_blogs = wp_count_posts('blogs');
$totalvids = $awpt['s_opt_video_search'];
$videos_count = str_replace("%total_videos%", $count_posts->publish, $totalvids);
$totalpics = $awpt['s_opt_photo_search'];
$photos_count = str_replace("%total_photos%", $count_galleries->publish, $totalpics);
$totalgifs = $awpt['s_opt_gif_search'];
$gifs_count = str_replace("%total_gifs%", $count_gifs->publish, $totalgifs);
$totalblogs = $awpt['s_opt_blog_search'];
$blogs_count = str_replace("%total_blogs%", $count_blogs->publish, $totalblogs);
?>
<div class="container">
<div class="row">
        <div class="col-md-12 mobile_search">
        <form action="<?php echo home_url( '/' ); ?>" method="get" name="search_type">
		    <div class="input-group">

          <?php if( $awpt['gallery_cpt'] == 1 || $awpt['gifs_cpt'] == 1 || $awpt['blogs_cpt'] == 1 ) : ?>
            <input type="hidden" id="search_type" name="post_type" value="post" />
                   <div class="input-group-btn search-panel">
                       <button type="button" class="df btn btn-default dropdown-toggle init" data-toggle="dropdown">
                         <span id="search_concept"><?php echo $awpt['s_opt_video']; ?></span>
                         <span class="caret"></span>
                       </button>
                       <ul class="dropdown-menu search_type" role="menu">
                         <li class="placeholder-changer" data-value="post" data-placeholder="<?php echo $videos_count; ?>"><a href="#post"><?php echo $awpt['s_opt_video']; ?></a></li>
                         <?php if( $awpt['gallery_cpt'] == 1 ) { ?>
                           <li class="placeholder-changer" data-value="gallery" data-placeholder="<?php echo $photos_count; ?>"><a href="#gallery"><?php echo $awpt['s_opt_photo']; ?></a></li>
                         <?php } ?>
                         <?php if( $awpt['gifs_cpt'] == 1 ) { ?>
                           <li class="placeholder-changer" data-value="gif" data-placeholder="<?php echo $gifs_count; ?>"><a href="#gif"><?php echo $awpt['s_opt_gif']; ?></a></li>
                         <?php } ?>
                         <?php if( $awpt['blogs_cpt'] == 1 ) { ?>
                           <li class="placeholder-changer" data-value="blogs" data-placeholder="<?php echo $blogs_count; ?>"><a href="#blog"><?php echo $awpt['s_opt_blog']; ?></a></li>
                         <?php } ?>
                         <!--
                         <li role="separator" class="divider"></li>
                         <li class="placeholder-changer" data-value="performer" data-placeholder="Search <?php //echo $published_blogs; ?> models..."><a href="#model">Model</a></li>
                         <li class="placeholder-changer" data-value="page" data-placeholder="Search <?php //echo $published_blogs; ?> members..."><a href="#member">Member</a></li>
                         -->
                 </ul>
              </div>
              <?php endif; ?>
              <input type="text" id="s" name="s" value="" class="form-control" autocomplete="off" placeholder="<?php echo $videos_count; ?>" requierd />
              <span class="input-group-btn">
                <button type="button" class="closer btn btn-default">
                  <i class="fa fa-angle-up" aria-hidden="true"></i>
                </button>
                <button class="df btn btn-default" type="submit">
                  <span class="fa fa-search"></span>
                </button>
              </span>
           </div>
        </form>
    </div>
	</div>
</div>
