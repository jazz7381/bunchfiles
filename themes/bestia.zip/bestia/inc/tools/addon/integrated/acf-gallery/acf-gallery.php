<?php

add_action('acf/register_fields', 'acfgp_register_fields');

function acfgp_register_fields()
{
	include_once('gallery.php');
}
?>
