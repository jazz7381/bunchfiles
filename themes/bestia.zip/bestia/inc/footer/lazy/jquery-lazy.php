<script src="<?php bloginfo('template_directory'); ?>/assets/js/lazy/jquery.lazyload.min.js"></script>
<script type="text/javascript">
jQuery(".Thumbnail_List img.lazy,#performer-thumbs img.lazy, attachment-img img, img.lazy,.sidebar img.lazy").lazyload({
    effect: "fadeIn"
});
</script>
