<script src="<?php bloginfo('template_directory'); ?>/assets/js/lazy/unveil.lazyload.min.js"></script>
<style type="text/css">.lazy {background: none !important;}</style>
<script type="text/javascript">
jQuery(document).ready(function($) {
  $(".Thumbnail_List img,#attachment-img img,.sidebar img,#performer-thumbs img").unveil();
});
</script>
