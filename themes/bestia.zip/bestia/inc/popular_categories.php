<?php if( !defined('ABSPATH') ) exit; global $awpt; ?>
<ul class="popular_categories">
<?php
$cat_args = array(
  'orderby' => 'count',
  'order' => 'desc',
   'number' => $awpt['video_categories_limit'],
   'exclude'       => array(),
   'hide_empty' => 1,
   'exclude_tree'  => array(),
   'fields'        => 'all',
   'hierarchical'  => true,
   'child_of'      => 0,
   'pad_counts'    => false,
   'cache_domain'  => 'core' );

$categories =   get_categories($cat_args);
$h_tag = $awpt['live_videos_heading'];
foreach($categories as $category) {
    echo '<li>';
    echo '<div class="heading">';
    echo '<a href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all videos in %s" ), $category->name ) . '" ' . '>' . '<' . $h_tag . '>' . $category->name . '</'.$h_tag.'></a>';
    echo '</div><div class="clearfix"></div>';
    if( $awpt['cat_desc_vic'] == 1 ){
	  echo short_desc('...', '120',category_description( $category->term_id ));
    }
     $post_args = array(
      'showposts' => 3,
      'orderby' => 'rand',
      'category' => $category->term_id
    );
    $posts = get_posts($post_args);
	echo '<div class="row"><div class="col-md-12"><ul class="video_list">';
	foreach($posts as $post) {
	?>
		<li>
        <a class="thumb" href="<?php the_permalink(); ?>">
          <?php
          if (function_exists('wpscript_mode') ) {
            echo '<div id="rotator" data-thumbs="'.wpscript_get_multithumbs($post->ID).'"><img alt="' . get_the_title() . '" src="'.get_the_post_thumbnail_url($post->ID, 'thumb-video').'"></div>';
          } else {
            echo do_action('bestia_preview_image');
          }
          ?>
        </a></li>
	<?php
	}
	echo '</ul></div></div>';
  $view_all = $awpt['view_all_in_term'];
  $view_all = str_replace("%term_videos%", $category->count, $view_all);
  $view_all = str_replace("%category_name%", $category->name, $view_all);
	echo '<div class="buttons"><a class="btn btn-default" href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all videos in %s" ), $s_name ) . '" ' . '>'.$view_all.'</a></div>';
	echo '</li>';
}
?>
</ul>
