<?php if( !defined('ABSPATH') ) exit;
global $awpt;
$gif_gallery_template = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-gifs.php') ) ;
$gallerySET = isset($gif_gallery_template[0]->ID) ? $gif_gallery_template[0]->ID : '';
$gif_gallery_link = get_permalink( $gallerySET );
$view_all_btn = $awpt['all_gifs_btn'];
$count_posts = wp_count_posts('gif');
$view_all_btn = str_replace("%total_gifs%", $count_posts->publish, $view_all_btn);
?>
<div class="clear"></div>
<div class="being_watched">
<div class="heading pull-left">
<?php $h_tag = $awpt['general_title_heading']; $title = $awpt['home_gif_title'];
echo '<'.$h_tag.'>'.$title.'</'.$h_tag.'>' ?>
</div>
<?php if(!empty($view_all_btn)) { ?>
<div class="viewall"><a href="<?php echo $gif_gallery_link; ?>" class="btn btn-default"><?php echo $view_all_btn; ?></a></div>
<?php } ?>
<div class="clear"></div>
<div class="row">
<div class="col-md-12">
<?php
$per_page = $awpt['homepage_gifs'];
query_posts('post_type=gif&showposts='.$per_page.'&orderby=desc');
?>
<?php get_template_part('inc/preview-gif',get_post_format()); ?>
<?php ?>
</div>
</div>
<?php wp_reset_query(); ?>
</div>
