<?php
if( !defined('ABSPATH') ) exit;
if( !class_exists('Bestia_ShortcodeSubmitVideo') ){
	class Bestia_ShortcodeSubmitVideo {
		function __construct() {
			add_action('init', array($this,'add_shortcodes'));
			add_action('wp_ajax_awpt_submit_video', array($this,'action_form'));
			add_action('wp_ajax_nopriv_awpt_submit_video', array($this,'action_form'));
		}
		function add_shortcodes(){
			add_shortcode('upload', array($this,'mytubepress_frontent_uploader'));
		}
		function mytubepress_frontent_uploader( $attr, $content = null){
			global $awpt;
			global $post;
			$html = null;
			extract(shortcode_atts(
			array(
				'vcategory'	=>	'on',
				'vtag'		=>	'on',
				'cat_exclude'	=>	'',
				'cat_include'	=>	'',
				'cat_orderby'		=>	'name',
				'cat_order'	=>	'DESC'
			), $attr));
			wp_enqueue_script( 'functions');
			wp_enqueue_script('ajax_handled');
			wp_enqueue_script('multiselect');
			$video_type = isset( $awpt['video-type'] ) ? $awpt['video-type'] : null;
			if( !is_array( $video_type ) ){
				$video_type = (array)$video_type;
			}
			$submit_roles = isset( $awpt['submit_roles'] ) ? (array)$awpt['submit_roles'] : 'author';
			if( count( $submit_roles ) == 1 ){
				$submit_roles = (array)$submit_roles;
			}
			//print_r($submit_roles);
			### 0 is not allow guest, 1 is only register.
			$submit_permission = isset( $awpt['submit_permission'] ) ? $awpt['submit_permission'] : 0;
			$user_id = get_current_user_id();
			$current_user_role = awpt_get_user_role( $user_id );
			### Check if Admin does not allow Visitor submit the video.
			if( $submit_permission == 0 && !$user_id ){
				$html .= 'Please <a class="formLink" _form="login" href="'.wp_login_url().'" id="show_login"><i class="icon"><i class="fa fa-sign-in" aria-hidden="true"></i></i> <span>Login</span></a> to use this feature!';

				//$html .= '[login]';
			}
			//elseif( $submit_permission == 0 && !in_array( $current_user_role, $submit_roles) && $current_user_role != 'administrator'){
			elseif( $submit_permission == 0 && !in_array( $current_user_role, $submit_roles)){
				$html .= '
					<div class="notifications "><div data-ntime="0" class="notifications__item notifications__item-error">'.__('You don\'t have the right permission to access this feature.','bestia').'</div></div>
				';
			}
			else{
				$categories_html = null;
				$category_array = array(
					'hide_empty'=> 0,
					'order'	=>	$cat_order,
					'orderby'	=>	$cat_orderby,
				);
				if( !empty( $cat_exclude ) ){
					$cat_exclude = explode(",", $cat_exclude);
					if( is_array( $cat_exclude ) ){
						$category_array['exclude']	= $cat_exclude;
					}
				}
				if( !empty( $cat_include ) ){
					$cat_include = explode(",", $cat_include);
					if( is_array( $cat_include ) ){
						$category_array['include']	= $cat_include;
					}
				}

				$categories = get_categories($category_array);
				 if ( !empty( $categories ) && !is_wp_error( $categories ) ){
				 	$categories_html .= '<select id="pre-selected-options" name="category[]" multiple="multiple">';
				 	foreach ( $categories as $category ){
				 		$categories_html .= '<option value="'.$category->term_id.'">'.$category->name.'</option>';
				 	}
				 	$categories_html .= '</select>';
				 }
				if( $awpt['post_description_type'] == 1 ){
					$description_type = 'post_content';
				} else {
					$description_type = 'video_description';
				}
				$html .= '
				<div class="holder" style="margin-top:0;">
					<form role="form" action="" method="post" id="awpt-submit-video-form" name="upload_form" enctype="multipart/form-data" style="padding:0;">
					  <div class="field_form post_title">
					    <label for="post_title">'.__('Video Title','bestia').' *</label>
					    <input type="text" class="input form-control" name="post_title" id="post_title">
					    <span class="help-block"></span>
					  </div>
						<div class="field_form '.$description_type.'">
					    <label for="'.$description_type.'">'.__('Video Description','bestia').'</label>
					    ';
						if( $awpt['submit_editor'] == 1 ){
							$html .= mytubepress_get_editor('', $description_type, $description_type);
						}
						else{
							$html .= '<div class="textarea_comment"><textarea name="'.$description_type.'" id="'.$description_type.'" class="textarea form-control" rows="3"></textarea></div>';
						}
					  $html .= '<span class="help-block"></span>';
					  $html .= '</div><div class="field_form video-types">
					  	<label for="post_title" style="float:left;width:100%;">'.__('Video Type','bestia').' *</label>';
					  	if( in_array( 'videolink', $video_type ) ){
					  		$html .= '
							  	<div class="radio inline">
								  	<input type="radio" value="video_link_type" name="chb_video_type"><i class="fa fa-external-link" aria-hidden="true"></i> '.__('Link','bestia').'
							  	</div>
					  		';
					  	}
					  	if( in_array( 'embedcode', $video_type ) ){
					  		$html .= '
							  	<div class="radio">
								  	<input type="radio" value="embed_code_type" name="chb_video_type"><i class="fa fa-code" aria-hidden="true"></i> '.__('Embed Code','bestia').'
							  	</div>
					  		';
					  	}
					  	if( in_array( 'videofile', $video_type ) ){
					  		$html .= '
							  	<div class="radio">
								  	<input checked type="radio" value="file_type" name="chb_video_type"><i class="fa fa-file-video-o" aria-hidden="true"></i> '.__('Upload file','bestia').'
							  	</div>
					  		';
					  	}
					  $html .= '
					  </div>';
					  if( in_array( 'videolink', $video_type ) ){
					  	$html .= '
						  <div class="controls field_form video_url video-type video_link_type" style="display:none;">
						    <label for="video_url" style="margin: -18px 0 20px 0 !important;">'.__('Video Link','bestia').' *</label>
						    <input type="text" class="input form-control" name="video_url" id="video_url" placeholder="Example: http://www.youtube.com/watch?v=X6pQ-pNSnRE">
						    <span class="help-block"></span>
						  </div>
					  	';
					  }
					  if( in_array( 'embedcode', $video_type ) ){
					  	$html .= '
						  <div class="field_form embed_code_type video-type embed_code_type" style="display:none;">
						    <label for="video_url">'.__('Embed Code','bestia').' *</label>
						    <textarea class="textarea_comment form-control" name="embed_code" id="embed_code" style="width:100%;"></textarea>

								<iframe id="preview_code" style="display:none"></iframe>

						    <span class="help-block"></span>
						  </div>
					  	';
					  }
					  if( in_array( 'videofile', $video_type ) ){
					  	$html .= '
						  <div class="field_form video_file video-type file_type">
						    <label for="video_url">'.__('Video File','bestia').' *</label>
							  <input type="file" class="form-control" name="video_file" id="video_file">
								<video id="video_preview" width="320" controls>
                </video>
						    <span class="help-block"></span>
						  </div>
					  	';
					  }
					  $html .= '
					  <div class="field_form video_thumbnail">
					  	<label for="video_url">'.__('Video Preview Image','bestia').' *</label>
					  	<span class="label label-info">'.__('This image is required if you submit an embed code or a video file.','bestia').'</span>
					  	<input type="file" class="form-control" name="video_thumbnail" id="video_thumbnail" onchange="loadFile(event)">
							<img id="output"/>
					  	<span class="help-block"></span>

					  </div>';
					  if( $vtag == 'on' ):
						  $html .= '<div class="field_form video-tag">
						    <label for="key">'.__('Video Tag','bestia').'</label>
						    <input type="text" class="input form-control" name="post_tag" id="post_tag">
						  </div>';
					  endif;
					  if( $vcategory == 'on' ):
					  	$html .= '<div class="field_form categories-video">
						    <label for="category">'.__('Select categories:','bestia').'</label>';
						    $html .= $categories_html;
						  $html .= '</div>';
					  endif;
						$loadingIMG = get_template_directory_uri() . '/assets/css/images/loader.gif';
						$html .= '<button type="submit" class="btn btn-primary">'.__('Upload', 'bestia').'</button>
						<img id="loading" style="display:none;" src="'.get_template_directory_uri().'/assets/css/images/loader.gif">
						<input type="hidden" name="current_page" value="'.$post->ID.'">
						<input type="hidden" name="action" value="awpt_submit_video">
						'.wp_nonce_field('submit_video_act','submit_video',true,false).'
					  </form></div>';
			}
			return do_shortcode( $html );
		}
		function action_form(){
			global $awpt;
			$videosize = isset( $awpt['videosize'] ) ? (int)$awpt['videosize'] : 10;
			$post_title = wp_filter_nohtml_kses( $_POST['post_title'] );
			$video_description = isset( $_POST['video_description'] ) ? trim( $_POST['video_description'] ) : null;
			$video_url = isset( $_POST['video_url'] ) ? trim( $_POST['video_url'] ) : null;
			$embed_code = isset( $_POST['embed_code'] ) ? trim( $_POST['embed_code'] ) : null;
			$video_file = isset( $_FILES['video_file'] ) ? $_FILES['video_file'] : null;
			$post_content = wp_filter_nohtml_kses( $_POST['post_content'] );
			$chb_video_type = isset( $_POST['chb_video_type'] ) ? $_POST['chb_video_type'] : null;
			$video_thumbnail = isset( $_FILES['video_thumbnail'] ) ? $_FILES['video_thumbnail'] : null;
			$post_tag = isset( $_POST['post_tag'] ) ? wp_filter_nohtml_kses( $_POST['post_tag'] ) : null;
			$video_category = isset( $_POST['category'] ) ? $_POST['category'] : null;
			$user_id = get_current_user_id() ? get_current_user_id() : $awpt['submit_assigned_user'];
			$post_status = $awpt['submit_status'] ? $awpt['submit_status'] : 'pending';
			$layout = isset( $_POST['layout'] ) ? $_POST['layout'] : 'small';

			if( !$post_title ){
				echo json_encode(array(
					'resp'	=>	'error',
					'message'	=>	__('Video Title is required','bestia'),
					'element_id'	=>	'post_title'
				));exit;
			}
			/*
			if( !$post_content ){
				echo json_encode(array(
					'resp'	=>	'error',
					'message'	=>	__('Video Description is required','bestia'),
					'element_id'	=>	'post_content'
				));exit;
			}

		if( !$video_description ){
			echo json_encode(array(
				'resp'	=>	'error',
				'message'	=>	__('Video Description is required','bestia'),
				'element_id'	=>	'video_description'
			));exit;
		}
*/

			if( !$chb_video_type ){
				echo json_encode(array(
					'resp'	=>	'error',
					'message'	=>	__('Video Type is required','bestia'),
					'element_id'	=>	'chb_video_type'
				));exit;
			}

			switch ($chb_video_type) {
				case 'video_link_type':
					if( !$video_url ){
						echo json_encode(array(
							'resp'	=>	'error',
							'message'	=>	__('Video Link is required','bestia'),
							'element_id'	=>	'video_url'
						));exit;
					}
					if( !wp_oembed_get( $video_url ) ){
						echo json_encode(array(
							'resp'	=>	'error',
							'message'	=>	__('The link does not support.','bestia'),
							'element_id'	=>	'video_url'
						));exit;
					}
				break;

				case 'embed_code_type':
					if( !$embed_code ){
						echo json_encode(array(
							'resp'	=>	'error',
							'message'	=>	__('Embed Code is required','bestia'),
							'element_id'	=>	'embed_code'
						));exit;
					}
					if( apply_filters( 'awpt_submitform_thumbnail_required' , true) === true ):
						if( !$video_thumbnail ){
							echo json_encode(array(
								'resp'	=>	'error',
								'message'	=>	__('Video Preview Image is required','bestia'),
								'element_id'	=>	'video_thumbnail'
							));exit;
						}
						if( !awpt_check_file_allowed( $video_thumbnail, 'image' ) ){
							echo json_encode(array(
								'resp'	=>	'error',
								'message'	=>	__('Video Preview Image type is invalid','bestia'),
								'element_id'	=>	'video_thumbnail'
							));exit;
						}
					endif;
				break;
				default:
					if( !$video_file ){
						echo json_encode(array(
							'resp'	=>	'error',
							'message'	=>	__('Video File is required.','bestia'),
							'element_id'	=>	'video_file'
						));exit;
					}
					if( !awpt_check_file_allowed( $video_file, 'video' ) ){
						echo json_encode(array(
							'resp'	=>	'error',
							'message'	=>	__('Video File format is invalid.','bestia'),
							'element_id'	=>	'video_file'
						));exit;
					}
					if( !awpt_check_file_size_allowed($video_file) ){
						echo json_encode(array(
							'resp'	=>	'error',
							'message'	=>	__('The video size must be less than ' . $videosize . 'MB','bestia'),
							'element_id'	=>	'video_file'
						));exit;
					}
					if( apply_filters( 'awpt_submitform_thumbnail_required' , true) === true ):
						if( !$video_thumbnail ){
							echo json_encode(array(
								'resp'	=>	'error',
								'message'	=>	__('Video Preview Image is required','bestia'),
								'element_id'	=>	'video_thumbnail'
							));exit;
						}
						if( !awpt_check_file_allowed( $video_thumbnail, 'image' ) ){
							echo json_encode(array(
								'resp'	=>	'error',
								'message'	=>	__('Video Preview Image type is invalid','bestia'),
								'element_id'	=>	'video_thumbnail'
							));exit;
						}
					endif;
				break;
			}

			/**
			 * Error handler
			 * @since Videotube V2.2.7
			 */
			$errors = new WP_Error();
			$errors	=	apply_filters( 'do_ajax_submit_video_errors' , $errors, $_POST );

			if ( ! empty( $errors->errors ) ) {
				echo json_encode(array(
					'resp'	=>	'error',
					'message'	=>	$errors->get_error_message(),
					'element_id'	=>	$errors->get_error_code()
				));exit;
			}

			$postarr = array(
				'post_title'	=>	$post_title,
				'post_content'	=>	$post_content,
				'post_type'	=>	'post',
				'post_category' => $video_category,
				'post_author'	=>	$user_id,
				'post_status'	=>	$post_status,
				'comment_status'	=>	'open'
			);

			$postarr	=	apply_filters( 'awpt_submit_data_args' , $postarr );

			$post_id = wp_insert_post($postarr, true);

			if ( is_wp_error( $post_id ) ){
				echo json_encode(array(
					'resp'	=>	'error',
					'message'	=>	$post_id->get_error_message()
				));
				exit;
			}

			###  update meta
			/*
			if( $layout ){
				update_post_meta( $post_id , 'layout', $layout);
			}
			*/
			if( $video_description ){
				update_post_meta( $post_id , 'video_description', $video_description);
			}
			if( $video_url ){
				update_post_meta( $post_id , 'video_url', $video_url);
			}
			elseif ( $embed_code){
				update_post_meta( $post_id , 'embed_code', $embed_code);
			}
			else {
				### Upload files.
				if( function_exists('awpt_insert_attachment') ){
					awpt_insert_attachment('video_file', $post_id, false, 'video_file');
					update_post_meta( $post_id , 'video_type', 'files');
				}
			}
			### Preview image
			if( $video_thumbnail ){
				### Upload files.
				if( function_exists('awpt_insert_attachment') ){
					awpt_insert_attachment('video_thumbnail', $post_id, true);
				}
			}
			### update term
			if( $post_tag ){
				wp_set_post_terms($post_id, $post_tag,'post_tag',true);
			}
			if( $video_category ){
				wp_set_post_categories($post_id, $video_category,'category',true);
			}
			do_action('awpt_save_post',$post_id);

			if( $post_status != 'publish' ){
				$redirect_to = $awpt['submit_redirect_to'] ? get_permalink( $awpt['submit_redirect_to'] ) : NULL;
				if( empty( $redirect_to ) ){
					echo json_encode(array(
						'resp'	=>	'success',
						'message'	=>	__('Congratulation, Your submit is waiting for approval.','bestia'),
						'post_id'	=>	$post_id,
					));
					 exit;
				}
				else{
					echo json_encode(array(
						'resp'	=>	'success',
						'message'	=>	__('Congratulation, Your submit is waiting for approval.','bestia'),
						'post_id'	=>	$post_id,
						'redirect_to'	=>	$redirect_to
					));
					exit;
				}
			}
			else {
				echo json_encode(array(
					'resp'	=>	'publish',
					'message'	=>	__('Congratulation, Your submit is published.','bestia'),
					'post_id'	=>	$post_id,
					'redirect_to'	=>	get_permalink( $post_id )
				));
				 exit;
			}
		}
	}
	new Bestia_ShortcodeSubmitVideo();
}
