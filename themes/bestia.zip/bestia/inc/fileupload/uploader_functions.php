<?php
if( !defined('ABSPATH') ) exit;
if( !function_exists('awpt_get_thumbnail_image') ){
	function awpt_get_thumbnail_image( $post_id ) {
		global $awpt;
		$post_status = $awpt['submit_status'] ? $awpt['submit_status'] : 'pending';
		if( $post_status == 'publish' && get_post_type( $post_id ) == 'post' && function_exists( 'get_video_thumbnail' ) ){
			get_video_thumbnail($post_id);
		}
	}
	add_action('awpt_save_post', 'awpt_get_thumbnail_image', 9999, 1);
}
if( !function_exists('awpt_get_user_role') ){
	function awpt_get_user_role( $user_id ) {
		if( !$user_id ){
			return;
		}
		$user = new WP_User( $user_id );
		if( isset( $user->roles[0] ) ){
			return $user->roles[0];
		}
		else {
			return null;
		}
	}
}
if( !function_exists('awpt_get_post_data') ){
	function awpt_get_post_data( $post_id ) {
		return get_post( $post_id );
	}
}

if( !function_exists( 'awpt_get_user_postcount' ) ){
	function awpt_get_user_postcount( $user_id, $post_type="post" ) {
		return count_user_posts( $user_id , $post_type  );
	}
}
if( !function_exists( 'awpt_get_user_metacount' ) ){
	function awpt_get_user_metacount( $user_id, $key ) {
		global $wpdb;

		if( false === ( $query = get_transient( $user_id . 'meta_count' . $key ) ) ){
			$query = $wpdb->get_var( $wpdb->prepare(
					"
					SELECT sum(meta_value)
					FROM $wpdb->postmeta LEFT JOIN $wpdb->posts ON ( $wpdb->postmeta.post_id = $wpdb->posts.ID )
					LEFT JOIN $wpdb->users ON ( $wpdb->posts.post_author = $wpdb->users.ID )
					WHERE meta_key = %s
					AND $wpdb->users.ID = %s
					AND $wpdb->posts.post_status = %s
					AND $wpdb->posts.post_type = %s
					",
					$key,
					$user_id,
					'publish',
					'post'
			) );

			if( (int)$query > 0 ){
				set_transient( $user_id . 'meta_count' . $key , $query, 600);
			}
		}
		return (int)$query > 0 ? number_format_i18n($query) : 0;
	}
}
if( !function_exists( 'awpt_viaudiofile_format' ) ){
	function awpt_viaudiofile_format() {
		$allowed_formats = array(
			'asf',
			'asx',
			'wmv',
			'wmx',
			'wm',
			'avi',
			'divx',
			'flv',
			'qt',
			'mpeg',
			'mpg',
			'mpe',
			'mp4',
			'mov',
			'm4v',
			'ogv',
			'webm',
			'mkv',
			'mp3',
			'm4a',
			'm4b',
			'ra',
			'ram',
			'wav',
			'ogg',
			'oga',
			'mid',
			'midi',
			'wma',
			'wax',
			'mka'
		);
		return apply_filters( 'awpt_viaudiofile_format/filetypes' , $allowed_formats);
	}
}
if( !function_exists( 'awpt_imagefile_format' ) ){
	function awpt_imagefile_format() {
		return apply_filters( 'awpt_imagefile_format/filetypes' , array('jpg','jpeg','png','gif'));
	}
}
if( !function_exists( 'awpt_check_file_allowed' ) ){
	function awpt_check_file_allowed( $file, $type = 'video' ){
		$bool = false;
		if( $type == 'video' ){
			$mimes = awpt_viaudiofile_format();
		}
		else{
			$mimes = awpt_imagefile_format();
		}
		$filetype = wp_check_filetype($file['name'], null);

		$ext = isset( $filetype ) ? strtolower( $filetype['ext'] ) : '';

		if( in_array( $ext , $mimes) ){
			$bool = true;
		}

		return $bool;
	}
}
if( !function_exists( 'awpt_check_file_size_allowed' ) ){
	function awpt_check_file_size_allowed( $file, $type = 'video' ){
		global $awpt;
		if( !$file )
			return false;
		if( $type == 'video' ){
			$filesize = isset( $awpt['videosize'] ) ? (int)$awpt['videosize'] : 10;
		}
		else{
			$filesize = isset( $awpt['imagesize'] ) ? (int)$awpt['imagesize'] : 2;
		}
		if( $filesize == -1 ){
			return true;
		}
		$byte_limit = awpt_convert_mb_to_b( $filesize );
		if( $file["size"] > $byte_limit ){
			return false;
		}
		return true;
	}
}

if( !function_exists( 'awpt_convert_mb_to_b' ) ){
	function awpt_convert_mb_to_b( $megabyte ) {
		if( !$megabyte || $megabyte == 0 )
			return 0;
		return (int)$megabyte * 1048576;
	}
}

if( !function_exists( 'awpt_insert_attachment' ) ){
	function awpt_insert_attachment($file_handler, $post_id, $setthumb='false', $post_meta = '') {
		// check to make sure its a successful upload
		if ($_FILES[$file_handler]['error'] !== UPLOAD_ERR_OK) __return_false();

		require_once(ABSPATH . "wp-admin" . '/includes/image.php');
		require_once(ABSPATH . "wp-admin" . '/includes/file.php');
		require_once(ABSPATH . "wp-admin" . '/includes/media.php');

		$attach_id = media_handle_upload( $file_handler, $post_id );

		if ($setthumb) update_post_meta($post_id,'_thumbnail_id',$attach_id);
		if(!$setthumb && $post_meta!=''){
			update_post_meta($post_id, $post_meta, array( $attach_id ));
		}
		return $attach_id;
	}	}
	if( !function_exists('awpt_get_current_postterm') ){
	function awpt_get_current_postterm($post_id, $taxonomy){
		$terms = wp_get_post_terms($post_id,$taxonomy, array("fields" => "ids"));
		return $terms;
	}
}
if(!function_exists('mytubepress_get_editor')){
	function mytubepress_get_editor($content, $id, $name, $display_media = false) {
		ob_start();
		$settings = array(
			'textarea_name' => $name,
			'media_buttons' => $display_media,
			'textarea_rows'	=>	5,
			'quicktags'	=>	false
		);
		// Echo the editor to the buffer
		wp_editor($content,$id, $settings);
		// Store the contents of the buffer in a variable
		$editor_contents = ob_get_clean();
		$editor_contents = str_ireplace("<br>","", $editor_contents);
		// Return the content you want to the calling function
		return $editor_contents;
	}
}
if( !function_exists('videoframe') ){
	function videoframe() {
		global $post,$awpt;
		$frame = null;
		$settings = array();
			### Fullwidth Video
			$settings = array(
				'width'	=>	1000,
				'height'	=>	641,
			);
		$settings['autoplay'] = "true";
		$video_url = get_post_meta($post->ID,'video_url',true);
		if( $video_url ){
			if( function_exists( 'wp_oembed_get' ) ){
				$frame .= wp_oembed_get($video_url, $settings);
			}
		}
		  elseif( get_post_meta($post->ID,'video_frame',true) !='' ){
			### The Frame.
			$frame .= get_post_meta($post->ID,'video_frame',true);
		}
		elseif( get_post_meta($post->ID,'video_file',true) !='' ){
			$video_file_url = wp_get_attachment_url( get_post_meta($post->ID,'video_file',true) );
			$frame .= '[video '.$settings.' src="'.$video_file_url.'"][/video]';
		}
		return $frame;
	}
	add_filter('videoframe', 'videoframe', 10);
}
if( !function_exists('bestia_get_remote_videoid') ){
	function bestia_get_remote_videoid($url) {
		$video_id = NULL;
		if( !$url )
			return;
		if( !function_exists('parse_url') )
			return;
		$string = parse_url($url);
		$host = $string['host'];

		if( $host == 'vimeo.com' || $host =='www.vimeo.com' ){
			$video_id = substr($string['path'], 1);
		}
		if( $host == 'youtube.com' || $host =='www.youtube.com' ){
			parse_str( parse_url( $url, PHP_URL_QUERY ), $array_of_vars );
			$video_id = $array_of_vars['v'];
		}
		return array(
			'id'	=>	$video_id,
			'source'	=>	$host
		);
	}
}
