<?php
global $awpt;
if( $awpt['gallery_cpt'] == 1 ){
$per_page = $awpt['homepage_photos'];
$photo_gallery_template = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-photo-gallery.php') ) ;
$gallerySET = isset($photo_gallery_template[0]->ID) ? $photo_gallery_template[0]->ID : '#';
$photo_gallery_link = get_permalink( $gallerySET );
$h_tag_general = $awpt['general_title_heading'];
$view_all_btn = $awpt['all_galleries_btn'];
$count_posts = wp_count_posts('gallery');
$view_all_btn = str_replace("%total_photos%", $count_posts->publish, $view_all_btn);
$new_galleries_title = $awpt['mtn_newest_galleries_title'];
echo '<div class="homepage_galleries"><div class="heading pull-left">', getBestiaHeadingtags($h_tag_general,$new_galleries_title), '</div>'; ?>
<?php if(!empty($view_all_btn)) { ?>
<div class="viewall visible-desktop"><a href="<?php echo $photo_gallery_link; ?>" class="btn btn-default"><?php echo $view_all_btn; ?></a></div>
<?php } ?>
<div class="clearfix"></div>
<?php query_posts('post_type=gallery&showposts='.$per_page.'&orderby=desc'); get_template_part('inc/preview-gallery-home',get_post_format()); ?>
</div>
<?php } ?>
<?php if(!empty($view_all_btn)) { ?>
<div class="viewall visible-mobile"><a href="<?php echo $photo_gallery_link; ?>" class="btn btn-default"><?php echo $view_all_btn; ?></a></div>
<?php } ?>
