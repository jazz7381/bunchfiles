<?php if( !defined('ABSPATH') ) exit; if ( have_posts() ) : $count = 1; ?>
<ul class="Thumbnail_List">
<?php do_action( 'bestia_homepage_ads' );
while ( have_posts() ) : the_post();
do_action( 'bestia_thumbnail_compatibility' ); if ($count == 6) : ?>
<?php do_action( 'bestia_after_post_ad' ); ?>
<?php endif; $count++; ?>
<?php endwhile; else : ?>
<div class="clearfix"></div>
<p class="none"><?php _e('No Videos Found', 'bestia'); ?></p>
<?php endif; ?>
</ul>
