<?php
if( !defined('ABSPATH') ) exit;
global $awpt;
if ( have_posts() ) : ?>
<div class="row">
	<div class="gifgal">
    <?php while ( have_posts() ) : the_post(); ?>
    <a href="<?php the_permalink(); ?>" class="title" title="<?php the_title_attribute(); ?>">
  <?php if ( has_post_thumbnail() ) {
	  echo the_post_thumbnail();
   } else {
    echo first_image_from_gif_gallery();
   } ?>
   <span class="gif-title">
     <?php echo the_title(); ?>
   </span>
    </a>
    <?php endwhile; ?>
	</div>
</div>
<?php else : ?>
<div class="clear"></div>
<p class="none"><?php _e('No Gif Galleries Found', 'bestia'); ?></p>
<?php endif; ?>
<div class="clearfix"></div>
