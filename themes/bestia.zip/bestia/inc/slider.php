<div class="hm-slide">
 <div class="owl-carousel slider-wraper" data-toggle="owlcarousel" data-owlcarousel-settings='{"mouseDrag": false, "singleItem": true, "nav": true, "lazyLoad": true, "items":1, "pagination":false, "navigation":true, "itemsScaleUp":true}'>
  <?php
  global $post;
  $tmp_post = $post;
  $blogposts = get_posts( 'post_type=slider&numberposts=-1&orderby=desc' );
  foreach( $blogposts as $post ) : setup_postdata($post);
  $content = get_post_meta( $post->ID, 'slider_content', true );
  $acf_video = get_post_meta($post->ID, "slider_video", true);
  $video = wp_get_attachment_url($acf_video);
  $acf_img = get_post_meta( $post->ID, 'slider_image', true );
  $toggle = get_post_meta( $post->ID, 'slider_toggle', true );
  $image = wp_get_attachment_image_url($acf_img, 'full');
  //preg_match('~\[button\s+link\s*=\s*("|\')(?<url>.*?)\1\s*\]~i', $input, $matches);
  //$url = isset($matches['url']) ? $matches['url']:'';
  ?>
  <div class="container sl-item">
  <button class="open-info"> <?php echo $toggle; ?> <i class="fa fa-caret-down"></i></button>
  <?php
  if(!empty($image)) {
      echo '<div class="sl-img" style="background-image: url('.$image.');"></div>';
        } elseif($video!='') {
      echo '<video autoplay muted playsinline loop id="SlideVideo"><source src="'.$video.'" type="video/mp4"></video>';
   } ?>
  <div class="container sli-overlay">
    <a>
      <h3><?php echo the_title(); ?></h3>
      <?php if($content!='') {
        echo apply_filters('the_content', get_post_meta( $post->ID, 'slider_content', true ));
      } ?>
    </a>
  </div>

  </div>

  <?php endforeach; ?>
  <?php $post = $tmp_post; ?>
 </div>
</div>
