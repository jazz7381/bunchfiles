<?php if( !defined('ABSPATH') ) exit; global $awpt;
$video_gallery_template = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-videos.php') ) ;
$videoSET = isset($video_gallery_template[0]->ID) ? $video_gallery_template[0]->ID : '#';
$video_gallery_link = get_permalink( $videoSET );
$view_all_btn = $awpt['all_videos_btn'];
$count_posts = wp_count_posts();
$view_all_btn = str_replace("%total_videos%", $count_posts->publish, $view_all_btn);
?>
<div>
<div class="heading pull-left">
<?php $h_tag = $awpt['general_title_heading']; $title = $awpt['mtn_newest_title'];
echo '<'.$h_tag.'>'.$title.'</'.$h_tag.'>' ?>
</div>
<?php if(!empty($view_all_btn)) { ?>
<div class="viewall visible-desktop"><a href="<?php echo $video_gallery_link; ?>" class="btn btn-default"><?php echo $view_all_btn; ?></a></div>
<?php } ?>
<div class="clearfix"></div>
<ul class="Thumbnail_List">
<?php
$per_page = $awpt['latest_videos_block'];
query_posts('showposts='.$per_page.'&orderby=desc');
if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php do_action( 'bestia_thumbnail_compatibility' ); ?>
<?php endwhile; else: endif; ?>

<?php wp_reset_query(); ?>
</ul>
</div>
<?php if(!empty($view_all_btn)) { ?>
<div class="viewall visible-mobile"><a href="<?php echo $video_gallery_link; ?>" class="btn btn-default"><?php echo $view_all_btn; ?></a></div>
<?php } ?>
