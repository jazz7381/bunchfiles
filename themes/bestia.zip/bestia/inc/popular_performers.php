<?php
if( !defined('ABSPATH') ) exit;
global $awpt;
$lazyLoading = $awpt['mtn_lazyloading'];
if ($lazyLoading == "jquery_lazy") {
$src = 'class="lazyOwl" src="'.get_template_directory_uri() . '/assets/css/images/1pixel.gif"';
$original = 'data-src';
} elseif ($lazyLoading == "unveil_lazy") {
$src = 'class="lazyOwl" src="'.get_template_directory_uri() . '/assets/css/images/1pixel.gif"';
$original = 'data-src';
} else {
$src = '';
$original = 'src';
}
$number   = $awpt['performers_block']; // number of terms to display per page

//Dynamic url
$sortby = isset($_GET['sortby']) ? $_GET['sortby'] : null;

//Taxonomy Setup
$taxonomy = 'performer';
$page = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
$offset       = ( $page > 0 ) ?  $number * ( $page - 1 ) : 1;

//Total terms to setup the pagination.
$totalterms   = wp_count_terms( $taxonomy, array( 'hide_empty' => false ) );
$totalpages   = ceil( $totalterms / $number );
if( isset( $sortby ) ) {
$args = array(
  'orderby' => 'count',
  'order' => 'desc',
        'hide_empty'    => false,
        'offset'        => $offset,
);
} else {
$args = array(
  'orderby' => 'count',
  'order' => 'desc',
        'hide_empty'    => false,
        'exclude'       => array(),
        'exclude_tree'  => array(),
        'include'       => array(),
        'number'        => $number,
        //'fields'        => 'all',
        'slug'          => '',
        'parent'         => '',
        'hierarchical'  => true,
        'child_of'      => 0,
        'get'           => '',
        'name__like'    => '',
        'pad_counts'    => false,
        'offset'        => $offset,
        'search'        => '',
        'cache_domain'  => 'core'
);
}
$tax_terms = get_terms( $taxonomy, $args );
$count_terms = wp_count_terms( $taxonomy, $args );
?>
<div class="heading pull-left">
<?php
$performers_page = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-performers.php') ) ;
$performerSET = isset($performers_page[0]->ID) ? $performers_page[0]->ID : '#';
$performers_page_url = get_permalink( $performerSET );
$view_all_btn = $awpt['all_performers_btn'];
$view_all_btn = str_replace("%total_terms%", $count_terms, $view_all_btn);
$h_tag = $awpt['general_title_heading'];
$title = $awpt['performers_block_title'];
echo '<'.$h_tag.'>'.$title.'</'.$h_tag.'>';
?>
</div>
<div class="viewall visible-desktop">
  <a href="<?php echo $performers_page_url; ?>" class="btn btn-default"><?php echo $view_all_btn; ?></a>
</div>
<div class="clearfix"></div>
<div id="performer-list">
<div id="performer-thumbs" class="performer-listing clearfix">

<div class="item-carousel owl-carousel owl-theme" data-toggle="owlcarousel" data-owlcarousel-settings='{"lazyLoad": true, "items":8, "pagination":false, "navigation":true, "autoPlay":true, "itemsScaleUp":true}'>
<?php
foreach ($tax_terms as $cat) : ?>
  <?php
   $flag = 0;
      if( $sortby == mb_substr( $cat->name, 0, 1 ) || $sortby=='' ) {
       $flag = 1;
      }
   ?>
<?php
$gender = get_term_meta($cat->term_id,'awpt_gender', true);
if ($gender == "male") {
  $img_type = 'male';
} elseif ($gender == "transgender") {
    $img_type = 'trans';
} else {
    $img_type = 'female';
}

$performer_image = z_taxonomy_image_url( $cat->term_id, null );
if( ! empty($performer_image)) :
  $image = aq_resize( $performer_image, 190, 278, true );
else :
  $image = get_template_directory_uri() . '/assets/css/images/'.$img_type.'.jpg';
endif;

if ( $flag == '1' ) {
?>
<div class="item performer-item">

<span class="performer-videos">
<span class="count"><?php echo $cat->count; ?></span>
<span class="txt"><?php echo _e('Videos', 'bestia'); ?></span>
</span>

<a class="outline" href="<?php echo get_term_link($cat->slug, 'performer'); ?>" title="<?php echo $cat->name; ?>">
<?php echo '<img '.$src, $original.'="'.$image.'" alt="'.$cat->name.'" />'; ?>
<span class="performer-name"><?php echo $cat->name; ?></span>
</a>
</div>
<?php } ?>
<?php endforeach; ?>
</div>
</div>
</div>
<div class="viewall visible-mobile">
  <a href="<?php echo $performers_page_url; ?>" class="btn btn-default"><?php echo $view_all_btn; ?></a>
</div>
