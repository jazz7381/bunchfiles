<div id="show">
<ul class="Thumbnail_List" id="first_related">
<?php global $awpt;
$per_page = $awpt['related_videos_per_page'];
$more = $awpt['related_more_per_page'];
query_posts('showposts='.$per_page.'&orderby=rand');
if ( have_posts() ) : while ( have_posts() ) : the_post();
do_action( 'bestia_thumbnail_compatibility' );
endwhile; else: endif; ?>
</ul>
<?php query_posts('showposts='.$more.'&orderby=rand&offset=3');
if ( have_posts() ) :
echo '<ul class="Thumbnail_List" id="second_related">';
while ( have_posts() ) : the_post();
do_action( 'bestia_thumbnail_compatibility' );
endwhile;
echo '</ul>';
echo '<div class="show_more_content"><button id="open" class="btn btn-default">'.$awpt['show_more_btn'].'</button></div>';
else: endif; ?>
</div>
