<div id="show">

<ul class="Thumbnail_List" id="first_related">
<?php
global $post,$awpt;
$orig_post = $post;
$per_page = $awpt['related_videos_per_page'];
$more = $awpt['related_more_per_page'];
$categories = get_the_category($post->ID);
if ($categories) {
$category_ids = array();
foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
$args=array(
'category__in' => $category_ids,
'post__not_in' => array($post->ID),
'showposts'=> $per_page, // Number of related posts that will be displayed.
'ignore_sticky_posts' => 1,
'orderby'=>'rand' // Randomize the posts
);
$my_query = new wp_query( $args );
if( $my_query->have_posts() ) {
while( $my_query->have_posts() ) {
$my_query->the_post();
do_action( 'bestia_thumbnail_compatibility' );
}
} }
$post = $orig_post;
wp_reset_query(); ?>
</ul>
<?php for($i = 0; $i< count($posts); $i+=$per_page) { ?>
<ul class="Thumbnail_List" id="second_related">
<?php
if ($categories) {
$category_ids = array();
foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
$args=array(
'category__in' => $category_ids,
'post__not_in' => array($post->ID),
'showposts'=> $more, // Number of related posts that will be displayed.
'ignore_sticky_posts' => 1,
'orderby'=>'rand', // Randomize the posts
'offset' => '3'
);
$my_query = new wp_query( $args );
if( $my_query->have_posts() ) {
while( $my_query->have_posts() ) {
$my_query->the_post();
do_action( 'bestia_thumbnail_compatibility' );
}
echo '</ul>';
echo '<div class="show_more_content"><button id="open" class="btn btn-default">'.$awpt['show_more_btn'].'</button></div>';
} }
$post = $orig_post;
wp_reset_query(); ?>
</ul>
<?php } ?>
</div>
