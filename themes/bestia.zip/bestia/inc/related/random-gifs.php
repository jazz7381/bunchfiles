<div class="row">
<div class="gifgal">
<?php
global $post,$awpt; $per_page = $awpt['related_gifs_per_page'];
$tmp_post = $post;
$blogposts = get_posts( 'post_type=gif&numberposts='.$per_page.'&orderby=rand' );
foreach( $blogposts as $post ) : setup_postdata($post); ?>
<a href="<?php the_permalink(); ?>" class="title" title="<?php the_title_attribute(); ?>">
<?php if ( has_post_thumbnail() ) {
echo the_post_thumbnail();
} else {
echo first_image_from_gif_gallery();
} ?>
<span class="gif-title">
 <?php echo the_title(); ?>
</span>
</a>
<?php endforeach; ?>
<?php $post = $tmp_post; ?>
</div>
</div>
