<ul class="Thumbnail_List">
<?php
global $post,$awpt; $per_page = $awpt['related_photos_per_page'];
$tmp_post = $post;
$albums = get_posts( 'post_type=gallery&numberposts='.$per_page.'&orderby=rand' );
foreach( $albums as $post ) : setup_postdata($post); ?>
<li id="post-<?php the_ID(); ?>" class="thumi">
<a href="<?php the_permalink() ?>" id="preview_image" title="<?php the_title_attribute(); ?>">
<?php
if (function_exists('wpscript_mode') ) {
  echo '<div id="rotator" data-thumbs="'.wpscript_get_multithumbs($post->ID).'"><img alt="' . get_the_title() . '" src="'.get_the_post_thumbnail_url($post->ID, 'thumb-video').'"></div>';
} else {
  echo do_action('bestia_preview_image');
}
?>
</a>
<div class="clearfix"></div>
<div class="thumb_bar">
<a href="<?php the_permalink(); ?>" class="title" title="<?php the_title_attribute(); ?>">
<?php do_action( 'bestia_heading_title_thumbnail' ); ?>
</a>
<strong class="toolbar">
<span class="rate_thumb">
  <i class="fa fa-thumbs-up"></i>
  <?php if (function_exists('adultwpthemes_getItemPostLikeRate')) {
    echo do_action('bestia_post_rating_mode');
  } ?>
</span>
<span class="time_thumb">
  <?php
  if ( $awpt['video_hd_all'] == 1 ) {
  echo '<em><i class="quality">HD</i></em>';
  } elseif($video_is_hd != '') {
  echo '<em><i class="quality">HD</i></em>';
  }
  do_action('bestia_video_duration');
  ?>
</span>
</strong>
<span class="post-views half-black">
<?php do_action( 'bestia_post_views_mode' ); ?>
<span class="bestia_view_text"> <?php _e('Views', 'bestia'); ?></span>
</span>
<span class="post-category half">
<?php
$category = get_the_category();
if ( $category[0] ) {
    echo '<a href="' . get_category_link( $category[0]->term_id ) . '">' . $category[0]->cat_name . '</a>';
}
?>
</span>
<span class="added">
<?php echo time_ago(); ?> <?php _e('ago', 'bestia'); ?>
</span>
</div>
</li>
<?php endforeach; ?>
<?php $post = $tmp_post; ?>
</ul>
