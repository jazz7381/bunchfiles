<div id="show">
<ul class="Thumbnail_List" id="first_related">
<?php $orig_post = $post;
global $post,$awpt; $per_page = $awpt['related_videos_per_page'];
$more = $awpt['related_more_per_page'];
$tags = wp_get_post_tags($post->ID);
if ($tags) {
$tag_ids = array();
foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
$args=array(
'tag__in' => $tag_ids,
'post__not_in' => array($post->ID),
'showposts'=> $per_page, // Number of related posts that will be displayed.
'ignore_sticky_posts' => 1,
'orderby'=>'rand' // Randomize the posts
);
$my_query = new wp_query( $args );
if( $my_query->have_posts() ) {
while( $my_query->have_posts() ) {
$my_query->the_post();
do_action( 'bestia_thumbnail_compatibility' );
}
} }
$post = $orig_post;
wp_reset_query(); ?>
</ul>
<?php
$tags = wp_get_post_tags($post->ID);
if ($tags) {
$tag_ids = array();
foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
$args=array(
'tag__in' => $tag_ids,
'post__not_in' => array($post->ID),
'showposts'=> $more, // Number of related posts that will be displayed.
'ignore_sticky_posts' => 1,
'orderby'=>'rand', // Randomize the posts
'offset' => '3'
);
$my_query = new wp_query( $args );
if( $my_query->have_posts() ) {
echo '<ul class="Thumbnail_List" id="second_related">';
while( $my_query->have_posts() ) {
$my_query->the_post();
do_action( 'bestia_thumbnail_compatibility' );
}
echo '</ul>';
echo '<div class="show_more_content"><button id="open" class="btn btn-default">'.$awpt['show_more_btn'].'</button></div>';
} }
$post = $orig_post;
wp_reset_query(); ?>
</div>
