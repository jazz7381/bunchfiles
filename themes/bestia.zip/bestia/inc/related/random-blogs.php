<?php
global $post,$awpt; $per_page = $awpt['related_blogs_per_page'];
$tmp_post = $post;
$blogposts = get_posts( 'post_type=blogs&numberposts='.$per_page.'&orderby=rand' );
foreach( $blogposts as $post ) : setup_postdata($post); ?>
<?php get_template_part('inc/blog',get_post_format()); ?>
<?php endforeach; ?>
<?php $post = $tmp_post; ?>
