<div class="slidemenu slidemenu-right">
<div class="wrap_holder">
<?php
wp_nav_menu( array( 'theme_location' => 'secondary' ) );
if( has_nav_menu('secondary-right') ){
wp_nav_menu( $secondary_2 );
wp_nav_menu( array( 'theme_location' => 'secondary-right' ) );
}
?>
</div>
</div>
