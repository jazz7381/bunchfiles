<?php
global $awpt;
do_action( 'bestia_bottom_ads' );
do_action( 'bestia_mobile_bottom_ad' );
echo '<div class="clearfix"></div>';
wp_footer(); ?>
<?php
if( $awpt['flyout-performers'] == 1 && !wp_is_mobile() ){ ?>
  <script type="text/javascript">
     jQuery('.flyout-performers').mouseenter(function(){
       jQuery('#performers-block').slideDown("fast");
    });
    jQuery('.flyout-performers').mouseleave(function(){
       jQuery('#performers-block').hide();
    });
    jQuery('#performers-block').mouseenter(function(){
      jQuery('#performers-block').show();
    });
    jQuery('#performers-block').mouseleave(function(){
      jQuery('#performers-block').hide();
    });
  </script>
<?php } if( $awpt['flyout-channels'] == 1 && !wp_is_mobile() ){ ?>
  <script type="text/javascript">
     jQuery('.flyout-channels').mouseenter(function(){
       jQuery('#channels-block').slideDown("fast");
    });
    jQuery('.flyout-channels').mouseleave(function(){
       jQuery('#channels-block').hide();
    });
    jQuery('#channels-block').mouseenter(function(){
      jQuery('#channels-block').show();
    });
    jQuery('#channels-block').mouseleave(function(){
      jQuery('#channels-block').hide();
    });
  </script>
<?php } if( $awpt['flyout-categories'] == 1 && !wp_is_mobile() ){ ?>
  <script type="text/javascript">
     jQuery('.flyout-categories').mouseenter(function(){
       jQuery('#categories-block').slideDown("fast");
    });
    jQuery('.flyout-categories').mouseleave(function(){
       jQuery('#categories-block').hide();
    });
    jQuery('#categories-block').mouseenter(function(){
      jQuery('#categories-block').show();
    });
    jQuery('#categories-block').mouseleave(function(){
      jQuery('#categories-block').hide();
    });
  </script>
<?php } ?>
<footer id="footer">
  <?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) || is_active_sidebar( 'footer-4' ) ) : ?>
  <div class="footer-top">
    <div class="container">
      <div class="row">

        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-1') ) : ?>
        <?php endif; ?>
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-2') ) : ?>
        <?php endif; ?>
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-3') ) : ?>
        <?php endif; ?>
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-4') ) : ?>
        <?php endif; ?>

      </div>
    </div>
  </div>
  <?php endif; ?>
  <?php $copy = $awpt['footer_copyright'];
  if (!empty($copy)) { ?>
    <div class="container">
      <div class="clearfix"></div>
      <div class="copyright">
        <?php echo $copy; ?>
      </div>
    </div>
  <?php } ?>
</footer>
<script type="text/javascript">
jQuery('#login_form .dropdown-menu').on({
	"click":function(e){
      e.stopPropagation();
    }
});
</script>
<script type="text/javascript">
        jQuery(function () {
            jQuery(".font-button").bind("click", function () {
                var size = parseInt(jQuery('.col-md-7').css("font-size"));
                if (jQuery(this).hasClass("plus")) {
                    size = size + 2;
                } else {
                    size = size - 2;
                    if (size <= 10) {
                        size = 10;
                    }
                }
                jQuery('.col-md-7').css("font-size", size);
            });
        });
    </script>
    
  <script type="text/javascript">
  jQuery(document).ready(function($) {
      $('input#submit').attr('disabled', true);
      $('input[type="text"], textarea').on('keyup',function() {
        var textarea_value = $("#texta").val();
        var text_value = $('input[name="text"]').val();
        var email_value = $('input[name="email"]').val();
        <?php //if ( is_user_logged_in() ) : ?>
         if(textarea_value != '') {
        <?php //else : ?>
         if(textarea_value != '' && text_value != '' && email_value != '') {
        <?php //endif; ?>
         $('input#submit').attr('disabled' , false);
        } else {
         $('input#submit"]').attr('disabled' , true);}
       });
     });
   });
   </script>

<a id="topButton" href="#" class="TopButton" style="display: inline;"></a>
<?php do_action( 'bestia_lazyloading_type' ); ?>
</body></html>
