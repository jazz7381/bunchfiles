<?php
/**
 * Available filters for extending Merlin WP.
 *
 * @package   Merlin WP
 * @version   @@pkg.version
 * @link      https://merlinwp.com/
 * @author    Rich Tabor, from ThemeBeans.com & the team at ProteusThemes.com
 * @copyright Copyright (c) 2018, Merlin WP of Inventionn LLC
 * @license   Licensed GPLv3 for Open Source Use
 */
 /**
  * Add your widget area to unset the default widgets from.
  * If your theme's first widget area is "sidebar-1", you don't need this.
  *
  * @see https://stackoverflow.com/questions/11757461/how-to-populate-widgets-on-sidebar-on-theme-activation
  *
  * @param  array $widget_areas Arguments for the sidebars_widgets widget areas.
  * @return array of arguments to update the sidebars_widgets option.
  */


function prefix_merlin_local_import_files() {
	return array(
		array(
			'import_file_name'             => 'BESTIA LIGHT',
			'local_import_file'            => trailingslashit( get_template_directory() ) . 'merlin/data/content.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'merlin/data/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'merlin/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( get_template_directory() ) . 'merlin/data/redux_options.json',
					'option_name' => 'awpt',
				),
			),
			'import_preview_image_url'     => trailingslashit( get_template_directory() ) . 'merlin/data/light.jpg',
			'preview_url'                  => 'https://bestia.mytubepress.com/light',
		),
		array(
			'import_file_name'             => 'BESTIA DARK',
			'local_import_file'            => trailingslashit( get_template_directory() ) . 'merlin/data/content.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'merlin/data/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'merlin/customizer2.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( get_template_directory() ) . 'merlin/data/dark/redux_options.json',
					'option_name' => 'redux_option_name2',
				),
			),
			'import_preview_image_url'     =>  trailingslashit( get_template_directory() ) . 'merlin/data/dark.jpg',
			'preview_url'                  => 'https://bestia.mytubepress.com/dark',
		),
	);
}

add_filter( 'merlin_import_files', 'prefix_merlin_local_import_files' );
function prefix_merlin_unset_default_widgets_args( $widget_areas ) {

 $widget_areas = array(
	 'sidebar-1' => array(),
 );

 return $widget_areas;
}
add_filter( 'merlin_unset_default_widgets_args', 'prefix_merlin_unset_default_widgets_args' );

/**
 * Execute custom code after the whole import has finished.
 */
function prefix_merlin_after_import_setup() {
	// Assign menus to their locations.
	$top_left = get_term_by( 'name', 'Top Bar', 'nav_menu' );
	$main_nav = get_term_by( 'name', 'Main Navigation', 'nav_menu' );
  $main_right = get_term_by( 'name', 'Nav Right', 'nav_menu' );

	set_theme_mod(
		'nav_menu_locations', array(
			'primary' => $top_left->term_id,
			'secondary' => $main_nav->term_id,
			'secondary-right' => $main_right->term_id,
		)
	);

	// Assign front page and posts page (blog page).
	$front_page_id = get_page_by_title( 'Videos' );
	//$blog_page_id  = get_page_by_title( 'Blog' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front_page_id->ID );
	//update_option( 'page_for_posts', $blog_page_id->ID );
	update_option('z_taxonomy_image'.$term_id, $_POST['taxonomy_image'], NULL);

	global $wp_rewrite;
	$wp_rewrite->set_permalink_structure('/%postname%/');
	$wp_rewrite->flush_rules();
	$args = array(
					'post_type' => 'post',
					'numberposts' => -1
			);
			$post_types = get_posts($args);
			foreach ($post_types as $mypost){
					$mypost->post_title = $mypost->post_title.'';
					wp_update_post( $mypost );
			}

}
add_action( 'merlin_after_all_import', 'prefix_merlin_after_import_setup' );
