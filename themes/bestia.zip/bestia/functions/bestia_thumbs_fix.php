<?php if( !defined('ABSPATH') ) exit;

//Full width thumbnails layout (homepage)
if( !function_exists('full_width_thumbs') ){
	function full_width_thumbs() {
		global $awpt;
    if ($awpt['homepage-layout'] == "1" && is_front_page()) {

    }

		if ($awpt['channel-archive-layout'] == "1" && is_tax('channel') ) {
			print '<style>
			@media screen and (min-width: 1260px) {
				.channel_taxonomy .Thumbnail_List .thumi img {height: 160px;}
				.channel_taxonomy .Thumbnail_List .thumbphoto img {height: 270px;}
			}
			@media screen and (min-width: 1210px) {
				.channel_taxonomy .Thumbnail_List .thumi img {height: 150px;}
				.channel_taxonomy .Thumbnail_List .thumbphoto img {height: 260px;}
			}
			@media screen and (min-width: 1118px) {
				.channel_taxonomy .Thumbnail_List .thumi img {height: 170px;}
				.channel_taxonomy .Thumbnail_List .thumbphoto img {height: 280px;}
			}
			@media screen and (max-width: 1117px) {
				.channel_taxonomy .Thumbnail_List .thumi img {height: 155px;}
				.channel_taxonomy .Thumbnail_List .thumbphoto img {height: 260px;}
			}
			</style>';
		}

		if ($awpt['performer-archive-layout'] == "1" && is_tax('performer') ) {
			print '<style>
			@media screen and (min-width: 1260px) {
				.performer_taxonomy .Thumbnail_List .thumi img {height: 160px;}
				.performer_taxonomy .Thumbnail_List .thumbphoto img {height: 270px;}
			}
			@media screen and (min-width: 1210px) {
				.performer_taxonomy .Thumbnail_List .thumi img {height: 150px;}
				.performer_taxonomy .Thumbnail_List .thumbphoto img {height: 260px;}
			}
			@media screen and (min-width: 1118px) {
				.performer_taxonomy .Thumbnail_List .thumi img {height: 170px;}
				.performer_taxonomy .Thumbnail_List .thumbphoto img {height: 280px;}
			}
			@media screen and (max-width: 1117px) {
				.performer_taxonomy .Thumbnail_List .thumi img {height: 155px;}
				.performer_taxonomy .Thumbnail_List .thumbphoto img {height: 260px;}
			}
			</style>';
		}
	}
add_action('wp_head', 'full_width_thumbs', 10);
}
//Full width thumbnails layout (category list template)
if( !function_exists('full_width_category_page') ){
	function full_width_category_page() {
		global $post;
    $sidebar = get_post_meta( $post->ID, 'sidebar_position', true );
    if ($sidebar == "0side-cm") {
      print '<style>
			.category-list .Thumbnail_List li {width:19.4%;}
      @media screen and (min-width: 1260px) {
        .category-list .Thumbnail_List .thumi img {height: 160px;}
        .category-list .Thumbnail_List .thumbphoto img {height: 270px;}
      }
      @media screen and (min-width: 1210px) {
        .category-list .Thumbnail_List .thumi img {height: 150px;}
        .category-list .Thumbnail_List .thumbphoto img {height: 260px;}
      }
      @media screen and (min-width: 1118px) {
        .category-list .Thumbnail_List .thumi img {height: 170px;}
        .category-list .Thumbnail_List .thumbphoto img {height: 280px;}
      }
      @media screen and (max-width: 1117px) {
        .category-list .Thumbnail_List .thumi img {height: 155px;}
        .category-list .Thumbnail_List .thumbphoto img {height: 260px;}
      }
      </style>';
    }
	}
add_action('wp_head', 'full_width_category_page', 10);
}
if( !function_exists('full_width_channel') ){
	function full_width_channel() {
		global $post;
    $sidebar = get_post_meta( $post->ID, 'sidebar_position', true );
    if ($sidebar == "0side-cm") {
      print '<style>
			.channel-list .Thumbnail_List li {width:19.4%;}
      @media screen and (min-width: 1260px) {
        .channel-list .Thumbnail_List .thumi img {height: 170px;}
      }
      @media screen and (min-width: 1210px) {
        .channel-list .Thumbnail_List .thumi img {height: 160px;}
      }
      @media screen and (min-width: 1118px) {
        .channel-list .Thumbnail_List .thumi img {height: 170px;}
      }
      @media screen and (max-width: 1117px) {
        .channel-list .Thumbnail_List .thumi img {height: 155px;}
      }
      </style>';
    }
	}
add_action('wp_head', 'full_width_channel', 10);
}
