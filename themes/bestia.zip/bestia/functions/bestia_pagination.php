<?php if( !defined('ABSPATH') ) exit;
/* Add Function Numeric Pagination adultwpthemes.eu . ------------------------------------*/
function adultwpthemes_pagination($args = null) {
	global $awpt;
	   if ( wp_is_mobile() ) {
      $ranger = '1'; $pagination_next = '<i class="fa fa-arrow-right"></i>'; $pagination_prev = '<i class="fa fa-arrow-left"></i>';
	   } else {
      $ranger = '3'; $pagination_next = $awpt['pagination_next']; $pagination_prev = $awpt['pagination_prev'];
      }
	   $defaults = array(
		'page' => null, 'pages' => null,
		'range' => $ranger, 'gap' => $ranger, 'anchor' => 1,
		'before' => '<div class="pager">', 'after' => '</div>',
		'title' => __('Pages:'),
		'nextpage' => $pagination_next,
		'previouspage' => $pagination_prev,
		'echo' => 1
	);

	$r = wp_parse_args($args, $defaults);
	extract($r, EXTR_SKIP);

	if (!$page && !$pages) {
		global $wp_query;

		$page = get_query_var('paged');
		$page = !empty($page) ? intval($page) : 1;

		$posts_per_page = intval(get_query_var('posts_per_page'));
		$pages = intval(ceil($wp_query->found_posts / $posts_per_page));
	}

	$output = "";
	if ($pages > 1) {
	$output .= "$before";
		$ellipsis = "<span class='page-numbers dots'>...</span>";

		if ($page > 1 && !empty($previouspage)) {
			$output .= "<a href='" . get_pagenum_link($page - 1) . "' class='page page-prev'>$previouspage</a>";
		}

		$min_links = $range * 2 + 1;
		$block_min = min($page - $range, $pages - $min_links);
		$block_high = max($page + $range, $min_links);
		$left_gap = (($block_min - $anchor - $gap) > 0) ? true : false;
		$right_gap = (($block_high + $anchor + $gap) < $pages) ? true : false;

		if ($left_gap && !$right_gap) {
			$output .= sprintf('%s%s%s',
				awpt_pagination_loop(1, $anchor),
				$ellipsis,
				awpt_pagination_loop($block_min, $pages, $page)
			);
		}
		else if ($left_gap && $right_gap) {
			$output .= sprintf('%s%s%s%s%s',
				awpt_pagination_loop(1, $anchor),
				$ellipsis,
				awpt_pagination_loop($block_min, $block_high, $page),
				$ellipsis,
				awpt_pagination_loop(($pages - $anchor + 1), $pages)
			);
		}
		else if ($right_gap && !$left_gap) {
			$output .= sprintf('%s%s%s',
				awpt_pagination_loop(1, $block_high, $page),
				$ellipsis,
				awpt_pagination_loop(($pages - $anchor + 1), $pages)
			);
		}
		else {
			$output .= awpt_pagination_loop(1, $pages, $page);
		}

		if ($page < $pages && !empty($nextpage)) {
			$output .= "<a href='" . get_pagenum_link($page + 1) . "' class='page page-next'>$nextpage</a>";
		}

		$output .= $after;
	}

	if ($echo) {
		echo $output;
	}

	return $output;
}

function awpt_pagination_loop($start, $max, $page = 0) {
	$output = "";
	for ($i = $start; $i <= $max; $i++) {
		$output .= ($page === intval($i))
			? "<span class='page-numbers current'>$i</span>"
			: "<a href='" . get_pagenum_link($i) . "' class='page page-mobile'>$i</a>";
	}
	return $output;
}
