<?php
if( !defined('ABSPATH') ) exit;
if( !function_exists('bestia_a_to_z_pagination') ) {
function bestia_a_to_z_pagination() {
//$url = '?showall=true';
$order = isset( $_REQUEST['sortby'] ) ?  trim($_REQUEST['sortby']) : null;
$sort_array = array( 'A'	=>	__('A'), 'B'	=>	__('B'), 'C'	=>	__('C'), 'D'	=>	__('D'), 'E'	=>	__('E'), 'F'	=>	__('F'),
'G'	=>	__('G'), 'H'	=>	__('H'), 'I'	=>	__('I'), 'J'	=>	__('J'), 'K'	=>	__('K'), 'L'	=>	__('L'), 'M'	=>	__('M'),
'N'	=>	__('N'),'O'	=>	__('O'), 'P'	=>	__('P'), 'Q'	=>	__('Q'), 'R'	=>	__('R'), 'S'	=>	__('S'), 'T'	=>	__('T'),
'U'	=>	__('U'), 'V'	=>	__('V'), 'W'	=>	__('W'), 'X'	=>	__('X'), 'Y'	=>	__('Y'), 'Z'	=>	__('Z')
);
$block = '';
$block = '<div class="dropdown a_to_z pull-right">
<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">'.__('A-Z').'<span class="caret"></span></button>
<ul class="dropdown-menu">';
foreach ( (array)$sort_array as $key=>$value ){
	$active = ( $order == $key ) ? 'active' : null;
		$block .= '<li><a class="'.$active.'" href="'.get_permalink().'?sortby='.$key.'">'.$value.'</a></li>';
	}
	$block .= '<li><a href="'.get_permalink().'"><i class="fa fa-times-circle" aria-hidden="true"></i></a></li></ul></div>';
   print $block;
}
add_action('bestia_a_to_z_pagination', 'bestia_a_to_z_pagination');
}

if( !function_exists('bestia_order_performers_by') ){
	function bestia_order_performers_by() {
		global $awpt,$post;
		$newpage_url = admin_url('post-new.php?post_type=page');

		/*
		$performers_page = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-performers.php') ) ;
		$performerSET = isset($performers_page[0]->ID) ? $performers_page[0]->ID : $newpage_url;
		$performers_page_url = get_permalink( $performerSET );
    */

		$male_template = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-performers-male.php') ) ;
		$maleSET = isset($male_template[0]->ID) ? $male_template[0]->ID : $newpage_url;
		$male_template_link = get_permalink( $maleSET );

		$female_template = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-performers-female.php') ) ;
		$femaleSET = isset($female_template[0]->ID) ? $female_template[0]->ID : $newpage_url;
		$female_template_link = get_permalink( $femaleSET );

		$ts_template = get_pages( array('meta_key' => '_wp_page_template','meta_value' => 'template-performers-ts.php') ) ;
		$tsSET = isset($ts_template[0]->ID) ? $ts_template[0]->ID : $newpage_url;
		$ts_template_link = get_permalink( $tsSET );

				$block = '<div class="dropdown pull-right"><button class="btn btn-primary pull-right dropdown-toggle" type="button" data-toggle="dropdown">'.$awpt['gender_btn'].'<span class="caret"></span></button><ul class="dropdown-menu">';

				$block .= '<li><a href="'.$female_template_link.'"><span class="women_btn">' .$awpt['women_btn'] . '</span></a></li>';

				$block .= '<li><a href="'.$male_template_link.'"><span class="men_btn">' .$awpt['men_btn'] . '</span></a></li>';

				$block .= '<li><a href="'.$ts_template_link.'"><span class="trans_btn">' .$awpt['trans_btn'] . '</span></a></li>';

				$block .= '</ul></div>';

				print $block;

	}
	add_action('bestia_order_performers_by', 'bestia_order_performers_by');
}

//Taxonomy Pagination
function taxonomy_pagination( $totalpages, $page, $end_size, $mid_size ) {
	  global $awpt;
		$page_next = $awpt['pagination_next'];
		$page_prev = $awpt['pagination_prev'];
		if ( wp_is_mobile() ) {
			$ranger = $mid_size;
		} else {
			$ranger = '3';
		}
		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
    $bignum = 999999999;
    if ( $totalpages <= 1 || $page > $totalpages ) return;
		
		return paginate_links( array(
        'base'          => str_replace( $bignum, '%#%', esc_url( get_pagenum_link( $bignum ) ) ),
        'format'        => '',
        'current'       => max( 1, $paged ),
				'showall'       => false,
        'total'         => $totalpages,
			 	'prev_text'     => $page_prev,
 			  'next_text'     => $page_next,
        'show_all'      => false,
        'end_size'      => $end_size,
        'mid_size'      => $ranger
    ) );
}
