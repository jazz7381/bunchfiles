<?php
if( !defined('ABSPATH') ) exit;
/* Add wmode transparent to media embeds adultwpthemes.eu . ------------------------------------*/
function bestia_embed_wmode_transparent( $html, $url, $attr ) {
	if ( strpos( $html, "<embed src=" ) !== false )
	   { return str_replace('</param><embed', '</param><param name="wmode" value="opaque"></param><embed wmode="opaque" ', $html); }
	elseif ( strpos ( $html, 'feature=oembed' ) !== false )
	   { return str_replace( 'feature=oembed', 'feature=oembed&wmode=opaque', $html ); }
	else
	   { return $html; }
}
if( !function_exists( 'bestia_setup' ) ){
	function bestia_setup() {
		//------------------------------ Load Language -----------------------------------------//
		load_theme_textdomain('bestia', get_template_directory() . '/languages');
		//------------------------------ Add Theme Support -----------------------------------------//
		add_theme_support('menus');
		add_theme_support('post-thumbnails');
		add_theme_support( 'title-tag' );
		add_theme_support('woocommerce');
		add_theme_support( 'jetpack-responsive-videos');
		add_theme_support( 'automatic-feed-links' );
		//------------------------------ Add Image Size -----------------------------------------//
		add_image_size( 'thumb-photo',  260, 310, array( 'center', 'top' ) );
		add_image_size( 'thumb-video', 260, 175, true );
		add_image_size( 'small', 100, 74, true );
		add_image_size( 'blogthumb', 200, 180, true );
		add_image_size( 'thumb-star', 316, 445, true );
	}
	add_action('after_setup_theme', 'bestia_setup');
}
/* Add time ago for posts adultwpthemes.eu . ------------------------------------*/
function time_ago( $type = 'post' ) {
    $d = 'comment' == $type ? 'get_comment_time' : 'get_post_time';

    return human_time_diff($d('U'), current_time('timestamp'));

}
add_filter('widget_text','do_shortcode');
// unregister all default WP Widgets
function unregister_default_wp_widgets() {
  unregister_widget('WP_Widget_Calendar');
  unregister_widget('WP_Widget_Meta');
  //unregister_widget('WP_Widget_Categories');
  unregister_widget('WP_Widget_Search');
  unregister_widget('WP_Widget_Recent_Comments');
  unregister_widget('WP_Widget_Pages');
  unregister_widget('WP_Widget_Archives');
  unregister_widget('WP_Widget_RSS');
  unregister_widget('WP_Widget_Akismet');
}
add_action('widgets_init', 'unregister_default_wp_widgets', 1);

/* Add Custom field function for the wp-tube-plugin adultwpthemes.eu . ------------------------------------*/
function tube_getcustomfield($filedname, $page_current_id = NULL)
{

	if($page_current_id==NULL)
		 $page_current_id = get_page_id();

	$value = get_post_meta($page_current_id, $filedname, true);
	return $value;
}

/* Add Menus ------------------------------------*/
	register_nav_menus( array(
		'primary' => __( 'Top Bar Navigation (Left Side)', 'bestia' ),
		'secondary' => __( 'Main Navigation (Left Side)', 'bestia' ),
		'secondary-right' => __( 'Main Navigation (Right Side)', 'bestia' ),
	) );
function wpb_widgets_init() {
		global $awpt;
		$h_tag_sidebar = $awpt['sidebar_title_heading'];
		$h_tag_footer = $awpt['footer_title_heading'];
		$footerw = isset($awpt['mtn_footwidgts']) ? $awpt['mtn_footwidgts'] : '';
		register_sidebar( array(
		'name' => __( 'General Sidebar', 'bestia' ),
		'id' => 'sidebar-2',
		'description' => __( 'The main sidebar wich appears on the left side on each page including the home page.', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
	register_sidebar( array(
		'name' => __( 'Single Video Sidebar (left)', 'bestia' ),
		'id' => 'sidebar-5',
		'description' => __( 'The sidebar of your single template', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
	register_sidebar( array(
		'name' => __( 'Single Video Sidebar (right)', 'bestia' ),
		'id' => 'sidebar-video-right',
		'description' => __( 'The sidebar of your single template', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
	register_sidebar( array(
		'name' => __( 'Video Category Sidebar', 'bestia' ),
		'id' => 'sidebar-cat',
		'description' => __( 'The sidebar of your video category list', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
	if( $awpt['blogs_cpt'] == 1 ){
		register_sidebar( array(
			'name' => __( 'Blog Sidebar', 'bestia' ),
			'id' => 'sidebar-3',
			'description' => __( 'The sidebar of your blog template', 'bestia' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
			'after_title' => '</'.$h_tag_sidebar.'>',
		) );
		register_sidebar( array(
			'name' => __( 'Single Blog (LEFT)', 'bestia' ),
			'id' => 'sidebar-single-blog',
			'description' => __( 'The sidebar of your single blog post.', 'bestia' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
			'after_title' => '</'.$h_tag_sidebar.'>',
		) );
		register_sidebar( array(
			'name' => __( 'Single Blog (RIGHT)', 'bestia' ),
			'id' => 'sidebar-single-blog-right',
			'description' => __( 'The sidebar of your single blog post.', 'bestia' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
			'after_title' => '</'.$h_tag_sidebar.'>',
		) );
	}
	register_sidebar( array(
		'name' => __( 'Channels Sidebar', 'bestia' ),
		'id' => 'channel-cat',
		'description' => __( 'The sidebar which appears on your channel list and archives', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
		register_sidebar( array(
		'name' => __( 'Page Sidebar (LEFT - 200px)', 'bestia' ),
		'id' => 'sidebar-6',
		'description' => __( 'Appears on the left side of your pages', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
		register_sidebar( array(
		'name' => __( 'Page Sidebar (RIGHT - 300px)', 'bestia' ),
		'id' => 'sidebar-page-right',
		'description' => __( 'Appears on the right side of your pages', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
if( $awpt['gallery_cpt'] == 1 ){
	register_sidebar( array(
		'name' => __( 'Photo Gallery Sidebar', 'bestia' ),
		'id' => 'sidebar-7',
		'description' => __( 'The sidebar of photo gallery', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
	register_sidebar( array(
		'name' => __( 'Single Gallery Sidebar (LEFT: 200px)', 'bestia' ),
		'id' => 'sidebar-8',
		'description' => __( 'The sidebar of photo gallery single page', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
	register_sidebar( array(
		'name' => __( 'Single Gallery Sidebar (RIGHT: 300px)', 'bestia' ),
		'id' => 'gallery-right',
		'description' => __( 'The right sidebar of the single gallery page.', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
}
if( $awpt['gifs_cpt'] == 1 ){
	register_sidebar( array(
		'name' => __( 'GIFS Gallery Sidebar', 'bestia' ),
		'id' => 'sidebar-gif',
		'description' => __( 'The sidebar of your gif gallery', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
	register_sidebar( array(
		'name' => __( 'Single GIF Sidebar (LEFT: 200px)', 'bestia' ),
		'id' => 'gif-left',
		'description' => __( 'The left sidebar your single gif page.', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
	register_sidebar( array(
		'name' => __( 'Single GIF Sidebar (RIGHT: 300px)', 'bestia' ),
		'id' => 'gif-right',
		'description' => __( 'The right sidebar of the single gif page.', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
}

	register_sidebar( array(
		'name' => __( 'Performers Page Sidebar', 'bestia' ),
		'id' => 'sidebar-performer',
		'description' => __( 'The left sidebar of your performer list  page template', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
   if ($footerw == "ftdisable") {
   } else {
	register_sidebar(array(
      'name' => 'Footer Widget 1',
      'id'        => 'footer-1',
      'description' => 'First footer widget area',
      'before_widget' => '<div class="col-lg-3 col-md-6 widget">',
      'after_widget' => '</div>',
      'before_title' => '<'.$h_tag_footer.'>',
      'after_title' => '</'.$h_tag_footer.'>',
   ) );
   register_sidebar(array(
      'name' => 'Footer Widget 2',
      'id'        => 'footer-2',
      'description' => 'Second footer widget area',
      'before_widget' => '<div class="col-lg-3 col-md-6 widget">',
      'after_widget' => '</div>',
      'before_title' => '<'.$h_tag_footer.'>',
      'after_title' => '</'.$h_tag_footer.'>',
    ) );
    register_sidebar(array(
     'name' => 'Footer Widget 3',
     'id'        => 'footer-3',
     'description' => 'Third footer widget area',
     'before_widget' => '<div class="col-lg-3 col-md-6 widget">',
     'after_widget' => '</div>',
     'before_title' => '<'.$h_tag_footer.'>',
     'after_title' => '</'.$h_tag_footer.'>',
    ) );
    register_sidebar(array(
     'name' => 'Footer Widget 4',
     'id'        => 'footer-4',
     'description' => 'Fourth footer widget area',
     'before_widget' => '<div class="col-lg-3 col-md-6 widget">',
     'after_widget' => '</div>',
     'before_title' => '<'.$h_tag_footer.'>',
     'after_title' => '</'.$h_tag_footer.'>',
    ) );
}
if ( function_exists('bp_is_active') ) {
	register_sidebar( array(
		'name' => __( 'Buddypress Sidebar (LEFT - 200px)', 'bestia' ),
		'id' => 'buddy-left',
		'description' => __( 'The left sidebar of your buddypress templates', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
	'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
	register_sidebar( array(
		'name' => __( 'Buddypress Sidebar (RIGHT - 300px)', 'bestia' ),
		'id' => 'buddy-right',
		'description' => __( 'The right sidebar of your buddypress templates', 'bestia' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<'.$h_tag_sidebar.' class="widget-title">',
		'after_title' => '</'.$h_tag_sidebar.'>',
	) );
}
}

add_action( 'widgets_init', 'wpb_widgets_init' );

/* Add Post Views adultwpthemes.eu . ------------------------------------*/
function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0 ";
    }
    return $count.' ';
}
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
//Ajax Pot Views
function bestia_set_post_views() {
    $nonce = $_POST['nonce'];
    if ( ! wp_verify_nonce( $nonce, 'ajax-nonce' ) )
      die ( 'Busted!');

    if( ! isset($_POST['post_id'] ) ){
      die ( 'post id required!');
    }

    $postID = $_POST['post_id'];

    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count == ''){
      $count = 0;
      delete_post_meta($postID, $count_key);
      add_post_meta($postID, $count_key, '0');
    }else{
      $count++;
      update_post_meta($postID, $count_key, $count);
    }

    wp_send_json(array('views' => $count));
    wp_die();
}
add_action('wp_ajax_nopriv_post-views', 'bestia_set_post_views');
add_action('wp_ajax_post-views', 'bestia_set_post_views');

//Ajax POst likes
function bestia_get_async_post_data() {
    $nonce = $_POST['nonce'];

    if ( ! wp_verify_nonce( $nonce, 'ajax-nonce' ) )
        die ( 'Busted!');

    if(isset($_POST['post_id'])){
        wp_send_json(
            array(
                'views'     => (int) bestia_getPostViews($_POST['post_id']),
                'likes'     => (int) get_post_meta($_POST['post_id'], 'likes_count', true),
                'dislikes'  => (int) get_post_meta($_POST['post_id'], 'dislikes_count', true ),
                'rating'    => bestia_getPostLikeRate($_POST['post_id'])
            )
        );
    } else {
        return false;
    }
    wp_die();
}

add_action('wp_ajax_nopriv_get-post-data', 'bestia_get_async_post_data');
add_action('wp_ajax_get-post-data', 'bestia_get_async_post_data');
/* Add Tags Style adultwpthemes.eu . ------------------------------------*/
function wpb_tags() {
$wpbtags =  get_tags();
foreach ($wpbtags as $tag) {
$string .= '<span class="tagbox"><a class="taglink" href="'. get_tag_link($tag->term_id) .'">'. $tag->name . '</a><span class="tagcount">'. $tag->count .'</span></span>' . "\n"   ;
}
return $string;
}
add_shortcode('wpbtags' , 'wpb_tags' );

/* Add custom field meta box for HD Videos adultwpthemes.eu . ------------------------------------*/
/* Define the custom box */
add_action( 'add_meta_boxes', 'bestia_hd_add_custom_box' );

/* Do something with the data entered */
add_action( 'save_post', 'bestia_hd_save_postdata' );

/* Adds a box to the main column on the Post and Page edit screens */
function bestia_hd_add_custom_box() {
    add_meta_box(
        'bestia_hd_sectionid',
        'High Definition Content?',
        'bestia_hd_inner_custom_box',
        array('post', 'gallery'),
        'side',
        'high'
    );
}

/* Prints the box content */
function bestia_hd_inner_custom_box($post) {
    // Use nonce for verification
    wp_nonce_field( 'bestia_hd_bestia_hd_field_nonce', 'bestia_hd_noncename' );

    // Get saved value, if none exists, "default" is selected
    $saved = get_post_meta( $post->ID, 'hd_flag', true);
    if( !$saved )
        $saved = 'default';

    $fields = array(
        'hd'       => __('Check if Video is HD', 'bestia'),
    );

		foreach($fields as $key => $label)
    {
        printf(
					'<div class="onoffswitch">
							<input type="checkbox" name="hd_flag" class="onoffswitch-checkbox" id="myonoffswitch" value="%1$s" id="hd_flag[%1$s]" %3$s>
							 <label class="onoffswitch-label" for="myonoffswitch">
								<span class="onoffswitch-inner"></span>
								<span class="onoffswitch-switch"></span>
							</label>
					</div>',
          esc_attr($key),
          esc_html($label),
          checked($saved, $key, false)
        );
    }
}
//Short category description
function short_desc($after = '', $length,$desc) {
    $mytitle = $desc;
    if ( strlen($mytitle) > $length ) {
    $mytitle = substr($mytitle,0,$length);
    echo rtrim($mytitle).$after;
    } else {
    echo $mytitle;
    }
}
/* When the post is saved, saves our custom data */
function bestia_hd_save_postdata( $post_id )
{
      // verify if this is an auto save routine.
      // If it is our form has not been submitted, so we dont want to do anything
      if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
          return;

      // verify this came from the our screen and with proper authorization,
      // because save_post can be triggered at other times
      if ( isset($_POST['bestia_hd_noncename']) && !wp_verify_nonce($_POST['bestia_hd_noncename'], 'bestia_hd_bestia_hd_field_nonce' ) )
      // Old Version Removed Notice Above - if ( !wp_verify_nonce( $_POST['bestia_hd_noncename'], 'bestia_hd_bestia_hd_field_nonce' ) )
          return;

      if ( isset($_POST['hd_flag']) && $_POST['hd_flag'] != "" ){
            update_post_meta( $post_id, 'hd_flag', $_POST['hd_flag'] );
      }
}

//Remove admin bar sections
function remove_admin_menu_bar_items ($wp_toolbar) {
    $wp_toolbar->remove_node( 'my-sites' );
    $wp_toolbar->remove_node( 'wp-logo' );
    $wp_toolbar->remove_node( 'new-content' );
    $wp_toolbar->remove_node( 'view' );
    $wp_toolbar->remove_node( 'search' );  // remove the search element
    return $wp_toolbar;
}
add_filter( 'admin_bar_menu', 'remove_admin_menu_bar_items' );
/* Remove Pages from Search loop adultwpthemes.eu . ------------------------------------*/
function remove_pages_from_search() {
    global $wp_post_types;
    $wp_post_types['page']->exclude_from_search = true;
}
add_action('init', 'remove_pages_from_search');
/* Remove the URL Field from the comments form adultwpthemes.eu */
function remove_comment_url_fields($fields) {
    if(isset($fields['url']))
    {
         unset($fields['url']);
    }
    return $fields;
}
add_filter('comment_form_default_fields','remove_comment_url_fields');

/* Add nofollow to comment links adultwpthemes.eu */
function add_nofollow_to_reply_link( $link ) {
    return str_replace( '")\'>', '")\' rel=\'nofollow\'>', $link );
}
add_filter( 'comment_reply_link', 'add_nofollow_to_reply_link' );

// Custom Callback

function your_theme_slug_comments($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment; ?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
		<div class="comment-wrap">
			<div class="comment-img">
				<?php echo get_avatar($comment,$args['avatar_size'],null,null,array('class' => array('img-responsive', 'img-circle') )); ?>
			</div>
			<div class="comment-body">
				<h4 class="comment-author"><?php echo get_comment_author_link(); ?></h4>
				<span class="comment-date"><?php printf(__('%1$s at %2$s', 'bestia'), get_comment_date(),  get_comment_time()) ?></span>
				<?php if ($comment->comment_approved == '0') { ?><em><i class="fa fa-spinner fa-spin" aria-hidden="true"></i> <?php _e('Comment awaiting approval', 'bestia'); ?></em><br /><?php } ?>
				<?php comment_text(); ?>
				<span class="comment-reply"> <?php comment_reply_link(array_merge( $args, array('reply_text' => __('Reply', 'bestia'), 'depth' => $depth, 'max_depth' => $args['max_depth'])), $comment->comment_ID); ?></span>
			</div>
		</div>
<?php }

// Enqueue comment-reply

add_action('wp_enqueue_scripts', 'your_theme_slug_public_scripts');

function your_theme_slug_public_scripts() {
    if (!is_admin()) {
        if (is_singular() && get_option('thread_comments')) { wp_enqueue_script('comment-reply'); }
    }
}

add_action( 'admin_menu', 'gowp_admin_menu' );
function gowp_admin_menu() {
  global $menu;
  foreach ( $menu as $key => $val ) {
    if ( 'Posts' == $val[0] ) {
      $menu[$key][6] = 'dashicons-format-video';
    }
  }
}

function bestia_change_post_menu_label() {
    global $menu;
    global $submenu;
    $menu[5][0] = 'Videos';
    $submenu['edit.php'][5][0] = __( 'Videos', 'bestia' );
    $submenu['edit.php'][10][0] = __( 'Add New Video', 'bestia' );
    $submenu['edit.php'][15][0] = __( 'Video Categories', 'bestia' );
    $submenu['edit.php'][16][0] = __( 'Video Tags', 'bestia' );
}
add_action( 'admin_menu', 'bestia_change_post_menu_label' );

/* Get Custom Templates Slug adultwpthemes.eu . ------------------------------------*/
function get_template_url($template_name){
    global $wpdb;
    $permalink = '#';  // provide a default

    $RetriveURL = $wpdb->get_results( "SELECT post_id FROM wp_postmeta WHERE meta_value = '$template_name'" );
    foreach ($RetriveURL as $slug) {
        if (get_page($slug->post_id)) {
            $permalink = get_permalink($slug->post_id);
        }
    }

    return $permalink;
}
/* Give own css class to wordpress tag cloud adultwpthemes.eu . ------------------------------------*/
add_filter( 'wp_tag_cloud', 'wpse_50242_unstyled_tag_cloud' );

/**
 * Change tag cloud inline style to CSS classes.
 *
 * @param  string $tags
 * @return string
 */
function wpse_50242_unstyled_tag_cloud( $tags )
{
    return preg_replace(
        "~ style='font-size: (\d+)pt;'~",
        ' class="tag-cloud-size-\1"',
        $tags
    );
}
function prefix_theme_updater() {
 require( get_template_directory() . '/admin/bestia-framework/core/required/theme-updater.php' );
}

function duration_converter($seconds){
    $hours = floor((int)$seconds / 3600);
    $mins = floor(((int)$seconds - $hours*3600) / 60);
    $s = (int)$seconds - ($hours*3600 + $mins*60);
    $mins = ($mins<10?"0".$mins:"".$mins);
    $s = ($s<10?"0".$s:"".$s);
    $time = ($hours>0?$hours.":":"").$mins.":".$s;
    return $time;
}

function acf_description_field() {
global $awpt;
if ( $awpt['post_description_type'] == 1 ){
print '<style type="text/css">#acf-video_description {display: none !important;}</style>';
} else {}
}
add_action('admin_head', 'acf_description_field');

function showalltags() {

  $tags = get_tags();
	$html;
	foreach ($tags as $tag){
		$tag_link = get_tag_link($tag->term_id);

		$html .= "<a href='{$tag_link}' title='{$tag->name} Tag' class='{$tag->slug}'>";
		$html .= "{$tag->name}</a>";
	}
	echo $html;

}

/**
 * Disable the emoji's
 */
function disable_emojis() {
 remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
 remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
 remove_action( 'wp_print_styles', 'print_emoji_styles' );
 remove_action( 'admin_print_styles', 'print_emoji_styles' );
 remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
 remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
 remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
 add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
 add_filter( 'wp_resource_hints', 'disable_emojis_remove_dns_prefetch', 10, 2 );
}
add_action( 'init', 'disable_emojis' );

/**
 * Filter function used to remove the tinymce emoji plugin.
 *
 * @param array $plugins
 * @return array Difference betwen the two arrays
 */
function disable_emojis_tinymce( $plugins ) {
 if ( is_array( $plugins ) ) {
 return array_diff( $plugins, array( 'wpemoji' ) );
 } else {
 return array();
 }
}

/**
 * Remove emoji CDN hostname from DNS prefetching hints.
 *
 * @param array $urls URLs to print for resource hints.
 * @param string $relation_type The relation type the URLs are printed for.
 * @return array Difference betwen the two arrays.
 */
function disable_emojis_remove_dns_prefetch( $urls, $relation_type ) {
 if ( 'dns-prefetch' == $relation_type ) {
 /** This filter is documented in wp-includes/formatting.php */
 $emoji_svg_url = apply_filters( 'emoji_svg_url', 'https://s.w.org/images/core/emoji/2/svg/' );

$urls = array_diff( $urls, array( $emoji_svg_url ) );
 }

return $urls;
}

function back_to_gallery() {
    if ( !is_attachment() && is_singular('gallery') )
    return false;
		global $awpt;
    $current_attachment = get_queried_object();
    $permalink = get_permalink( $current_attachment->post_parent );
    $parent_title = get_post( $current_attachment->post_parent )->post_title;
    $link = '<a class="back-to-gallery btn btn-default" href="' . $permalink  . '"  title="' . $parent_title . '">' . $awpt['image_back'] . '</a>';
    return $link;
}
add_action('wp_footer', 'add_gallery_options');


/* The Post Tags Function using commas with or without links adultwpthemes.eu . ------------------------------------*/
function comma_tags($tags, $show_links = true) {
  if($tags)
  {
    $t = array();
    foreach($tags as $tag)
    {
      $t[] = (!$show_links) ? $tag->name : '<a href="' . get_tag_link($tag->term_id) . '">' . $tag->name . '</a>';
    }
    return implode(", ", $t);
  }
  else
  {
    return false;
  }
}

//Add a body class for logged in users, this will help us to add styles in css for logged in users only
add_filter('body_class','bestia_body_class_logged_in');
function bestia_body_class_logged_in($classes) {
    if ( is_user_logged_in() && current_user_can('administrator') ) {
        $classes[] = 'logged-in';
    }
    return $classes;
}

//Add count into span in category widgets.
add_filter('wp_list_categories', 'cat_count_span');
function cat_count_span($links) {
  $links = str_replace('</a>', '</a> <span class="count">', $links);
  $links = str_replace('', '</span>', $links);
  return $links;
}
function add_form_fields_example($term, $taxonomy){
    ?>
    <tr valign="top">
        <th scope="row">Description</th>
        <td>
            <?php wp_editor(html_entity_decode($term->description), 'description', array('media_buttons' => false)); ?>
            <script>
                jQuery(window).ready(function(){
                    jQuery('label[for=description]').parent().parent().remove();
                });
            </script>
        </td>
    </tr>
    <?php
}
function catch_gif_image_from_post() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches[1][0];

  if(empty($first_img)) {
    $first_img = "";
  }
  return $first_img;
}

function bestia_license_key_notice() {
	$store_url = 'http://mytubepress.com';
	$item_name = 'bestia';
	$license = trim( get_option( 'bestia_license_key' ) );
	$whitelist = array(
			'127.0.0.1',
			'::1'
	);
	$api_params = array(
		'edd_action' => 'check_license',
		'license' => $license,
		'item_name' => urlencode( $item_name ),
		'url' => home_url()
	);

	$response = wp_remote_post( $store_url, array( 'body' => $api_params, 'timeout' => 15, 'sslverify' => false ) );
	if ( is_wp_error( $response ) ) {
		return false;
	}

	$license_data = json_decode( wp_remote_retrieve_body( $response ) );

	$expired = '<div data-dismissible="disable-done-notice-forever" class="notice notice-error is-dismissible"><p>Looks like your license key is out of date. Please go to <a target="_blank" href="'.$store_url.'">account area</a> if you wish to renew this license key.</a></p>
	<div data-dismissible="disable-done-notice-forever" class="notice notice-warning is-dismissible"><p>BESTIA subjects to yearly license for support and updates. Even if the license is expired theme settings panel works normally, we do not limit anything except update notifications and support access.</p></div>
	</div>';
   $negative = '<div class="error">
			 <p>You have invalid license key for Bestia. Please go to the <a href="admin.php?page=bestia-license">License verification page</a> to correct this issue.</p>
			 <p>BESTIA subjects to yearly license for support and updates. Even if the license is expired theme settings panel works normally, we do not limit anything except update notifications and support access.</p>
	 </div>';
   $positive = '<div data-dismissible="disable-done-notice-forever" id="message" class="updated fade notice is-dismissible rlrsssl-success">
                <p>
                    BESTIA successfully activated on '.$_SERVER['SERVER_NAME'].'!&nbsp;
                    If you need any help feel free to ask at any time you wish, we stand behind our themes.                    &nbsp;
                    <a target="_blank" href="https://mytubepress.com/contact-us/">Get in touch</a>
                </p>
            <button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
						<div id="message" class="updated fade notice is-dismissible rlrsssl-success">
				                 <p>BESTIA subjects to yearly license for support and updates. Even if the license is expired theme settings panel works normally, we do not limit anything except update notifications.</p>
				             </div>';
	if( $license_data->license == 'valid' ) {
		//echo $positive;
	}	elseif( $license_data->license == 'expired' ) {
		echo $expired;
	} elseif(in_array($_SERVER['REMOTE_ADDR'], $whitelist)) {

	} else {
		echo $negative;
	}

}
add_action('admin_notices', 'bestia_license_key_notice');
//add_action('wp_footer', 'bestia_license_key_notice');

function bestia_license_key_status() {
	$store_url = 'http://mytubepress.com';
	$item_name = 'bestia';
	$license = trim( get_option( 'bestia_license_key' ) );
	$api_params = array(
		'edd_action' => 'check_license',
		'license' => $license,
		'item_name' => urlencode( $item_name ),
		'url' => home_url()
	);

	$response = wp_remote_post( $store_url, array( 'body' => $api_params, 'timeout' => 15, 'sslverify' => false ) );
	if ( is_wp_error( $response ) ) {
		return false;
	}

	$license_data = json_decode( wp_remote_retrieve_body( $response ) );

	$whitelist = array(
			'127.0.0.1',
			'::1'
	);

  if(in_array($_SERVER['REMOTE_ADDR'], $whitelist)) {
		$message = 'unnecessary in localhost';
	} elseif( $license_data->license == 'valid' ) {
		$message = 'is active' . ' - ' . $license;
	}	elseif( $license_data->license == 'expired' ) {
		$message = 'is out of date' . ' - ' . $license;
	} else {
		$message = 'invalid key' . ' - ' . $license;
	}
    return $message;
}
add_action('bestia_license_key_notice', 'bestia_license_key_notice');
