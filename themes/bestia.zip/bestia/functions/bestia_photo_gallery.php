<?php if( !defined('ABSPATH') ) exit;
if( !class_exists('bestia_photo_gallery') ){
	class bestia_photo_gallery {
		function __construct() {
			add_action('init', array($this,'register_my_cpt_gallery'));
		}
		function register_my_cpt_gallery() {
			global $awpt;
			$rewrite_slug = trim( $awpt['gallery_rewrite_slug'] ) ? trim( $awpt['gallery_rewrite_slug'] ) : 'gallery';
			$args = array(
				'label' => __('Photo gallery','bestia'),
				'description' => '',
				'public' => true,
				'menu_position' => 4,
				'has_archive'	=>true,
				'show_ui' => true,
				'show_in_menu' => true,
				'capability_type' => 'post',
				'map_meta_cap' => true,
				'hierarchical' => false,
				'menu_icon'	=>	'dashicons-format-image',
				'rewrite' => array('slug' => $rewrite_slug, 'with_front' => true),
				'query_var' => true,
				'supports' => array('title','editor','publicize','comments','thumbnail','author','post-formats'),
				'labels' => array (
					  'name' => __('Photo Gallery','bestia'),
					  'singular_name' => __('Photo Gallery','bestia'),
					  'menu_name' => __('Photos','bestia'),
					  'add_new' => __('Add Gallery','bestia'),
					  'add_new_item' => __('Add new gallery','bestia'),
					  'edit' => __('Edit','bestia'),
					  'edit_item' => __('Edit Gallery','bestia'),
					  'new_item' => __('New Gallery','bestia'),
					  'view' => __('View Gallerys','bestia'),
					  'view_item' => __('View galleries','bestia'),
					  'search_items' => __('Search Gallery','bestia'),
					  'not_found' => __('No gallery found','bestia'),
					  'not_found_in_trash' => __('No gallery Found in Trash','bestia'),
					  'parent' => __('Parent galleries','bestia'),
						'parent_item_colon' => _x( 'Parent Gallery:', 'bestia' ),
					)
			);
			$args	=	apply_filters( 'bestia_photo_gallery_args' , $args);
			if( $awpt['gallery_cpt'] == 1 ){
			  register_post_type('gallery', $args);
			}
		}
	}
	new bestia_photo_gallery();
}
