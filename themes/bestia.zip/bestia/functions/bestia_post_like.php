<?php if( !defined('ABSPATH') ) exit;
$timebeforerevote = 1;//1 * 60min * 24h
function load_postlike_script(){
	wp_register_script('like_post', get_template_directory_uri().'/assets/js/post-like/post-like.js', array('jquery'), '1.1', true );
    wp_enqueue_script('like_post');
    wp_localize_script('like_post', 'ajax_var', array(
    'url' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('ajax-nonce')
));
add_action('wp_ajax_nopriv_post-like', 'adultwpthemes_post_like');
add_action('wp_ajax_post-like', 'adultwpthemes_post_like');
}
add_action('init', 'load_postlike_script');

function adultwpthemes_hasAlreadyVoted($post_id)
{
	global $timebeforerevote;

	$meta_IP = get_post_meta($post_id, "voted_IP");
	$voted_IP = isset($meta_IP[0]) ? $meta_IP[0] : '';
	if(!is_array($voted_IP))
		$voted_IP = array();
	$ip = $_SERVER['REMOTE_ADDR'];

	if(in_array($ip, array_keys($voted_IP)))
	{
		$time = $voted_IP[$ip];
		$now = time();

		if(round(($now - $time) / 60) > $timebeforerevote)
			return false;

		return true;
	}

	return false;
}
function adultwpthemes_getPostLikeLink($post_id) {
	global $awpt;
   $output = '<ul class="rate_bar" id="flagging_container">';
	 $output = '<li class="item_rate like">
		          <a id="flag_like_this_video" href="#" data-post_id="'.$post_id.'" data-post_like="like" class="positivelike" data-tooltip="'.__('like', 'bestia').'">
			        <i class="fa fa-thumbs-up" id="positivelike"></i>
		          </a>
	            </li>
	            <li class="item_rate dislike">
		          <a id="flag_dislike_this_video" href="#" data-post_id="'.$post_id.'" data-post_like="dislike" class="negativelike" data-tooltip="'.__('Dislike', 'bestia').'">
			        <i class="fa fa-thumbs-down"></i>
		          </a>
	            </li>
							<div class="vote output-vote">
				      <span></span></div>';
  $output .= '</ul>';
 return $output;
}
function adultwpthemes_getPostLikeRate( $post_id ){
    $like_count     = get_post_meta($post_id, "likes_count", true);
    $dislike_count  = get_post_meta($post_id, "dislikes_count", true);
    $total_count    = (int)$like_count + (int)$dislike_count;
    if($total_count > 0)
        return (int)$like_count / (int)$total_count * 100;
    else
        return false;
}

function adultwpthemes_getItemPostLikeRate( $post_id ){

    if( adultwpthemes_getPostLikeRate($post_id) !== false )
        return floor( adultwpthemes_getPostLikeRate($post_id) ) . '%';
    else
        return '0%';

}
