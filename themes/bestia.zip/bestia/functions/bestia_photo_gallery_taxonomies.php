<?php if( !defined('ABSPATH') ) exit;
if( !class_exists('Bestia_Custom_Photo_Gallery_Taxonomies') ){
	class Bestia_Custom_Photo_Gallery_Taxonomies {
		function __construct() {
			add_action('init', array($this,'cptui_register_my_taxes_phototype'));
			add_action('init', array($this,'cptui_register_photo_gallery_taxes_key'));

			add_filter( 'cptui_register_my_taxes_phototype' , array( $this, 'rewrite_taxes_phototype' ), 10, 1 );
			add_filter( 'cptui_register_photo_gallery_taxes_key' , array( $this, 'rewrite_taxes_key' ), 10, 1 );
		}
		function cptui_register_my_taxes_phototype() {
			global $awpt;
			$labels = array(
				'name'              => __( 'Photo Categories', 'bestia' ),
				'singular_name'     => __( 'Photo Categories', 'bestia' ),
				'search_items'      => __( 'Search Photo Category','bestia' ),
				'all_items'         => __( 'All Photo Category','bestia' ),
				'parent_item'       => __( 'Parent Photo Category','bestia' ),
				'parent_item_colon' => __( 'Parent Photo Category:','bestia' ),
				'edit_item'         => __( 'Edit Photo Category','bestia' ),
				'update_item'       => __( 'Update Photo Category','bestia' ),
				'add_new_item'      => __( 'Add New Photo Category','bestia' ),
				'new_item_name'     => __( 'New Photo Category','bestia' ),
				'menu_name'         => __( 'Photo Categories','bestia' ),
			);

			$args = array( 'hierarchical' => true,
				'label' => __( 'Gallery Category', 'bestia' ),
				'show_ui' => true,
				'query_var' => true,
				'show_admin_column' => true,
				'labels' => $labels,
				'rewrite'    => array( 'slug' => 'phototype' )
			);
			$args = apply_filters( 'cptui_register_my_taxes_phototype' , $args);
			if( $awpt['gallery_cpt'] == 1 ){
				register_taxonomy( 'phototype',array ( 0 => 'gallery' ), $args );
			}
		}

		function rewrite_taxes_phototype( $args ){
			global $awpt;
			if( isset( $awpt['rewrite_slug_gallery_category'] ) && $awpt['rewrite_slug_gallery_category'] != 'phototype' ){
				$args['rewrite'] = array(
					'slug'	=> esc_attr( $awpt['rewrite_slug_gallery_category'] )
				);
			}
			return $args;
		}

		function cptui_register_photo_gallery_taxes_key() {
			global $awpt;
			$labels = array(
				'name'              => __( 'Photo Tags', 'bestia' ),
				'singular_name'     => __( 'Photo Tags', 'bestia' ),
				'search_items'      => __( 'Photo Tag','bestia' ),
				'all_items'         => __( 'All Photo Tag','bestia' ),
				'parent_item'       => __( 'Parent Photo Tag','bestia' ),
				'parent_item_colon' => __( 'Parent Photo Tag:','bestia' ),
				'edit_item'         => __( 'Edit Photo Tag','bestia' ),
				'update_item'       => __( 'Update Photo Tag','bestia' ),
				'add_new_item'      => __( 'Add New Photo Tag','bestia' ),
				'new_item_name'     => __( 'New Photo Tag','bestia' ),
				'menu_name'         => __( 'Photo Tags','bestia' ),
			);
			$args = array( 'hierarchical' => false,
				'label' => __( 'Gallery Tag', 'bestia' ),
				'rewrite'    => array( 'slug' => 'blog_tag' ),
				'show_ui' => true,
				'query_var' => true,
				'show_admin_column' => true,
				'labels' => $labels
			);
			$args = apply_filters( 'cptui_register_photo_gallery_taxes_key' , $args);

			if( $awpt['gallery_cpt'] == 1 ){
				register_taxonomy( 'photo_tag',array ( 0 => 'gallery' ), $args );
			}
		}

		function rewrite_taxes_key( $args ){
			global $awpt;
			if( isset( $awpt['rewrite_slug_gallery_tag'] ) && $awpt['rewrite_slug_gallery_tag'] != 'blog_tag' ){
				$args['rewrite'] = array(
					'slug'	=> esc_attr( $awpt['rewrite_slug_gallery_tag'] )
				);
			}
			return $args;
		}

	}
	new Bestia_Custom_Photo_Gallery_Taxonomies();
}
