<?php
if( !defined('ABSPATH') ) exit;
function bestia_ajax_login_form() { ?>
<div class="pull-right" id="login_form">
     <a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Login</b> <span class="caret"></span></a>
     <ul id="login-dp" class="dropdown-menu">
       <li>
          <div class="row">
             <div class="col-md-12">



               <?php //_e('Login via', 'bestia'); ?>
               <!--<div class="social-buttons">
                 <a href="#" class="btn btn-fb"><i class="fa fa-facebook"></i> Facebook</a>
                 <a href="#" class="btn btn-tw"><i class="fa fa-twitter"></i> Twitter</a>
               </div>
                <span class="or_social"> or </span>
                -->


                <form class="form" role="form" method="post" action="login" id="login-form-modal" accept-charset="UTF-8" method="post">
                  <div class="hidden">
                  <input type="hidden" name="_TOKEN" value="">
                  </div>
                  <div class="form-group">
                      <label class="sr-only" for="username"><?php _e('Username', 'bestia'); ?></label>
                      <input type="text" class="form-control" name="username" id="username" placeholder="<?php _e('Username', 'bestia'); ?>">
                   </div>
                   <div class="form-group">
                      <label class="sr-only" for="password"><?php _e('Password', 'bestia'); ?></label>
                      <input type="password" class="form-control" name="password" id="password" placeholder="<?php _e('Password', 'bestia'); ?>">
                      <div class="help-block text-right">
                        <a href=""><?php _e('Forget the password ?', 'bestia'); ?>
                        </a>
                      </div>
                   </div>
                   <div class="form-group">
                      <button type="submit" class="btn btn-primary btn-block"><?php _e( 'Login','bestia'); ?></button>
                      <?php wp_nonce_field( 'ajax-login-nonce', 'security' ); ?>
                   </div>
                   <div class="checkbox">
                      <label>
                       <input name="rememberme" id="LoginForm_remember" type="checkbox"><?php _e('Remember me.', 'bestia'); ?>
                      </label>
                   </div>
                   <p class="status"></p>
                </form>
             </div>
             <div class="bottom text-center">
            <?php _e( 'New here ?','bestia'); ?> <a href="<?php echo bp_signup_page(); ?>"><b><?php _e( 'Join Us','bestia'); ?></b></a>
             </div>
          </div>
       </li>
     </ul>
</div>
<?php
}
function ajax_login_init(){
    wp_register_script('ajax-login-script', get_template_directory_uri() . '/assets/js/login/ajax-login.js', array('jquery') );
    wp_enqueue_script('ajax-login-script');
    wp_localize_script( 'ajax-login-script', 'ajax_login_object', array(
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'redirecturl' => bestia_get_requested_url(),
        'loadingmessage' => __('Sending user info, please wait...', 'bestia')
    ));
    // Enable the user with no privileges to run ajax_login() in AJAX
    add_action( 'wp_ajax_nopriv_ajaxlogin', 'ajax_login' );
}
// Execute the action only if the user isn't logged in
if (!is_user_logged_in()) {
    add_action('init', 'ajax_login_init');
}
function ajax_login(){

    // First check the nonce, if it fails the function will break
    check_ajax_referer( 'ajax-login-nonce', 'security' );

    // Nonce is checked, get the POST data and sign user on
    $info = array();
    $info['user_login'] = $_POST['username'];
    $info['user_password'] = $_POST['password'];
    $info['remember'] = true;

    $user_signon = wp_signon( $info, false );
    if ( is_wp_error($user_signon) ){
        echo json_encode(array('loggedin'=>false, 'message'=>__('Wrong username or password.', 'bestia')));
    } else {
        echo json_encode(array('loggedin'=>true, 'message'=>__('Login successful, redirecting...', 'bestia')));
    }

    die();
}
