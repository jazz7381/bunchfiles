<?php
if( !defined( 'ABSPATH' ) ) exit();
if( !function_exists( 'mytubepress_add_query_vars' ) ) {
	/**
	 * Adding tape var
	 * @param array $vars
	 * @return array
	 */
	function mytubepress_add_query_vars( $vars ) {
		$vars[] = 'tape';
		return $vars;
	}
	add_filter( 'query_vars' , 'mytubepress_add_query_vars', 100, 1);
}
if( !function_exists( 'mytubepress_get_video_type' ) ){
	/**
	 * get video type
	 * @param int $post_id
	 * return string.
	 */
	function mytubepress_get_video_type( $post_id ) {
		if( get_post_type( $post_id ) != 'post' || !$post_id )
			return;
		$type = get_post_meta( $post_id, 'video_type', true ) ? get_post_meta( $post_id, 'video_type', true ) : 'normal';
		return $type;
	}
}

if( !function_exists( 'mytubepress_get_media_object' ) ){
	/**
	 * Get the media object, this can be a string, int or an array.
	 * @param unknown_type $post_id
	 * @return void|Ambigous <mixed, string, multitype:, boolean, unknown>
	 */
	function mytubepress_get_media_object( $post_id ) {
		$tape = get_query_var( 'tape' ) ? absint( get_query_var( 'tape' ) ) : 1;
		$tape = $tape - 1;
		$object = array();
		if( !$post_id ){
			return;
		}
		if( mytubepress_get_video_type( $post_id ) == 'files' ){
			$object	= get_post_meta( $post_id, 'video_file', true );
			if( is_array( $object ) && count( $object ) > 1 ){
				// this is an array of media files.
				// get the embed code of the first element.
				if( isset( $object[ $tape ] ) ){
					print mytubepress_get_player( $object[ $tape ] , $post_id);
				} else{
					print mytubepress_get_player( $object[0] , $post_id);
				}

			} elseif( is_array( $object ) && count( $object )  == 1 ){
				print mytubepress_get_player( $object[0] , $post_id);
			} else {
				// this is a single media file.
				// this should ne a integer.
				print mytubepress_get_player( $object , $post_id);
			}
		}
		else{
			$object = get_post_meta( $post_id, 'video_url', true ) ? get_post_meta( $post_id, 'video_url', true ) : ( get_post_meta( $post_id, 'video_frame', true ) ? get_post_meta( $post_id, 'video_frame', true ) : null );
			$object	=	explode("\r\n", $object);
			$object	=	array_filter( $object );
			if( is_array( $object ) ){
				if( count( $object ) > 1 ){
					if( isset( $object[ $tape ] ) ){
						print mytubepress_get_player( $object[ $tape ] , $post_id);
					}
					else{
						print mytubepress_get_player( $object[0] , $post_id);
					}
				}
				elseif( count( $object ) == 1 ){
					print mytubepress_get_player( $object[0] , $post_id);
				}
			}
			else{
				print mytubepress_get_player( $object , $post_id);
			}
		}
	}
	add_action( 'mytubepress_media' , 'mytubepress_get_media_object', 10, 1);
}

if( !function_exists( 'mytubepress_get_player' ) ){
	/**
	 * Return embedcode/iframe
	 * @param string/int $media_object.
	 * return iframe html;
	 */
	function mytubepress_get_player( $media_object, $post_id ) {
		global $awpt,  $post;
		$output = $shortcode = $poster = '';
		// check if this is media file.
		// 'mp4', 'm4v', 'webm', 'ogv', 'wmv', 'flv' support.
		if( mytubepress_get_video_type( $post_id ) == 'files'){
			$media_object = (int)$media_object;
			// check if this file is publish.
			if( is_integer( $media_object ) ){
				// this is media file id.
				$media_url = wp_get_attachment_url( $media_object );
				if( !$media_url )
					return;
				// set the thumbnail image as poster.
				if( has_post_thumbnail( $post_id ) ){
					$post_thumbnail_id = get_post_thumbnail_id( $post_id );
					$thumb_image = wp_get_attachment_image_src( $post_thumbnail_id,'full' );
					$poster = $thumb_image[0];
				}
				$media_object_file_args = array(
					'src'		=>		!empty( $media_url ) ? esc_url( $media_url ) : '',
					'poster'	=>		!empty( $poster ) ? esc_url( $poster ) : '',
					'loop'		=>		false,
					//'autoplay'	=>		( $awpt['video_autostart'] == 1 ) ? 'true' : 'false',
					'preload'	=>		'metadata',
					'width'		=>		'750',
					'height'	=>		'442'
				);
				$media_object_file_args = apply_filters( 'mytubepress_media_object_file_args' , $media_object_file_args);
				// extract the array.
				extract($media_object_file_args, EXTR_PREFIX_SAME,'mytubepress');
       if( shortcode_exists( 'fluid-player' ) ){
				 if(!empty(mytubepress("player_logo"))) { $logobrand = 'logo="'.mytubepress("player_logo").'"'; } else { $logobrand = ''; }
				 if(!empty(mytubepress("in_video_ad"))) { $vast_url = 'vast_file="'.mytubepress("in_video_ad").'"'; } else { $vast_url = ''; }
				 if(!empty(mytubepress("adtext"))) { $adtxt = 'ad-text="'.mytubepress("adtext").'"'; } else { $adtxt = ''; }
				 if(!empty(mytubepress("adctatext"))) { $ctatxt = 'ad-cta-text="'.mytubepress("adctatext").'"'; } else { $ctatxt = ''; }
				 if( mytubepress("videojs_autoplay") == 1 ) { $autoplay = 'auto-play="autoPlay"'; } else { $autoplay = ''; }
				 if( mytubepress("video_download_btn") == 1 ) { $download_btn = 'allow-download="allowDownload"'; } else { $download_btn = ''; }
				 if( mytubepress("playback_speed") == 1 ) { $playback_speed = 'playback-speed="playbackRateEnabled"'; } else { $playback_speed = ''; }
				 $multiple_images = get_post_meta( $post->ID, 'image_rotator', true );
				 if ( has_post_thumbnail() ) {
					 $thumb = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
				 } elseif (!empty($multiple_images)) {
						$thumb = multi_thumb_default_image_full();
				 }
			   $shortcode = '
			   [fluid-player-extended
				  logo-position="'.mytubepress("logo_position").'"
				  '.$vast_url.'
				  '.$autoplay.'
				  '.$logobrand.'
				  '.$download_btn.'
				  '.$playback_speed.'
				  '.$adtxt.'
				  '.$ctatxt.'
				   logo-hyperlink="redirectUrl"
					 layout="default"
			     logo-opacity=".8"
			     html-on-pause-block-width="100"
			     html-on-pause-block-height="100"
					 poster-image="'.$thumb.'"
			     responsive="true"]
			       [fluid-player-multi-res-video]
			         [
			            {"label": "1080", "url": "'.$src.'"},
			            {"label": "720", "url": "'.$src.'"},
			            {"label": "480", "url": "'.$src.'"}
			          ]
			       [/fluid-player-multi-res-video]
			     [/fluid-player-extended]';
		     } elseif( shortcode_exists( 'KGVID' ) ){
					$options = get_option('kgvid_video_embed_options');
					$shortcode = '
						[KGVID
						  class="embed-responsive-item"
							poster="'.$poster.'"
							height="'.$options['height'].'"
							width="'.$options['width'].'"
						]
							'.$src.'
						[/KGVID]
					';
				} else {
					$shortcode = '
						[video
						  class="embed-responsive-item"
							src="'.$src.'"
							poster="'.$poster.'"
							loop="'.$loop.'"
							preload="'.$preload.'"
							height="'.$height.'"
							width="'.$width.'"
						]
					';
				}
				$output .= $shortcode;
			}
		}
		if( mytubepress_get_video_type($post_id) == 'normal'){
			// get the embed code.
			$mytubepress_object_url_args = array(
				'width'	=>	'',
				'height'	=>	''
			);
			$mytubepress_object_url_args = apply_filters( 'mytubepress_media_object_url_args' , $mytubepress_object_url_args);

			if( ! wp_oembed_get( $media_object, $mytubepress_object_url_args ) ){
				// yeah, I'm an iframe.
				$output .= $media_object;
			} else {
				// I'm a link.
				$output .= wp_oembed_get( $media_object, $mytubepress_object_url_args );
			}
		}
		if( ! post_password_required( $post_id ) ){
			$output = apply_filters( 'mytubepress_player' , $output );
			return do_shortcode( $output );
		}
		return get_the_password_form( $post_id );
	}
}

if( !function_exists( 'mytubepress_get_media_pagination' ) ){
	function mytubepress_get_media_pagination( $post_id ) {
		global $awpt,$post;
		$tape = get_query_var( 'tape' ) ? absint( get_query_var( 'tape' ) ) : 1;
		$pagination_array = $temp = array();
		if( mytubepress_get_video_type( $post_id ) == 'normal' ){
			$media_object = get_post_meta( $post_id, 'video_url', true );
			$temp	=	explode("\r\n", $media_object);
			if( is_array( $temp ) && count( $temp ) > 1 ){
				$pagination_array	=	$temp;
			}
		}
		else {
			$media_object = get_post_meta( $post_id, 'video_file', true );
			if( is_array( $media_object ) && !empty( $media_object ) ){
				$pagination_array	=	$media_object;
			}
		}
		$pagination_array	=	array_filter($pagination_array);
		if( is_array( $pagination_array ) && count( $pagination_array ) > 1 ){
			$prefix = get_option( 'permalink_structure' ) ? '?' : '&';
			print '<div class="btn-group buttons video_sorter pull-left">';
				for ($i = 1; $i <= count( $pagination_array ); $i++) {
					$current_link = isset( $post->ID ) ? esc_url( add_query_arg( array( 'tape'=>$i ), get_permalink( $post->ID ) ) ) : null;
					if( !isset( $pagination_array[$tape-1] ) ){
						$tape = 1;
					}
					$current_item = ( $i == $tape ) ? 'active' : null;
					print '<a class="btn '.$current_item.'" href="'.$current_link.'">'.$awpt['part_btn'].' '.$i.'</a>';
				}
			print '</div>
			<div class="clearfix"></div>';
		}
	}
	add_action( 'mytubepress_media_pagination' , 'mytubepress_get_media_pagination', 10, 1);
}
