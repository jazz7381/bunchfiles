<?php if( !defined('ABSPATH') ) exit;
function adultwpthemes_post_like() {
	$nonce = $_POST['nonce'];

    if ( ! wp_verify_nonce( $nonce, 'ajax-nonce' ) )
        die ( 'Busted!');

	if(isset($_POST['post_like']))
	{
		$ip = $_SERVER['REMOTE_ADDR'];
		$post_id = $_POST['post_id'];
    $post_like = $_POST['post_like'];

		$meta_IP = get_post_meta($post_id, "voted_IP");

		$voted_IP = $meta_IP[0];
		if(!is_array($voted_IP))
			$voted_IP = array();

        $meta_likes_count = get_post_meta($post_id, "likes_count", true);

        $meta_dislikes_count = get_post_meta($post_id, "dislikes_count", true);

        $meta_total_count = $meta_likes_count + $meta_dislikes_count;

		if(!adultwpthemes_hasAlreadyVoted($post_id))
		{
			$voted_IP[$ip] = time();

			update_post_meta($post_id, "voted_IP", $voted_IP);

            if( $post_like == "like" ){
                update_post_meta($post_id, "likes_count", ++$meta_likes_count);
            } else {
                update_post_meta($post_id, "dislikes_count", ++$meta_dislikes_count);
            }

            update_post_meta($post_id, "vote_avarage", floor( adultwpthemes_getPostLikeRate($post_id) ) );
            global $awpt;
            $already = false;

            $pourcentage    = ($meta_likes_count / ( $meta_total_count + 1 ) ) * 100;
            $bouton         = $awpt['vote_thanks'];
            $nbvotes        = $meta_total_count + 1;
            $barre          = ( $meta_likes_count / ( $meta_total_count + 1 ) ) * 100;

		    } else {
			     $already = true;
        }

        $json_arr = array(  "already"       => $already,
                            "pourcentage"   => $pourcentage,
                            "bouton"        => $bouton,
                            "nbvotes"       => $nbvotes,
                            "barre"         => $barre
                             );
        header("Content-Type: application/json", true);

        $output=json_encode($json_arr);

        if(is_array($output)){
            print_r($output);
        } else {
            echo $output;
        }

        die;

	} else {

       return false;

    }

	exit;
}
?>
