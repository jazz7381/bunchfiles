<?php
function footer_enqueue_scripts() {
    remove_action('wp_head', 'wp_print_scripts');
    remove_action('wp_head', 'wp_print_head_scripts', 9);
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );
    add_action('wp_footer', 'wp_print_scripts', 5);
    add_action('wp_footer', 'wp_enqueue_style', 5);
    add_action('wp_footer', 'wp_enqueue_scripts', 5);
    add_action('wp_footer', 'wp_print_head_scripts', 5);
}
add_action('after_setup_theme', 'footer_enqueue_scripts');

function bestia_enqueue_css() {
        wp_enqueue_style( 'stylesheet', get_template_directory_uri() . '/assets/css/base.css' );
        wp_enqueue_style( 'responsive-css', get_template_directory_uri() . '/assets/css/media.css' );
}
add_action( 'wp_enqueue_scripts', 'bestia_enqueue_css' );
// Async load
function bestia_async_scripts($url) {
if ( strpos( $url, '#asyncload') === false )
      return $url;
else if ( is_admin() )
     return str_replace( '#asyncload', '', $url );
else
	return str_replace( '#asyncload', '', $url )."' async='async";
}
add_filter( 'clean_url', 'bestia_async_scripts', 11, 1 );
function jquery_main_scripts() {
global $awpt;
//Main bestia scripts
wp_register_script('main-js', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0', true );
wp_enqueue_script( 'main-js');
//Thumbs rotation for multiple preview images
wp_register_script('image-rotator', get_template_directory_uri() . '/assets/js/thumbs.js', array('jquery'), '1.0', true );
wp_enqueue_script( 'image-rotator');
//Load bootstrap Script
wp_register_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '1.0', true );
wp_enqueue_script( 'bootstrap');
wp_register_script('functions', get_template_directory_uri() . '/assets/js/jquery/functions.js', array('jquery'), '1.2.4', true );
//wp_register_script('scroll-to-top', get_template_directory_uri() . '/assets/js/jquery/back-to-top.js', array('jquery'), '1.6.9', true );
//wp_enqueue_script( 'scroll-to-top');
wp_register_script('post-views', get_template_directory_uri() . '/assets/js/post-views.js', array('jquery'), '1.6.9', true );
//wp_enqueue_script( 'post-views');
wp_register_script('owlcarousel', get_template_directory_uri() . '/assets/js/owlcarousel/owl.carousel.min.js', array('jquery'), '1.9', true );
wp_enqueue_script( 'owlcarousel' );
wp_register_script('ajax_handled', get_template_directory_uri() . '/assets/js/jquery/ajax_handled.js', array('jquery'), '2.0.1', true );
wp_register_script('multiselect', get_template_directory_uri() . '/assets/js/jquery/jquery.multi-select.js', array('jquery'), '1.0', true );
wp_register_script('thumbfix', get_template_directory_uri() . '/assets/js/thumbfix.js', array('jquery'), '1.0', true );
wp_register_script('searchbox', get_template_directory_uri() . '/assets/js/searchbox.js', array('jquery'), '1.0', true );
wp_enqueue_script( 'searchbox');
wp_register_script('jquery-form', get_template_directory_uri() . '/assets/js/jquery/jquery.form.js', array('jquery'), '1.0', true );
wp_enqueue_script( 'jquery-form');

if ( function_exists( 'wpscript_mode') ) {
  wp_enqueue_style('cover-images', get_template_directory_uri() . '/assets/css/covering.css');
} elseif( $awpt['thumbfix'] == 1 ) {
  wp_enqueue_script( 'thumbfix');
} else {
}
echo '<script type="text/javascript">var ajaxurl = "'.admin_url('admin-ajax.php').'";</script>';
}
add_action('wp_enqueue_scripts', 'jquery_main_scripts');

//enqueues our locally supplied font awesome stylesheet
function enqueue_bestia_required_stylesheets(){
	wp_enqueue_style('bootsrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
	wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css');
	//wp_enqueue_style('bestia-color', get_template_directory_uri() . '/assets/css/default-colors.css');
	wp_enqueue_style('performer-css', get_template_directory_uri() . '/assets/css/performer.css');
  //wp_enqueue_style('animate', get_template_directory_uri() . '/assets/css/animate.css');
  wp_enqueue_style('multiselect', get_template_directory_uri() . '/assets/css/multi-select.css');
  wp_enqueue_style('carousel', get_template_directory_uri() . '/assets/css/owlcarousel/owl.carousel.min.css');
}
add_action('wp_enqueue_scripts','enqueue_bestia_required_stylesheets');

function add_single_page_stylesheet() {
     if ( is_single() )
     wp_enqueue_style('single-page-css', get_template_directory_uri() . '/assets/css/single.css');
    //wp_enqueue_style('lightslider-css', get_template_directory_uri() . '/css/lightslider.css');
}
add_action( 'wp_enqueue_scripts', 'add_single_page_stylesheet' );

if(!function_exists('load_rotator_script')){
    function load_rotator_script() {
        $deps = array('jquery');
        $version= '1.0';
        $in_footer = true;
        wp_enqueue_script('rotator', get_stylesheet_directory_uri() . '/assets/js/thumbs.js', $deps, $version, $in_footer);
    }
}
add_action('wp_enqueue_scripts', 'load_rotator_script');

function redux_hidden_fields_manager() {
  global $awpt;
    if( $awpt['gallery_cpt'] == 0 ){
    print '<style>.gallery_option {display: none;}</style>';
    }
    if( $awpt['blogs_cpt'] == 0 ){
    print '<style>.blog_option {display: none;}</style>';
    }
    if( $awpt['fake-post-rating'] == 0 ){
    print '<style>.fpr {display: none;}</style>';
    }
    if( $awpt['fake-post-views'] == 0 ){
    print '<style>.fpv {display: none;}</style>';
    }
    echo '<script type="text/javascript">
  jQuery(document).ready(function ($) {
      $("#awpt-gallery_cpt label.cb-enable").click(function () {
        $(".gallery_option").show();
        }),$("#awpt-gallery_cpt label.cb-disable").click(function () {
         $(".gallery_option").hide("slide");
       }),
       $("#awpt-blogs_cpt label.cb-enable").click(function () {
       $(".blog_option").show();
       }),$("#awpt-blogs_cpt label.cb-disable").click(function () {
        $(".blog_option").hide("slide");
      }),
      $("#awpt-fake-post-views label.cb-enable").click(function () {
        $(".fpv").show();
        }),$("#awpt-fake-post-views label.cb-disable").click(function () {
         $(".fpv").hide("slide");
       }),
       $("#awpt-fake-post-rating label.cb-enable").click(function () {
         $(".fpr").show();
         }),$("#awpt-fake-post-rating label.cb-disable").click(function () {
          $(".fpr").hide("slide");
        });
  });
  </script>';
}
add_action( 'admin_head', 'redux_hidden_fields_manager' );

function bestia_admin_enqueue() {
wp_enqueue_style('snapshot-style', get_bloginfo( 'template_url' ) . '/admin/assets/css/snapshot.css');
//wp_enqueue_style('image-select', get_bloginfo( 'template_url' ) . '/admin/assets/css/image-select.css');
wp_enqueue_style('admin_style', get_bloginfo( 'template_url' ) . '/admin/assets/css/bestia-admin.css');
wp_enqueue_script('snapshot-js', get_bloginfo( 'template_url' ) . '/admin/assets/js/snapshot.js');
//wp_enqueue_script('image-select', get_bloginfo( 'template_url' ) . '/admin/assets/js/image-select.js');
}
add_action('admin_init', 'bestia_admin_enqueue');
function add_bestia_pagination_style() {
global $awpt; $pagination_style = $awpt['pagination_style'];
if ($pagination_style == "default") {$pg = 'pagination-default.css';
} elseif ($pagination_style == "inherit") { $pg = 'pagination-inherit.css';
} elseif ($pagination_style == "light") { $pg = 'pagination-light.css';
} elseif ($pagination_style == "dark") { $pg = 'pagination-dark.css';
} else {$pg = 'pagination-default.css';}
wp_enqueue_style('bestia-pagination', get_bloginfo( 'template_url' ) . '/assets/css/pagination/'.$pg.'');
}
add_action( 'wp_head', 'add_bestia_pagination_style' );

function bestia_single_scripts() {
if ( is_single() )
wp_register_script('single_scripts', get_template_directory_uri() . '/assets/js/single.js', array('jquery'), '1.0', true );
//wp_register_script('lightslider', get_template_directory_uri() . '/js/lightslider.js', array('jquery'), '1.0', true );
//wp_enqueue_script( 'lightslider' );
wp_enqueue_script( 'single_scripts' );
}
add_action( 'wp_enqueue_scripts', 'bestia_single_scripts' );

function activate_custompmpro_css() {
  if ( function_exists( 'pmpro_activation' ) ) {
    wp_enqueue_style( 'pmpro_custom', get_template_directory_uri() . '/assets/css/pmpro.css' );
  }
}
add_action( 'wp_enqueue_scripts', 'activate_custompmpro_css' );

add_action('admin_head', 'admin_tabs');

function admin_tabs() {
  echo '<style>
  .nav-tab {
      float: left;
      border-bottom: none;
      padding: 12px !important;
      font-size: 14px !important;
      font-weight: 600;
      text-decoration: none;
      white-space: nowrap;
  }
  .easytube-wrap .about-description, .about-wrap .about-text {
      font-size: 15px !important;
  }
  .easytube-wrap h1 {
      font-size: 24px !important;
      font-weight: 400;
      margin: 0;
      padding: 9px 0 4px 0;
      line-height: 1.3;
  }
  @media (min-width: 768px) {
  .redux-container .redux-main .form-table tr.rdxycv {
    border-bottom: 0 !important;
    float:left;
    clear:left;
    padding: 0 !important;
    margin-top: -180px !important;
  }
  .redux-container .redux-main .form-table tr.rdxycv2 {
    border-bottom: 0 !important;
    float:left;
    clear:left;
    padding: 0 !important;
    margin-top: -140px !important;
  }
  .form-table tr.icon_position {
      border-bottom: 0 !important;
      float:left;
      clear:left;
      padding: 0 !important;
      margin-top: -97px !important;
      margin-left: -80px;
      width:300px !important;
    }
  .redux-container .redux-main .form-table tr.rdxycv .select2-container,
  .redux-container .redux-main .form-table tr.rdxycv2 .select2-container {
    width:200px !important;
  }
  }
  </style>';
}
