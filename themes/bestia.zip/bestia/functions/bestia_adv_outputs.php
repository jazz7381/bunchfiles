<?php if( !defined('ABSPATH') ) exit;
if( !function_exists('bestia_homepage_ads') ){
function bestia_homepage_ads() {
global $awpt;
$right_banner = $awpt['mtn_adsindex'];
$banner = apply_filters('the_content', $right_banner );
if (!empty($right_banner)) {
//echo '<li class="xtact"><div class="child_xtact">'.$right_banner.'</div></li>';
echo '<li class="xtact"><p class="child_xtact">' . $banner . '</p></li>';
} else {}
}
add_action('bestia_homepage_ads', 'bestia_homepage_ads');
}
/*
if( !function_exists('bestia_homepage_ads') ){
function bestia_homepage_ads() {
global $awpt;
$right_banner = $awpt['mtn_adsindex']; if (!empty($right_banner)) {
echo '<li class="5890"><div class="child_5890">'.$right_banner.'</div></li>';
} else {}
}
add_action('bestia_homepage_ads', 'bestia_homepage_ads');
}
*/
if( !function_exists('bestia_single_right_ads') ){
function bestia_single_right_ads() {
global $awpt; if (!empty($awpt['mtn_adsright'])) {
echo $awpt['mtn_adsright']; } else {}
}
add_action('bestia_single_right_ads', 'bestia_single_right_ads');
}

if( !function_exists('bestia_bottom_ads') ){
function bestia_bottom_ads() {
global $awpt;
$bottom_banner = $awpt['mtn_adsbottom'];
$banner = apply_filters('the_content', $bottom_banner );
if (!empty($bottom_banner)) { ?>
<div id="l_340">
<?php echo $banner; ?>
</div>
<?php } else { ?>
<?php }
}
add_action('bestia_bottom_ads', 'bestia_bottom_ads');
}

if( !function_exists('bestia_bottom_video_ads') ){
function bestia_bottom_video_ads() {
global $awpt,$post;
$adv_b = get_post_meta($post->ID, 'awpt_adv', true);
$banner = apply_filters('the_content', get_post_meta($post->ID, 'awpt_adv', true) );
if(!empty($adv_b)) { ?>
<div id="UnderplayerP">
<?php echo $banner; ?>
</div>
<?php } elseif (!empty($awpt['mtn_adsvideo'])) {
$banner = apply_filters('the_content', $awpt['mtn_adsvideo'] );
?>
<div id="UnderplayerP">
<?php echo $banner; ?>
</div>
<?php } else { ?>
<?php }
}
add_action('bestia_bottom_video_ads', 'bestia_bottom_video_ads');
}

if( !function_exists('bestia_after_post_ad') ){
function bestia_after_post_ad() {
global $awpt;
$after_post_ad = $awpt['mtn_afterpost'];
$banner = apply_filters('the_content', $after_post_ad );
if (!empty($after_post_ad)) {
//echo '<div class="after-post-ads">'.$after_post_ad.'</div>';
echo '<li class="aft_bnr"><div class="child_5890">'.$banner.'</div></li>';
}
}
add_action('bestia_after_post_ad', 'bestia_after_post_ad');
}

if( !function_exists('bestia_mobile_top_ad') ){
function bestia_mobile_top_ad() {
global $awpt;
$mobile_top_ad = $awpt['mtn_mobiletop'];
$banner = apply_filters('the_content', $mobile_top_ad );
if (!empty($mobile_top_ad)) {
echo '<div class="mobiletop">'.$banner.'</div>';
}
}
add_action('bestia_mobile_top_ad', 'bestia_mobile_top_ad');
}

if( !function_exists('bestia_mobile_bottom_ad') ){
function bestia_mobile_bottom_ad() {
global $awpt;
$mobile_bottom_ad = $awpt['mtn_mobilebottom'];
$banner = apply_filters('the_content', $mobile_bottom_ad );
if (!empty($mobile_bottom_ad)) {
echo '<div class="mobilebottom">'.$banner.'</div>';
}
}
add_action('bestia_mobile_bottom_ad', 'bestia_mobile_bottom_ad');
}

function bestia_popunder_ads_mobile() {
global $awpt;
if( isset( $awpt['popunders_mobile'] ) && trim( $awpt['popunders_mobile'] ) !='' ){
print $awpt['popunders_mobile'];
}
}
function bestia_popunder_ads() {
global $awpt;
if( isset( $awpt['popunders'] ) && trim( $awpt['popunders'] ) !='' ){
print $awpt['popunders'];
}
}
function bestia_popunder_ads_display() {
global $awpt;
if ($awpt['pop_desk_position'] == "header") { $position = 'wp_head'; } else { $position = 'wp_footer'; }
if ($awpt['pop_mob_position'] == "header") { $position_mobile = 'wp_head'; } else { $position_mobile = 'wp_footer'; }
if ( wp_is_mobile() ){ add_action($position_mobile, 'bestia_popunder_ads_mobile'); } else { add_action($position, 'bestia_popunder_ads'); }
}
add_action('init', 'bestia_popunder_ads_display');
