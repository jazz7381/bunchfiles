<?php if( !defined('ABSPATH') ) exit;
if( !class_exists('Bestia_Custom_Channels_Taxonomy') ){
	class Bestia_Custom_Channels_Taxonomy {
		function __construct() {
			add_action('init', array($this,'cptui_register_channel_taxonomy'));
			add_filter( 'cptui_register_channel_taxonomy' , array( $this, 'rewrite_channel_tax' ), 10, 1 );
		}
		function cptui_register_channel_taxonomy() {
			$labels = array(
				'name'              => __( 'Channels', 'bestia' ),
				'singular_name'     => __( 'Channel', 'bestia' ),
				'popular_items' => __( 'Popular channels', 'bestia' ),
				'search_items'      => __( 'Search Channels','bestia' ),
				'all_items'         => __( 'All Channels','bestia' ),
				'parent_item' => null,
				'parent_item_colon' => null,
				'edit_item'         => __( 'Edit Channels','bestia' ),
				'update_item'       => __( 'Update Channel','bestia' ),
				'add_new_item'      => __( 'Add New Channel','bestia' ),
				'new_item_name'     => __( 'New Channel','bestia' ),
				'menu_name'         => __( 'Channels','bestia' ),
				'separate_items_with_commas' => __( 'Separate channels with commas', 'bestia' ),
            'add_or_remove_items' => __( 'Add or remove channels', 'bestia' ),
            'choose_from_most_used' => __( 'Choose from the most used channels', 'bestia' ),
			);

			$args = array( 'hierarchical' => true,
				'label' => __( 'Channels', 'bestia' ),
				'hierarchical' => false,
				'show_ui' => true,
				'query_var' => true,
				'show_admin_column' => true,
				'update_count_callback' => '_update_post_term_count',
				'labels' => $labels,
				'rewrite'    => array( 'slug' => 'channel' )
			);
			$args = apply_filters( 'cptui_register_channel_taxonomy' , $args);
			register_taxonomy( 'channel',array ( 0 => 'post' ), $args );
		}

		function rewrite_channel_tax( $args ){
			global $awpt;
			if( isset( $awpt['rewrite_slug_channel'] ) && $awpt['rewrite_slug_channel'] != 'channel' ){
				$args['rewrite'] = array(
					'slug'	=> esc_attr( $awpt['rewrite_slug_channel'] )
				);
			}
			return $args;
		}

	}
	new Bestia_Custom_Channels_Taxonomy();
}
