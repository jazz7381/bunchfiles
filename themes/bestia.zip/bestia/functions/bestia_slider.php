<?php
if( !defined('ABSPATH') ) exit;
// Custom Post types for Feature project sliders on home page
	   add_action('init', 'bestia_slider');
	     function bestia_slider() {
	       $slides_args = array(
	          'labels' => array(
	           'name' => __( 'Slider', 'bestia'),
	           'singular_name' => __( 'Slide', 'bestia'),
	           'add_new' => __( 'Add New Slide', 'bestia'),
	           'add_new_item' => __( 'Add New', 'bestia'),
	           'edit_item' => __( 'Edit', 'bestia'),
	           'new_item' => __( 'Add New', 'bestia'),
	           'view_item' => __( 'View', 'bestia'),
	           'search_items' => __( 'Search', 'bestia'),
	           'not_found' => __( 'No items found', 'bestia'),
	           'not_found_in_trash' => __( 'No items found in trash', 'bestia')
						 ),
						 'public' => true,
	           'show_ui' => true,
	           'capability_type' => 'post',
	           'menu_icon'	=>	'dashicons-image-rotate-left',
	           'hierarchical' => false,
	           'rewrite' => true,
						 'page_parent' => 'bestia',
						 'menu_type' => 'submenu',
	           'menu_position' => 9,
	           'supports' => array('title')
	         );
	    register_post_type('slider',$slides_args);
	}
	    add_filter("manage_slides_edit_columns", "slides_edit_columns");

	function slides_edit_columns($slides_columns){
	   $slides_columns = array(
	      "cb" => "<input type=\"checkbox\" />",
	      "title" => "Title",
	   );
	  return $slides_columns;
	}
//slider button shortcode
function slider_button_shortcode($atts) {
	 $default = array(
	   'link' => '#',
		 'text' => 'Button Text',
	 );
$a = shortcode_atts($default, $atts);
	return '<form action="'.$a['link'].'"><button class="slider-join">'.$a['text'].'</button></form>';
}
add_shortcode('button', 'slider_button_shortcode');
