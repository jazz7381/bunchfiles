<?php if( !defined('ABSPATH') ) exit;
if( !function_exists('bestia_video_description') ){
function bestia_video_description() {
global $awpt; $bot = isset($awpt['mtn_video_grabber']) ? $awpt['mtn_video_grabber'] : '';
get_template_part( 'compatibility/'.$bot.'/description', get_post_format() );
}
add_action('bestia_video_description', 'bestia_video_description', 10);
}

if( !function_exists('bestia_thumbnail_compatibility') ){
function bestia_thumbnail_compatibility() {
global $awpt;
$bot = isset($awpt['mtn_video_grabber']) ? $awpt['mtn_video_grabber'] : '';
get_template_part( 'compatibility/'.$bot.'/thumblist', get_post_format() );
}
add_action('bestia_thumbnail_compatibility', 'bestia_thumbnail_compatibility', 10);
}

if( !function_exists('bestia_video_player_default') ){
function bestia_video_player_default() {
global $awpt,$post;
   $bot = isset($awpt['mtn_video_grabber']) ? $awpt['mtn_video_grabber'] : '';
   get_template_part( 'compatibility/'.$bot.'/player', get_post_format() );
  }
}

function bestia_video_player_paid() {
global $post;
if ( function_exists( 'pmpro_activation' ) && pmpro_has_membership_access($post->ID) ) {
   echo bestia_video_player_default();
     } else {
      //echo pmpro_membership_content_filter($content);
      echo apply_filters( 'the_content','[pmpro_levels]');
  }
}
add_action('bestia_video_player_paid', 'bestia_video_player_paid', 10);

if( !function_exists('bestia_video_player') ){
function bestia_video_player() {
global $post;
if ( function_exists( 'pmpro_activation' ) ) {
   do_action('bestia_video_player_paid');
    } else {
   bestia_video_player_default();
  }
 }
 add_action('bestia_video_player', 'bestia_video_player', 10);
}
