<?php
if( !defined( 'ABSPATH' ) ) exit();
//Inplayer ads (overlay over the video!)
function bestia_player_ad_overlay() {
	global $awpt,$post;
	$in_embed_ad = $awpt['mtn_inembed'];
	$banner = apply_filters('the_content', $in_embed_ad );

	?>
	<?php if (!empty($in_embed_ad)) { ?>
		<div style="position: relative;width: 100%;background:transparent;">
		<div class="v-overlay" id="v-overlay">
		<span style="padding: 5px;display: block;text-align: left; color: #ccc;background: #000;font-size: 12px">
		<?php echo $awpt['ad_text']; ?>
		<a class="video_lek_times close_lek">
		<i class="fa fa-times"></i>
		</a>
		</span>
		<div style="width: 300px; height: 250px; display: table-cell; vertical-align: middle;">
		<?php echo $banner; ?>
		<div id="playerPause"></div>
		<div class="continue_watch"><a class="close_lek"><?php echo $awpt['ad_close']; ?></a></div>
		</div>
		</div>
		</div>
	<?php }
}
add_action('bestia_player_ad_overlay','bestia_player_ad_overlay');

//sponsor logolink
function bestia_sponsor_link() {
    global $post;
		$sponsor_txt = get_post_meta($post->ID, 'sponsor_link_txt', true);
		$sponsor_url = get_post_meta($post->ID, 'sponsor_link_url', true);
		if(!empty($sponsor_url)) { ?>
		<div class="video-sponsor">
			<a class="fullmovie" rel="nofollow noopener" href="<?php echo $sponsor_url; ?>" target="_blank"><?php echo $sponsor_txt; ?></a>
		</div>
	<?php }
}
add_action('bestia_sponsor_link', 'bestia_sponsor_link');

//video player
function bestia_player() {
	global $awpt;
	global $post;
	//Video Url
  $video = get_post_meta($post->ID,'video_url', true); //default custom field
	$custom_field_embed = isset($awpt['embed']) ? $awpt['embed'] : ''; //Retrieve the embed_code field from theme settings panel
	$custom_field_mp4 = isset($awpt['videourl']) ? $awpt['videourl'] : ''; //Retrieve the video_url field from theme settings panel
	$video_custom = get_post_meta($post->ID, $custom_field_mp4, true);
	$video_old = get_post_meta($post->ID,'awpt_videourl', true);
	//Embed
  $embed_video = get_post_meta($post->ID, $custom_field_embed, true);
	$embedvideo =  get_post_meta($post->ID,'embed_code', true);
	$video_frame = get_post_meta($post->ID,'video_frame', true);
	//$embed_code =  get_post_meta($post->ID,'video_frame', true);
	$sefurL = get_bloginfo('template_url', true);

	$multiple_images = get_post_meta( $post->ID, 'image_rotator', true );
	if ( has_post_thumbnail() ) {
	  $thumb = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	} elseif (!empty($multiple_images)) {
    $thumb = multi_thumb_default_image_full();
	} else {
	  $thumb = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	}
		//get the video url from the correct field
  if (!empty($video)) {
		$get_video = $video;
	} elseif (!empty($video_custom)) {
    $get_video = $video_custom;
	} elseif (!empty($video_old)) {
    $get_video = $video_old;
  } else {
		$get_video = '';
	}

	if( shortcode_exists( 'fluid-player' ) ){
		if(!empty(mytubepress("player_logo"))) { $logobrand = 'logo="'.mytubepress("player_logo").'"'; } else { $logobrand = ''; }
		if(!empty(mytubepress("in_video_ad"))) { $vast_url = 'vast_file="'.mytubepress("in_video_ad").'"'; } else { $vast_url = ''; }
		if(!empty(mytubepress("adtext"))) { $adtxt = 'ad-text="'.mytubepress("adtext").'"'; } else { $adtxt = ''; }
		if(!empty(mytubepress("adctatext"))) { $ctatxt = 'ad-cta-text="'.mytubepress("adctatext").'"'; } else { $ctatxt = ''; }
		if( mytubepress("videojs_autoplay") == 1 ) { $autoplay = 'auto-play="autoPlay"'; } else { $autoplay = ''; }
		if( mytubepress("video_download_btn") == 1 ) { $download_btn = 'allow-download="allowDownload"'; } else { $download_btn = ''; }
		if( mytubepress("playback_speed") == 1 ) { $playback_speed = 'playback-speed="playbackRateEnabled"'; } else { $playback_speed = ''; }
		$shortcode = '
		[fluid-player-extended
		 logo-position="'.mytubepress("logo_position").'"
		 '.$vast_url.'
		 '.$autoplay.'
		 '.$logobrand.'
		 '.$download_btn.'
		 '.$playback_speed.'
		 '.$adtxt.'
		 '.$ctatxt.'
			logo-hyperlink="redirectUrl"
			layout="default"
			logo-opacity=".8"
			html-on-pause-block-width="100"
			html-on-pause-block-height="100"
			poster-image="'.$thumb.'"
			responsive="true"]
				[fluid-player-multi-res-video]
					[
						 {"label": "1080", "url": "'.$get_video.'"},
						 {"label": "720", "url": "'.$get_video.'"},
						 {"label": "480", "url": "'.$get_video.'"}
					 ]
				[/fluid-player-multi-res-video]
			[/fluid-player-extended]';
		} elseif( shortcode_exists( 'KGVID' ) ){
		$options = get_option('kgvid_video_embed_options');
		$shortcode = '
			[KGVID
				poster="'.$thumb.'"
				height="'.$options['height'].'"
				width="'.$options['width'].'"
				autoplay=""
			]
				'.$get_video.'
			[/KGVID]
		';
	} else {
		$shortcode = '
			[video src="'.$get_video.'" poster="'.$thumb.'" preload="" height="" width=""]
		';
	}
	if (function_exists('tubeace_append_video_player_to_the_content')) {
		echo do_action('tubeace_video_player');
	}
	if (!empty($embed_video) ) {
		echo $embed_video;
	} elseif (!empty($embedvideo) ) {
		echo $embedvideo;
	}
	if( '' !== get_post()->post_content && $awpt['post_description_type'] == 0 ) {
	  echo the_content();
	  } elseif( mytubepress_get_video_type( $post->ID ) == 'files' ) {
	  do_action( 'mytubepress_media', get_the_ID() );
	} elseif (!empty($video) && strpos($video, '.mp4') !== false || strpos($video, '.webm') !== false || strpos($video, '.ogv') !== false || strpos($video, '.ogg') !== false || strpos($video, '.m3u8') !== false
   || strpos($video, '.mpd') !== false ) {
		echo do_shortcode( $shortcode ) . '<style>#player .video_sorter {display:none !important;}</style>';
  } elseif (!empty($video_custom) && strpos($video_custom, '.mp4') !== false || strpos($video_custom, '.webm') !== false || strpos($video_custom, '.ogv') !== false || strpos($video_custom, '.ogg') !== false || strpos($video_custom, '.m3u8') !== false
   || strpos($video, '.mpd') !== false ) {
		echo do_shortcode( $shortcode );
  } elseif (!empty($video) && strpos($video, '.flv') !== false ) {
		echo do_shortcode( '[fvplayer src="'.$get_video.'" poster="'.$thumb.'" preload="" height="" width=""]' ) . '<style>#player .video_sorter {display:none !important;}</style>';
	} elseif (!empty($video_custom) && strpos($video_custom, 'flv') !== false ) {
		echo do_shortcode( '[fvplayer src="'.$get_video.'" poster="'.$thumb.'" preload="" height="" width=""]' );
	} elseif( mytubepress_get_video_type( $post->ID ) == 'normal' ) {
		do_action( 'mytubepress_media', get_the_ID() );
	} else {

	}
 }
add_action('bestia_player','bestia_player');


function crooked_gen_thumbnail() {
	global $awpt;
	$custom_field_mp4 = isset($awpt['videourl']) ? $awpt['videourl'] : ''; //Retrieve the video_url field from theme settings panel
	$video_hd = get_post_meta($post->ID, $custom_field_mp4, true);

		//Animated GIF maker
		if (!file_exists(WP_CONTENT_DIR."/gifs/".$video_hd['ID'].".gif")) :
			if ( isset($video_hd['ID'])) {
				$vid = get_attached_file( $video_hd['ID'] );
				$gif = WP_CONTENT_DIR."/gifs/".$video_hd['ID'].".gif";
				$cmd2 = "ffmpeg -ss 30 -t 5 -i $vid -vf 'fps=5,scale=420:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse' -loop 0 $gif";
				shell_exec($cmd2);
			}
		endif;

		if (file_exists(WP_CONTENT_DIR."/thumbs/".$video_hd['ID'].".jpg") ||
			file_exists(WP_CONTENT_DIR."/thumbs/".$video_sd['ID'].".jpg")) {
				return;
			}

		if ( isset($video_hd['ID'])) {
			$vid = get_attached_file( $video_hd['ID'] );
			$thumbnail = WP_CONTENT_DIR."/thumbs/".$video_hd['ID'].".jpg";
			//$cmd = "ffmpeg -i $vid -deinterlace -an -ss 1 -t 00:00:05 -r 1 -y -vcodec mjpeg -f mjpeg $thumbnail 2>&1";
			$cmd = "ffmpeg -i $vid -ss 00:03:01.000 -vframes 1 $thumbnail";
			shell_exec($cmd); //$process will contain no file or directory in case of error.
		} else if (isset($video_sd['ID'])) {
			$vid = get_attached_file( $video_sd['ID'] );
			$thumbnail = WP_CONTENT_DIR."/thumbs/".$video_sd['ID'].".jpg";
			$cmd = "ffmpeg -i $vid -deinterlace -an -ss 1 -t 00:00:05 -r 1 -y -vcodec mjpeg -f mjpeg $thumbnail 2>&1";
			shell_exec($cmd);
		}
}

function crooked_featured_thumbnail() {
	$videos = rwmb_meta( 'crooked-video_hd', array( 'limit' => 1 ) );
	$video_hd = reset( $videos );

	$videos = rwmb_meta( 'crooked-video_sd', array( 'limit' => 1 ) );
	$video_sd = reset( $videos );

	//Check if thumbnails have already been resized or not
	if (file_exists(WP_CONTENT_DIR."/thumbs/".$video_hd['ID']."-resized.jpg"))
		return WP_CONTENT_DIR."/thumbs/".$video_hd['ID']."-resized.jpg";
	else if (file_exists(WP_CONTENT_DIR."/thumbs/".$video_sd['ID']."-resized.jpg"))
		return 	WP_CONTENT_DIR."/thumbs/".$video_sd['ID']."-resized.jpg";

	if ( isset($video_hd['ID'])) {
			$video_id = $video_hd['ID'];
			$image = wp_get_image_editor( WP_CONTENT_DIR.'/thumbs/'.$video_id.'.jpg' );
			if ( ! is_wp_error( $image ) ) {
		    $image->resize( 600, 380, true );
		    $image->save( WP_CONTENT_DIR.'/thumbs/'.$video_id.'-resized.jpg' );
		    return WP_CONTENT_DIR."/thumbs/".$video_id."-resized.jpg";
			}
		}
	else if (isset($video_sd['ID'])) {
			$video_id = $video_sd['ID'];
			$image = wp_get_image_editor( WP_CONTENT_DIR.'/thumbs/'.$video_id.'.jpg' );
			if ( ! is_wp_error( $image ) ) {
		    $image->resize( 600, 380, true );
		    $image->save( WP_CONTENT_DIR.'/thumbs/'.$video_id.'-resized.jpg' );

		    return WP_CONTENT_DIR.'/thumbs/'.$video_id.'-resized.jpg';
		    }
	}
	else {
		return false;
	}
}
