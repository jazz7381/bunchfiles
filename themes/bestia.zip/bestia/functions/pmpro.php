<?php
if( !defined('ABSPATH') ) exit;
if ( !function_exists( 'pmpro_hasMembershipLevel' ) ) {

// The levels to check.
$levels = NULL;

// The user ID to check.
$user_id = NULL;

// NOTICE! Understand what this does before running.
$result = pmpro_hasMembershipLevel($levels, $user_id);

function pmpro_hasMembershipLevel($levels = NULL, $user_id = NULL) {
    global $current_user, $wpdb;

    $return = false;

    if(empty($user_id)) //no user_id passed, check the current user
    {
        $user_id = $current_user->ID;
    }

    if(!empty($user_id) && is_numeric($user_id)) //get membership levels for given user
        $membership_levels = pmpro_getMembershipLevelsForUser($user_id);
    else
        $membership_levels = NULL; //non-users don't have levels

    if($levels === "0" || $levels === 0) //if 0 was passed, return true if they have no level and false if they have any
    {
        $return = empty($membership_levels);
    }
    elseif(empty($levels)) //if no level var was passed, we're just checking if they have any level
    {
        $return = !empty($membership_levels);
    }
    else
    {
        if(!is_array($levels)) //make an array out of a single element so we can use the same code
        {
            $levels = array($levels);
        }

        if(empty($membership_levels))    //user has no levels just check if 0, L, -1, or e was sent in one of the levels
        {
            //check for negative level
            $negative_level = false;
            foreach($levels as $level) {
                if(intval($level) < 0) {
                    $negative_level = true;
                    break;
                }
            }

            //are we looking for non-members or not?
            if($negative_level)
                return true;                                                        //-1/etc, negative level
            elseif(in_array(0, $levels, true) || in_array("0", $levels))
                $return = true;                                                        //0 level
            elseif(in_array("L", $levels) || in_array("l", $levels))
                $return = (!empty($user_id) && $user_id == $current_user->ID);        //L, logged in users
            elseif(in_array("-L", $levels) || in_array("-l", $levels))
                $return = (empty($user_id) || $user_id != $current_user->ID);        //-L, not logged in users
            elseif(in_array("E", $levels) || in_array("e", $levels)) {
                $sql = "SELECT id FROM $wpdb->pmpro_memberships_users WHERE user_id=$user_id AND status='expired' LIMIT 1";
                $expired = $wpdb->get_var($sql);                                    //E, expired members
                $return = !empty($expired);
            }
        }
        else
        {
            foreach($levels as $level)
            {
                if(strtoupper($level) == "L")
                {
                    //checking if user is logged in
                    if(!empty($user_id) && $user_id == $current_user->ID)
                        $return = true;
                }
                elseif(strtoupper($level) == "-L")
                {
                    //checking if user is logged out
                    if(empty($user_id) || $user_id != $current_user->ID)
                        $return = true;
                }
                elseif($level === "0" || $level === 0 || strtoupper($level) === "E")
                {
                    continue;    //user with levels so not a "non-member" or expired
                }
                else
                {
                    //checking a level id
                    $level_obj = pmpro_getLevel(is_numeric($level) ? abs(intval($level)) : $level); //make sure our level is in a proper format
                    if(empty($level_obj)) {continue;} //invalid level
                    $found_level = false;

                    foreach($membership_levels as $membership_level)
                    {
                        if($membership_level->id == $level_obj->id) //found a match
                        {
                            $found_level = true;
                        }
                    }

                    if(is_numeric($level) && intval($level) < 0 && !$found_level) //checking for the absence of this level and they don't have it
                    {
                        $return = true;
                    }
                    elseif(is_numeric($level) && intval($level) > 0 && $found_level) //checking for the presence of this level and they have it
                    {
                        $return = true;
                    }
                    elseif(!is_numeric($level))    //if a level name was passed
                        $return = $found_level;
                }
            }
        }
    }

    $return = apply_filters("pmpro_has_membership_level", $return, $user_id, $levels);
    return $return;
}
} 
