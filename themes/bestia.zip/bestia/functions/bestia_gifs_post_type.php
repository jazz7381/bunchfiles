<?php if( !defined('ABSPATH') ) exit;
if( !class_exists('bestia_gifs_post_type') ){
	class bestia_gifs_post_type {
		function __construct() {
			add_action('init', array($this,'register_bestia_cpt_gifs'));
		}
		function register_bestia_cpt_gifs() {
			global $awpt;
			$rewrite_slug = trim( $awpt['gif_rewrite_slug'] ) ? trim( $awpt['gif_rewrite_slug'] ) : 'gif';
			$args = array(
				'label' => __('Gifs','bestia'),
				'description' => '',
				'public' => true,
				'menu_position' => 4,
				'has_archive'	=>true,
				'show_ui' => true,
				'show_in_menu' => true,
				'capability_type' => 'post',
				'map_meta_cap' => true,
				'hierarchical' => false,
				'menu_icon'	=>	'dashicons-images-alt2',
				'rewrite' => array('slug' => $rewrite_slug, 'with_front' => true),
				'query_var' => true,
				'supports' => array('title','editor','publicize','comments','thumbnail','author','post-formats', 'buddypress-activity'),
				'labels' => array (
					  'name' => 'Gifs',
					  'singular_name' => __('Gif','bestia'),
					  'menu_name' => __('Gifs','bestia'),
					  'add_new' => __('Add New','bestia'),
					  'add_new_item' => __('Add New Gif Post','bestia'),
					  'edit' => __('Edit','bestia'),
					  'edit_item' => __('Edit Gif','bestia'),
					  'new_item' => __('New Gif Post','bestia'),
					  'view' => __('View Gif Post','bestia'),
					  'view_item' => __('View Gif','bestia'),
					  'search_items' => __('Search Gifs','bestia'),
					  'not_found' => __('No Gifs Found','bestia'),
					  'not_found_in_trash' => __('No Gifs Found in Trash','bestia'),
					  'parent' => __('Parent Gif','bestia'),
					)
			);
			$args	=	apply_filters( 'bestia_gifs_post_type_args' , $args);
			if( $awpt['gifs_cpt'] == 1 ){
				register_post_type('gif', $args);
			}
		}
	}
	new bestia_gifs_post_type();
}
