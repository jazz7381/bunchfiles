<?php if( !defined('ABSPATH') ) exit;
add_action('pre_get_posts', 'bestia_limit_videos_photos');
function bestia_limit_videos_photos( $query ) {
global $awpt;
    $tag_videos = $awpt['tax_videos'];
    $tag_photos = $awpt['tax_photos'];
    $tag_blogs = $awpt['blogs_per_page'];
    $gifs = $awpt['gifs_per_page'];
 if( $query->is_category() && !is_admin()):
    $query->set('posts_per_page', $tag_videos);
   return;
 endif;
 if( $query->is_search() && !is_admin()):
    $query->set('posts_per_page', $tag_videos);
   return;
 endif;
 if( $query->is_tag() && !is_admin()):
    $query->set('posts_per_page', $tag_videos);
   return;
 endif;
 if( !is_admin() && is_tax( 'phototype' ) ) {
    $query->set( 'posts_per_page', $tag_photos );
  }
 if( !is_admin() && is_tax( 'photo_tag' ) || is_post_type_archive( 'gallery' ) ) {
    $query->set( 'posts_per_page', $tag_photos );
  }
 if( !is_admin() && is_tax( 'blogtype' ) || is_post_type_archive( 'blogs' ) ) {
    $query->set( 'posts_per_page', $tag_blogs );
  }
 if( !is_admin() && is_tax( 'blog_tag' )) {
    $query->set( 'posts_per_page', $tag_blogs );
  }
  if( !is_admin() && is_tax( 'giftype' ) || is_post_type_archive( 'gif' ) ) {
     $query->set( 'posts_per_page', $gifs );
   }
  if( !is_admin() && is_tax( 'gif_tag' )) {
     $query->set( 'posts_per_page', $gifs );
   }
}
