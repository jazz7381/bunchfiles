<?php if( !defined('ABSPATH') ) exit;
if( !function_exists('widget_notice') ){
		function widget_notice() {
	    if( current_user_can('administrator') ) {
				//echo '<p class="sidebar_notice">Click <a href="'.home_url( '/' ).'wp-admin/widgets.php">Here</a> to manage this sidebar.</p>';
			}
		}
	add_action('widget_notice', 'widget_notice');
}
//Category Sdiebar
if( !function_exists('category_sidebar') ){
	function category_sidebar() {
		if ( is_active_sidebar( 'sidebar-cat' ) ) {
			dynamic_sidebar( 'sidebar-cat' );
		} else {
      //do_action('widget_notice');
			echo '<p></p>';
		}
	}
add_action('category_sidebar', 'category_sidebar');
}
//General Sdiebar
if( !function_exists('general_sidebar') ){
	function general_sidebar() {
		if ( is_active_sidebar( 'sidebar-2' ) ) {
			get_sidebar();
		 } else {
			echo '<p></p>';
		}
	}
add_action('general_sidebar', 'general_sidebar');
}
//Page Sdiebar
if( !function_exists('page_sidebar') ){
	function page_sidebar() {
		if ( is_active_sidebar( 'sidebar-6' ) ) {
			dynamic_sidebar( 'sidebar-6' );
		 } else {
			echo '<p></p>';
		}
	}
add_action('page_sidebar', 'page_sidebar');
}
//Blog Sdiebar
if( !function_exists('blog_sidebar') ){
	function blog_sidebar() {
		if ( is_active_sidebar( 'sidebar-3' ) ) {
			dynamic_sidebar( 'sidebar-3' );
		 } else {
			echo '<p></p>';
		}
	}
add_action('blog_sidebar', 'blog_sidebar');
}
//Gallery Sidebar
if( !function_exists('gallery_sidebar') ){
	function gallery_sidebar() {
		if ( is_active_sidebar( 'sidebar-7' ) ) {
			dynamic_sidebar( 'sidebar-7' );
		 } else {
			echo '<p></p>';
		}
	}
add_action('gallery_sidebar', 'gallery_sidebar');
}
//Gallery Sidebar
if( !function_exists('channel_sidebar') ){
	function channel_sidebar() {
		if ( is_active_sidebar( 'channel-cat' ) ) {
			dynamic_sidebar( 'channel-cat' );
		 } else {
			echo '<p></p>';
		}
	}
add_action('channel_sidebar', 'channel_sidebar');
}

//GIF Sidebar
if( !function_exists('gif_sidebar') ){
	function gif_sidebar() {
		if ( is_active_sidebar( 'sidebar-gif' ) ) {
			dynamic_sidebar( 'sidebar-gif' );
		 } else {
			echo '<p></p>';
		}
	}
add_action('gif_sidebar', 'gif_sidebar');
}

//Single Video Sdiebar left
if( !function_exists('single_sidebar_left') ){
	function single_sidebar_left() {
		if ( is_active_sidebar( 'sidebar-5' ) ) {
			dynamic_sidebar( 'sidebar-5' );
		 } else {
			echo '<p></p>';
		}
	}
add_action('single_sidebar_left', 'single_sidebar_left');
}
//Single Gallery Sdiebar Left
if( !function_exists('single_gallery_sidebar') ){
	function single_gallery_sidebar() {
		if ( is_active_sidebar( 'sidebar-8' ) ) {
			dynamic_sidebar( 'sidebar-8' );
		 } else {
			echo '<p></p>';
		}
	}
add_action('single_gallery_sidebar', 'single_gallery_sidebar');
}
//Single Blogs Sdiebar left
if( !function_exists('single_blog_sidebar') ){
	function single_blog_sidebar() {
		if ( is_active_sidebar( 'sidebar-single-blog' ) ) {
			dynamic_sidebar( 'sidebar-single-blog' );
		 } else {
			echo '<p></p>';
		}
	}
add_action('single_blog_sidebar', 'single_blog_sidebar');
}
