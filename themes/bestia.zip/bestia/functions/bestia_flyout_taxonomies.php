<?php if( !defined('ABSPATH') ) exit;
// Categories Flyout Menu Item
add_filter( 'nav_menu_link_attributes', 'flyout_categories_menu_atts', 10, 3 );
function flyout_categories_menu_atts( $atts, $item, $args )
{
  // Provide the id of the targeted menu item
  $menu_target = 123;

  // inspect $item

  if ($item->ID == $menu_target) {
    // original post used a comma after 'modal' but this caused a 500 error as is mentioned in the OP's reply
    $atts['data-action'] = 'dropdown-toggle';
    $atts['data-target'] = '#categories-block';
  }
  return $atts;
}
// Performers Flyout Menu Item
add_filter( 'nav_menu_link_attributes', 'flyout_performers_menu_atts', 10, 3 );
function flyout_performers_menu_atts( $atts, $item, $args )
{
  // Provide the id of the targeted menu item
  $menu_target = 124;

  // inspect $item

  if ($item->ID == $menu_target) {
    // original post used a comma after 'modal' but this caused a 500 error as is mentioned in the OP's reply
    $atts['data-action'] = 'dropdown-toggle';
    $atts['data-target'] = '#performers-block';
  }
  return $atts;
}
// ChannelsFlyout Menu Item
add_filter( 'nav_menu_link_attributes', 'flyout_channels_menu_atts', 10, 3 );
function flyout_channels_menu_atts( $atts, $item, $args )
{
  // Provide the id of the targeted menu item
  $menu_target = 125;

  // inspect $item

  if ($item->ID == $menu_target) {
    // original post used a comma after 'modal' but this caused a 500 error as is mentioned in the OP's reply
    $atts['data-action'] = 'dropdown-toggle';
    $atts['data-target'] = '#channels-block';
  }
  return $atts;
}