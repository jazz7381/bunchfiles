<?php
if( !defined('ABSPATH') ) exit;
if (function_exists('tubeace_activate')) { //checks if tubeace is active
//Remove default tubeace player function from plugin
remove_filter( 'the_content', 'tubeace_activate', 10 );
// add video player to the single.php . tubeace is require for this funcition
function tubeace_video_player() {
  $embed_code = get_post_meta( get_the_ID(),'embed_code',true);
  $video_id = get_post_meta( get_the_ID(),'video_id',true);
  $site = get_post_meta( get_the_ID(),'site',true);
  if(!empty($embed_code)){
    $code = $embed_code;
  } elseif($site =="drtuber.com"){
    $code = get_site_option('tubeace_drtuber_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="pornhub.com"){
    $code = get_site_option('tubeace_pornhub_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="keezmovies.com"){
    $code = get_site_option('tubeace_keezmovies_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="porntube.com"){
    $code = get_site_option('tubeace_porntube_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="redtube.com"){
    $code = get_site_option('tubeace_redtube_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="spankwire.com"){
    $code = get_site_option('tubeace_spankwire_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="sunporno.com"){
    $code = get_site_option('tubeace_sunporno_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="tube8.com"){
    $code = get_site_option('tubeace_tube8_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="xhamster.com"){
    $code = get_site_option('tubeace_xhamster_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="xtube.com"){
    $code = get_site_option('tubeace_xtube_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="xvideos.com"){
    $code = get_site_option('tubeace_xvideos_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } elseif($site =="youporn.com"){
    $code = get_site_option('tubeace_youporn_video_player_code');
    $code = str_replace("{video_id}", $video_id, $code);
    $code = $code;
  } else{
    $code = '';
  }
    echo '<div class="videoWrapper">'.$code.'</div>';
}
add_action('tubeace_video_player','tubeace_video_player');
}
// show single or rotating thumbnail.
function tubeace_thumbs( $html, $post_id, $post_image_id ) {
   global $awpt;
    $saved_thmb = get_post_meta( $post_id,'saved_thmb',true);

    $subPath = tubeace_sub_dir_path($post_id);

    $upload_dir = wp_upload_dir();
    $thumb_url = $upload_dir['baseurl']."/tubeace-thumbs/".$subPath."/";

    if($saved_thmb>1) {

        $def_thmb = get_post_meta( $post_id,'def_thmb',true);

        $thumb = $thumb_url."/".$post_id."_".$def_thmb.".jpg";

        $prefix = 'main';

        $title = get_the_title($post_id);

        $rotate_thumbs = "onmouseover=\"thumbStart('$prefix-".$post_id."', $saved_thmb, '$thumb_url');\" onmouseout=\"thumbStop('$prefix-".$post_id."', '$thumb_url', '$def_thmb');\"";

        $thumb = "<img class=\"img-responsive wp-post-image\" src=\"$thumb\" $rotate_thumbs id=\"$prefix-".$post_id."\" alt=\"".esc_attr($title)."\">";
        return $thumb;

    } else {//single thumb generated or non-tubeace post
        return $html;
    }
}
add_filter( 'post_thumbnail_html', 'tubeace_thumbs', 10, 8 );
