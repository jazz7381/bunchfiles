<?php if( !defined('ABSPATH') ) exit;
if( !function_exists('bestia_performer_video_photos') ){
	function bestia_performer_video_photos() {
		$order = isset( $_REQUEST['order'] ) ?  trim($_REQUEST['order']) : null;
		$sort_array = array(
			'videos'	=>	__('Videos','bestia'),
			'photos'	=>	__('Photos','bestia')
		);
		   $block = '';
         $block .= '<span class="ordering">';
			foreach ( $sort_array as $key=>$value ){
				$active = ( $order == $key ) ? 'active' : null;
					$block .= '<a href="?order='.$key.'" class="'.$key.' performer-photos '.$active.'"><span>'.$value.'</span></a>';
			}
			$block .= '</span>';

		print $block;
	}
	add_action('bestia_performer_video_photos', 'bestia_performer_video_photos');
}

// in the future drop down for sorted today, this year etc...  echo '<a class="btn drop" href="#drop"><span></span></a>';
if( !function_exists('bestia_orderblock_videos') ){
	function bestia_orderblock_videos() {
		global $awpt;
		$newest = $awpt['newest_btn'];
		$viewed = $awpt['viewed_btn'];
    $voted = $awpt['rating_btn'];
    $commented = $awpt['discussed_btn'];
    $sort_by = $awpt['sort_by_mobile'];
		$order = isset( $_REQUEST['order'] ) ?  trim($_REQUEST['order']) : null;
		$sort_array = array(
			'newest'	=>	$newest,
			'views'	=>	$viewed,
			'rate'	=>	$voted,
			'discussed'	=>	$commented
		);

		$block = '<div class="btn-group buttons visible-desktop video_sorter">';
			foreach ( $sort_array as $key=>$value ){
				$active = ( $order == $key ) ? 'active' : null;
				if( is_search() ){
					$block .= '<a class="btn '.$active.'" href="?s='.get_query_var('s').'&order='.$key.'">'.$value.'</a>';
				} elseif (is_category() ) { $category_id = get_query_var('cat');
				   $block .= '<a class="btn '.$active.'" href="'.get_category_link( $category_id ).'?order='.$key.'">'.$value.'</a>';
				} else{
					$block .= '<a class="btn '.$active.'" href="?order='.$key.'">'.$value.'</a>';
				}
			}
		$block .= '</div>';
		print $block;

		$block_mobile = '';
		$block_mobile = '<div class="dropdown pull-right visible-mobile">
		<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
		'.$sort_by.'
		 <span class="caret"></span></button>
		<ul class="dropdown-menu">';
		foreach ( $sort_array as $key=>$value ){
			$active = ( $order == $key ) ? 'active' : null;
			if( is_search() ){
				$block_mobile .= '<a class="btn '.$active.'" href="?s='.get_query_var('s').'&order='.$key.'">'.$value.'</a>';
			} elseif (is_category() ) { $category_id = get_query_var('cat');
				 $block_mobile .= '<li><a class="'.$active.'" href="'.get_category_link( $category_id ).'?order='.$key.'">'.$value.'</a></li>';
			} else{
				$block_mobile .= '<li><a class="'.$active.'" href="?order='.$key.'">'.$value.'</a></li>';
			}
		}
			$block_mobile .= '</ul></div>';
		   print $block_mobile;
	}
	add_action('bestia_orderblock_videos', 'bestia_orderblock_videos');
}
if( !function_exists('bestia_orderquery_videos') ){
	function bestia_orderquery_videos( $query ) {
		global $awpt; $home_videos = $awpt['homepage_videos'];
		$likes_key = 'likes_count';
		$order = isset( $_REQUEST['order'] ) ? trim( $_REQUEST['order'] ) : null;
		if( is_search() || is_tax() || is_archive() && !is_admin() ){
			if( $query->is_main_query() ){
				switch ( $order ) {
					case 'newest':
						$query->set( 'order', 'DESC' );
					break;
					case 'discussed':
						$query->set( 'orderby', 'comment_count' );
					break;
					case 'views':
						$query->set( 'meta_key','post_views_count' );
						$query->set( 'orderby', 'meta_value_num' );
					break;
					case 'rate':
						$query->set( 'meta_key', $likes_key );
					break;
				}
			}
			$query->set( 'order', 'DESC' );
		}
		return $query;
	}
	add_filter('pre_get_posts', 'bestia_orderquery_videos');
}

if( !function_exists('bestia_get_ordered_title') ){
function bestia_get_ordered_title() {
$order = isset( $_REQUEST['order'] ) ?  trim($_REQUEST['order']) : null;
global $awpt;
$h_tag_general = $awpt['general_title_heading'];
  if($order=='rate') {
    $title = $awpt['mtn_rated_title'];
    } elseif($order=='views') {
    $title = $awpt['mtn_viewed_title'];
    } elseif($order=='discussed') {
    $title = $awpt['mtn_commented_title'];
    } elseif($order=='newest'){
    $title = $awpt['mtn_newest_title'];
    } else {
		//print '<style>.video_sorter > .btn:first-child {}</style>';
    $title = $awpt['mtn_newest_title'];
   }
print getBestiaHeadingtags($h_tag_general,$title);
}
add_action('bestia_get_ordered_title', 'bestia_get_ordered_title');
}
/*
add_filter('pre_get_document_title', 'bestia_update_wp_title_tag');
function bestia_update_wp_title_tag() {
	$order = isset( $_REQUEST['order'] ) ?  trim($_REQUEST['order']) : null;
	global $awpt;
	$title = '';
  $first_tag = '';
	if ( is_front_page() ) {
	  $first_tag = ' - ' . get_bloginfo( 'name' );
  } elseif ( is_search() ) {
		$first_tag = ' - ' . get_search_query();
	}
	if($order=='rate') {
    $title = $awpt['mtn_rated_title'] . $first_tag;
    } elseif($order=='views') {
    $title = $awpt['mtn_viewed_title'] . $first_tag;
    } elseif($order=='discussed') {
    $title = $awpt['mtn_commented_title'] . $first_tag;
    } elseif($order=='newest'){
    $title = $awpt['mtn_newest_title'] . $first_tag;
    }
	return $title;
}
*/
if( !function_exists('bestia_get_ordered_changes_on_homepage') ){
function bestia_get_ordered_changes_on_homepage() {
$order = isset( $_REQUEST['order'] ) ?  trim($_REQUEST['order']) : null;
global $awpt;
  if($order=='rate') {
  	print '<style>.being_watched,.homepage_galleries{display:none;}</style>';
  	 } elseif($order=='views') {
  	print '<style>.being_watched,.homepage_galleries{display:none;}</style>';
    } elseif($order=='newest') {
  	print '<style>.being_watched,.homepage_galleries{display:none;}</style>';
    } elseif($order=='discussed') {
  	print '<style>.being_watched,.homepage_galleries{display:none;}</style>';
    } else {
    //print '<style>.inline_sorters .buttons a.btn:first-child{background: rgba(0, 0, 0, 0) linear-gradient(to bottom, #ddd 0px, #e1e1e1 100%) repeat scroll 0 0;border: 1px solid #aaa;box-shadow: 1px 1px 1px rgba(0, 0, 0, 0.2) inset;}</style>';
   }
}
add_action('wp_head', 'bestia_get_ordered_changes_on_homepage');
}

//Block robots from dynamic urls
if( !function_exists('bestia_add_noindex_to_dynamic_pages') ){
function bestia_add_noindex_to_dynamic_pages() {
$order = isset( $_REQUEST['order'] ) ?  trim($_REQUEST['order']) : null;
global $awpt;
  if($order) {
		print '<meta name="robots" content="noindex, nofollow">';
  }
}
add_action('wp_head', 'bestia_add_noindex_to_dynamic_pages');
}
