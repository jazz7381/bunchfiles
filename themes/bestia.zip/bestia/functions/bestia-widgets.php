<?php if( !defined('ABSPATH') ) exit;
/* Register Bestia Widgets */
function bestia_register_custom_widgets() {
global $awpt;
register_widget( 'Bestia_Widget_Recent_Posts' );
register_widget( 'WP_Widget_Custom_Categories' );
register_widget( 'wpse97411_WP_Widget_Categories' );
//register_widget( 'Bestia_Popular_Performers' );
if( $awpt['blogs_cpt'] == 1 ){
register_widget( 'Bestia_Widget_Blog_Posts' );
}
if( $awpt['gallery_cpt'] == 1 ){
register_widget( 'Bestia_Gallery_Photos_Widget' );
}
/*
if( $awpt['blogs_cpt'] == 1 ){
register_widget( 'Bestia_Widget_Blog_Posts' );
register_widget( 'Widget_Random_Blogs' );
}
*/
}
add_action( 'widgets_init', 'bestia_register_custom_widgets' );

if ( ! class_exists( 'WP_Widget_Custom_Categories' ) ) {
    /**
     * Class for adding widget
     *
     * @package Coder Customizer Framework
     * @since 1.0
     */
    class WP_Widget_Custom_Categories extends WP_Widget {
        function __construct() {
            parent::__construct(
            /*Base ID of your widget*/
                'taxonomy_term_widget',
                /*Widget name will appear in UI*/
                __('(Bestia) Taxonomies', 'bestia'),
                /*Widget description*/
                array( 'description' => __( 'Add advanced widget to your wordpress blog,like an extension of Categories widget', 'bestia' ), )
            );
        }
        /*Widget Backend*/
        public function form( $instance ) {
            if ( isset( $instance[ 'title' ] ) ) {
                $title = $instance[ 'title' ];
            }
            else {
                $title = __( 'New title', 'bestia' );
            }
            if ( isset( $instance[ 'taxonomy' ] ) ) {
                $selected_taxonomy = $instance[ 'taxonomy' ];
            }
            else {
                $selected_taxonomy = '';
            }
            if ( isset( $instance[ 'tax_is_display_dropdown' ] ) ) {
                $tax_is_display_dropdown = $instance[ 'tax_is_display_dropdown' ];
            }
            else {
                $tax_is_display_dropdown = '';
            }
            if ( isset( $instance[ 'tax_is_show_posts_count' ] ) ) {
                $tax_is_show_posts_count = $instance[ 'tax_is_show_posts_count' ];
            }
            else {
                $tax_is_show_posts_count = '';
            }
            if ( isset( $instance[ 'tax_is_show_hierarchy' ] ) ) {
                $tax_is_show_hierarchy = $instance[ 'tax_is_show_hierarchy' ];
            }
            else {
                $tax_is_show_hierarchy = '';
            }
            if ( isset( $instance[ 'tax_orderby' ] ) ) {
                $tax_orderby = $instance[ 'tax_orderby' ];
            }
            else {
                $tax_orderby = '';
            }
            if ( isset( $instance[ 'tax_order' ] ) ) {
                $tax_order = $instance[ 'tax_order' ];
            }
            else {
                $tax_order = '';
            }
            if ( isset( $instance[ 'child_of' ] ) ) {
                $child_of = $instance[ 'child_of' ];
            }
            else {
                $child_of = '';
            }
            if ( isset( $instance[ 'tax_exclude' ] ) ) {
                $tax_exclude = $instance[ 'tax_exclude' ];
            }
            else {
                $tax_exclude = '';
            }
            if ( isset( $instance[ 'tax_hidempty' ] ) ) {
                $tax_hidempty = $instance[ 'tax_hidempty' ];
            }
            else {
                $tax_hidempty = '';
            }
            if ( isset( $instance[ 'tax_firstoption' ] ) ) {
                $tax_firstoption = $instance[ 'tax_firstoption' ];
            }
            else {
                $tax_firstoption = '';
            }
            /*Widget admin form*/
            ?>
            <p>
                <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Enter title:' ,'bestia'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('taxonomy'); ?>"><?php _e('Select Taxonomy', 'bestia'); ?></label>
                <select name="<?php echo $this->get_field_name('taxonomy'); ?>" id="<?php echo $this->get_field_id('taxonomy'); ?>" class="widefat">
                    <?php
                    $args = array(
                        'public'   => true,
                    );
                    $taxonomies = get_taxonomies($args, 'objects');
                    foreach ($taxonomies as $taxonomy) {
                    if('post_format' == $taxonomy->name ) { continue; }
                    echo '<option value="' . $taxonomy->name . '" id="' . $taxonomy->name . '"', $selected_taxonomy == $taxonomy->name ? ' selected="selected"' : '', '>', $taxonomy->labels->name, '</option>'; } ?>
                </select>
            </p>
            <p>
                <input id="<?php echo $this->get_field_id('tax_is_display_dropdown'); ?>" name="<?php echo $this->get_field_name('tax_is_display_dropdown'); ?>" type="checkbox" value="1" <?php checked( '1', $tax_is_display_dropdown ); ?> />
                <label for="<?php echo $this->get_field_id('tax_is_display_dropdown'); ?>"><?php _e('Display as dropdown', 'bestia'); ?></label><br>

                <input id="<?php echo $this->get_field_id('tax_is_show_posts_count'); ?>" name="<?php echo $this->get_field_name('tax_is_show_posts_count'); ?>" type="checkbox" value="1" <?php checked( '1', $tax_is_show_posts_count ); ?> />
                <label for="<?php echo $this->get_field_id('tax_is_show_posts_count'); ?>"><?php _e('Show post counts', 'bestia'); ?></label><br>

                <input id="<?php echo $this->get_field_id('tax_is_show_hierarchy'); ?>" name="<?php echo $this->get_field_name('tax_is_show_hierarchy'); ?>" type="checkbox" value="1" <?php checked( '1', $tax_is_show_hierarchy ); ?> />
                <label for="<?php echo $this->get_field_id('tax_is_show_hierarchy'); ?>"><?php _e('Show hierarchy', 'bestia'); ?></label><br>

                <input id="<?php echo $this->get_field_id('tax_hidempty'); ?>" name="<?php echo $this->get_field_name('tax_hidempty'); ?>" type="checkbox" value="1" <?php checked( '1', $tax_hidempty ); ?> />
                <label for="<?php echo $this->get_field_id('tax_hidempty'); ?>"><?php _e('Hide empty', 'bestia'); ?></label><br>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('tax_orderby'); ?>"><?php _e('Select Order By', 'bestia'); ?></label>
                <select name="<?php echo $this->get_field_name('tax_orderby'); ?>" id="<?php echo $this->get_field_id('tax_orderby'); ?>" class="widefat">
                    <?php
                    $options_orderby = array('ID', 'NAME', 'SLUG','COUNT');
                    foreach ($options_orderby as $option_orderby) {
                        echo '<option value="' . $option_orderby . '" id="' . $option_orderby . '"', $tax_orderby == $option_orderby ? ' selected="selected"' : '', '>', $option_orderby, '</option>';
                    }
                    ?>
                </select>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('tax_order'); ?>"><?php _e('Select Order', 'bestia'); ?></label>
                <select name="<?php echo $this->get_field_name('tax_order'); ?>" id="<?php echo $this->get_field_id('tax_order'); ?>" class="widefat">
                    <?php
                    $options_order = array('ASC', 'DESC');
                    foreach ($options_order as $option_order) {
                        echo '<option value="' . $option_order . '" id="' . $option_order . '"', $tax_order == $option_order ? ' selected="selected"' : '', '>', $option_order, '</option>';
                    }
                    ?>
                </select>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'child_of' ); ?>"><?php _e( 'Enter parent term id ( Only display terms that are children of this ):' ,'bestia'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'child_of' ); ?>" name="<?php echo $this->get_field_name( 'child_of' ); ?>" type="text" value="<?php echo esc_attr( $child_of ); ?>" placeholder="<?php _e( '12' ,'bestia'); ?>"/>
                <br>
                <small>Left empty for show all terms, also make sure if the term have any child. For finding id, edit term, in the address bar you will see tag_ID=3 or others number, the number is id of any term.</small>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'tax_exclude' ); ?>"><?php _e( 'Enter comma separated id/ids to exclude:' ,'bestia'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'tax_exclude' ); ?>" name="<?php echo $this->get_field_name( 'tax_exclude' ); ?>" type="text" value="<?php echo esc_attr( $tax_exclude ); ?>" placeholder="<?php _e( '1,25,9' ,'bestia'); ?>"/>
                <br>
                <small>Left empty for show all terms without excluding any</small>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'tax_firstoption' ); ?>"><?php _e( 'Enter first option value to display only if you have checked- Display as dropdown' ,'bestia'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'tax_firstoption' ); ?>" name="<?php echo $this->get_field_name( 'tax_firstoption' ); ?>" type="text" value="<?php echo esc_attr( $tax_firstoption ); ?>" placeholder="<?php _e( 'Select option' ,'bestia'); ?>"/>
            </p>
        <?php
        }

        /**
         * Function to Updating widget replacing old instances with new
         *
         * @access public
         * @since 1.0
         *
         * @param array $new_instance new arrays value
         * @param array $old_instance old arrays value
         * @return array
         *
         */
        public function update( $new_instance, $old_instance ) {
            $instance = array();
            $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
            $instance['taxonomy'] = ( ! empty( $new_instance['taxonomy'] ) ) ? strip_tags( $new_instance['taxonomy'] ) : '';
            $instance['tax_is_display_dropdown'] = ( ! empty( $new_instance['tax_is_display_dropdown'] ) ) ? strip_tags( $new_instance['tax_is_display_dropdown'] ) : '';
            $instance['tax_is_show_posts_count'] = ( ! empty( $new_instance['tax_is_show_posts_count'] ) ) ? strip_tags( $new_instance['tax_is_show_posts_count'] ) : '';
            $instance['tax_is_show_hierarchy'] = ( ! empty( $new_instance['tax_is_show_hierarchy'] ) ) ? strip_tags( $new_instance['tax_is_show_hierarchy'] ) : '';
            $instance['tax_hidempty'] = ( ! empty( $new_instance['tax_hidempty'] ) ) ? strip_tags( $new_instance['tax_hidempty'] ) : '';
            $instance['tax_orderby'] = ( ! empty( $new_instance['tax_orderby'] ) ) ? sanitize_text_field( $new_instance['tax_orderby'] ) : '';
            $instance['child_of'] = ( ! empty( $new_instance['child_of'] ) ) ? sanitize_text_field( $new_instance['child_of'] ) : '';
            $instance['tax_order'] = ( ! empty( $new_instance['tax_order'] ) ) ? sanitize_text_field( $new_instance['tax_order'] ) : '';
            $instance['tax_exclude'] = ( ! empty( $new_instance['tax_exclude'] ) ) ? sanitize_text_field( $new_instance['tax_exclude'] ) : '';
            $instance['tax_firstoption'] = ( ! empty( $new_instance['tax_firstoption'] ) ) ? sanitize_text_field( $new_instance['tax_firstoption'] ) : '';

            return $instance;
        }
        /**
         * Function to Creating widget front-end. This is where the action happens
         *
         * @access public
         * @since 1.0
         *
         * @param array $args widget setting
         * @param array $instance saved values
         * @return array
         *
         */
        public function widget( $args, $instance ) {
            //$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? __( 'Pages' ) : $instance['title'], $instance, $this->id_base );
            $title = apply_filters( 'widget_title', isset($instance['title']) ? $instance['title'] : '' );
            $taxonomy = isset($instance['taxonomy']) ? $instance['taxonomy'] : '';
            $tax_is_display_dropdown = isset($instance['tax_is_display_dropdown']) ? $instance['tax_is_display_dropdown'] : '';
            $tax_is_show_posts_count = isset($instance['tax_is_show_posts_count']) ? $instance['tax_is_show_posts_count'] : '6';
            $tax_is_show_hierarchy = isset($instance['tax_is_show_hierarchy']) ? $instance['tax_is_show_hierarchy'] : '';
            $tax_hidempty = isset($instance['tax_hidempty']) ? $instance['tax_hidempty'] : '';
            if(empty($tax_hidempty)) $tax_hidempty = 0;
            $tax_orderby = isset($instance['tax_orderby']) ? $instance['tax_orderby'] : '';
            $tax_order = isset($instance['tax_order']) ? $instance['tax_order'] : '';
            $child_of = isset($instance['child_of']) ? $instance['child_of'] : '';
            $tax_exclude = isset($instance['tax_exclude']) ? $instance['tax_exclude'] : '';
            $tax_firstoption = isset($instance['tax_firstoption']) ? $instance['tax_firstoption'] : '';
            // before and after widget arguments are defined by themes
            echo $args['before_widget'];
            if ( ! empty( $title ) )
                echo $args['before_title'] . $title . $args['after_title'];
            if( $tax_is_display_dropdown == 1){
                $args1 = array(
                    'show_option_none'   => $tax_firstoption,
                    'orderby'            => $tax_orderby,
                    'order'              => $tax_order,
                    'show_count'         => $tax_is_show_posts_count,
                    'hide_empty'         => $tax_hidempty,
                    'child_of'          => $child_of,
                    'exclude'            => $tax_exclude,
                    'echo'               => 1,
                    'hierarchical'       => $tax_is_show_hierarchy,
                    'name'               => 'coder_taxonomy',
                    'id'                 => 'coder_taxonomy',
                    'class'              => 'postform bestia_custom_taxonomy_widget',
                    'taxonomy'           => $taxonomy,
                    'hide_if_empty'      => false,
                );
                ?>
                <?php
                wp_dropdown_categories($args1);
                echo "<input type='hidden' id='coder_term_widget_current_taxonomy' value='{$taxonomy}'>";
                ?>

            <?php
            }
            else {
                $args2 = array(
                    'show_option_all'    => '',
                    'orderby'            => $tax_orderby,
                    'order'              => $tax_order,
                    'style'              => 'list',
                    'show_count'         => $tax_is_show_posts_count,
                    'hide_empty'         => $tax_hidempty,
                    'use_desc_for_title' => 1,
                    'child_of'          => $child_of,
                    'exclude'            => $tax_exclude,
                    'hierarchical'       => $tax_is_show_hierarchy,
                    'title_li'           => __( '' ),
                    'show_option_none'   => __('No Terms'),
                    'number'             => null,
                    'echo'               => 1,
                    'taxonomy'           => $taxonomy,
                );
                echo "<ul>";
                wp_list_categories( $args2 );
                echo "</ul>";
            }
            echo $args['after_widget'];
        }
    } // Class coder_taxonomy_term ends here

}
/* Bestia Video Categories Widget */
class wpse97411_WP_Widget_Categories extends WP_Widget {

	public function __construct() {
		$widget_ops = array( 'classname' => 'widget_categories', 'description' => __( "A list or dropdown of categories." ) );
		parent::__construct('categories', __('Categories'), $widget_ops);
	}

	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? __( 'Categories' ) : $instance['title'], $instance, $this->id_base );

		$c = ! empty( $instance['count'] ) ? '1' : '0';
		$h = ! empty( $instance['hierarchical'] ) ? '1' : '0';
		$d = ! empty( $instance['dropdown'] ) ? '1' : '0';

		echo $args['before_widget'];
		if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}
	$categories = get_categories();
echo '<ul>';
foreach($categories as $category) {
    echo '<li class="cat-item">
         <a href="' . get_category_link( $category->term_id ) . '">' . $category->name;
         echo '</a>';
				 if ( $c ) {
				 static $post_count = true;
					 echo '<span class="count">(' . $category->count . ')</span>';
				}
				echo '</li>';
}
echo '</ul>';

		echo $args['after_widget'];
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['count'] = !empty($new_instance['count']) ? 1 : 0;

		return $instance;
	}

	public function form( $instance ) {
		//Defaults
		$instance = wp_parse_args( (array) $instance, array( 'title' => '') );
		$title = esc_attr( $instance['title'] );
		$count = isset($instance['count']) ? (bool) $instance['count'] :false;
?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title:' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>"<?php checked( $count ); ?> />
		<label for="<?php echo $this->get_field_id('count'); ?>"><?php _e( 'Show post counts' ); ?></label><br />
<?php
	}

}

/* recent videos */
class Bestia_Widget_Recent_Posts extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'widget_recent_entries', 'description' => __( "The most recent videos on your site") );
        parent::__construct('recent-posts', __('(Bestia) - Recent Videos'), $widget_ops);
        $this->alt_option_name = 'widget_recent_entries';

        add_action( 'save_post', array($this, 'flush_widget_cache') );
        add_action( 'deleted_post', array($this, 'flush_widget_cache') );
        add_action( 'switch_theme', array($this, 'flush_widget_cache') );
    }

    function widget($args, $instance) {
        $cache = wp_cache_get('widget_recent_posts', 'widget');

        if ( !is_array($cache) )
            $cache = array();

        if ( ! isset( $args['widget_id'] ) )
            $args['widget_id'] = $this->id;

        if ( isset( $cache[ $args['widget_id'] ] ) ) {
            echo $cache[ $args['widget_id'] ];
            return;
        }

        ob_start();
        extract($args);

        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( '' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
        if ( ! $number )
        $number = 5;

        $r = new WP_Query( apply_filters( 'widget_posts_args', array( 'posts_per_page' => $number, 'no_found_rows' => true, 'post_status' => 'publish', 'ignore_sticky_posts' => true ) ) );
        if ($r->have_posts()) :
        ?>
        <?php echo $before_widget; ?>
        <?php if ( $title ) echo $before_title . $title . $after_title; ?>
        <ul class="WidgetThumbs">
        <?php while ( $r->have_posts() ) : $r->the_post(); do_action( 'bestia_thumbnail_compatibility' ); endwhile; ?>
        </ul>
        <?php echo $after_widget; ?>
        <?php
        // Reset the global $the_post as this query will have stomped on it
        wp_reset_postdata();

        endif;

        $cache[$args['widget_id']] = ob_get_flush();
        wp_cache_set('widget_recent_posts', $cache, 'widget');
    }

        function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = (int) $new_instance['number'];
        $this->flush_widget_cache();

        $alloptions = wp_cache_get( 'alloptions', 'options' );
        if ( isset($alloptions['widget_recent_entries']) )
            delete_option('widget_recent_entries');

        return $instance;
    }

    function flush_widget_cache() {
        wp_cache_delete('widget_recent_posts', 'widget');
    }

    function form( $instance ) {
        $title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
        $number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
?>
        <p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>

        <p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of posts to show:' ); ?></label>
        <input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo $number; ?>" size="3" /></p>
<?php
    }
}

/* random photo galleries */
class Bestia_Gallery_Photos_Widget extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'widget_random_photo_galleries', 'description' => __( "The random photo galleries widget") );
        parent::__construct('random-pics', __('(Bestia) - Photo Galleries'), $widget_ops);
        $this->alt_option_name = 'widget_random_photo_galleries';

        add_action( 'save_post', array($this, 'flush_photos_widget_page') );
        add_action( 'deleted_post', array($this, 'flush_photos_widget_page') );
        add_action( 'switch_theme', array($this, 'flush_photos_widget_page') );
    }

    function widget($args, $instance) {
        $cache = wp_cache_get('widget_random_posts', 'widget');

        if ( !is_array($cache) )
            $cache = array();

        if ( ! isset( $args['widget_id'] ) )
            $args['widget_id'] = $this->id;

        if ( isset( $cache[ $args['widget_id'] ] ) ) {
            echo $cache[ $args['widget_id'] ];
            return;
        }

        ob_start();
        extract($args);

        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( '' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
        if ( ! $number )
        $number = 5;
        $r = new WP_Query(array('showposts' => $number, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => true, 'orderby' => 'rand', 'post_type' => 'gallery' ));
        if ($r->have_posts()) :
        ?>
        <?php echo $before_widget; ?>
        <?php if ( $title ) echo $before_title . $title . $after_title; ?>
        <ul class="WidgetThumbs">
        <?php while ( $r->have_posts() ) : $r->the_post(); do_action( 'bestia_thumbnail_compatibility' ); endwhile; ?>
        </ul>
        <?php echo $after_widget; ?>
        <?php
        // Reset the global $the_post as this query will have stomped on it
        wp_reset_postdata();

        endif;

        $cache[$args['widget_id']] = ob_get_flush();
        wp_cache_set('widget_random_posts', $cache, 'widget');
    }

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = (int) $new_instance['number'];
        $this->flush_photos_widget_page();

        $alloptions = wp_cache_get( 'alloptions', 'options' );
        if ( isset($alloptions['widget_random_photo_galleries']) )
            delete_option('widget_random_photo_galleries');

        return $instance;
    }

    function flush_photos_widget_page() {
        wp_cache_delete('widget_random_posts', 'widget');
    }

    function form( $instance ) {
        $title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
        $number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
?>
        <p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>

        <p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of posts to show:' ); ?></label>
        <input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo $number; ?>" size="3" /></p>
<?php
    }
}


/* Popular Performers
class Bestia_Popular_Performers extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'widget_popular_performers', 'description' => __( "The most popular performer list.") );
        parent::__construct('popular-performers', __('(Bestia) - Popular Performers'), $widget_ops);
        $this->alt_option_name = 'widget_popular_performers';

        add_action( 'save_post', array($this, 'flush_widget_cache') );
        add_action( 'deleted_post', array($this, 'flush_widget_cache') );
        add_action( 'switch_theme', array($this, 'flush_widget_cache') );
    }

    function widget($args, $instance) {
        $cache = wp_cache_get('widget_recent_posts', 'widget');

        if ( !is_array($cache) )
            $cache = array();

        if ( ! isset( $args['widget_id'] ) )
            $args['widget_id'] = $this->id;

        if ( isset( $cache[ $args['widget_id'] ] ) ) {
            echo $cache[ $args['widget_id'] ];
            return;
        }

        ob_start();
        extract($args);

        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( '' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
        if ( ! $number )
        $number = 5;
        $r = new WP_Query( apply_filters( 'widget_posts_args', array( 'posts_per_page' => $number, 'no_found_rows' => true, 'post_type' => 'blogs', 'post_status' => 'publish', 'ignore_sticky_posts' => true ) ) );
        if ($r->have_posts()) :
        ?>
        <?php echo $before_widget; ?>
        <?php if ( $title ) echo $before_title . $title . $after_title; ?>

<div id="ModelWidget" class="container" style="padding:0;">
<ul  class="nav nav-pills ">
			<li class="active">
        <a href="#1b" data-toggle="tab">Female</a>
			</li>
			<li><a href="#2b" data-toggle="tab">Male</a>
			</li>
  		<li><a href="#3a" data-toggle="tab">Trans</a>
			</li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1b">
          <h3>Female Models</h3>


<?php
          //Retriwe redux options
          global $awpt;
          $lazyLoading = $awpt['mtn_lazyloading'];
          if ($lazyLoading == "jquery_lazy") {
          $src = 'class="lazy" src="'.get_template_directory_uri() . '/images/1pixel.gif"';
          $original = 'data-original';
          } elseif ($lazyLoading == "unveil_lazy") {
          $src = 'class="lazy" src="'.get_template_directory_uri() . '/images/1pixel.gif"';
          $original = 'data-original';
          } else {
          $src = '';
          $original = 'src';
          }
          $number   = $awpt['performers_per_page']; // number of terms to display per page
          $h_tag = $awpt['general_title_heading'];

          //Dynamic url
          $sortby = isset($_GET['sortby']) ? $_GET['sortby'] : null;

          //Taxonomy Setup
          $taxonomy = 'performer';
          $page = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
          $offset       = ( $page > 0 ) ?  $number * ( $page - 1 ) : 1;

          //Total terms to setup the pagination.
          $totalterms   = wp_count_terms( $taxonomy, array( 'hide_empty' => false, 'orderby' => 'female', 'meta_value' => 'female' ) );
          $totalpages   = ceil( $totalterms / $number );
          if( isset( $sortby ) ) {
          $args = array(
                  'orderby' => 'female',
                  'meta_value' => 'female',
                  'order'         => 'ASC',
                  'hide_empty'    => false,
                  'offset'        => $offset,
          );
          } else {
          $args = array(
                  'orderby' => 'female',
                  'meta_value' => 'female',
                  'order'         => 'ASC',
                  'hide_empty'    => false,
                  'exclude'       => array(),
                  'exclude_tree'  => array(),
                  'include'       => array(),
                  'number'        => $number,
                  //'fields'        => 'all',
                  'slug'          => '',
                  'parent'         => '',
                  'hierarchical'  => true,
                  'child_of'      => 0,
                  'get'           => '',
                  'name__like'    => '',
                  'pad_counts'    => false,
                  'offset'        => $offset,
                  'search'        => '',
                  'cache_domain'  => 'core'
          );
          }
          $tax_terms = get_terms( $taxonomy, $args );
          ?>
          <div id="performer-list" class="list-view">
          <div id="performer-thumbs" class="performer-listing clearfix">

          <div class="items">
          <?php
          foreach ($tax_terms as $cat) : ?>
            <?php
             $flag = 0;
               if( $sortby == mb_substr( $cat->name, 0, 1 ) || $sortby=='' ) {
                 $flag = 1;
                }
             ?>
          <?php
          $gender = get_term_meta($cat->term_id,'awpt_gender', true);
          if ($gender == "male") {
            $img_type = 'female';
          } elseif ($gender == "transgender") {
              $img_type = 'trans';
          } else {
              $img_type = 'female';
          }

          $performer_image = z_taxonomy_image_url( $cat->term_id, null );
          if( ! empty($performer_image)) :
            $image = aq_resize( $performer_image, 190, 278, true );
          else :
            $image = get_template_directory_uri() . '/assets/css/images/'.$img_type.'.jpg';
          endif;

          if ( $flag == '1' ) {
          ?>
          <div class="performer-item">

          <span class="performer-videos">
          <span class="count"><?php echo $cat->count; ?></span>
          <span class="txt"><?php echo _e('Videos', 'bestia'); ?></span>
          </span>

          <a class="outline" href="<?php echo get_term_link($cat->slug, 'performer'); ?>" title="<?php echo $cat->name; ?>">
          <?php echo '<img '.$src, $original.'="'.$image.'" alt="'.$cat->name.'" />'; ?>
          <span class="performer-name"><?php echo $cat->name; ?></span>
          </a>
          </div>
           <?php } ?>
          <?php endforeach; ?>
          </div>
          </div>
          </div>





				</div>
				<div class="tab-pane" id="2b">
          <h3>Male Models</h3>
				</div>
        <div class="tab-pane" id="3a">
          <h3>Trans Models</h3>
				</div>
			</div>
      </div>


        <div class="fBox3">
        <ul>
        <?php while ( $r->have_posts() ) : $r->the_post(); ?>
        <li class="recent-post">
          <a href="<?php the_permalink(); ?>">
          <div class="post-img">
						<?php if ( has_post_thumbnail() ) {
							$thumb_id = get_post_thumbnail_id();
							$thumbnail_src = wp_get_attachment_image_src($thumb_id,'medium', true);
						?>
						<img src="<?php echo $thumbnail_src[0]; ?>" alt="<?php the_title(); ?>" class="img-responsive" />
						<?php } else { ?>
						<img src="<?php bloginfo('template_directory'); ?>/images/noimage-blog.jpg" class="img-responsive" alt="<?php bloginfo('name'); ?>">
						<?php } ?>
         </div>
          <h5><?php the_title(); ?></h5>
              <p>
                <small>
                  <i class="fa fa-calendar" data-original-title="" title=""></i> <?php the_time('F jS, Y') ?>
                 </small>
               </p>
          </a>
        </li>
        <?php endwhile; ?>
        </ul>
        </div>
        <?php echo $after_widget; ?>
        <div style="clear:both;"></div>
        <?php
        // Reset the global $the_post as this query will have stomped on it
        wp_reset_postdata();

        endif;

        $cache[$args['widget_id']] = ob_get_flush();
        wp_cache_set('widget_popular_performers', $cache, 'widget');
    }

        function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = (int) $new_instance['number'];
        $this->flush_widget_cache();

        $alloptions = wp_cache_get( 'alloptions', 'options' );
        if ( isset($alloptions['widget_popular_performers']) )
            delete_option('widget_popular_performers');

        return $instance;
    }

    function flush_widget_cache() {
        wp_cache_delete('widget_popular_performers', 'widget');
    }

    function form( $instance ) {
        $title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
        $number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
?>
        <p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>

        <p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of posts to show:' ); ?></label>
        <input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo $number; ?>" size="3" /></p>
<?php
    }
}
*/

/* recent blogs */
class Bestia_Widget_Blog_Posts extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'widget_recent_blogs', 'description' => __( "The most recent or random blogs.") );
        parent::__construct('recent-blogs', __('(Bestia) - Blog Posts'), $widget_ops);
        $this->alt_option_name = 'widget_recent_blogs';

        add_action( 'save_post', array($this, 'flush_widget_cache') );
        add_action( 'deleted_post', array($this, 'flush_widget_cache') );
        add_action( 'switch_theme', array($this, 'flush_widget_cache') );
    }

    function widget($args, $instance) {
        $cache = wp_cache_get('widget_recent_posts', 'widget');

        if ( !is_array($cache) )
            $cache = array();

        if ( ! isset( $args['widget_id'] ) )
            $args['widget_id'] = $this->id;

        if ( isset( $cache[ $args['widget_id'] ] ) ) {
            echo $cache[ $args['widget_id'] ];
            return;
        }

        ob_start();
        extract($args);

        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( '' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
        if ( ! $number )
        $number = 5;
        $r = new WP_Query( apply_filters( 'widget_posts_args', array( 'posts_per_page' => $number, 'no_found_rows' => true, 'post_type' => 'blogs', 'post_status' => 'publish', 'ignore_sticky_posts' => true ) ) );
        if ($r->have_posts()) :
        ?>
        <?php echo $before_widget; ?>
        <?php if ( $title ) echo $before_title . $title . $after_title; ?>
        <div class="fBox3">
        <ul>
        <?php while ( $r->have_posts() ) : $r->the_post(); ?>
        <li class="recent-post">
          <a href="<?php the_permalink(); ?>">
          <div class="post-img">
						<?php if ( has_post_thumbnail() ) {
							$thumb_id = get_post_thumbnail_id();
							$thumbnail_src = wp_get_attachment_image_src($thumb_id,'medium', true);
						?>
						<img src="<?php echo $thumbnail_src[0]; ?>" alt="<?php the_title(); ?>" class="img-responsive" />
						<?php } else { ?>
						<img src="<?php bloginfo('template_directory'); ?>/images/noimage-blog.jpg" class="img-responsive" alt="<?php bloginfo('name'); ?>">
						<?php } ?>
         </div>
          <h5><?php the_title(); ?></h5>
              <p>
                <small>
                  <i class="fa fa-calendar" data-original-title="" title=""></i> <?php the_time('F jS, Y') ?>
                 </small>
               </p>
          </a>
        </li>
        <?php endwhile; ?>
        </ul>
        </div>
        <?php echo $after_widget; ?>
        <div style="clear:both;"></div>
        <?php
        // Reset the global $the_post as this query will have stomped on it
        wp_reset_postdata();

        endif;

        $cache[$args['widget_id']] = ob_get_flush();
        wp_cache_set('widget_recent_blogs', $cache, 'widget');
    }

        function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = (int) $new_instance['number'];
        $this->flush_widget_cache();

        $alloptions = wp_cache_get( 'alloptions', 'options' );
        if ( isset($alloptions['widget_recent_blogs']) )
            delete_option('widget_recent_blogs');

        return $instance;
    }

    function flush_widget_cache() {
        wp_cache_delete('widget_recent_blogs', 'widget');
    }

    function form( $instance ) {
        $title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
        $number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
?>
        <p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>

        <p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of posts to show:' ); ?></label>
        <input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo $number; ?>" size="3" /></p>
<?php
    }
}
