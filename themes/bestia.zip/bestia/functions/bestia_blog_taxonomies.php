<?php if( !defined('ABSPATH') ) exit;
if( !class_exists('Bestia_Custom_Blog_Taxonomies') ){
	class Bestia_Custom_Blog_Taxonomies {
		function __construct() {
			add_action('init', array($this,'cptui_register_my_taxes_blogtype'));
			add_action('init', array($this,'cptui_register_my_taxes_key'));

			add_filter( 'cptui_register_my_taxes_blogtype' , array( $this, 'rewrite_taxes_blogtype' ), 10, 1 );
			add_filter( 'cptui_register_my_taxes_key' , array( $this, 'rewrite_taxes_key' ), 10, 1 );
		}
		function cptui_register_my_taxes_blogtype() {
			global $awpt;
			$labels = array(
				'name'              => __( 'Blog Categories', 'bestia' ),
				'singular_name'     => __( 'Blog Categories', 'bestia' ),
				'search_items'      => __( 'Search Blog Category','bestia' ),
				'all_items'         => __( 'All Blog Category','bestia' ),
				'parent_item'       => __( 'Parent Blog Category','bestia' ),
				'parent_item_colon' => __( 'Parent Blog Category:','bestia' ),
				'edit_item'         => __( 'Edit Blog Category','bestia' ),
				'update_item'       => __( 'Update Blog Category','bestia' ),
				'add_new_item'      => __( 'Add New','bestia' ),
				'new_item_name'     => __( 'New Blog Category','bestia' ),
				'menu_name'         => __( 'Blog Categories','bestia' ),
			);

			$args = array( 'hierarchical' => true,
				'label' => __( 'Blog Category', 'bestia' ),
				'show_ui' => true,
				'query_var' => true,
				'show_admin_column' => true,
				'labels' => $labels,
				'rewrite'    => array( 'slug' => 'blogtype' )
			);
			$args = apply_filters( 'cptui_register_my_taxes_blogtype' , $args);
			if( $awpt['blogs_cpt'] == 1 ){
				 register_taxonomy( 'blogtype',array ( 0 => 'blogs' ), $args );
			}
		}

		function rewrite_taxes_blogtype( $args ){
			global $awpt;
			if( isset( $awpt['rewrite_slug_blog_category'] ) && $awpt['rewrite_slug_blog_category'] != 'blogtype' ){
				$args['rewrite'] = array(
					'slug'	=> esc_attr( $awpt['rewrite_slug_blog_category'] )
				);
			}
			return $args;
		}

		function cptui_register_my_taxes_key() {
			global $awpt;
			$labels = array(
				'name'              => __( 'Blog Tags', 'bestia' ),
				'singular_name'     => __( 'Blog Tags', 'bestia' ),
				'search_items'      => __( 'Blog Video Tag','bestia' ),
				'all_items'         => __( 'All Blog Tag','bestia' ),
				'parent_item'       => __( 'Parent Blog Tag','bestia' ),
				'parent_item_colon' => __( 'Parent Blog Tag:','bestia' ),
				'edit_item'         => __( 'Edit Blog Tag','bestia' ),
				'update_item'       => __( 'Update Blog Tag','bestia' ),
				'add_new_item'      => __( 'Add New Blog Tag','bestia' ),
				'new_item_name'     => __( 'New Blog Tag','bestia' ),
				'menu_name'         => __( 'Blog Tags','bestia' ),
			);
			$args = array( 'hierarchical' => false,
				'label' => __( 'Blog Tag', 'bestia' ),
				'rewrite'    => array( 'slug' => 'blog_tag' ),
				'show_ui' => true,
				'query_var' => true,
				'show_admin_column' => true,
				'labels' => $labels
			);
			$args = apply_filters( 'cptui_register_my_taxes_key' , $args);
			if( $awpt['blogs_cpt'] == 1 ){
				 register_taxonomy( 'blog_tag',array ( 0 => 'blogs' ), $args );
			}
		}

		function rewrite_taxes_key( $args ){
			global $awpt;
			if( isset( $awpt['rewrite_slug_blog_tag'] ) && $awpt['rewrite_slug_blog_tag'] != 'blogtype' ){
				$args['rewrite'] = array(
					'slug'	=> esc_attr( $awpt['rewrite_slug_blog_tag'] )
				);
			}
			return $args;
		}

	}
	new Bestia_Custom_Blog_Taxonomies();
}
