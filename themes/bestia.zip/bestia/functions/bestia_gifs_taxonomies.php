<?php if( !defined('ABSPATH') ) exit;
if( !class_exists('Bestia_Custom_Gif_Taxonomies') ){
	class Bestia_Custom_Gif_Taxonomies {
		function __construct() {
			add_action('init', array($this,'cptui_register_my_taxes_giftype'));
			add_action('init', array($this,'cptui_register_gif_taxes_key'));

			add_filter( 'cptui_register_my_taxes_giftype' , array( $this, 'rewrite_taxes_giftype' ), 10, 1 );
			add_filter( 'cptui_register_gif_taxes_key' , array( $this, 'rewrite_taxes_key' ), 10, 1 );
		}
		function cptui_register_my_taxes_giftype() {
			global $awpt;
			$labels = array(
				'name'              => __( 'Gif Categories', 'bestia' ),
				'singular_name'     => __( 'Gif Categories', 'bestia' ),
				'search_items'      => __( 'Search Gif Category','bestia' ),
				'all_items'         => __( 'All Gif Categories','bestia' ),
				'parent_item'       => __( 'Parent Gif Category','bestia' ),
				'parent_item_colon' => __( 'Parent Gif Category:','bestia' ),
				'edit_item'         => __( 'Edit Gif Category','bestia' ),
				'update_item'       => __( 'Update Gif Category','bestia' ),
				'add_new_item'      => __( 'Add New','bestia' ),
				'new_item_name'     => __( 'New Gif Category','bestia' ),
				'menu_name'         => __( 'Categories','bestia' ),
			);

			$args = array( 'hierarchical' => true,
				'label' => __( 'Gif Category', 'bestia' ),
				'show_ui' => true,
				'query_var' => true,
				'show_admin_column' => true,
				'labels' => $labels,
				'rewrite'    => array( 'slug' => 'giftype' )
			);
			$args = apply_filters( 'cptui_register_my_taxes_giftype' , $args);
			if( $awpt['gifs_cpt'] == 1 ){
				 register_taxonomy( 'giftype',array ( 0 => 'gif' ), $args );
			}
		}

		function rewrite_taxes_giftype( $args ){
			global $awpt;
			if( isset( $awpt['rewrite_slug_gif_category'] ) && $awpt['rewrite_slug_gif_category'] != 'giftype' ){
				$args['rewrite'] = array(
					'slug'	=> esc_attr( $awpt['rewrite_slug_gif_category'] )
				);
			}
			return $args;
		}

		function cptui_register_gif_taxes_key() {
			global $awpt;
			$labels = array(
				'name'              => __( 'Gif Tags', 'bestia' ),
				'singular_name'     => __( 'Gif Tags', 'bestia' ),
				'search_items'      => __( 'Gif Tag','bestia' ),
				'all_items'         => __( 'All Gif Tags','bestia' ),
				'parent_item'       => __( 'Parent Gif Tag','bestia' ),
				'parent_item_colon' => __( 'Parent Gif Tag:','bestia' ),
				'edit_item'         => __( 'Edit Gif Tag','bestia' ),
				'update_item'       => __( 'Update Gif Tag','bestia' ),
				'add_new_item'      => __( 'Add New Gif Tag','bestia' ),
				'new_item_name'     => __( 'New Gif Tag','bestia' ),
				'menu_name'         => __( 'Tags','bestia' ),
			);
			$args = array( 'hierarchical' => false,
				'label' => __( 'Gif Tag', 'bestia' ),
				'rewrite'    => array( 'slug' => 'gif_tag' ),
				'show_ui' => true,
				'query_var' => true,
				'show_admin_column' => true,
				'labels' => $labels
			);
			$args = apply_filters( 'cptui_register_gif_taxes_key' , $args);
			if( $awpt['gifs_cpt'] == 1 ){
				 register_taxonomy( 'gif_tag',array ( 0 => 'gif' ), $args );
			}
		}

		function rewrite_taxes_key( $args ){
			global $awpt;
			if( isset( $awpt['rewrite_slug_gif_tag'] ) && $awpt['rewrite_slug_gif_tag'] != 'giftype' ){
				$args['rewrite'] = array(
					'slug'	=> esc_attr( $awpt['rewrite_slug_gif_tag'] )
				);
			}
			return $args;
		}

	}
	new Bestia_Custom_Gif_Taxonomies();
}
