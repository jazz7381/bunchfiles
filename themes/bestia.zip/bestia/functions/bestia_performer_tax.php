<?php if( !defined('ABSPATH') ) exit;
if( !class_exists('Bestia_Custom_Performers_Taxonomy') ){
	class Bestia_Custom_Performers_Taxonomy {
		function __construct() {
			add_action('init', array($this,'cptui_register_performer_taxonomy'));
			add_filter( 'cptui_register_performer_taxonomy' , array( $this, 'rewrite_performer_tax' ), 10, 1 );
		}
		function cptui_register_performer_taxonomy() {
			$labels = array(
				'name'              => __( 'Performers', 'bestia' ),
				'singular_name'     => __( 'Performer', 'bestia' ),
				'popular_items'     => __( 'Popular Performers', 'bestia' ),
				'search_items'      => __( 'Search Performers','bestia' ),
				'all_items'         => __( 'All Performers','bestia' ),
				'parent_item' => null,
				'parent_item_colon' => null,
				'edit_item'         => __( 'Edit Performer','bestia' ),
				'update_item'       => __( 'Update Performer','bestia' ),
				'add_new_item'      => __( 'Add New Performer','bestia' ),
				'new_item_name'     => __( 'New Performer','bestia' ),
				'menu_name'         => __( 'Performers','bestia' ),
				'separate_items_with_commas' => __( 'Separate performers with commas', 'bestia' ),
            'add_or_remove_items' => __( 'Add or remove performers', 'bestia' ),
            'choose_from_most_used' => __( 'Choose from the most used performers', 'bestia' ),
			);

			$args = array( 'hierarchical' => true,
				'label' => __( 'Performers', 'bestia' ),
				'hierarchical' => false,
				'show_ui' => true,
				'query_var' => true,
				'show_admin_column' => true,
				'update_count_callback' => '_update_post_term_count',
				'labels' => $labels,
				'rewrite'    => array( 'slug' => 'performer' )
			);
			$args = apply_filters( 'cptui_register_performer_taxonomy' , $args);
			register_taxonomy( 'performer',array ( 0 => 'post', 'gallery', 'gif' ), $args );
		}

		function rewrite_performer_tax( $args ){
			global $awpt;
			if( isset( $awpt['rewrite_slug_performer'] ) && $awpt['rewrite_slug_performer'] != 'performer' ){
				$args['rewrite'] = array(
					'slug'	=> esc_attr( $awpt['rewrite_slug_performer'] )
				);
			}
			return $args;
		}

	}
	new Bestia_Custom_Performers_Taxonomy();
}
