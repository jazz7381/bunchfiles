<?php if( !defined('ABSPATH') ) exit;
/* Favicon. ------------------------------------*/
if( !function_exists('bestia_show_favicon') ){
function bestia_show_favicon() {
global $awpt;
if( isset( $awpt['mtn_favicon']['url'] ) && trim( $awpt['mtn_favicon']['url'] ) !='' ){
print '<link rel="apple-touch-icon" href="'.$awpt['mtn_favicon']['url'].'"/>
<link rel="apple-touch-icon" sizes="72x72" href="'.$awpt['mtn_favicon']['url'].'"/>
<link rel="apple-touch-icon" sizes="114x114" href="'.$awpt['mtn_favicon']['url'].'"/>
<link rel="apple-touch-icon" sizes="144x144" href="'.$awpt['mtn_favicon']['url'].'"/>
<link rel="Shortcut Icon" type="image/x-icon" href="'.$awpt['mtn_favicon']['url'].'"/>
<link rel="icon" type="image/png" href="'.$awpt['mtn_favicon']['url'].'">';
}
}
add_action('wp_head', 'bestia_show_favicon');
}
function bestia_disable_post_ad() {
global $post; $offplayerFIELD =  get_post_meta($post->ID,'awpt_offplayerad', true);
print $offplayerFIELD;
}
add_action('bestia_disable_post_ad', 'bestia_disable_post_ad');

if ( wp_is_mobile() ) {
function bestia_mobile_optimized() {
print '<meta name="HandheldFriendly" content="True">
<meta name="MobileOptimized" content="320">
<meta name="mobile-web-app-capable" content="yes">';
}
add_action('wp_head', 'bestia_mobile_optimized');
}

if( !function_exists('bestia_homepage_manager') ){
function bestia_homepage_manager() {
global $awpt; $layout = $awpt['home_page_layout']['enabled'];
if ($layout): foreach ($layout as $key=>$value) {
    switch($key) {

        case 'video_listing': do_action('bestia_orderblock_videos',null); get_template_part('inc/video_listing',get_post_format());
        break;

        case 'galleries': get_template_part('inc/new-galleries',get_post_format());
        break;

        case 'random_listing': get_template_part('inc/random_videos',get_post_format());
        break;

        case 'last_listing': get_template_part('inc/latest_videos',get_post_format());
        break;

        case 'popular_categories': get_template_part('inc/popular_categories',get_post_format());
        break;

        case 'latest_gifs': get_template_part('inc/latest_gifs',get_post_format());
        break;

        case 'popular_performers': get_template_part('inc/popular_performers',get_post_format());
        break;
    }
 }
endif;
}
add_action('bestia_homepage_manager', 'bestia_homepage_manager', 10);
}

if( !function_exists('bestia_search_options') ){
function bestia_search_options() {
global $awpt; if( $awpt['search_options'] == 1 ){
get_template_part( 'inc/tools/search_options', get_post_format() );
}else{}
}
add_action('bestia_search_options', 'bestia_search_options', 9);
}

global $awpt; if($awpt['mtn_rta'] == 1 ){
function rta_headers() {
	header("Rating: RTA-5042-1996-1400-1577-RTA\n");
}
add_action('wp_head', 'rta_headers');
// Add to the page header
function rta_head() {
	echo "<meta name=\"RATING\" content=\"RTA-5042-1996-1400-1577-RTA\" />\n";
}
add_action('wp_head', 'rta_head');
}

/* Related Videos By. ------------------------------------*/
if( !function_exists('bestia_related_by') ){
function bestia_related_by() {
global $awpt; $related_by = $awpt['mtn_rel_op'];
if ($related_by == "tags") {
get_template_part( 'inc/related/tags', get_post_format() );
} elseif ($related_by == "category") {
get_template_part( 'inc/related/category', get_post_format() );
} elseif ($related_by == "random") {
get_template_part( 'inc/related/random', get_post_format() );
//} else {
//get_template_part( 'inc/related/tags', get_post_format() );
}
}
add_action('bestia_related_by', 'bestia_related_by', 10);
}

/* LIKES COUNT AVARAGE . ------------------------------------*/
if( !function_exists('bestia_likes_avarage') ){
function bestia_likes_avarage() {
if (function_exists('adultwpthemes_getItemPostLikeRate')) {  echo adultwpthemes_getItemPostLikeRate( get_the_ID() ); }
}
add_action('bestia_likes_avarage', 'bestia_likes_avarage', 10);
}

/* Vote System Selection . ------------------------------------*/
if( !function_exists('bestia_like_buttons') ){
function bestia_like_buttons() {
if (function_exists('adultwpthemes_getPostLikeLink')) { echo adultwpthemes_getPostLikeLink(get_the_ID()); }
}
add_action('bestia_like_buttons', 'bestia_like_buttons', 10);
}

/* Performer List Page type . ------------------------------------*/
if( !function_exists('performer_list_page_images_by') ){
function performer_list_page_images_by() {
global $awpt; $performer_list = $awpt['performer_list_type'];
if ($performer_list == "custom_image") {
get_template_part( 'template_parts/performer-list-custom', get_post_format() );
} elseif ($performer_list == "last_post_image") {
get_template_part( 'template_parts/performer-list-last-post', get_post_format() );
} elseif ($performer_list == "random_post_image") {
get_template_part( 'template_parts/performer-list-last-post', get_post_format() );
}
}
add_action('performer_list_page_images_by', 'performer_list_page_images_by', 10);
}


/* Category List Page type . ------------------------------------*/
if( !function_exists('category_list_page_images_by') ){
function category_list_page_images_by() {
global $awpt; $category_list = $awpt['category_list_type'];
if ($category_list == "custom_image") {
get_template_part( 'inc/tools/templates/categories-custom', get_post_format() );
} elseif ($category_list == "last_post_image") {
get_template_part( 'inc/tools/templates/categories-last-post', get_post_format() );
} elseif ($category_list == "random_post_image") {
get_template_part( 'inc/tools/templates/categories-last-post', get_post_format() );
}
}
add_action('category_list_page_images_by', 'category_list_page_images_by', 10);
}

/* Channel List Page type . ------------------------------------*/
if( !function_exists('channel_list_page_images_by') ){
function channel_list_page_images_by() {
global $awpt; $channel_list = $awpt['channel_list_type'];
if ($channel_list == "custom_image") {
get_template_part( 'inc/tools/templates/channels-custom', get_post_format() );
} elseif ($channel_list == "last_post_image") {
get_template_part( 'inc/tools/templates/channels-last-post', get_post_format() );
} elseif ($channel_list == "random_post_image") {
get_template_part( 'inc/tools/templates/channels-last-post', get_post_format() );
}
}
add_action('channel_list_page_images_by', 'channel_list_page_images_by', 10);
}

/* Fake Player */
if( !function_exists('bestia_player_type') ){
function bestia_player_type() {
global $awpt; $fake_player = isset($awpt['mtn_fakeplayer']) ? $awpt['mtn_fakeplayer'] : '';
if ( (($fake_player == 1 ) &&  wp_is_mobile() )) {
get_template_part( 'compatibility/players/fake-player', get_post_format() );
} else {
get_template_part( 'compatibility/players/real-player', get_post_format() );
}
echo '</div>';
get_template_part( 'compatibility/undervideoads', get_post_format() );
}
add_action('bestia_player_type', 'bestia_player_type', 10);
}

/* FakePlayer in Mobile */
if( !function_exists('bestia_fake_player') ){
function bestia_fake_player() {
if ( !wp_is_mobile() ) {
get_template_part( 'inc/compatibility/players/tpl/is-desktop', get_post_format() );
} else {
get_template_part( 'inc/compatibility/players/tpl/is-mobile', get_post_format() );
}
}
add_action('bestia_fake_player', 'bestia_fake_player', 10);
}

if( !function_exists('bestia_add_google_analytics') ){
	function bestia_add_google_analytics() {
		global $awpt;
		if( isset( $awpt['google-analytics'] ) && trim( $awpt['google-analytics'] ) != '' ){
			$code = trim( $awpt['google-analytics'] );
			print '
				<script type="text/javascript">
				var _gaq = _gaq || [];
				_gaq.push([\'_setAccount\', \''.$code.'\']);
				_gaq.push([\'_trackPageview\']);
				(function() {
				var ga = document.createElement(\'script\'); ga.type = \'text/javascript\'; ga.async = true;
				ga.src = (\'https:\' == document.location.protocol ? \'https://ssl\' : \'http://www\') + \'.google-analytics.com/ga.js\';
				var s = document.getElementsByTagName(\'script\')[0]; s.parentNode.insertBefore(ga, s);
				})();
				</script>
			';
		}
	}
	add_action('wp_footer', 'bestia_add_google_analytics');
}
//RTA
if( !function_exists('bestia_RTA_option') ){
	function bestia_RTA_option() {
    global $awpt; if( $awpt['mtn_rta'] == 1 ){
     echo '<div class="rta">';
    get_template_part( 'inc/footer/rta/rta-footer-logo', get_post_format() );
    get_template_part( 'inc/footer/rta/rta-footer-text', get_post_format() );
     echo '</div>';
   } else {}
}
add_action('bestia_RTA_option', 'bestia_RTA_option', 9);
}
if( !function_exists('bestia_footer_logo') ){
	function bestia_footer_logo() {
   global $awpt; if( $awpt['mtn_d-logo'] == 1 ){ get_template_part( 'inc/footer/footer-logo', get_post_format() ); } else {}
	}
add_action('bestia_footer_logo', 'bestia_footer_logo', 9);
}

if( !function_exists('bestia_header_hook_js') ){
function bestia_header_hook_js() {
global $awpt;
if( isset( $awpt['mtn_headerhook'] ) && trim( $awpt['mtn_headerhook'] ) !='' ){
print $awpt['mtn_headerhook'];
}
}
add_action('wp_head', 'bestia_header_hook_js');
}

if( !function_exists('bestia_header_hook_css') ){
function bestia_header_hook_css() {
global $awpt;
if( isset( $awpt['mtn_stil'] ) && trim( $awpt['mtn_stil'] ) !='' ){
print '<style type="text/css">'.$awpt['mtn_stil'].'</style>';
}
}
add_action('wp_head', 'bestia_header_hook_css');
}

if( !function_exists('bestia_footer_hook_js') ){
function bestia_footer_hook_js() {
global $awpt;
if( isset( $awpt['mtn_analtik'] ) && trim( $awpt['mtn_analtik'] ) !='' ){
print $awpt['mtn_analtik'];
}
}
add_action('wp_footer', 'bestia_footer_hook_js');
}
if( !function_exists('bestia_custom_tracker') ){
function bestia_custom_tracker() {
global $awpt;
if( isset( $awpt['custom-analytics'] ) && trim( $awpt['custom-analytics'] ) !='' ){
print $awpt['custom-analytics'];
}
}
add_action('wp_footer', 'bestia_custom_tracker');
}
//Lazy Loading Type
if( !function_exists('bestia_lazyloading_type') ){
	function bestia_lazyloading_type() {
		global $awpt;
      $lazyLoading = $awpt['mtn_lazyloading'];
      if ($lazyLoading == "jquery_lazy") { $lazyLoading = 'jquery';}
      elseif ($lazyLoading == "unveil_lazy") { $lazyLoading = 'unveil';}
      elseif ($lazyLoading == "disabled") { $lazyLoading = 'none'; }
      else {$lazyLoading = 'unveil';}
     get_template_part( 'inc/footer/lazy/'.$lazyLoading.'-lazy', get_post_format() );
	}
add_action('bestia_lazyloading_type', 'bestia_lazyloading_type', 10);
}

if( !function_exists('bestia_post_views_mode') ){
function bestia_post_views_mode() {
global $awpt; $min = $awpt['fake-views-min-value'];
$max = $awpt['fake-views-max-value'];
if( $awpt['fake-post-views'] == 1 ) {
	echo rand($min, $max);
}
elseif ( function_exists('JPV_display_top_posts') ) {
echo get_the_ID( 'jetpack-post-views');
}
elseif ( function_exists('process_postviews') ) {
echo do_shortcode('[views]');
echo '<style>.bestia_view_text {display:none !important;}</style>';
}
else {
echo getPostViews(get_the_ID());
}
}
add_action('bestia_post_views_mode', 'bestia_post_views_mode', 10);
}

//Fake post views
if( !function_exists('bestia_post_views_mode') ){
function bestia_post_views_mode() {
global $awpt;
$min = $awpt['fake-views-min-value'];
$max = $awpt['fake-views-max-value'];
if( $awpt['fake-post-views'] == 1 ) {
echo rand($min, $max);
}
elseif ( function_exists('JPV_display_top_posts') ) {
echo get_the_ID( 'jetpack-post-views');
}	else {
echo getPostViews(get_the_ID());
}
}
add_action('bestia_post_views_mode', 'bestia_post_views_mode', 10);
}
//Fake post Rating
if( !function_exists('bestia_post_rating_mode') ){
function bestia_post_rating_mode() {
global $awpt;
$min = $awpt['fake-rating-min-value'];
$max = $awpt['fake-rating-max-value'];
if( $awpt['fake-post-rating'] == 1 ) {
echo rand($min, $max).'%';
}	else {
do_action( 'bestia_likes_avarage' );
}
}
add_action('bestia_post_rating_mode', 'bestia_post_rating_mode', 10);
}

//Video Duration on video previews
if( !function_exists('bestia_video_duration') ){
function bestia_video_duration() {
global $awpt,$post;
$custom_field_duration = $awpt['duration'];
if( $awpt['video_duration_seconds'] == 1 ) {
	$duration = duration_converter(get_post_meta( get_the_ID(), $custom_field_duration, true));
 }	elseif( $awpt['video_duration_seconds'] == 0 ) {
	$duration = get_post_meta($post->ID, $custom_field_duration, true);
}	elseif ( ! function_exists( 'wpscript_mode' ) ) {
  $duration = wpsevst_get_video_duration();
 } else {
	$duration = get_post_meta($post->ID, $custom_field_duration, true);
}
if(!empty($duration)) {
    echo '<span class="duration">' . $duration . '</span>';
    } else {
	}
}
add_action('bestia_video_duration', 'bestia_video_duration', 10);
}

//Video Duration on video previews
if( !function_exists('bestia_single_video_duration') ){
function bestia_single_video_duration() {
global $awpt,$post;
$custom_field_duration = $awpt['duration'];
if( $awpt['video_duration_seconds'] == 1 ) {
	$duration = duration_converter(get_post_meta( get_the_ID(), $custom_field_duration, true));
 }	elseif( $awpt['video_duration_seconds'] == 0 ) {
	$duration = get_post_meta($post->ID, $custom_field_duration, true);
}	elseif ( ! function_exists( 'wpscript_mode' ) ) {
  $duration = wpsevst_get_video_duration();
 } else {
	$duration = get_post_meta($post->ID, $custom_field_duration, true);
}
if(!empty($duration)) {
    echo '<p class="data-row">
          <span class="heading"><i class="fa fa-clock-o" aria-hidden="true"></i> '.__('Duration', 'bestia').':</span>
           '.$duration.'
          </p>';
   }
  }
add_action('bestia_single_video_duration', 'bestia_single_video_duration');
}
//remove height and width attributes from wp attachment url.
function remove_width_and_height_attribute( $html ) {
   return preg_replace( '/(height|width)="\d*"\s/', "", $html );
}

// Bestia thumbnails rotation function on mouse hover
function first_image_from_rotator_gallery(){
    global $awpt,$post;
		$images = get_post_meta( $post->ID, 'image_rotator', true );
      if( $images ):
        $size = 'thumb-video';
            foreach( $images as $image ):
              echo remove_width_and_height_attribute(wp_get_attachment_image_url($image, $size));
              break;
            endforeach;
      endif;
 }

 function first_image_from_gif_gallery(){
    global $awpt,$post;
 		$images = get_post_meta( $post->ID, 'gif_files', true );
       if( $images ):
         $size = 'full';
             foreach( $images as $image ):
               echo wp_get_attachment_image($image, $size, false, array('title' => '', 'alt' => get_the_title(), 'class' => 'img-responsive'));
               break;
             endforeach;
       endif;
  }

function multi_thumb_default_image(){
    global $awpt,$post;
 		$images = get_post_meta( $post->ID, 'image_rotator', true );
       if( $images ):
         $size = 'thumb-video';
             foreach( $images as $image ) :
               $default_thumb =  wp_get_attachment_image_url($image, $size);
               break;
             endforeach;
       endif;
       return $default_thumb;
}
add_action('first_image_from_rotator_gallery', 'first_image_from_rotator_gallery');

function multi_thumb_default_image_full() {
    global $awpt,$post;
 		$images = get_post_meta( $post->ID, 'image_rotator', true );
       if( $images ):
         $size = 'full';
             foreach( $images as $image ) :
               $default_thumb =  wp_get_attachment_image_url($image, $size);
               break;
             endforeach;
       endif;
       return $default_thumb;
}
add_action('multi_thumb_default_image_full', 'multi_thumb_default_image_full');

function bestia_data_thumbs(){
    global $post;
    $thumbs=array();
        $images = get_post_meta( $post->ID, 'image_rotator', true );
      if( $images ) {
        $size = 'thumb-video';
            foreach( $images as $image ) {
              $thumbs[] = wp_get_attachment_image_url($image, $size);
         }
     }
     if( is_array($thumbs) ){
        return implode(',', $thumbs);
    }
    return false;
}

// Bestia thumbnails rotation function on mouse hover
function thumnails_rotation(){
    global $awpt,$post;
		$images = get_post_meta( $post->ID, 'image_rotator', true );
    $sp = bestia_data_thumbs($post->ID);
      if( $images ):
         $thumb_url = get_post_meta($post->ID, 'image_rotator', false, false);
        $size = 'thumb-video';
        echo '<div id="rotator" data-thumbs="'.$sp.'">';
  				echo '<img alt="' . get_the_title() . '" src="'.multi_thumb_default_image().'">';
        echo '</div>';
      endif;
 }
add_action('thumnails_rotation', 'thumnails_rotation');

 //Bestia lazyloading images
function bestia_preview_image_lazy() {
global $awpt,$post;
$thumb_id = get_post_thumbnail_id();
$saved_thmb = get_post_meta( get_the_ID(),'saved_thmb',true);
$multiple_images = get_post_meta( $post->ID, 'image_rotator', true );
$custom_field_thumb = $awpt['thumb'];
$thumb = tube_getcustomfield($custom_field_thumb,get_the_ID());
if ( is_post_type_archive('gallery') || is_singular( 'gallery' ) || is_attachment() || is_tax('phototype') || is_tax('photo_tag') ) {
$thumbnail_src = wp_get_attachment_image_src($thumb_id, 'thumb-photo', true);
$no_image = 'nothumb-photo.jpg';
} elseif ( is_post_type_archive('blogs') || is_singular( 'blogs' ) || is_attachment() || is_tax('blogs') || is_tax('blogs') ) {
$thumbnail_src = wp_get_attachment_image_src($thumb_id,'blogthumb', true);
$no_image = 'noimage-blog.jpg';
} else {
$thumbnail_src = wp_get_attachment_image_src($thumb_id, 'thumb-video', true);
$no_image = 'noimage.png';
}
if (!empty($thumb)) {
echo '<img class="lazy" src="'.get_template_directory_uri().'/images/1pixel.gif" data-original="'.$thumb.'" alt="'.get_the_title().'" />';
} elseif (!empty($multiple_images)) {
do_action('thumnails_rotation');
} elseif (function_exists('tubeace_append_video_player_to_the_content') && !empty($saved_thmb)) {
echo the_post_thumbnail();
} elseif ( has_post_thumbnail() ) {
echo '<img class="lazy" src="'.get_template_directory_uri().'/images/1pixel.gif" data-original="'.$thumbnail_src[0].'" alt="'.get_the_title().'" />
      <noscript><img src="'.$thumbnail_src[0].'" alt="'.get_the_title().'" /></noscript>';
} else {
echo '<img class="noimage" src="'.get_template_directory_uri().'/images/'.$no_image.'" alt="'.get_the_title().'">';
}
}
add_action('bestia_preview_image_lazy', 'bestia_preview_image_lazy');

function bestia_preview_image_default() {
global $awpt,$post;
$multiple_images = get_post_meta( $post->ID, 'image_rotator', true );
$saved_thmb = get_post_meta( get_the_ID(),'saved_thmb',true);
$custom_field_thumb = $awpt['thumb'];
$thumb = tube_getcustomfield($custom_field_thumb,get_the_ID());
$thumb_id = get_post_thumbnail_id();
if ( is_post_type_archive('gallery') || is_singular( 'gallery' ) || is_attachment() || is_tax('phototype') || is_tax('photo_tag') ) {
$thumbnail_src = wp_get_attachment_image_src($thumb_id, 'thumb-photo', true);
$no_image = 'nothumb-photo.jpg';
} elseif ( is_post_type_archive('blogs') || is_singular( 'blogs' ) || is_attachment() || is_tax('blogs') || is_tax('blogs') ) {
$thumbnail_src = wp_get_attachment_image_src($thumb_id,'blogthumb', true);
$no_image = 'noimage-blog.jpg';
} else {
$thumbnail_src = wp_get_attachment_image_src($thumb_id, 'thumb-video', true);
$no_image = 'noimage.png';
}
if (!empty($multiple_images)) {
do_action('thumnails_rotation');
} elseif (function_exists('tubeace_append_video_player_to_the_content') && !empty($saved_thmb)) {
echo the_post_thumbnail();
} elseif (!empty($thumb)) {
echo '<img src="'.$thumb.'" alt="'.get_the_title().'" />';
} elseif ( has_post_thumbnail() ) {
echo '<img src="'.$thumbnail_src[0].'" alt="'.get_the_title().'" />';
} else {
echo '<img src="'.get_template_directory_uri().'/images/'.$no_image.'" alt="'.get_the_title().'">';
}
}
add_action('bestia_preview_image_default', 'bestia_preview_image_default');
//Lazy Loading Type
if( !function_exists('bestia_preview_image') ){
	function bestia_preview_image() {
		global $awpt;
      $lazyLoading = $awpt['mtn_lazyloading'];
      if ($lazyLoading == "disabled") {
        do_action('bestia_preview_image_default');
       } else {
        do_action('bestia_preview_image_lazy');
      }
	}
add_action('bestia_preview_image', 'bestia_preview_image', 10);
}

// Unset custom templates if the post type is disabled, blog and photo gallery
add_filter( 'theme_page_templates', 'bestia_remove_page_template' );
function bestia_remove_page_template( $pages_templates ) {
    global $awpt;
    if( $awpt['blogs_cpt'] == 0 ){
      unset( $pages_templates['template-blog.php'] );
		}
    if( $awpt['gallery_cpt'] == 0 ){
      unset( $pages_templates['template-photo-gallery.php'] );
    }
    return $pages_templates;
}

function bestia_addtoany() {
    if (function_exists('A2A_SHARE_SAVE_init')) {
      echo do_shortcode('[addtoany]');
    }
}
add_action('bestia_addtoany', 'bestia_addtoany');
