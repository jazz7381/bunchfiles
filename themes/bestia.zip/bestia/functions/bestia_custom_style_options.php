<?php if( !defined('ABSPATH') ) exit;
if( !function_exists('bestia_color_outputs') ){
function bestia_color_outputs() { ?>
<?php global $awpt;
$main_menu_bg = $awpt['main_menu_hover'];
$sidebar_bg = $awpt['sidebar_bg'];
?>
<style type="text/css">
#head .navbar-default, .mobile_header {border-bottom: 1px solid <?php echo $awpt['nav_border_bottom']; ?> !important;border-top: 1px solid <?php echo $awpt['nav_border_top']; ?> !important;}
.top-bar .fa {font-family: FontAwesome !important;}
.top-bar .notifications .notification-item .open .circle{background-color: <?php echo $awpt['top_bar_color']; ?>;}
.Thumbnail_List li .toolbar .rate_thumb {background: <?php echo $awpt['likes_icon_bg']; ?>;}
.Thumbnail_List li .quality {background: <?php echo $awpt['hd_icon_bg']; ?>;}
.mobile_search input.form-control, .mobile_search button.closer, .mobile_search button.df, .mobile_search input.form-control {border: 1px solid <?php echo $awpt['srchfrm_borders']; ?> !important;}
.mobile_search input.form-control::placeholder, .search_type a,.mobile_search .open>.dropdown-toggle.btn-default:focus,.mobile_search .open>.dropdown-toggle.btn-default:hover {color: <?php echo $awpt['searchfrm_fnt_color']; ?> !important;}
a.close_lek {background: <?php echo $awpt['foot_heading_border_1']; ?>;}
.top-bar .top-bar-left .nav li a {color: <?php echo $awpt['top-bar-typography']['color']; ?>;}
#head .navbar-default .navbar-nav > .active > a, #head .navbar-default .navbar-nav > .active > a:hover, #head .navbar-default .navbar-nav > .active > a:focus {background-color: <?php echo $main_menu_bg; ?> !important;}
#footer {background: <?php echo $awpt['foot_bg']; ?>;}
.col-md-10, .col-md-12, .col-md-7{color: <?php echo $awpt['content-font-typography']['color']; ?>;}
#footer .footer-top {background: <?php echo $awpt['foot_widgets_bg']; ?>;}
#footer .footer-top .widget h1::after,
#footer .footer-top .widget h2::after,
#footer .footer-top .widget h3::after,
#footer .footer-top .widget h4::after,
#footer .footer-top .widget h5::after,
#footer .footer-top .widget h6::after,
#footer .footer-top .widget span::after {background: <?php echo $awpt['foot_heading_border_1']; ?>;width: 60px;}
#footer .footer-top .widget h1::before,
#footer .footer-top .widget h2::before,
#footer .footer-top .widget h3::before,
#footer .footer-top .widget h4::before,
#footer .footer-top .widget h5::before,
#footer .footer-top .widget h6::before,
#footer .footer-top .widget span::before {right: 0;background: <?php echo $awpt['foot_heading_border_2']; ?>;}
#footer .footer-top .widget ul li {border-bottom: 1px solid <?php echo $awpt['foot_heading_border_2']; ?>;padding: 10px 0;}
.item_rate a {background: <?php echo $awpt['r_avarage_like_buttons_bg']; ?>;}
.rate_bar_view {background: <?php echo $awpt['r_avarage_bg']; ?>;color: <?php echo $awpt['r_avarage_counter']; ?> !important;}
.rate_precent {color: <?php echo $awpt['r_avarage_progress']; ?> !important;}
.progress {background: <?php echo $awpt['r_avarage_progress']; ?> !important;}
.col_bar:nth-child(2){border-left: 1px solid <?php echo $awpt['r_avarage_border_left']; ?>;}
.item_rate:hover.like a {background: <?php echo $awpt['r_avarage_like_btn_bg']; ?>;}
.item_rate:hover.like a .fa {color: <?php echo $awpt['r_avarage_like_btn_color']; ?> !important;}
.item_rate:hover.dislike a {background: <?php echo $awpt['r_avarage_dislike_btn_bg']; ?>;}
.item_rate:hover.dislike a .fa {color: <?php echo $awpt['r_avarage_dislike_btn_color']; ?> !important;}
.item_rate {border-left: 1px solid <?php echo $awpt['dislike_btn_border_left_color']; ?>;}
.content-title-holder,.nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover,.nav-tabs>li>a:hover {background: <?php echo $awpt['single_content_title_background']; ?>;color: <?php echo $awpt['single_content_title_color']; ?> !important;}
#inplayerADS, .inPly {max-width:<?php echo $inplayerADsize; ?>px;min-width: 300px;}
a.close_play, a.close_play_embed {width:<?php echo $closeBTN; ?>%;}
a.close_play {width: <?php echo $playbtn; ?>;}
#suggestions .duration,#suggestions .photo-count,#suggestions .video-count {bottom: 48px !important;}
#head .navbar-default {background-color:<?php echo $awpt['head_bg']; ?>;position:absolute;}
.mobile_header {background-color:<?php echo $awpt['head_bg']; ?>;}
input[type="submit"] {color:<?php echo $awpt['buttons-typography']['color']; ?> !important;}
.Thumbnail_List li,.WidgetThumbs li, .breadcrumbs, .buddypress-wrap .grid.bp-list>li .list-wrap,.buddypress .activity-list .activity-item .activity-content .activity-inner{background: <?php echo $awpt['thumb_bg']; ?>;}
.buddypress-wrap .grid.bp-list>li .list-wrap :hover {color:<?php echo $awpt['thumb_bg_hover']; ?> !important;}
.breadcrumbs span a, .breadcrumbs span,.buddypress-wrap .grid.bp-list>li .list-wrap,.buddypress .activity-list .activity-item .activity-content .activity-inner{color:<?php echo $awpt['thumb_color']; ?> !important;}
.Category_List a.tax-title:hover {color:<?php echo $awpt['thumb_color_hover']; ?>;}
.Thumbnail_List li:hover,.WidgetThumbs li:hover,#blog li:hover,.Category_List a.tax-title:hover {color:<?php echo $awpt['thumb_color_hover']; ?>; box-shadow:1px 1px 0 rgba(0,0,0,0.2) inset,-1px -1px 0 rgba(0,0,0,0.2) inset;background:<?php echo $awpt['thumb_bg_hover']; ?>;}
.Thumbnail_List li a.title,.WidgetThumbs li a.title, #blog li a, #blog li h3,.thumi h1, .thumi h2, .thumi h3,.thumi h4, .thumi h5, .thumi h6,.thumbphoto h1, .thumbphoto h2, .thumbphoto h3,.thumbphoto h4, .thumbphoto h5, .thumbphoto h6,.post-category a{color:<?php echo $awpt['thumb_color']; ?>;}
.Thumbnail_List li:hover a.title,.WidgetThumbs li:hover a.title, #blog li a:hover, #blog li:hover h3,.thumi:hover h1, .thumi:hover h2, .thumi:hover h3,.thumi:hover h4, .thumi:hover h5, .thumi:hover h6,.thumbphoto:hover h1, .thumbphoto:hover h2, .thumbphoto:hover h3,.thumbphoto:hover h4, .thumbphoto:hover h5, .thumbphoto:hover h6,.post-category a:hover, th{color:<?php echo $awpt['thumb_color_hover']; ?>;}
.WidgetThumbs li a.title, .WidgetThumbs li a{border-bottom: none !important;}
.sidebar {background: <?php echo $sidebar_bg; ?> !important;}
.sidebar .widget ul li::after {background: <?php echo $awpt['slide_line']; ?>;}
.WidgetThumbs li::after {background: none !important;}
.sidebar .widget ul li.cat-item:hover .count{color: <?php echo $awpt['r_avarage_progress']; ?>;}
ul.Menu_List li a, .sidebar li a{border-bottom:1px solid <?php echo $awpt['side_menu_border_bottom']; ?> !important;}
.select_search .wrs,.searchbox input[type="text"],.drop_search, textarea#whats-new {color: <?php echo $awpt['search-form-color']; ?> !important;}
.VideoInformation {border-top:3px solid <?php echo $awpt['side_menu_border_bottom']; ?> !important;}
.video-sponsor {border: 1px solid <?php echo $awpt['side_menu_border_bottom']; ?>;}
@media (max-width: 1200px) {#head .navbar-default{background-color: <?php echo $awpt['head_bg']; ?> !important;}}
.searchbox,.drop_search span,.drop_search span:hover, textarea#whats-new { border:1px solid <?php echo $awpt['search-form-border']; ?> !important;background-color:<?php echo $awpt['search-form-bg']; ?> !important;}
.searchbox button.btn, #aw-whats-new-submit{border-left:1px solid <?php echo $awpt['search-form-border']; ?> !important;}
.saic-wrapper .saic-wrap-form .saic-container-form .saic-captcha .saic-captcha-text {color: <?php echo $awpt['content-font-typography']['color']; ?>}
.saic-textarea {color: #000;}
.activity-list .activity-item .activity-content .activity-inner{color: <?php echo $awpt['bp_itembody_bg']; ?> !important;}
</style>
<?php }
add_action('wp_head', 'bestia_color_outputs');
}
