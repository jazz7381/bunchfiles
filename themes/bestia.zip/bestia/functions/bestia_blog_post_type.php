<?php if( !defined('ABSPATH') ) exit;
if( !class_exists('bestia_blog_post_type') ){
	class bestia_blog_post_type {
		function __construct() {
			add_action('init', array($this,'register_my_cpt_blog'));
		}
		function register_my_cpt_blog() {
			global $awpt;
			$rewrite_slug = trim( $awpt['blog_rewrite_slug'] ) ? trim( $awpt['blog_rewrite_slug'] ) : 'blogs';
			$args = array(
				'label' => __('Blog','bestia'),
				'description' => '',
				'public' => true,
				'menu_position' => 4,
				'has_archive'	=>true,
				'show_ui' => true,
				'show_in_menu' => true,
				'capability_type' => 'post',
				'map_meta_cap' => true,
				'hierarchical' => false,
				'menu_icon'	=>	'dashicons-edit',
				'rewrite' => array('slug' => $rewrite_slug, 'with_front' => true),
				'query_var' => true,
				'supports' => array('title','editor','publicize','comments','thumbnail','author','post-formats', 'buddypress-activity'),
				'labels' => array (
					  'name' => 'Blogs',
					  'singular_name' => __('Blog','bestia'),
					  'menu_name' => __('Blogs','bestia'),
					  'add_new' => __('Add New Post','bestia'),
					  'add_new_item' => __('Add New Blog Post','bestia'),
					  'edit' => __('Edit','bestia'),
					  'edit_item' => __('Edit Post','bestia'),
					  'new_item' => __('New Blog Post','bestia'),
					  'view' => __('View Post','bestia'),
					  'view_item' => __('View Post','bestia'),
					  'search_items' => __('Search Blogs','bestia'),
					  'not_found' => __('No Blogs Found','bestia'),
					  'not_found_in_trash' => __('No Blogs Found in Trash','bestia'),
					  'parent' => __('Parent Blog','bestia'),
					)
			);
			$args	=	apply_filters( 'bestia_blog_post_type_args' , $args);
			if( $awpt['blogs_cpt'] == 1 ){
				register_post_type('blogs', $args);
			}
		}
	}
	new bestia_blog_post_type();
}
