<?php if( !defined('ABSPATH') ) exit;
function getBestiaHeadingtags($tagName, $titleValue){
return "<".$tagName.">".$titleValue."</".$tagName.">";
}
//$tag = getTag("h1", "hello");
// $tag = <h1>hello</h1>
/* Thumbnail Heading Tags . ------------------------------------*/
if( !function_exists('bestia_heading_title_thumbnail') ){
function bestia_heading_title_thumbnail() {
global $awpt;
$h_tag_thumb = isset($awpt['thumbnail_title_heading']) ? $awpt['thumbnail_title_heading'] : '';
print getBestiaHeadingtags($h_tag_thumb,get_the_title());
}
add_action('bestia_heading_title_thumbnail', 'bestia_heading_title_thumbnail');
}
