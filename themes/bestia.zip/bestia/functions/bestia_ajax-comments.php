<?php if( !defined('ABSPATH') ) exit;
function bestia_ajax_comment_form_mod( $settings ){
if( !is_admin() && is_single() ) {
printf( '<div id="submitting-comment" style="padding: 15px 20px; text-align: center; display: none;">%s</div>', __( 'Submitting comment...', 'bestia' ) );
  }
}
add_action( 'comment_form', 'bestia_ajax_comment_form_mod' );
function bestia_ajax_comment_script(){
if( !is_admin() && is_single() ) {
if( apply_filters( 'bestia_ajax_comment_is_used', is_singular() ) ){
wp_enqueue_script( 'simple-ajax-comment-script', get_template_directory_uri(). '/assets/js/ajax-comment.js#asyncload' , array( 'jquery', 'jquery-form' ), '1.0.0', true );
wp_localize_script( 'simple-ajax-comment-script', 'bestia_ajax_comment_params', apply_filters( 'bestia_ajax_comment_params', array(
'error_messages' => array(
'409' => __( 'Duplicate comment detected; it looks as though you have already said that!', 'bestia' ),
'429' => __( 'You are posting comments too quickly. Slow down.', 'bestia' )
   )
  )
 )
);
    }
  }
}
add_action( 'wp_enqueue_scripts', 'bestia_ajax_comment_script' );
