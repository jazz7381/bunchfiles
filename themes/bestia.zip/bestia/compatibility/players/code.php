<?php remove_filter ('the_content', 'wpautop'); ?>
<textarea style="width:98.5%;" id="embed_video" onclick="this.focus();this.select()" readonly="readonly">
<?php 
echo '<script type="text/javascript" src="' . get_template_directory_uri() .'/inc/tools/jwplayer/jwplayer.js" ></script>'; 
echo '<script>loadCSS("' . get_template_directory_uri() .'/css/embed_code.css");</script>';
get_template_part( 'inc/compatibility/default/player', get_post_format() ); ?>
</textarea>

