<?php
get_template_part( 'compatibility/players/tpl/is-desktop', get_post_format() ); 
?>
