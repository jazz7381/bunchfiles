<?php global $awpt; $affiliate_link = $awpt['mtn_adslink']; ?>
<a target="_blank" href="<?php echo $affiliate_link; ?> ">
<div class="fake-player">
<?php $thumb = tube_getcustomfield('wtp_thumb_url',get_the_ID()); if(!empty($thumb)) { ?>
<img src"<?php echo $thumb; ?>" src="<?php echo $thumb; ?>" alt="<?php the_title_attribute(); ?>" />
<?php } elseif ( has_post_thumbnail() ) {
the_post_thumbnail('thumb-video', array( 'title' => get_the_title(), 'alt' => get_the_title()));
} else { ?>
<img src="<?php bloginfo('template_directory'); ?>/css/images/noimage.png" alt="<?php bloginfo('name'); ?>">
<?php } ?>
<span style="position:absolute;top:0;left:0;right:0;width:100%;" class="player-transparent"><img src="<?php bloginfo('template_url'); ?>/images/player.png" alt="<?php the_title_attribute(); ?>"></span>
</div>
</a>