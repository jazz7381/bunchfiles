<li class="widget-thumb">
<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
<?php get_template_part( 'inc/tools/thumb/video/no-lazy', get_post_format() ); ?>
</a>  
<a href="<?php the_permalink(); ?>" id="it" class="title" rel="bookmark"><?php if (strlen($post->post_title) > 40) {
echo mb_substr(the_title($before = '', $after = '', FALSE), 0, 45) . '...'; } else {
the_title();
} ?>
<?php global $awpt; $custom_field_duration = $awpt['duration']; $duration = get_post_meta($post->ID, $custom_field_duration, true); if(!empty($duration)) { echo '<span class="duration"><i class="fa fa-clock-o"></i> '.$duration . '</span>';} ?>
</a>
<?php
$key = 'hd_flag';
$themeta = get_post_meta($post->ID, $key, TRUE);
if($themeta != '') {
echo '<span class="hd-flag"></span>';
}
?>
</li>