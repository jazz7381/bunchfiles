<?php
if( !defined('ABSPATH') ) exit;
global $awpt;
//$option = isset($awpt['video_description']) ? $awpt['video_description'] : ''; //using isset to provide an empty value
$redux_description = get_post_meta($post->ID, 'video_description', true);// description custoim field renamed in rtedux framework (theme panel)
$acf_description = get_post_meta($post->ID, 'video_description', true);//value from advanced custom fields
$old_description = get_post_meta($post->ID, 'awpt_desc', true);//Old video description meta
if (!empty($old_description)) {
  $video_description = $old_description;
} elseif (!empty($acf_description)) {
  $video_description = $acf_description;
} elseif (!empty($redux_description)) {
  $video_description = $redux_description;
} else {
  $video_description = '';
}

//$read_more = $awpt['read_more'];
//$collapse = $awpt['collapse'];
if( '' !== get_post()->post_content  && ( $awpt['post_description_type'] == 1 ) ) { ?>
<div class="the_description">
<div class="small">
<?php echo the_content(); ?>
</div>
</div>
<?php } elseif (!empty($acf_description) || !empty($redux_description) || !empty($old_description) ) { ?>
<div class="the_description">
<div class="small">
<?php echo $video_description; ?>
</div>
</div>
<?php do_action('bestia_addtoany'); ?>
<?php } else { ?>
<?php do_action('bestia_addtoany'); ?>
<?php } ?>
