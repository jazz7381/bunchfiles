<div id="Video_Player">
<?php include (TEMPLATEPATH . '/inc/tools/ONplayer300x250.php'); ?>
<span class="embed-video"><?php the_content(); ?></span>
</div>