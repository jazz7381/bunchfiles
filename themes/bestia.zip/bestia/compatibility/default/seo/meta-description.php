<?php 
global $awpt; 
$default = $awpt['mtn_fixed_desc'];
$default = str_replace("{post_title}", $post->post_title, $default);
$default = str_replace("{post_tags}", get_the_term_list( $post->ID, 'post_tag', '', ',', '' ), $default);
$default = str_replace("{post_categories}", get_the_term_list( $post->ID, 'category', '', ',', '' ), $default);
$desc = get_post_meta($post->ID, 'awpt_desc', true);
$default = strip_tags( $default ); 
$description =  strip_tags($desc);
if ( !empty($desc )) {
echo '<meta name="description" content="'.$description.'" />';
} elseif(!empty($default)) {
echo '<meta name="description" content="'.$default.'" />';	
} ?>