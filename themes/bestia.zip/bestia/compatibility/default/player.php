<?php
do_action('bestia_sponsor_link');
do_action('bestia_player_ad_overlay');;
echo '<div class="video_player">
<div class="embed-responsive embed-responsive-16by9">';
do_action('bestia_player');
echo '</div>
</div>';
do_action( 'mytubepress_media_pagination', get_the_ID() );
do_action('bestia_bottom_video_ads');
?>
