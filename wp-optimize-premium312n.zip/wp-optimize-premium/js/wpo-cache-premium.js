jQuery(function($) {
	var send_command = wp_optimize.send_command;

	/**
	 * Handle delete from cache on the Advanced settings tab.
	 */
	$('.wpo-exclude-from-cache').click(function () {
		var btn = $(this),
			post_id = btn.data('id');

		send_command('change_post_disable_caching', {
			post_id: post_id,
			disable: 0
		}, function (response) {
			if (response.result) {
				var row = btn.closest('tr');
				row.fadeOut('fast', function () {
					if (!(row.prev().is('tr') || row.next().is('tr'))) {
						row.closest('table').remove();
					}
					row.remove();
				});
			}
		});
	});

});