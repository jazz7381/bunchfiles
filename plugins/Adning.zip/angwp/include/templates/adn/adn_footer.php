

	<?php if(function_exists('wp_footer')) { wp_footer(); } ?>

</body>
</html>