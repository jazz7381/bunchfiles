/*
 * Dummy file just to upset AD Blockers.
 * If adblockers are activated they will most likely hide this file.
 * If this file is hidden we know an AD Blocker is active.
*/
window.adning_no_adblock = true;