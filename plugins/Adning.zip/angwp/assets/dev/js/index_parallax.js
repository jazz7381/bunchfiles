import '../../packages/jarallax/dist/jarallax.css';

import '../../packages/jarallax/dist/jarallax.min.js';
import '../../packages/jarallax/dist/jarallax-element.min.js';
import '../../packages/jarallax/dist/jarallax-video.min.js';