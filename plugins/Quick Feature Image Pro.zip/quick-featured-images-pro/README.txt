=== Quick Featured Images Pro ===
Contributors: Hinjiriyo
Tags: add, arabic, assign, associate, attach, attachment, attachments, audio, audios, author, automatic, batch, brazilian, bulk, categories, category, change, column, control, custom post type, custom post types, custom taxonomies, custom taxonomy, date, dates, default, define, delete, detach, exchange, featured, featured image, featured images, filter, francais, french, gallery, galleries, german, greek, image, image size, images, japanese, mass, media, mime, multimedia, nextgen, pages, parent page, period, portuguese, post type, post types, posts, quick, random, rapid, remove, replace, rules, search, set, spanish, standard, tag, taxonomies, taxonomy, thumb, thumbnail, thumbnails, thumbs, time, unset, update, user, video, videos
Requires at least: 3.8
Requires PHP: 5.2
Tested up to: 5.5
Stable tag: 9.3.0
Commercial Software Licence
License URI: https://www.quickfeaturedimages.com/terms-licence-withdrawal/

Your time-saving Swiss army knife for managing tons of featured images within minutes: Set, replace and delete them in bulk, in posts lists and set default images for future posts.

== Description ==

Your time-saving Swiss army knife for managing tons of featured images within minutes: Set, replace and delete them in bulk, in posts lists and set default images for future posts.

The plugin is available in English and German (Deutsch), for the most part in Spanish (Español), Brazilian Portuguese (Português do Brasil), French (Francais), Arabic (العربية), Japanese (日本語) and Greek (Ελληνικά). It does not collect any personal data, so it is ready for EU General Data Protection Regulation (GDPR) compliance.

= Manage featured images quickly =

The plugin 'Quick Featured Images Pro' helps you bulk managing featured images, setting automatic default featured images to save your time. 

1. It **sets, replaces and removes featured images for hundreds of posts, pages, audios, videos and custom post types in one go**. You can run it over all contens or let it work only to desired contents by using flexible filters. You can define presets for recurring tasks.
2. It **sets, replaces and removes featured images in a sortable image column** in lists of posts, pages and custom post types if they support thumbnails. So you can change the images per post quickly without leaving the posts list page.
3. It enables you to **define presets for automatic default featured images** for future posts as many as you need. You can set **accurate rules based on post properties**.
4. It **removes database entries of featured images without existing image files** with a simple single click

See comments under [Reviews](https://www.quickfeaturedimages.com/reviews/).

= Access =

1. You will find the plugin under the own **menu item 'Featured Images'** 
2. You can select an image in the media library with the **action link 'Bulk set as featured image'**. Click on it and you can go on with the plugin.
3. You can set in 'Settings' which **minimum user role is allowed to see the plugin** in his/her adminstration area. You can switch between 'Administrator' and 'Editor'. The default value is 'Editor'.

= Bulk Edit: Actions =

With Quick Featured Images Pro you can apply time-saving tasks with many featured images: add, exchange and delete them in bulk.

1. **Adding featured images:** You can select an image, or scan for the first post image, or for the first image of WordPress standard galleries, or of NextGen galleries, to set it as the new featured image to hundreds of posts in one go. You can select multiple images to set them randomly as featured images.
2. **Exchanging featured images:** You can replace or update several existing featured images with a selected image in one go.
3. **Deleting featured images:** You can remove a selected featured image or all existing featured images in one go.
4. **Removing database entries of featured images without existing image files:** You can remove them and clean your database with a simple single click.

= Bulk Edit: Options =

Based on your selected action you can toggle on and off some options:

1. **overwrite existing featured images** or **keeping them unchanged**. The latter setting is the default.
2. **consider only posts without a featured image**. This will hide posts with featured images in the results list and will speed up the process.
3. **remove first image in the content** after it was set as featured image.

If you want to catch the first image of a post you can switch between:

1. **the first post image** if available in the media library
2. **the first post image from the current site domain**, copy and add it to the media library if not available there
3. **the first external post image**, download it and add it to the media library
4. **the first attached image of a post**
5. **the first image of a WordPress standard gallery**
6. **the first embedded content thumbnail** (like YouTube etc.)
7. **the first image of a NextGen Gallery**.

If you selected multiple images to set them as featured images in random order you can add these options:

1. **Use each selected image only once**. If there are more posts than selected images the remaining posts will not be changed.
2. **Remove excess featured images** after all selected images are used.

= Bulk Edit: Filters =

If there would be no filters Quick Featured Images Pro would affect all posts and pages without exception! In most cases this is not desired. 

The implemented filters allow you to narrow down the action to only the posts and pages you want to modify. The built-in filters are:

1. Filter by **post type**: Search by post types. By **default all** posts, pages and custom post types will be affected
2. Filter by **post format**: Search by post formats. By **default standard** posts format will be affected
3. Filter by **multimedia type**: Search for audio and video files
4. Filter by **status**: Search by several statuses (published, draft, private etc.). By **default all** statuses will be affected
5. Filter by **search**: Search by search term: Search in post title and post content or in post title only
6. Filter by **time**: Search by time specifications
7. Filter by **author**: Search by author
8. Filter by **custom taxonomy**: Search by terms of registered taxonomies of a plugin or a theme
9. Filter by **featured image size**: Search for small featured images below a given size
10. Filter by **category**: Search posts by category
11. Filter by **tag**: Search posts by tag
12. Filter by **parent page**: Search child pages by parent page

= Bulk Edit: Presets =

If you have to manage featured images recurrently presets are the time-saver for you. You can store all settings of a process to recall them easily the next time.

= Automatic Default Featured Images: Rules =

**You can set rules for default featured images of posts easily.** Every time you insert a new post or save an existing post Quick Featured Images Pro will look for a rule to add and to change the preset featured image to the saved post. 

For every rule you can set an single default image or multiple images for random assign per post.

You can define the rules based on

1. **first image**
2. **search string in post title**
3. **custom taxonomy** supporting featured images
4. **post tag**
5. **post category**
6. **post author**
7. **post format**
8. **post types**: 'Post', 'Page' and **custom post types** supporting featured images

The rules are easy to set: choose an image (or several random images), a taxonomy, a value and save the settings. That's it. **You do not need to code.**

You can add, change and delete every rule whenever you want. So you get an **precise set of rules** for automatic default featured images in your website.

The rules take effect when a post is saved in the backend &ndash; e.g. on the post edit page &ndash; or in the frontend &ndash; e.g. via a "Create Post" form by Gravity Forms.

= Automatic Default Featured Images: Options =

You can activate

1. **overwriting existing featured images**
2. **removing the first content image automatically** after the featured image was set successfully
3. **running automatically all rules daily** to make sure the rules are applied after creation and changes of posts 

= Easy managing in a sortable image column in posts lists =

Quick Featured Images Pro adds a new column called 'Featured image' in posts lists. The additional column is sortable by the image ID. It shows the currently assigned **featured image of each post** and **action links to set, replace, edit and remove the featured image at each post**.

With that column you can get a **quick overview about all used images** and a **change featured images at every single post quickly**. You can also see posts with no featured image at a glance.

Under **'Featured Images' &gt; 'Settings'** you can switch on and off the additional image column for every single post type, even custom post types if they support thumbnails.

= Languages =

For the most part the user interface is available in

* Arabic (العربية), kindly drawn up by [Shadi AlZard](https://wordpress.org/support/profile/salzard)
* Brazilian Portuguese (Português do Brasil)
* English
* French (Francais), kindly drawn up by Ivan M. Frakov
* German (Deutsch)
* Greek (Ελληνικά), kindly drawn up by Kostas Arvanitidis
* Japanese (日本語), kindly drawn up by [Kazuyuki Kumai](https://wordpress.org/support/users/kazuyk/)
* Spanish (Español), kindly drawn up by Andrew Kurtis from [www.webhostinghub.com](http://www.webhostinghub.com/)

Further translations are welcome. If you want to give in your translation please leave a notice in the [plugin's support forum](https://wordpress.org/support/plugin/quick-featured-images).

= Your idea to improve the plugin is welcome =

If you have any new idea for Quick Featured Images Pro post your questions and ideas in the [support forum at wordpress.org](https://www.quickfeaturedimages.com/forums/). I will try to take a look and answer as soon as possible.

= Support =

Support for this plugin will be provided in the form of Product Support. This means that I intend to fix any confirmed bugs, listen to ideas for this plugin and improve the user experience when enhancements are identified and can reasonably be accomodated.

There is no User Support provided for this plugin. If you are having trouble with this plugin in your particular installation of WordPress, I will not be able to help you troubleshoot the problem.

== Installation ==

= Uploading in WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Navigate to the 'Upload' area
3. Select `quick-featured-images-pro.zip` from your computer
4. Click 'Install Now'
5. Activate the plugin in the Plugin dashboard
6. Go to 'Featured Images'

= Using FTP =

1. Download `quick-featured-images-pro.zip`
2. Extract the `quick-featured-images-pro` directory to your computer
3. Upload the `quick-featured-images-pro` directory to the `/wp-content/plugins/` directory
4. Activate the plugin in the Plugin dashboard
5. Go to 'Featured Images'

== Changelog ==

= 9.3.0 =
* Fixed missed binding to dynamically created selection options in 'Default Images'
* Fixed missed higher upgrade of the version number
* Published on 2020-08-16

= 9.2.3 =
* Revised translations for WP 5.5
* Revised an error message in 'Bulk Edit'
* Alt text for external images is no longer required in 'Bulk Edit'
* Fixed deprecated jQuery function live() in 'Default Images'
* Tested successfully with WP 5.5
* Published on 2020-08-13

= 9.2.2 =
* Removed a redudant notice on the License page for the expired license status
* Published on 2020-07-07

= 9.2.1 =
* Fixed in 'Default images' an undefined variable which causes warnings
* Tested successfully with WordPress 5.4.2
* Published on 2020-06-20

= 9.2.0 =
* Added new column in the media library to list at each image for which posts it is set as featured image
* Added a description for the category filter in 'Bulk Edit'
* Added a description for the rules order in 'Default Images'
* Fixed outdated translations due to WordPress 5.4
* Tested successfully with WordPress 5.4
* Published on 2020-04-22

= 9.1.0 =
* Added support of Dokan vendors as users in 'Default Images'
* Refactored user query for 'Default Images'
* Published on 2019-11-29

= 9.0.2 =
* Fixed wrong versioning
* Published on 2019-11-21

= 9.0.1 =
* Fixed some broken translations in 'Default Images'
* Updated translations
* Tested successfully with WordPress 5.3
* Published on 2019-11-14

= 9.0.0 =
* Added support of plugin 'Featured Image From URL' in 'Bulk Edit', 'Default Images' and image column
* Added support of plugin 'Featured Image By URL' in 'Bulk Edit', 'Default Images' and image column
* Improved performance for the image column on post overview pages
* Updated translations
* Tested successfully with WordPress 5.2.4
* Published on 2019-11-06

= 8.5.0 =
* Added support for WooCommerce products in 'Default Images'
* Tested successfully with WordPress 5.2.2
* Published on 2019-08-29

= 8.4.11 =
* Fixed function for image URL sanitizing
* Tested successfully with WordPress 5.2
* Published on 2019-05-16

= 8.4.10 =
* Added checkered background for transparent thumbnails
* Tested successfully with WordPress 5.1
* Published on 2019-03-18

= 8.4.9 =
* Fixed missing feature to include images from external servers in 'Default Images'
* Tested successfully with WordPress 5.0.2
* Published on 2019-01-04

= 8.4.8 =
* Fixed missing parameter in a function call in Default Images
* Published on 2018-10-17

= 8.4.7 =
* Added missing shortcode name 'ngg' for NextGen galleries
* Fixed missing conversions for NextGen Gallery 3
* Published on 2018-10-17

= 8.4.6 =
* Fixed a minor bug in Bulk Edit which caused no results for YouTube videos
* Improved regex in Bulk Edit for YouTube video IDs
* Improved storing data of downloaded images in Bulk Edit and Default Images
* Published on 2018-10-15

= 8.4.5 =
* Revised search operation for internal images in Bulk Edit
* Revised search operation for internal images in Default Images
* Hardened add_image function if download function is not available
* Published on 2018-10-13

= 8.4.4 =
* Fixed search operation for internal images with relative paths
* Published on 2018-10-05

= 8.4.3 =
* Fixed improper URL building with relative image paths
* Published on 2018-09-27

= 8.4.2 =
* Added support for the old notation of NextGen singlepic
* Tested successfully with WordPress 4.9.8
* Published on 2018-08-04

= 8.4.1 =
* Fixed a fatal error in 'Bulk Edit'
* Fixed a typo in the german translation
* Published on 2018-07-26

= 8.4 =
* Added support of external images on Facebook to download them properly
* Added Export/Import functions on page 'Default Images'
* Some refactoring of sanitations on image URLs
* Updated translations
* Published on 2018-07-23

= 8.3.8 =
* Added recognition of 'poster' attribute of 'video' shortcodes
* Tested successfully with WordPress 4.9.7
* Published on 2018-07-06

= 8.3.7 =
* Fixed a warning raised by the search filter
* Made calling the function to set the image in 'Default Images' more secure against errors
* Small refactoring for URL parsing
* Small refactoring for URL comparision
* Tested successfully with WordPress 4.9.6
* Published on 2018-07-04

= 8.3.6 =
* Updated translations due to WordPress 4.9.5
* Tested successfully with WordPress 4.9.5
* Published on 2018-04-11

= 8.3.5 =
* Fixed return of wrong variable which raised PHP warnings
* Tested successfully with WordPress 4.9.4
* Published on 2018-02-27

= 8.3.4 =
* Revised recognition of relative image paths in 'Default Images'
* Fixed wrong variable assignment in 'Default Images' which caused PHP warnings
* Published on 2018-01-23

= 8.3.3 =
* Fixed missing recognition of protocol relative URLs
* Revised recognition pattern for IFRAME embeds of YouTube (added YT nocookie domain)
* Improved performance by detecting the site URL only once
* Tested successfully with WordPress 4.9.2
* Published on 2018-01-18

= 8.3.2 =
* Added support for IFRAME embeds of YouTube, Vimeo and Instagram
* Added greek translation. Thank you, Kostas Arvanitidis!
* Fixed: broken YouTube maximum size thumbnail if not available, takes YouTube default size thumbnail instead
* Updated translations due to WordPress 4.9
* Tested successfully with WordPress 4.9.1
* Published on 2017-12-02

= 8.3.1 =
* Improved: Contents embedded via URLs are also recognized if their URLs are put in "embed" shortcuts
* Changed label 'Set, replace, remove' to WP string 'Bulk Edit' to be translated in much more languages
* Changed label 'Preset Featured Images' to WP string 'Default Images' to be translated in much more languages
* Changed previous mentioned labels in readme file
* Tested successfully with WordPress 4.8.3
* Published on 2017-11-02

= 8.3 =
* Added japanese translation. Thank you, Kazuyuki Kumai!
* Added 'Requires PHP' info in readme.txt
* Fixed in 'Set, replace, remove': empty string as array key name if preset name contains multibyte signs
* Fixed in 'Set, replace, remove': locale name as variable in error message section
* Fixed in 'Set, replace, remove': typo in page description
* Removed redudand explanations
* Tested successfully with WordPress 4.8.2
* Published on 2017-10-15

= 8.2.1 =
* Improved in 'Preset Default Images': Grid layout in case of multiple images for better overview
* Improved in all modules: Image paths starting with '/' will be considered
* Tested successfully with WordPress 4.8.1
* Published on 2017-08-14

= 8.2 =
* Added in 'Preset Default Images': Post type filters for first image option
* Revised translations
* Published on 2017-07-30

= 8.1 =
* Added french translation. Thank you, Ivan M. Frakov!
* Revised sanitations for texts and URLs on the pages
* Revised translations
* Set activation message as dismissible
* Published on 2017-07-17

= 8.0 =
* Added in 'Set, replace, remove': Presets
* Updated translations
* Published on 2017-07-12

= 7.0 =
* Added in 'Set, replace, remove': action for removing database entries of featured images without existing image files
* Added in image column: check for existence of image file and, if not available, Delete link
* Revised: added sanitations to (nearly) all displayed texts
* Updated translations
* Published on 2017-07-07

= 6.3 =
* Added options for external thumbnails of external services embedded with an URL
* Added background color for transparent thumbnails or vector graphics on admin pages
* Revised translations
* Changed in 'Set, replace, remove': Tiny rearrangement of explanations
* Published on 2017-06-21

= 6.2.3 =
* Fixed missing sanitations of ID in "Columns" class to close possible cross-site-scripting security hole
* Published on 2017-06-12

= 6.2.2 =
* Fixed outdated (pre WP 4.8) texts for WP 4.8
* Added link on the license page to customer account at the online shop
* Tested successfully with WordPress 4.8
* Published on 2017-06-09

= 6.2.1 =
* Fixed minor errors for SVG support
* Tested successfully with WordPress 4.7.5
* Published on 2017-05-20

= 6.2 =
* Added day options to Time Filter
* Fixed layout in Time Filter
* Revised translations
* Published on 2017-03-31

= 6.1.2 =
* Added loading of Javascript media API on Preset Default Images page
* Published on 2017-03-20

= 6.1.1 =
* Fixed missing loading of Javascript media API on post edit pages
* Fixed a typo, revised translations
* Published on 2017-03-19

= 6.1 =
* Changed in 'Set, replace, remove': Media library dialog box instead of image list to select the replacement image
* Added in "Preset Featured Images": Recognize first image of WordPress standard gallery
* Published on 2017-03-12

= 6.0.2 =
* Fixed in 'Set, replace, remove': Missing change of featured images
* Tested successfully with WordPress 4.7.3
* Published on 2017-03-09

= 6.0.1 =
* Removed in 'Preset Default Images': Check for existence of plugin 'Video Thumbnail'
* Published on 2017-03-09

= 6.0 =
* Improved in all modules: Faster check for found attachment against being an image
* Improved in 'Set, replace, remove': Show feedback about removed images only when the removal option was checked
* Improved in 'Activate License': More stable and verbose license check
* Improved in 'Activate License': Updated EDD Plugin Updater class
* Changed in 'Activate License': link to shop to secure protocol
* Tested successfully with WordPress 4.7.2
* Published on 2017-02-23

= 5.4.2 =
* Added in 'Preset Default Images': Do not set the featured image if plugin 'Video Thumbnail' is active
* Fixed in 'Preset Default Images': Remove first content image only if setting the featured image is successful
* Published on 2017-01-04

= 5.4.1 =
* Fixed deprecated jquery live()
* Published on 2016-11-08

= 5.4 =
* Added in 'Set, replace, remove': server configuration to avoid PHP timeout and memory limitation in most cases
* Adjusted texts for WP 4.7
* Tested successfully with WordPress 4.7
* Published on 2016-11-07

= 5.3 =
* Added in 'Set, replace, remove': Options to attach and detach image to post
* Updated translations
* Published on 2016-10-31

= 5.2 =
* Added in 'Set, replace, remove': Support for hierarchical custom post type in the parent page filter
* Updated translations, especially German and Spanish
* Published on 2016-10-17

= 5.1.3 =
* Improved in 'Preset Default Images': Avoiding featured image of last post repeated in new post
* Published on 2016-10-13

= 5.1.2 =
* Fixed 'Set, replace, remove': unwanted removing of the more-tag in post contents
* Fixed typo in german translation
* Published on 2016-10-07

= 5.1.1 =
* Fixed undefined variable in 'Preset Default Images'
* Published on 2016-08-24

= 5.1 =
* Fixed fatal error at plugin activation
* Fixed missing default settings
* Tested successfully with WordPress 4.6.1
* Published on 2016-08-17

= 5.0 =
* Changed menu item name 'Image Columns' to 'Settings'
* Added in Settings: option to set a minimum user role to be allowed to see the plugin
* Added in 'Preset Default Images': option for displaying random featured images at each page load
* Added in image column: action links to add, change and remove featured images at each post
* Improved in 'Preset Default Images': Random image selection
* Revised uninstall function for WordPress 4.6 due to the introduction of WP_Site_Query class
* Revised style of thumbnails in image column, 'Preset Default Images' and bulk edit pages
* Updated *.pot file and german translation
* Tested successfully with WordPress 4.6
* Published on 2016-08-16

= 4.0 =
* Added in 'Preset Default Images': import function for rules from the free plugin Quick Featured Images if available
* Added in 'Preset Default Images': option for removing the first content image automatically after the featured image was set successfully
* Improved: media dialogs show only images instead of all files
* Improved in 'Preset Default Images': only authors instead of all users are listed
* Fixed in 'Preset Default Images': empty user data
* Fixed in 'Preset Default Images': remove forgotten image from an image set if the image is deleted in the library
* Updated portuguese and german translations
* Published on 2016-07-21

= 3.9.4 =
* Added brazilian portuguese translation
* Tested with WP 4.5.3
* Published on 2016-07-13

= 3.9.3 =
* Fixed: outdated translations for post statusses
* Tested successfully with WordPress 4.5.2
* Published on 2016-05-09

= 3.9.2 =
* Fixed: broken recognition of first post image if IMG tag was written in multiple lines
* Revised plugin activation message function
* Tested successfully with WordPress 4.5
* Published on 2016-04-24

= 3.9.1 =
* Added in 'Set, replace, remove': Option to include the parent page in the parent page filter
* Updated *.pot file and translations
* Published on 2016-03-14

= 3.9 =
* Improved: 'Preset Default Images' are working in the frontend, too, e.g. at creating a post with 3rd-party applications
* Improved: Headline hierarchy on options page for better accessibility since WP 4.4
* Fixed: Not closing HTML table row on license activation page
* Tested successfully with WordPress 4.4.2
* Published on 2016-03-10

= 3.8.1 =
* Fixed in 'Preset Default Images': Broken single image rule.
* Tested successfully with WordPress 4.4.2
* Published on 2016-02-04

= 3.8 =
* Added in 'Preset Default Images': Selection of multiple images to set one of them randomly as default featured image
* Improved usability: Advice for selection of multiple images in the media dialog box
* Improved usability in 'Set, replace, remove': On the start page show selected images after closing the media dialog box
* Fixed in 'Preset Default Images': Missing author match case
* Refactored page 'Preset Default Images'
* Tested successfully with WordPress 4.4
* Updated *.pot file and translations
* Published on 2015-12-10

= 3.7.1 =
* Fixed in 'Preset Default Images': Double output of 'no featured image' in rules order list
* Fixed in 'Preset Default Images': Missing default values of rules order
* Published on 2015-11-28

= 3.7 =
* Added in 'Preset Default Images': User defined order of applying the types of rules
* Added in 'Preset Default Images': Option 'First content image' also takes image of an external server
* Added in 'Preset Default Images': After an image is removed from the library all preset rules assigned with that image will be removed automatically
* Fixed in 'Set, replace, remove': Missing parameter 'search in title only' in last step
* Fixed in 'Preset Default Images': Wrong background color for third table row
* Fixed in 'Preset Default Images': Missing translations for changed texts
* Fixed in 'Preset Default Images' and  'Set, replace, remove': Remove passwort part of temporary downloaded file name
* Refactoring in 'Preset Default Images'
* Updated *.pot file and translations
* Published on 2015-11-27

= 3.6 =
* Added arabic translation. Thank you, [Shadi AlZard](https://wordpress.org/support/profile/salzard)!
* Added in 'Set, replace, remove': Post Formats Filter
* Added in 'Set, replace, remove': Option to force removal of first content image even the featured image was not changed
* Added in 'Set, replace, remove': Back button on result page. So you can start a further run faster
* Added in 'Preset Default Images': Option to use the first attached image as featured image automatically
* Fixed table row colors due to changes in WP 4.3
* Fixed bug in NextGen option
* Fixed typo in german translation
* Redesigned in 'Preset Default Images': Moved checkboxes to middle column
* Changed text domain from variable to string
* Updated *.pot file and translations
* Published on 2015-10-02

= 3.5 =
* Added in 'Set, replace, remove': Search filter option for searching only in post titles, not in post contents
* Added search field in default images rules: You can set a default featured image for posts with a specific search term in their title
* Revised styles for image column in small displays, since WP 4.3
* Revised styles for page descriptions
* Revised sentence in footer
* Updated *.pot file and translations
* Tested successfully with WordPress 4.3
* Published on 2015-08-22

= 3.4 =
* Added spanish translation; thanks to Andrew Kurtis of www.webhostinghub.com
* Published on 2015-08-02

= 3.3 =
* Added in image column: Link to the edit page of the displayed image
* Fixed in license activation: undefined variable
* Published on 2015-07-16

= 3.2 =
* Fixed broken activation feature
* Fixed in 'Set, replace, remove': thumbnail IDs of not existing images will be ignored
* Fixed in 'Set, replace, remove': stopping at the more-tag. The plugin ignores the more-tag now and finds content placed after that
* Added option in 'Set, replace, remove': Take the first post image from current site domain
* Removed IFRAME from footer section
* Updated german translation
* Published on 2015-06-28

= 3.1.1 =
* Removed debug code in activation class
* Published on 2015-06-06

= 3.1 =
* Fixed in 'Set, replace, remove': Missing class methods for Set, replace, remove
* Fixed in 'Set, replace, remove': Bug which yielded the error message "No matches found" at the Confirmation step
* Fixed in 'Set, replace, remove': Wrong links in the Confirmation list if cache was used
* Fixed in 'Set, replace, remove': Broken bulk assign link at each image in the media library
* Published on 2015-06-04

= 3.0 =
* Added option in 'Set, replace, remove' for selection of multiple images: Use each selected only once
* Added option in 'Set, replace, remove' for selection of multiple images: Remove excess featured images after all selected images are used
* Tested successfully with WordPress 4.2.2
* Updated german translation
* Published on 2015-05-10

= 2.0 =
* Introduced licensing via activation key
* Added option in 'Set, replace, remove': Take first image of NextGen galleries
* Added option in 'Set, replace, remove': Take first external image
* Added option in 'Set, replace, remove': Remove first image in content
* Improved performance of confirmation step by using cached results of preview step
* Updated german translation
* Published on 2015-05-04

= 1.1.0 =
* Added option in 'Set, replace, remove': Take first attached image
* Published on 2015-04-08

= 1.0.0 =
* Initial Pro version
* Published on 2015-03-15

== Upgrade Notice ==

= 9.3.0 =
Fixed missed binding to dynamically created selection options in 'Default Images'

= 9.2.3 =
Revisions and fixes for WordPress 5.5, tested successfully with WP 5.5

= 9.2.2 =
Removed a redudant notice on the License page for the expired license status

= 9.2.1 =
Fixed in 'Default images' an undefined variable, tested with WordPress 5.4.2

= 9.2.0 =
Added column in the library and some descrptive texts, tested with WordPress 5.4

= 9.1.0 =
Added support of Dokan vendors as users in 'Default Images'

= 9.0.2 =
Fixed wrong versioning

= 9.0.1 =
Updated translations, tested successfully with WordPress 5.3

= 9.0.0 =
Added support external featured images, improved image column, tested with WordPress 5.2.4

= 8.5.0 =
Added support for WooCommerce products, tested successfully with WordPress 5.2.2

= 8.4.11 =
Fixed function for image URL sanitizing, tested with WordPress 5.2

= 8.4.10 =
Added checkered background for transparent thumbnails, tested with WordPress 5.1

= 8.4.9 =
Fixed missing parameter in a function call in Default Images, tested with WordPress 5.0.2

= 8.4.8 =
Fixed missing parameter in a function call in Default Images

= 8.4.7 =
Fixed missing shortcode name and conversions for NextGen Gallery 3

= 8.4.6 =
Minor fix and improvements for YouTube videos and downloaded images

= 8.4.5 =
Revised search operation for internal images in Bulk Edit and Default Images

= 8.4.4 =
Fixed search operation for internal images with relative paths in Bulk Edit

= 8.4.3 =
Fixed URL building with relative image paths

= 8.4.2 =
Added support for the old notation of NextGen singlepic, tested with WordPress 4.9.8

= 8.4.1 =
Fixed a fatal error in 'Bulk Edit', fixed a typo in the german translation

= 8.4 =
Added support of Facebook images, added Export/Import functions on page 'Default Images'

= 8.3.8 =
Added recognition of 'poster' attribute of 'video' shortcodes, tested with WordPress 4.9.7

= 8.3.7 =
Small improvemnts for more robustness, tested successfully with WordPress 4.9.6

= 8.3.6 =
Updated translations due to WordPress 4.9.5, tested with WordPress 4.9.5

= 8.3.5 =
Fixed return of wrong variable which raised PHP warnings, tested with WordPress 4.9.4

= 8.3.4 =
Revision and fix in 'Default Images'

= 8.3.3 =
Revised recognition patterns and improved performance, tested with WordPress 4.9.2

= 8.3.2 =
* Added support for IFRAME embeds of YouTube, Vimeo and Instagram, greek translation, tested with WordPress 4.9.1

= 8.3.1 =
Considering embed shortcuts, changed labels

v= 8.3 =
Added japanese translation and Requires PHP info in readme.txt

= 8.2.1 =
Grid layout in 'Preset Default Images', recognition of '/' at paths starts, tested with WP 4.8.1

= 8.2 =
Added post type filters for first image option in 'Preset Default Images'

= 8.1 =
Added french translation, revised sanitations and translations, tested with WordPress 4.8

= 8.0 =
Added presets in 'Set, replace, remove'

= 7.0 =
Added actions for removing database entries of featured images without existing image files

= 6.3 =
Added support for external thumbnails of external services embedded with an URL

= 6.2.3 =
Fixed missing sanitations of ID in "Columns" class to close possible cross-site-scripting security hole

= 6.2.2 =
Fixed outdated (pre WP 4.8) texts for WP 4.8, tested with WP 4.8

= 6.2.1 =
Fixed minor errors for SVG support, tested with WP 4.7.5

= 6.2 =
Added day options to Time Filter

= 6.1.2 =
Added wp_enqueue_media() in 'Preset Default Images'

= 6.1.1 =
Fixed missing wp_enqueue_media(), fixed typo

= 6.1 =
Selecting replacement images via Media library dialog box, first image of galleries as default image

= 6.0.2 =
Fixed in 'Set, replace, remove': Missing change of featured images

= 6.0.1 =
Removed in 'Preset Default Images': Check for existence of plugin 'Video Thumbnail'

= 6.0 =
Improvements in license activation, bulk edit and image check

= 5.4.2 =
Fixes in 'Preset Default Images'

= 5.4.1 =
Fixed deprecated jquery live()

= 5.4 =
Added in 'Set, replace, remove': server configuration to avoid PHP timeout and memory limitation

= 5.3 =
Added in 'Set, replace, remove': Options to attach and detach image to post

= 5.2 =
Added in 'Set, replace, remove': Support for hierarchical custom post type in the parent page filter

= 5.1.3 =
Improved in 'Preset Default Images': Avoiding featured image of last post repeated in new post

= 5.1.2 =
Fixed unwanted removing of the more-tag in post contents

= 5.1.1 =
Fixed undefined variable in 'Preset Default Images'

= 5.1 =
Fixed fatal error at plugin activation, fixed missing default settings

= 5.0 =
New features: user role option, random images per page load, action links in image columns, tested with WP 4.6

= 4.0 =
Added in 'Preset Default Images': import function and option for removing the first content image automatically, some improvemnts and fixes

= 3.9.4 =
Added brazilian portuguese translation, tested with WP 4.5.3

= 3.9.3 =
Fixed: outdated translations for post statusses, tested with WP 4.5.2

= 3.9.2 =
Fixed broken recognition of first post image, revised plugin activation message function, tested with WP 4.5

= 3.9.1 =
Added in 'Set, replace, remove': Option to include the parent page in the parent page filter

= 3.9 =
'Preset Default Images' are working in the frontend, too; improved headline hierarchy on options page

= 3.8.1 =
Fixed broken single image rule

= 3.8 =
Added in 'Preset Default Images': Selection of multiple images to assign one of them randomly per post

= 3.7.1 =
In 'Preset Default Images': Fixed two warnings

= 3.7 =
In 'Preset Default Images': Considers first image from an external server and automated removal of rules after an image is removed in the library, some fixes

= 3.6 =
Added Post Formats Filter, added forced removal of first content images, added first attached image as default featured image, fixed table row colors, fixed bug in NextGen option, fixed typo in german translation

= 3.5 =
Added search field in default images rules, revised styles for image column since WP 4.3, tested in WP 4.3

= 3.4 =
Added spanish translation; thanks to Andrew Kurtis of www.webhostinghub.com

= 3.3 =
Added image edit link, fixed undefined variable

= 3.2 =
Fixed broken activation feature, added option 'first post image from current site domain'

= 3.1.1 =
Removed debug code in activation class

= 3.1 =
Fixed bugs

= 3.0 =
New options for multiple image selection

= 2.0 =
Introduced licensing via activation key, added functions for first images, improved performance of confirmation step

= 1.1.0 =
New options: Consider first attached image

= 1.0.0 =
Initial release
