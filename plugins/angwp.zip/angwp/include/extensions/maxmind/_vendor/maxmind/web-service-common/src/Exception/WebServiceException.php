<?php

namespace MaxMind\Exception;

/**
 * This class represents a generic web service error.
 */
class WebServiceException extends \Exception
{
}
